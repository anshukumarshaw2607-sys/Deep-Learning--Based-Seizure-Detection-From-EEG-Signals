"""
EEG Seizure Detection Backend Application
"""

