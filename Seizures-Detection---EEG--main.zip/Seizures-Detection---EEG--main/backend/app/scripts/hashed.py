"""
Script to generate bcrypt hash for passwords.
Supports passwords of any length using SHA-256 pre-hashing.

Run from backend directory: python app/scripts/hashed.py
"""
import sys
from pathlib import Path

# Add backend directory to Python path
backend_dir = Path(__file__).parent.parent.parent
sys.path.insert(0, str(backend_dir))

from app.core.security import get_password_hash

password = "Hello@123"
hashed = get_password_hash(password)
print(f"Password: {password}")
print(f"Hash: {hashed}")