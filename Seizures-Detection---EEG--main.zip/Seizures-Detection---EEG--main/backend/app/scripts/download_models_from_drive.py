"""
Script to download model files from Google Drive to Render persistent disk

This script downloads model files from Google Drive shareable links
and saves them to /mnt/data/models/

Usage:
    python -m app.scripts.download_models_from_drive
    OR
    python backend/app/scripts/download_models_from_drive.py

Environment Variables Required:
    GOOGLE_DRIVE_RESNET_MODEL_ID - Google Drive file ID or shareable link for resnet-18_pretrained.pth
    GOOGLE_DRIVE_MODEL_WEIGHTS_ID - Google Drive file ID or shareable link for model.pckl
    GOOGLE_DRIVE_MODEL_TUSZ_ID - Google Drive file ID or shareable link for model_tusz.pckl (optional)

You can set either:
    - Just the file ID: "1a2b3c4d5e6f7g8h9i0j"
    - Full shareable link: "https://drive.google.com/file/d/1a2b3c4d5e6f7g8h9i0j/view?usp=sharing"
    
Or set individual file URLs:
    GOOGLE_DRIVE_RESNET_MODEL_URL - Direct download URL
    GOOGLE_DRIVE_MODEL_WEIGHTS_URL - Direct download URL
    GOOGLE_DRIVE_MODEL_TUSZ_URL - Direct download URL (optional)
"""
import os
import sys
import subprocess
import re
from pathlib import Path
from typing import List, Tuple, Optional
import urllib.parse


def get_destination_dir() -> Path:
    """Get the destination directory (/mnt/data/models)"""
    return Path("/mnt/data/models")


def convert_google_drive_link(file_id: str) -> str:
    """
    Convert Google Drive file ID to direct download URL
    
    For large files, Google Drive shows a virus scan warning.
    We add confirm=t to bypass this warning page.
    
    Args:
        file_id: Google Drive file ID (from shareable link)
        
    Returns:
        Direct download URL with confirmation parameter
    """
    return f"https://drive.google.com/uc?export=download&id={file_id}&confirm=t"


def download_file(url: str, destination: Path, filename: str) -> Tuple[bool, str]:
    """
    Download a file from URL to destination
    
    Handles Google Drive's virus scan warning for large files by:
    1. First trying with confirm=t parameter
    2. If HTML is returned, extracting confirmation token and retrying
    
    Args:
        url: URL to download from
        destination: Destination directory
        filename: Name of the file to save
        
    Returns:
        Tuple of (success, message)
    """
    dest_file = destination / filename
    
    # Ensure URL has confirm=t for Google Drive (handles large files)
    if "drive.google.com" in url and "confirm=" not in url:
        if "&" in url:
            url = f"{url}&confirm=t"
        else:
            url = f"{url}&confirm=t"
    
    try:
        # Check if curl is available
        curl_check = subprocess.run(
            ["which", "curl"],
            capture_output=True,
            text=True
        )
        
        if curl_check.returncode == 0:
            # Use curl
            print(f"📥 Downloading {filename} using curl...")
            
            # First attempt
            result = subprocess.run(
                [
                    "curl",
                    "-L",  # Follow redirects
                    "-C", "-",  # Resume if partial
                    "-o", str(dest_file),
                    url
                ],
                capture_output=True,
                text=True,
                timeout=600  # 10 minute timeout for large files
            )
            
            if result.returncode == 0 and dest_file.exists():
                # Check if we got HTML instead of the actual file
                file_size = dest_file.stat().st_size
                
                # If file is suspiciously small (< 10KB), check if it's HTML
                if file_size < 10240:  # 10KB threshold
                    try:
                        with open(dest_file, 'rb') as f:
                            first_bytes = f.read(100)
                            if b'<!DOCTYPE html' in first_bytes or b'<html' in first_bytes:
                                # We got HTML, need to extract confirmation token
                                print(f"⚠️  Received HTML page (virus scan warning), extracting confirmation token...")
                                
                                # Read the HTML to extract confirmation token
                                with open(dest_file, 'r', encoding='utf-8', errors='ignore') as f:
                                    html_content = f.read()
                                
                                # Extract confirmation token using regex
                                confirm_match = re.search(r'name="confirm"\s+value="([^"]+)"', html_content)
                                uuid_match = re.search(r'name="uuid"\s+value="([^"]+)"', html_content)
                                
                                if confirm_match and uuid_match:
                                    confirm_token = confirm_match.group(1)
                                    uuid = uuid_match.group(1)
                                    
                                    # Extract file ID from URL or HTML
                                    file_id_match = re.search(r'name="id"\s+value="([^"]+)"', html_content)
                                    if file_id_match:
                                        file_id = file_id_match.group(1)
                                        # Build direct download URL with confirmation
                                        direct_url = f"https://drive.usercontent.google.com/download?id={file_id}&export=download&confirm={confirm_token}&uuid={uuid}"
                                        
                                        # Retry download with confirmation
                                        print(f"🔄 Retrying download with confirmation token...")
                                        result = subprocess.run(
                                            [
                                                "curl",
                                                "-L",
                                                "-C", "-",
                                                "-o", str(dest_file),
                                                direct_url
                                            ],
                                            capture_output=True,
                                            text=True,
                                            timeout=600
                                        )
                                        
                                        if result.returncode == 0 and dest_file.exists():
                                            new_size = dest_file.stat().st_size
                                            # Check again if it's still HTML
                                            with open(dest_file, 'rb') as f:
                                                check_bytes = f.read(100)
                                                if b'<!DOCTYPE html' not in check_bytes and b'<html' not in check_bytes:
                                                    return True, f"Downloaded {filename} ({new_size:,} bytes)"
                                    else:
                                        return False, f"Failed to extract file ID from Google Drive warning page"
                                else:
                                    return False, f"Failed to extract confirmation token from Google Drive warning page"
                    except Exception as e:
                        # If we can't read the file, assume it's valid
                        pass
                
                # File seems valid
                return True, f"Downloaded {filename} ({file_size:,} bytes)"
            else:
                error_msg = result.stderr or "Unknown error"
                return False, f"Failed to download {filename}: {error_msg}"
        else:
            # Try wget
            wget_check = subprocess.run(
                ["which", "wget"],
                capture_output=True,
                text=True
            )
            
            if wget_check.returncode == 0:
                print(f"📥 Downloading {filename} using wget...")
                result = subprocess.run(
                    [
                        "wget",
                        "--continue",  # Resume if partial
                        "-O", str(dest_file),
                        url
                    ],
                    capture_output=True,
                    text=True,
                    timeout=600
                )
                
                if result.returncode == 0 and dest_file.exists():
                    file_size = dest_file.stat().st_size
                    # Check if we got HTML (same check as curl)
                    if file_size < 10240:
                        try:
                            with open(dest_file, 'rb') as f:
                                first_bytes = f.read(100)
                                if b'<!DOCTYPE html' in first_bytes or b'<html' in first_bytes:
                                    return False, f"Received HTML page instead of file. Try using curl or check file permissions."
                        except:
                            pass
                    return True, f"Downloaded {filename} ({file_size:,} bytes)"
                else:
                    error_msg = result.stderr or "Unknown error"
                    return False, f"Failed to download {filename}: {error_msg}"
            else:
                # Try Python urllib as fallback
                print(f"📥 Downloading {filename} using Python urllib...")
                try:
                    import urllib.request
                    urllib.request.urlretrieve(url, str(dest_file))
                    if dest_file.exists():
                        file_size = dest_file.stat().st_size
                        return True, f"Downloaded {filename} ({file_size:,} bytes)"
                    else:
                        return False, f"Download failed: file not created"
                except Exception as e:
                    return False, f"Failed to download {filename}: {e}"
                    
    except subprocess.TimeoutExpired:
        return False, f"Download timeout for {filename}"
    except Exception as e:
        return False, f"Error downloading {filename}: {e}"


def extract_file_id_from_link(link: str) -> Optional[str]:
    """
    Extract file ID from various Google Drive link formats
    
    Supports:
    - https://drive.google.com/file/d/FILE_ID/view
    - https://drive.google.com/file/d/FILE_ID/edit
    - https://drive.google.com/open?id=FILE_ID
    - https://drive.google.com/drive/folders/FOLDER_ID (folder, not file)
    
    Args:
        link: Google Drive shareable link
        
    Returns:
        File ID or None if not found
    """
    import re
    
    # Pattern 1: /file/d/FILE_ID/
    pattern1 = r'/file/d/([a-zA-Z0-9_-]+)'
    match = re.search(pattern1, link)
    if match:
        return match.group(1)
    
    # Pattern 2: ?id=FILE_ID
    pattern2 = r'[?&]id=([a-zA-Z0-9_-]+)'
    match = re.search(pattern2, link)
    if match:
        return match.group(1)
    
    return None


def get_file_url_from_env(file_key: str) -> Optional[str]:
    """
    Get file URL from environment variable (either ID, full link, or direct URL)
    
    Args:
        file_key: Base key name (e.g., 'RESNET_MODEL')
        
    Returns:
        Download URL or None
    """
    # Try full URL first (direct download URL)
    url_key = f"GOOGLE_DRIVE_{file_key}_URL"
    url = os.getenv(url_key)
    if url:
        return url
    
    # Try file ID or full shareable link
    id_key = f"GOOGLE_DRIVE_{file_key}_ID"
    file_id_or_link = os.getenv(id_key)
    if file_id_or_link:
        # Check if it's a full link or just an ID
        if file_id_or_link.startswith("http"):
            # It's a full link, extract the file ID
            extracted_id = extract_file_id_from_link(file_id_or_link)
            if extracted_id:
                return convert_google_drive_link(extracted_id)
            else:
                # If we can't extract, try using the link as-is (might be a direct URL)
                return file_id_or_link
        else:
            # It's just an ID
            return convert_google_drive_link(file_id_or_link)
    
    return None


def main():
    """Main function to download models from Google Drive"""
    print("=" * 70)
    print("🚀 Download Models from Google Drive")
    print("   Downloading to /mnt/data/models")
    print("=" * 70)
    
    # Get destination directory
    dest_dir = get_destination_dir()
    
    # Create destination directory
    try:
        dest_dir.mkdir(parents=True, exist_ok=True)
        print(f"✅ Created/verified destination directory: {dest_dir}\n")
    except Exception as e:
        print(f"❌ Failed to create destination directory: {e}")
        sys.exit(1)
    
    # Define model files to download
    models = [
        {
            "name": "resnet-18_pretrained.pth",
            "env_key": "RESNET_MODEL",
            "required": True
        },
        {
            "name": "model.pckl",
            "env_key": "MODEL_WEIGHTS",
            "required": True
        },
        {
            "name": "model_tusz.pckl",
            "env_key": "MODEL_TUSZ",
            "required": False
        }
    ]
    
    downloaded = []
    skipped = []
    errors = []
    
    print("📋 Checking for model files to download...\n")
    
    for model in models:
        filename = model["name"]
        env_key = model["env_key"]
        required = model["required"]
        
        dest_file = dest_dir / filename
        
        # Check if file already exists
        if dest_file.exists():
            file_size = dest_file.stat().st_size
            print(f"⏭️  Skipped (already exists): {filename} ({file_size:,} bytes)")
            skipped.append(filename)
            continue
        
        # Get download URL
        url = get_file_url_from_env(env_key)
        
        if not url:
            if required:
                error_msg = f"Missing environment variable for {filename}"
                print(f"❌ {error_msg}")
                print(f"   Set GOOGLE_DRIVE_{env_key}_ID (file ID or shareable link)")
                print(f"   Or set GOOGLE_DRIVE_{env_key}_URL (direct download URL)")
                errors.append(error_msg)
            else:
                print(f"⚠️  Skipping optional file: {filename} (no URL configured)")
            continue
        
        # Download the file
        success, message = download_file(url, dest_dir, filename)
        
        if success:
            print(f"✅ {message}")
            downloaded.append(filename)
        else:
            print(f"❌ {message}")
            errors.append(message)
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 Download Summary")
    print("=" * 70)
    print(f"✅ Successfully downloaded: {len(downloaded)} file(s)")
    print(f"⏭️  Skipped (already exists): {len(skipped)} file(s)")
    print(f"❌ Errors: {len(errors)} file(s)")
    
    if downloaded:
        print("\n📋 Downloaded files:")
        for file in downloaded:
            print(f"   - {file}")
    
    if skipped:
        print("\n⏭️  Skipped files:")
        for file in skipped:
            print(f"   - {file}")
    
    if errors:
        print("\n❌ Errors:")
        for error in errors:
            print(f"   - {error}")
    
    # Check for required files
    required_files = [m["name"] for m in models if m["required"]]
    missing_required = []
    for req_file in required_files:
        if not (dest_dir / req_file).exists():
            missing_required.append(req_file)
    
    if missing_required:
        print(f"\n⚠️  Missing required files: {', '.join(missing_required)}")
        print("   Please check your environment variables and try again.")
        sys.exit(1)
    
    if downloaded or skipped:
        print("\n✅ Model download completed!")
        print(f"\n💡 Next steps:")
        print(f"   1. Verify files: ls -lh {dest_dir}")
        print(f"   2. Set MODEL_PATH environment variable: MODEL_PATH={dest_dir}")
        print(f"   3. Restart your Render service if needed")


if __name__ == "__main__":
    main()

