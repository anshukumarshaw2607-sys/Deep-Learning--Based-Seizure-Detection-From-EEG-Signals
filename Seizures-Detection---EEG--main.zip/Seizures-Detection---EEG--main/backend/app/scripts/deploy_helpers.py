"""
Deployment helper scripts for Render deployment
"""
import secrets
import sys
from pathlib import Path


def generate_secret_key():
    """Generate a secure secret key for JWT tokens"""
    key = secrets.token_urlsafe(32)
    print(f"\n🔑 Generated SECRET_KEY:")
    print(f"{key}\n")
    print("Copy this to your Render environment variables as SECRET_KEY")
    return key


def verify_env_vars():
    """Verify required environment variables are set"""
    from app.core.config import settings
    
    print("\n🔍 Checking Environment Configuration...\n")
    
    checks = {
        "ENVIRONMENT": settings.ENVIRONMENT,
        "DATABASE_URL": "✅ Set" if settings.DATABASE_URL else "❌ Missing",
        "SECRET_KEY": "✅ Set" if settings.SECRET_KEY else "❌ Missing",
        "FRONTEND_URL": settings.FRONTEND_URL or "⚠️  Not set (optional)",
        "RENDER": "✅ True" if settings.RENDER else "⚠️  False",
    }
    
    for key, value in checks.items():
        print(f"{key:20} : {value}")
    
    print("\n📁 Directory Configuration:")
    print(f"Upload Directory: {settings.resolved_upload_dir}")
    
    # Check if directories exist
    upload_dir = Path(settings.resolved_upload_dir)
    
    print(f"\n📂 Directory Status:")
    print(f"Uploads: {'✅ Exists' if upload_dir.exists() else '❌ Missing'}")
    
    # Warnings
    warnings = []
    if not settings.DATABASE_URL:
        warnings.append("DATABASE_URL is required")
    if not settings.SECRET_KEY and settings.is_production:
        warnings.append("SECRET_KEY is required in production")
    if not settings.FRONTEND_URL and settings.is_production:
        warnings.append("FRONTEND_URL should be set in production for CORS")
    
    if warnings:
        print("\n⚠️  Warnings:")
        for warning in warnings:
            print(f"  - {warning}")
    else:
        print("\n✅ All checks passed!")
    
    return len(warnings) == 0


def print_deployment_info():
    """Print deployment information"""
    from app.core.config import settings
    
    print("\n📋 Deployment Information\n")
    print(f"Environment: {settings.ENVIRONMENT}")
    print(f"Project: {settings.PROJECT_NAME}")
    print(f"Version: {settings.VERSION}")
    print(f"API Version: {settings.API_V1_STR}")
    print(f"Debug Mode: {settings.DEBUG}")
    print(f"Production: {settings.is_production}")
    print(f"Render: {settings.RENDER}")
    
    if settings.RENDER_EXTERNAL_HOSTNAME:
        print(f"Render Hostname: {settings.RENDER_EXTERNAL_HOSTNAME}")
    
    print(f"\n🌐 CORS Origins: {settings.resolved_cors_origins}")
    print(f"🔒 Allowed Hosts: {settings.resolved_allowed_hosts}")
    
    print(f"\n💾 Database: {'✅ Configured' if settings.DATABASE_URL else '❌ Not configured'}")
    print(f"📁 Upload Dir: {settings.resolved_upload_dir}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python deploy_helpers.py generate-key    # Generate SECRET_KEY")
        print("  python deploy_helpers.py verify          # Verify environment config")
        print("  python deploy_helpers.py info             # Print deployment info")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "generate-key":
        generate_secret_key()
    elif command == "verify":
        verify_env_vars()
    elif command == "info":
        print_deployment_info()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

