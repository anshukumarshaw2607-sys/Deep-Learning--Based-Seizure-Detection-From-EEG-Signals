"""
Report schemas for API requests and responses
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


class SeizureEventSchema(BaseModel):
    """Schema for a single seizure event"""
    start_time: float = Field(..., description="Start time in seconds")
    end_time: float = Field(..., description="End time in seconds")
    duration: float = Field(..., description="Duration in seconds")
    channels: List[str] = Field(default_factory=list, description="Affected channels")
    confidence: float = Field(default=0.0, description="Confidence level 0-100")


class ReportCreateRequest(BaseModel):
    """Request to create a new report"""
    title: str = Field(..., description="Report title")
    report_type: str = Field(..., description="Type of report (Seizure Detection, Spectral Analysis, etc)")
    eeg_file_id: str = Field(..., description="ID of the EEG file analyzed")
    seizure_count: int = Field(default=0)
    total_seizure_duration_seconds: float = Field(default=0.0)
    seizure_percentage: float = Field(default=0.0)
    seizure_events: Optional[List[Dict[str, Any]]] = None
    clinical_notes: Optional[str] = None
    clinical_recommendations: Optional[str] = None
    recording_duration_minutes: Optional[float] = None
    num_channels: Optional[int] = None


class ReportUpdateRequest(BaseModel):
    """Request to update an existing report"""
    title: Optional[str] = None
    description: Optional[str] = None
    clinical_notes: Optional[str] = None
    clinical_recommendations: Optional[str] = None
    status: Optional[str] = None


class ReportResponse(BaseModel):
    """Response with report data"""
    id: str
    title: str
    report_type: str
    description: Optional[str]
    patient_id: Optional[str]
    eeg_file_id: Optional[str]
    created_by_id: str
    recording_date: Optional[datetime]
    recording_duration_minutes: Optional[float]
    num_channels: int
    seizure_count: int
    total_seizure_duration_seconds: float
    seizure_percentage: float
    seizure_events: Optional[List[Dict[str, Any]]]
    clinical_notes: Optional[str]
    clinical_recommendations: Optional[str]
    analysis_timestamp: datetime
    generated_at: datetime
    status: str
    
    class Config:
        from_attributes = True


class ReportListResponse(BaseModel):
    """Response for report list"""
    id: str
    title: str
    report_type: str
    patient_id: Optional[str]
    eeg_file_id: Optional[str]
    generated_at: datetime
    seizure_count: int
    total_seizure_duration_seconds: float
    seizure_percentage: float
    status: str
    
    class Config:
        from_attributes = True


class ReportDetailedResponse(ReportResponse):
    """Detailed report response with all fields"""
    pass
