"""
Patient-related Pydantic schemas
"""
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, EmailStr
from datetime import datetime, date


class PatientBase(BaseModel):
    """Base patient schema"""
    full_name: str
    date_of_birth: Optional[date] = None
    age: Optional[int] = None
    gender: Optional[str] = None  # e.g., "Male", "Female"
    contact_number: Optional[str] = None
    email: Optional[EmailStr] = None
    medical_history: Optional[str] = None
    notes: Optional[str] = None


class PatientCreate(PatientBase):
    """Schema for patient creation"""
    doctor_id: Optional[UUID] = None


class PatientUpdate(BaseModel):
    """Schema for patient update"""
    doctor_id: Optional[UUID] = None
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    contact_number: Optional[str] = None
    email: Optional[EmailStr] = None
    medical_history: Optional[str] = None
    notes: Optional[str] = None
    is_deleted: Optional[bool] = None


class PatientResponse(PatientBase):
    """Schema for patient response"""
    id: UUID
    doctor_id: Optional[UUID] = None
    is_deleted: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    doctor_name: Optional[str] = None  # Doctor's full name
    
    class Config:
        from_attributes = True

