"""
User-related Pydantic schemas
"""
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, EmailStr
from datetime import datetime


class OrganizationBase(BaseModel):
    """Base organization schema"""
    name: str
    contact: Optional[str] = None
    address: Optional[str] = None
    description: Optional[str] = None


class OrganizationCreate(OrganizationBase):
    """Schema for organization creation"""
    pass


class OrganizationUpdate(BaseModel):
    """Schema for organization update"""
    name: Optional[str] = None
    contact: Optional[str] = None
    address: Optional[str] = None
    description: Optional[str] = None


class OrganizationResponse(OrganizationBase):
    """Schema for organization response"""
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UserBase(BaseModel):
    """Base user schema"""
    org_id: Optional[UUID] = None
    email: EmailStr
    username: str
    full_name: Optional[str] = None
    title: Optional[str] = None


class UserCreate(UserBase):
    """Schema for user creation"""
    password: str
    role: Optional[str] = "assistant"


class UserUpdate(BaseModel):
    """Schema for user update"""
    email: Optional[EmailStr] = None
    org_id: Optional[UUID] = None
    username: Optional[str] = None
    password: Optional[str] = None
    full_name: Optional[str] = None
    title: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None


class UserLogin(BaseModel):
    """Schema for user login"""
    username: str
    password: str


class UserResponse(UserBase):
    """Schema for user response"""
    id: UUID
    org_id: Optional[UUID] = None
    role: str
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    organization: Optional[str] = None
    
    class Config:
        from_attributes = True


class Token(BaseModel):
    """Schema for authentication token"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_role: Optional[str] = None
    expires_at: Optional[str] = None  # ISO format datetime
    expires_in_minutes: Optional[int] = None


class TokenData(BaseModel):
    """Schema for token data"""
    user_id: Optional[UUID] = None


class RefreshTokenRequest(BaseModel):
    """Schema for refresh token request"""
    refresh_token: str


# Doctor-Assistant relationship schemas
class DoctorAssistantBase(BaseModel):
    """Base schema for doctor-assistant relationship"""
    doctor_id: UUID
    assistant_id: UUID


class DoctorAssistantCreate(BaseModel):
    """Schema for creating a doctor-assistant relationship"""
    assistant_id: UUID
    doctor_id: UUID  # Required - admin must specify which doctor to assign the assistant to


class DoctorAssistantResponse(DoctorAssistantBase):
    """Schema for doctor-assistant relationship response"""
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class DoctorAssistantWithDetails(DoctorAssistantResponse):
    """Schema for doctor-assistant relationship with user details"""
    doctor: UserResponse
    assistant: UserResponse

