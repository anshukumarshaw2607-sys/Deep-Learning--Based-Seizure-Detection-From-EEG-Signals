"""
Seizure detection-related Pydantic schemas
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class SeizureEvent(BaseModel):
    """Schema for a single seizure event"""
    start: float = Field(..., description="Start time in seconds")
    stop: float = Field(..., description="Stop time in seconds")
    duration: float = Field(..., description="Duration in seconds")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "start": 50.0,
                "stop": 70.0,
                "duration": 20.0
            }
        }


class BackgroundSegment(BaseModel):
    """Schema for a background segment"""
    start: float = Field(..., description="Start time in seconds")
    stop: float = Field(..., description="Stop time in seconds")
    duration: float = Field(..., description="Duration in seconds")
    
    class Config:
        from_attributes = True


class SeizureDetectionResponse(BaseModel):
    """Schema for seizure detection response"""
    input_file: str = Field(..., description="Path to input EDF file")
    output_file: Optional[str] = Field(None, description="Path to output CSV_BI file if saved")
    duration: float = Field(..., description="Total duration of recording in seconds")
    seizure_count: int = Field(..., description="Number of seizures detected")
    total_seizure_time: float = Field(..., description="Total seizure duration in seconds")
    seizure_percentage: float = Field(..., description="Percentage of recording with seizures")
    has_seizures: bool = Field(..., description="Whether any seizures were detected")
    seizures: List[SeizureEvent] = Field(..., description="List of detected seizure events")
    background_segments: List[BackgroundSegment] = Field(default_factory=list, description="List of background segments")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "input_file": "/path/to/recording.edf",
                "output_file": "/path/to/recording.csv_bi",
                "duration": 300.0,
                "seizure_count": 2,
                "total_seizure_time": 45.0,
                "seizure_percentage": 15.0,
                "has_seizures": True,
                "seizures": [
                    {
                        "start": 50.0,
                        "stop": 70.0,
                        "duration": 20.0
                    },
                    {
                        "start": 150.0,
                        "stop": 175.0,
                        "duration": 25.0
                    }
                ],
                "background_segments": []
            }
        }


class SeizureDetectionErrorResponse(BaseModel):
    """Schema for error response"""
    error: str = Field(..., description="Error message")
    detail: Optional[str] = Field(None, description="Additional error details")
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": "Seizure detection failed",
                "detail": "File not found or invalid format"
            }
        }


class AnnotationSegment(BaseModel):
    """Schema for a single annotation segment from CSV_BI file"""
    start_time: float = Field(..., description="Start time in seconds")
    stop_time: float = Field(..., description="Stop time in seconds")
    label: str = Field(..., description="Label (seiz or bckg)")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "start_time": 58.0,
                "stop_time": 317.0,
                "label": "seiz"
            }
        }


class ReportMetadata(BaseModel):
    """Schema for report metadata from CSV_BI header"""
    version: str = Field(..., description="CSV file version")
    bname: str = Field(..., description="Base name of the file")
    duration: float = Field(..., description="Total duration in seconds")
    
    class Config:
        from_attributes = True


class ReportJSONResponse(BaseModel):
    """Schema for JSON report response"""
    metadata: ReportMetadata = Field(..., description="Report metadata")
    segments: List[AnnotationSegment] = Field(..., description="List of annotation segments")
    seizure_segments: List[AnnotationSegment] = Field(default_factory=list, description="Filtered seizure segments only")
    background_segments: List[AnnotationSegment] = Field(default_factory=list, description="Filtered background segments only")
    seizure_count: int = Field(..., description="Number of seizure segments")
    total_seizure_time: float = Field(..., description="Total seizure duration in seconds")
    seizure_percentage: float = Field(..., description="Percentage of recording with seizures")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "metadata": {
                    "version": "csv_v1.0.0",
                    "bname": "recording_001",
                    "duration": 1289.0
                },
                "segments": [
                    {
                        "start_time": 0.0,
                        "stop_time": 58.0,
                        "label": "bckg"
                    },
                    {
                        "start_time": 58.0,
                        "stop_time": 317.0,
                        "label": "seiz"
                    }
                ],
                "seizure_segments": [
                    {
                        "start_time": 58.0,
                        "stop_time": 317.0,
                        "label": "seiz"
                    }
                ],
                "background_segments": [
                    {
                        "start_time": 0.0,
                        "stop_time": 58.0,
                        "label": "bckg"
                    }
                ],
                "seizure_count": 3,
                "total_seizure_time": 423.0,
                "seizure_percentage": 32.8
            }
        }

