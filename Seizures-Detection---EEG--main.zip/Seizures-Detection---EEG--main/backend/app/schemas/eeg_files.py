"""
EEG file-related Pydantic schemas
"""
from typing import Optional, List
from uuid import UUID
from pydantic import BaseModel, Field
from datetime import datetime


class PatientBasicInfo(BaseModel):
    """Basic patient information for EEG file responses"""
    id: UUID
    full_name: str
    age: Optional[int] = None
    gender: Optional[str] = None
    contact_number: Optional[str] = None
    email: Optional[str] = None
    
    class Config:
        from_attributes = True


class EEGFileBase(BaseModel):
    """Base EEG file schema"""
    patient_id: UUID
    description: Optional[str] = None
    notes: Optional[str] = None


class EEGFileCreate(EEGFileBase):
    """Schema for EEG file creation (from upload)"""
    pass  # File data comes from multipart form


class EEGFileUpdate(BaseModel):
    """Schema for EEG file update"""
    description: Optional[str] = None
    notes: Optional[str] = None
    is_deleted: Optional[bool] = None


class EEGFileResponse(EEGFileBase):
    """Schema for EEG file response"""
    id: UUID
    uploaded_by: Optional[UUID] = None
    filename: str
    original_filename: str
    file_path: str
    file_size: int
    file_hash: Optional[str] = None
    recording_duration: Optional[float] = None
    sampling_rate: Optional[float] = None
    number_of_channels: Optional[int] = None
    channel_names: Optional[str] = None
    is_deleted: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    uploader_name: Optional[str] = None  # Uploader's full name
    patient: Optional[PatientBasicInfo] = None  # Patient details
    
    class Config:
        from_attributes = True


class EEGFileUploadResponse(BaseModel):
    """Schema for file upload response"""
    message: str
    data: EEGFileResponse


class EEGFileListResponse(BaseModel):
    """Schema for list of EEG files"""
    files: List[EEGFileResponse]
    total: int
    skip: int
    limit: int

