from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    # TODO: Implement actual authentication
    if username and password:
        access_token = create_access_token(identity=username)
        return jsonify({
            'token': access_token,
            'user': {'name': username, 'role': 'Doctor'}
        }), 200
    
    return jsonify({'error': 'Invalid credentials'}), 401

@bp.route('/register', methods=['POST'])
def register():
    # TODO: Implement registration logic
    return jsonify({'message': 'Registration endpoint'}), 200