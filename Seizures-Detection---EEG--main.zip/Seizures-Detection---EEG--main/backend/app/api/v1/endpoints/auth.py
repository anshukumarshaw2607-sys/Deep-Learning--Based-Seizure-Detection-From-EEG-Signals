"""
Authentication endpoints
"""
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from app.core.security import (
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_access_token,
    decode_refresh_token,
    get_current_user,
    get_user_service,
    get_token_service,
    oauth2_scheme,
)
from app.core.config import settings
from app.models.users import User
from app.schemas.users import UserResponse, Token, RefreshTokenRequest
from app.services.users import UserService
from app.services.tokens import TokenService

router = APIRouter()


@router.post("/login", status_code=status.HTTP_200_OK, response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    user_service: UserService = Depends(get_user_service),
    token_service: TokenService = Depends(get_token_service)
):
    """Login and get access token and refresh token"""
    from datetime import datetime
    
    user = await user_service.get_by_username(form_data.username)
    
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive"
        )
    
    # Create access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id)},
        expires_delta=access_token_expires
    )
    
    # Create refresh token
    refresh_token_expires = timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    refresh_token = create_refresh_token(
        data={"sub": str(user.id)},
        expires_delta=refresh_token_expires
    )
    
    # Calculate expiration datetimes (timezone-naive)
    access_expires_at = datetime.utcnow() + access_token_expires
    refresh_expires_at = datetime.utcnow() + refresh_token_expires
    
    # Store tokens in database
    await token_service.create_token(
        user_id=user.id,
        token=access_token,
        token_type="access",
        expires_at=access_expires_at
    )
    await token_service.create_token(
        user_id=user.id,
        token=refresh_token,
        token_type="refresh",
        expires_at=refresh_expires_at
    )
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user_role": user.role,
        "expires_at": access_expires_at.isoformat(),
        "expires_in_minutes": settings.ACCESS_TOKEN_EXPIRE_MINUTES
    }


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    """Get current authenticated user information"""
    from app.api.v1.endpoints.users import user_to_response
    return UserResponse(**user_to_response(current_user))


@router.post("/logout", status_code=status.HTTP_200_OK)
async def logout(
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme),
    token_service: TokenService = Depends(get_token_service)
):
    """
    Logout the current user.
    Revokes the current access token and all refresh tokens for the user.
    """
    # Revoke the current access token
    await token_service.revoke_token(token)
    
    # Revoke all refresh tokens for this user
    await token_service.revoke_user_tokens(current_user.id, token_type="refresh")
    
    return {
        "message": "Successfully logged out",
        "user_id": str(current_user.id),
        "username": current_user.username
    }


# Token-related endpoints
@router.post("/verify", status_code=status.HTTP_200_OK)
async def verify_token(
    token: str = Depends(oauth2_scheme),
    token_service: TokenService = Depends(get_token_service)
):
    """
    Verify if a token is valid.
    Returns token validity status and expiration information.
    Checks if token is revoked.
    """
    from datetime import datetime
    
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if token is revoked
    if await token_service.is_token_revoked(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Extract expiration time
    exp = payload.get("exp")
    exp_datetime = None
    if exp:
        exp_datetime = datetime.fromtimestamp(exp)
        # Double-check expiration (decode_access_token should catch this, but just in case)
        if datetime.utcnow() >= exp_datetime:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired",
                headers={"WWW-Authenticate": "Bearer"},
            )
    
    return {
        "valid": True,
        "user_id": payload.get("sub"),
        "expires_at": exp_datetime.isoformat() if exp_datetime else None
    }


@router.get("/token-info", status_code=status.HTTP_200_OK)
async def get_token_info(
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """
    Get information about the current token.
    Returns decoded token payload and user information.
    """
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    from datetime import datetime
    exp = payload.get("exp")
    exp_datetime = None
    if exp:
        exp_datetime = datetime.fromtimestamp(exp)
    
    # Get organization info if available
    organization_info = None
    if current_user.organization:
        organization_info = {
            "id": str(current_user.organization.id),
            "name": current_user.organization.name
        }
    
    return {
        "user_id": str(current_user.id),
        "username": current_user.username,
        "email": current_user.email,
        "role": current_user.role,
        "organization": organization_info,
        "token_issued_at": datetime.fromtimestamp(payload.get("iat", 0)).isoformat() if payload.get("iat") else None,
        "token_expires_at": exp_datetime.isoformat() if exp_datetime else None,
        "token_expires_in_minutes": int((exp_datetime - datetime.utcnow()).total_seconds() / 60) if exp_datetime else None
    }


@router.post("/refresh", status_code=status.HTTP_200_OK, response_model=Token)
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    user_service: UserService = Depends(get_user_service),
    token_service: TokenService = Depends(get_token_service)
):
    """
    Refresh access token using a refresh token.
    Returns a new access token and a new refresh token (token rotation for security).
    Revokes the old refresh token and any related access tokens.
    """
    from datetime import datetime
    from uuid import UUID
    
    # Decode and validate refresh token
    payload = decode_refresh_token(refresh_data.refresh_token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if refresh token is revoked
    if await token_service.is_token_revoked(refresh_data.refresh_token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has been revoked",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Get user ID from token
    user_id_str = payload.get("sub")
    if not user_id_str:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Get user from database
    try:
        user_id = UUID(user_id_str)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user ID in token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive"
        )
    
    # Revoke the old refresh token and related access tokens
    await token_service.revoke_refresh_token_and_related(refresh_data.refresh_token)
    
    # Create new access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id)},
        expires_delta=access_token_expires
    )
    
    # Create new refresh token (rotate refresh token for security)
    refresh_token_expires = timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    refresh_token = create_refresh_token(
        data={"sub": str(user.id)},
        expires_delta=refresh_token_expires
    )
    
    # Calculate expiration datetimes (timezone-naive)
    access_expires_at = datetime.utcnow() + access_token_expires
    refresh_expires_at = datetime.utcnow() + refresh_token_expires
    
    # Store new tokens in database
    await token_service.create_token(
        user_id=user.id,
        token=access_token,
        token_type="access",
        expires_at=access_expires_at
    )
    await token_service.create_token(
        user_id=user.id,
        token=refresh_token,
        token_type="refresh",
        expires_at=refresh_expires_at
    )
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user_role": user.role,
        "expires_at": access_expires_at.isoformat(),
        "expires_in_minutes": settings.ACCESS_TOKEN_EXPIRE_MINUTES
    }

