"""
Patient management endpoints
"""
from typing import List, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status, Query
from app.core.security import (
    get_current_user,
    get_patient_service,
    validate_organization_access,
)
from app.models.users import User
from app.models.patients import Patient
from app.schemas.patients import (
    PatientCreate,
    PatientUpdate,
    PatientResponse,
)
from app.services.patients import PatientService
from app.services.users import UserService
from app.core.database import get_db
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()


def patient_to_response(patient: Patient) -> dict:
    """Convert Patient model to PatientResponse dict"""
    return {
        "id": patient.id,
        "doctor_id": patient.doctor_id,
        "full_name": patient.full_name,
        "date_of_birth": patient.date_of_birth,
        "age": patient.age,
        "gender": patient.gender,
        "contact_number": patient.contact_number,
        "email": patient.email,
        "medical_history": patient.medical_history,
        "notes": patient.notes,
        "is_deleted": patient.is_deleted,
        "created_at": patient.created_at,
        "updated_at": patient.updated_at,
        "doctor_name": patient.doctor.full_name if patient.doctor else None,
    }


# Patient management endpoints
@router.post("", status_code=status.HTTP_200_OK)
async def create_patient(
    patient_data: PatientCreate,
    current_user: User = Depends(get_current_user),
    patient_service: PatientService = Depends(get_patient_service),
    db: AsyncSession = Depends(get_db),
):
    """
    Create a new patient
    - Doctors can create patients and assign them to themselves
    - Admins can create patients and assign them to doctors in their organization
    - Root can create patients and assign them to any doctor
    """
    # Determine the doctor_id to use
    doctor_id = patient_data.doctor_id
    
    # If no doctor_id provided, assign to current user if they are a doctor
    if not doctor_id:
        if current_user.role == "doctor":
            doctor_id = current_user.id
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="doctor_id is required when creating a patient"
            )
    
    # Validate doctor access permissions
    if doctor_id:
        user_service = UserService(db)
        doctor = await user_service.get_by_id(doctor_id)
        if not doctor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Doctor not found"
            )
        if doctor.role != "doctor":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User is not a doctor"
            )
        
        # Check permissions to assign patient to this doctor
        if current_user.role == "root":
            # Root can assign to any doctor
            pass
        elif current_user.role == "admin":
            # Admins can only assign to doctors in their organization
            validate_organization_access(
                current_user,
                doctor.org_id,
                "You can only assign patients to doctors in your organization"
            )
        elif current_user.role == "doctor":
            # Doctors can only assign patients to themselves
            if doctor_id != current_user.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Doctors can only create patients for themselves"
                )
        else:
            # Assistants cannot create patients
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to create patients"
            )
    
    try:
        patient = await patient_service.create_patient(patient_data, doctor_id=doctor_id)
        return {
            "message": "Patient created successfully",
            "data": PatientResponse(**patient_to_response(patient))
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("", response_model=List[PatientResponse])
async def get_patients(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    doctor_id: Optional[UUID] = Query(None),
    include_deleted: bool = Query(False),
    current_user: User = Depends(get_current_user),
    patient_service: PatientService = Depends(get_patient_service),
    db: AsyncSession = Depends(get_db),
):
    """
    Get all patients with pagination
    - Doctors can see their own patients
    - Admins can see patients of doctors in their organization
    - Assistants can see patients of their assigned doctor
    - Root can see all patients
    """
    # Determine which patients the user can access
    if current_user.role == "root":
        # Root can see all patients
        patients = await patient_service.get_all(
            skip=skip, limit=limit, doctor_id=doctor_id, include_deleted=include_deleted
        )
    elif current_user.role == "admin":
        # Admins can see patients of doctors in their organization
        if not current_user.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is not associated with an organization"
            )
        
        if doctor_id:
            # Validate the doctor is in the admin's organization
            user_service = UserService(db)
            doctor = await user_service.get_by_id(doctor_id)
            if not doctor:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Doctor not found"
                )
            validate_organization_access(
                current_user,
                doctor.org_id,
                "You can only view patients of doctors in your organization"
            )
        
        # Filter patients by admin's organization
        patients = await patient_service.get_all(
            skip=skip, limit=limit, doctor_id=doctor_id, org_id=current_user.org_id, include_deleted=include_deleted
        )
    elif current_user.role == "doctor":
        # Doctors can only see their own patients
        if doctor_id and doctor_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only view your own patients"
            )
        patients = await patient_service.get_all(
            skip=skip, limit=limit, doctor_id=current_user.id, include_deleted=include_deleted
        )
    elif current_user.role == "assistant":
        # Assistants can see patients of their assigned doctor
        user_service = UserService(db)
        assigned_doctor = await user_service.get_doctor_by_assistant_id(current_user.id)
        
        if not assigned_doctor:
            # Assistant not assigned to any doctor
            return []
        
        # If doctor_id is specified, verify it matches the assistant's assigned doctor
        if doctor_id and doctor_id != assigned_doctor.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only view patients of your assigned doctor"
            )
        
        patients = await patient_service.get_all(
            skip=skip, limit=limit, doctor_id=assigned_doctor.id, include_deleted=include_deleted
        )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to view patients"
        )
    
    return [PatientResponse(**patient_to_response(p)) for p in patients]


@router.get("/{patient_id}", response_model=PatientResponse)
async def get_patient(
    patient_id: UUID,
    current_user: User = Depends(get_current_user),
    patient_service: PatientService = Depends(get_patient_service),
    db: AsyncSession = Depends(get_db),
):
    """
    Get a specific patient by ID
    - Doctors can see their own patients
    - Admins can see patients of doctors in their organization
    - Root can see any patient
    """
    patient = await patient_service.get_by_id(patient_id, include_deleted=False)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Check permissions
    if current_user.role == "root":
        return PatientResponse(**patient_to_response(patient))
    
    if current_user.role == "admin":
        if patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only view patients of doctors in your organization"
                )
        return PatientResponse(**patient_to_response(patient))
    
    if current_user.role == "doctor":
        if patient.doctor_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only view your own patients"
            )
        return PatientResponse(**patient_to_response(patient))
    
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have permission to view this patient"
    )


@router.put("/{patient_id}", status_code=status.HTTP_200_OK)
async def update_patient(
    patient_id: UUID,
    patient_update: PatientUpdate,
    current_user: User = Depends(get_current_user),
    patient_service: PatientService = Depends(get_patient_service),
    db: AsyncSession = Depends(get_db),
):
    """
    Update patient information
    - Doctors can update their own patients
    - Admins can update patients of doctors in their organization
    - Root can update any patient
    """
    patient = await patient_service.get_by_id(patient_id, include_deleted=True)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Check permissions
    can_update = False
    
    if current_user.role == "root":
        can_update = True
    elif current_user.role == "admin":
        if patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only update patients of doctors in your organization"
                )
        can_update = True
    elif current_user.role == "doctor":
        if patient.doctor_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only update your own patients"
            )
        # Doctors cannot reassign patients to other doctors
        if patient_update.doctor_id is not None and patient_update.doctor_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You cannot reassign patients to other doctors"
            )
        can_update = True
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to update patients"
        )
    
    if not can_update:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to update this patient"
        )
    
    # Validate doctor_id if being updated
    if patient_update.doctor_id is not None:
        user_service = UserService(db)
        doctor = await user_service.get_by_id(patient_update.doctor_id)
        if not doctor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Doctor not found"
            )
        if doctor.role != "doctor":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User is not a doctor"
            )
        # Check permissions for reassignment
        if current_user.role == "admin":
            validate_organization_access(
                current_user,
                doctor.org_id,
                "You can only reassign patients to doctors in your organization"
            )
    
    try:
        updated_patient = await patient_service.update_patient(
            patient_id=patient_id,
            doctor_id=patient_update.doctor_id,
            full_name=patient_update.full_name,
            date_of_birth=patient_update.date_of_birth,
            age=patient_update.age,
            gender=patient_update.gender,
            contact_number=patient_update.contact_number,
            email=patient_update.email,
            medical_history=patient_update.medical_history,
            notes=patient_update.notes,
            is_deleted=patient_update.is_deleted,
        )
        if not updated_patient:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found"
            )
        return {
            "message": "Patient updated successfully",
            "data": PatientResponse(**patient_to_response(updated_patient))
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete("/{patient_id}", status_code=status.HTTP_200_OK)
async def delete_patient(
    patient_id: UUID,
    hard_delete: bool = Query(False, description="Permanently delete the patient"),
    current_user: User = Depends(get_current_user),
    patient_service: PatientService = Depends(get_patient_service),
    db: AsyncSession = Depends(get_db),
):
    """
    Delete a patient (soft delete by default, hard delete if specified)
    - Doctors can delete their own patients
    - Admins can delete patients of doctors in their organization
    - Root can delete any patient
    - Only root can perform hard deletes
    """
    patient = await patient_service.get_by_id(patient_id, include_deleted=True)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Check permissions
    can_delete = False
    
    if current_user.role == "root":
        can_delete = True
    elif current_user.role == "admin":
        if patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only delete patients of doctors in your organization"
                )
        can_delete = True
        # Only root can hard delete
        if hard_delete:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can perform hard deletes"
            )
    elif current_user.role == "doctor":
        if patient.doctor_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only delete your own patients"
            )
        can_delete = True
        # Only root can hard delete
        if hard_delete:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can perform hard deletes"
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to delete patients"
        )
    
    if not can_delete:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to delete this patient"
        )
    
    deleted = await patient_service.delete_patient(patient_id, hard_delete=hard_delete)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    return {
        "message": "Patient deleted successfully",
        "patient_id": str(patient_id),
        "deletion_type": "hard" if hard_delete else "soft"
    }

