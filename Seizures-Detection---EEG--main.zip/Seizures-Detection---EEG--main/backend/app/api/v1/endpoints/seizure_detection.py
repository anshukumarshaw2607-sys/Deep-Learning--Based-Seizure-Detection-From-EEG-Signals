"""
Seizure detection endpoints
"""
from typing import Optional
from uuid import UUID
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import FileResponse

from app.core.security import get_current_user
from app.models.users import User
from app.models.eeg_files import EEGFile
from app.services.eeg_files import EEGFileService
from app.services.seizure_detection import SeizureDetectionService
from app.schemas.seizure_detection import (
    SeizureDetectionResponse,
    SeizureDetectionErrorResponse,
    ReportJSONResponse,
    ReportMetadata,
    AnnotationSegment
)
from app.core.database import get_db
from app.core.config import settings
from app.services.reports import ReportService
from app.schemas.reports import ReportCreateRequest
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

router = APIRouter()


def parse_csv_bi_file(file_path: Path) -> dict:
    """
    Parse a CSV_BI annotation file and return structured data
    
    Args:
        file_path: Path to the CSV_BI file
        
    Returns:
        Dictionary with metadata and segments
    """
    metadata = {
        "version": None,
        "bname": None,
        "duration": None
    }
    segments = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Parse header lines (lines starting with #)
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        if line.startswith('# version ='):
            metadata["version"] = line.split('=', 1)[1].strip()
        elif line.startswith('# bname ='):
            metadata["bname"] = line.split('=', 1)[1].strip()
        elif line.startswith('# duration ='):
            duration_str = line.split('=', 1)[1].strip().replace(' secs', '')
            try:
                metadata["duration"] = float(duration_str)
            except ValueError:
                metadata["duration"] = 0.0
        elif line.startswith('channel,start_time,stop_time,label,confidence'):
            # Skip header row
            continue
        elif line and not line.startswith('#'):
            # Parse data row (skip channel field - it's always TERM, skip confidence)
            parts = line.split(',')
            if len(parts) >= 5:
                try:
                    segment = {
                        "start_time": float(parts[1].strip()),
                        "stop_time": float(parts[2].strip()),
                        "label": parts[3].strip()
                    }
                    segments.append(segment)
                except (ValueError, IndexError) as e:
                    logger.warning(f"Failed to parse segment line: {line}. Error: {e}")
                    continue
    
    # Calculate statistics
    seizure_segments = [s for s in segments if s["label"] == "seiz"]
    background_segments = [s for s in segments if s["label"] == "bckg"]
    seizure_count = len(seizure_segments)
    total_seizure_time = sum(s["stop_time"] - s["start_time"] for s in seizure_segments)
    duration = metadata["duration"] or 0.0
    seizure_percentage = (total_seizure_time / duration * 100) if duration > 0 else 0.0
    
    return {
        "metadata": metadata,
        "segments": segments,
        "seizure_segments": seizure_segments,
        "background_segments": background_segments,
        "seizure_count": seizure_count,
        "total_seizure_time": total_seizure_time,
        "seizure_percentage": seizure_percentage
    }


# ============================================================================
# SPECIFIC ROUTES (must come before generic {file_id} routes)
# ============================================================================

@router.get("/reports/list", status_code=status.HTTP_200_OK)
async def list_all_reports(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    List all seizure detection reports from CSV_BI files
    
    - Requires authentication
    - Scans the reports directory for CSV_BI files
    - Parses each file and returns structured report data
    - Includes patient and EEG file information for each report
    - Endpoint: GET /api/v1/detection/reports/list
    
    Returns:
        List of report objects with seizure data, file info, and patient info
    """
    try:
        # Get reports directory
        reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
        
        if not reports_dir.exists():
            logger.info(f"Reports directory does not exist yet: {reports_dir}")
            return {"reports": [], "total_count": 0}
        
        # Find all CSV_BI files
        csv_bi_files = list(reports_dir.glob("*.csv_bi"))
        
        if not csv_bi_files:
            logger.info("No CSV_BI files found in reports directory")
            return {"reports": [], "total_count": 0}
        
        # Parse each CSV_BI file and build report list
        reports_list = []
        eeg_file_service = EEGFileService(db)
        
        # Load all EEG files to build a mapping from filename (without extension) to file object
        all_eeg_files, _ = await eeg_file_service.get_all(skip=0, limit=10000)
        eeg_files_by_filename = {}
        for f in all_eeg_files:
            # Use filename stem (without extension) as key for matching CSV_BI files
            filename_stem = Path(f.filename).stem
            eeg_files_by_filename[filename_stem] = f
        
        logger.debug(f"EEG filename mapping: {list(eeg_files_by_filename.keys())[:5]}")
        
        for csv_file in csv_bi_files:
            try:
                # Parse the CSV_BI file
                parsed_data = parse_csv_bi_file(csv_file)
                
                # The CSV_BI filename is the stored filename (UUID without extension), try to match it
                file_stem = csv_file.stem
                eeg_file = eeg_files_by_filename.get(file_stem)
                
                patient_id = None
                patient_name = None
                eeg_filename = None
                
                if eeg_file:
                    patient_id = eeg_file.patient_id
                    eeg_filename = eeg_file.original_filename
                    logger.debug(f"Matched CSV_BI {file_stem} to EEG file {eeg_filename}")
                    
                    # Get patient info if patient_id exists
                    if patient_id:
                        try:
                            from app.services.patients import PatientService
                            patient_service = PatientService(db)
                            patient = await patient_service.get_by_id(patient_id)
                            if patient:
                                patient_name = patient.full_name
                        except Exception as e:
                            logger.warning(f"Failed to load patient {patient_id}: {e}")
                else:
                    # File not found in database, use the stem as fallback
                    logger.warning(f"CSV_BI file {file_stem} not found in EEG database")
                    eeg_filename = file_stem
                
                # Build report object
                report = {
                    "id": f"report_{csv_file.stem}_{int(csv_file.stat().st_mtime)}",
                    "csv_bi_file": str(csv_file),
                    "filename": eeg_filename or file_stem,
                    "eeg_file_id": str(eeg_file.id) if eeg_file else file_stem,
                    "patient_id": str(patient_id) if patient_id else None,
                    "patient_name": patient_name or "Unknown",
                    "seizure_count": parsed_data["seizure_count"],
                    "total_seizure_duration_seconds": parsed_data["total_seizure_time"],
                    "seizure_percentage": parsed_data["seizure_percentage"],
                    "recording_duration_seconds": parsed_data["metadata"].get("duration", 0),
                    "status": "completed",
                    "generated_at": datetime.fromtimestamp(csv_file.stat().st_mtime).isoformat()
                }
                
                reports_list.append(report)
                logger.info(f"Parsed report from CSV_BI file: {csv_file.name} -> Patient: {patient_name}")
                
            except Exception as e:
                logger.warning(f"Failed to parse CSV_BI file {csv_file.name}: {e}")
                continue
        
        # Sort by generated_at (newest first)
        reports_list.sort(key=lambda x: x["generated_at"], reverse=True)
        
        logger.info(f"Retrieved {len(reports_list)} reports from CSV_BI files")
        return {
            "reports": reports_list,
            "total_count": len(reports_list)
        }
        
    except Exception as e:
        logger.error(f"Error listing reports: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list reports: {str(e)}"
        )


# ============================================================================
# GENERIC ROUTES (must come after specific routes)
# ============================================================================

@router.delete("/{file_id}/report", status_code=status.HTTP_204_NO_CONTENT)
async def delete_report(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Delete a seizure detection report (CSV_BI file)
    
    - Requires authentication
    - Deletes the CSV_BI output file for the given EEG file
    - Same permission rules as other prediction endpoints
    - Endpoint: DELETE /api/v1/detection/{file_id}/report
    """
    # Get EEG file
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same as other endpoints)
    if current_user.role != "root":
        if current_user.role == "admin":
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.services.users import UserService
                from app.core.security import validate_organization_access
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    validate_organization_access(
                        current_user,
                        doctor.org_id,
                        "You can only delete reports for patients of doctors in your organization"
                    )
        elif current_user.role in ["doctor", "assistant"]:
            from app.models.users import DoctorAssistant
            from sqlalchemy import select
            
            if current_user.role == "assistant":
                doc_assistant = await db.execute(
                    select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                )
                assistant_record = doc_assistant.scalar_one_or_none()
                if not assistant_record:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not assigned to any doctor"
                    )
                doctor_id_to_check = assistant_record.doctor_id
            else:
                doctor_id_to_check = current_user.id
            
            if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only delete reports for your assigned doctor's patients"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to delete reports"
            )
    
    # Delete CSV_BI file if it exists
    reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
    file_stem = Path(eeg_file.filename).stem
    output_file = reports_dir / f"{file_stem}.csv_bi"
    
    if output_file.exists():
        try:
            output_file.unlink()
            logger.info(f"Deleted report file: {output_file}")
        except Exception as e:
            logger.error(f"Failed to delete report file {output_file}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete report file: {str(e)}"
            )
    else:
        logger.warning(f"Report file not found: {output_file}")
        # Don't raise error - file might have already been deleted
    
    return None


@router.get("/{file_id}/report/pdf", response_class=FileResponse)
async def export_report_pdf(
    file_id: UUID,
    clinical_notes: Optional[str] = Query(None, description="Optional clinical notes to include in the report"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Export seizure detection report as PDF
    
    - Requires authentication
    - Generates a professional PDF report with:
      * Patient information
      * Analysis details
      * Seizure summary statistics
      * All seizure intervals
    - Same permission rules as other detection endpoints
    - Endpoint: GET /api/v1/detection/{file_id}/report/pdf
    """
    from app.services.pdf_report import PDFReportGenerator
    from app.services.users import UserService
    
    # Get EEG file
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions
    if current_user.role != "root":
        if current_user.role == "admin":
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.core.security import validate_organization_access
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    validate_organization_access(
                        current_user,
                        doctor.org_id,
                        "You can only export reports for patients of doctors in your organization"
                    )
        elif current_user.role in ["doctor", "assistant"]:
            from app.models.users import DoctorAssistant
            from sqlalchemy import select
            
            if current_user.role == "assistant":
                doc_assistant = await db.execute(
                    select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                )
                assistant_record = doc_assistant.scalar_one_or_none()
                if not assistant_record:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not assigned to any doctor"
                    )
                doctor_id_to_check = assistant_record.doctor_id
            else:
                doctor_id_to_check = current_user.id
            
            if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only export reports for your assigned doctor's patients"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to export reports"
            )
    
    # Look for CSV_BI file
    reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
    file_stem = Path(eeg_file.filename).stem
    output_file = reports_dir / f"{file_stem}.csv_bi"
    
    if not output_file.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report file not found. Please run analysis first."
        )
    
    try:
        # Parse CSV_BI file to get seizure data
        parsed_data = parse_csv_bi_file(output_file)
        
        # Get patient and doctor information
        patient_name = "Unknown Patient"
        doctor_name = "Unknown Doctor"
        
        if eeg_file.patient:
            patient_name = eeg_file.patient.full_name
            
            if eeg_file.patient.doctor_id:
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    doctor_name = doctor.full_name
        
        # Get analysis date from file's modification time
        analysis_date = datetime.fromtimestamp(output_file.stat().st_mtime)
        
        # Get seizure intervals from parsed data
        seizure_intervals = parsed_data["seizure_segments"]
        
        # Generate PDF
        pdf_generator = PDFReportGenerator()
        pdf_bytes = pdf_generator.generate_report(
            patient_name=patient_name,
            edf_filename=eeg_file.original_filename,
            analysis_date=analysis_date,
            doctor_name=doctor_name,
            seizure_count=parsed_data["seizure_count"],
            total_seizure_duration=parsed_data["total_seizure_time"],
            total_signal_duration=parsed_data["metadata"].get("duration", 0),
            seizure_intervals=seizure_intervals,
            clinical_notes=clinical_notes
        )
        
        # Create temporary file for response
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(pdf_bytes)
            tmp_path = tmp.name
        
        logger.info(f"PDF report generated for file {file_id}")
        
        return FileResponse(
            path=tmp_path,
            filename=f"seizure_report_{file_stem}_{analysis_date.strftime('%Y%m%d_%H%M%S')}.pdf",
            media_type="application/pdf"
        )
        
    except Exception as e:
        logger.error(f"Error generating PDF report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate PDF report: {str(e)}"
        )


@router.post(
    "/{file_id}",
    status_code=status.HTTP_200_OK,
    response_model=SeizureDetectionResponse,
    responses={
        404: {"model": SeizureDetectionErrorResponse},
        500: {"model": SeizureDetectionErrorResponse}
    }
)
async def predict_seizures(
    file_id: UUID,
    save_output: bool = Query(True, description="Save output CSV_BI file"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Detect seizures in an uploaded EEG file
    
    - Requires authentication
    - Uses the NEDC ResNet model for seizure detection
    - Returns detailed seizure detection results including timestamps and durations
    - Optionally saves output CSV_BI annotation file
    - Endpoint: POST /api/v1/detection/{file_id}
    
    **Permission Rules:**
    - Doctors and assistants can predict for their own patients' files
    - Admins can predict for patients of doctors in their organization
    - Root can predict for any file
    """
    # Get EEG file
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same logic as get_eeg_file endpoint)
    if current_user.role != "root":
        if current_user.role == "admin":
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.services.users import UserService
                from app.core.security import validate_organization_access
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    validate_organization_access(
                        current_user,
                        doctor.org_id,
                        "You can only predict seizures for patients of doctors in your organization"
                    )
        elif current_user.role in ["doctor", "assistant"]:
            from app.models.users import DoctorAssistant
            from sqlalchemy import select
            
            if current_user.role == "assistant":
                doc_assistant = await db.execute(
                    select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                )
                assistant_record = doc_assistant.scalar_one_or_none()
                if not assistant_record:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not assigned to any doctor"
                    )
                doctor_id_to_check = assistant_record.doctor_id
            else:
                doctor_id_to_check = current_user.id
            
            if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only predict seizures for your assigned doctor's patients"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to predict seizures"
            )
    
    # Get file path
    file_path = eeg_file_service.get_file_path(eeg_file)
    
    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found on server"
        )
    
    # Determine output directory if saving
    output_dir = None
    if save_output:
        reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        output_dir = str(reports_dir)
    
    # Run seizure detection
    try:
        detection_service = SeizureDetectionService()
        results = detection_service.detect_seizures_from_file_id(
            file_path=str(file_path),
            output_dir=output_dir
        )
        
        logger.info(
            f"Seizure detection completed for file {file_id}: "
            f"{results['seizure_count']} seizures detected"
        )
        
        # Auto-create a report from the seizure detection results
        try:
            report_data = ReportCreateRequest(
                title=f"Seizure Detection Report - {eeg_file.original_filename}",
                report_type="Seizure Detection",
                eeg_file_id=str(file_id),
                seizure_count=results['seizure_count'],
                total_seizure_duration_seconds=results['total_seizure_duration'],
                seizure_percentage=results['seizure_percentage'],
                seizure_events=results.get('seizures', []),
                recording_duration_minutes=results.get('recording_duration', 0) / 60 if results.get('recording_duration') else None,
                num_channels=results.get('num_channels', 19),
                clinical_notes=f"Automated seizure detection analysis completed on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            report = await ReportService.create_report(db, str(current_user.id), report_data)
            logger.info(f"Report created automatically from seizure detection: {report.id}")
        except Exception as e:
            logger.warning(f"Failed to auto-create report: {e}. Continuing with detection results.")
        
        return SeizureDetectionResponse(**results)
        
    except FileNotFoundError as e:
        logger.error(f"File not found during seizure detection: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"EEG file not found: {str(e)}"
        )
    except RuntimeError as e:
        logger.error(f"Seizure detection error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Seizure detection failed: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Unexpected error during seizure detection: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred: {str(e)}"
        )


@router.get(
    "/{file_id}/download",
    response_class=FileResponse,
    responses={
        404: {"description": "Output file not found"}
    }
)
async def download_prediction_output(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Download the CSV_BI output file from a previous prediction
    
    - Requires authentication
    - Same permission rules as predict endpoint
    - Returns the annotation file if it exists
    - Endpoint: GET /api/v1/detection/{file_id}/download
    """
    # Get EEG file
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same as predict endpoint)
    if current_user.role != "root":
        if current_user.role == "admin":
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.services.users import UserService
                from app.core.security import validate_organization_access
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    validate_organization_access(
                        current_user,
                        doctor.org_id,
                        "You can only download prediction outputs for patients of doctors in your organization"
                    )
        elif current_user.role in ["doctor", "assistant"]:
            from app.models.users import DoctorAssistant
            from sqlalchemy import select
            
            if current_user.role == "assistant":
                doc_assistant = await db.execute(
                    select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                )
                assistant_record = doc_assistant.scalar_one_or_none()
                if not assistant_record:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not assigned to any doctor"
                    )
                doctor_id_to_check = assistant_record.doctor_id
            else:
                doctor_id_to_check = current_user.id
            
            if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only download prediction outputs for your assigned doctor's patients"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to download prediction outputs"
            )
    
    # Look for output file
    reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
    file_stem = Path(eeg_file.filename).stem
    output_file = reports_dir / f"{file_stem}.csv_bi"
    
    if not output_file.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction output file not found. Please run prediction first with save_output=true"
        )
    
    return FileResponse(
        path=str(output_file),
        filename=f"{eeg_file.original_filename.replace('.edf', '')}_prediction.csv_bi",
        media_type="text/csv"
    )


@router.get(
    "/{file_id}",
    status_code=status.HTTP_200_OK,
    response_model=ReportJSONResponse,
    responses={
        404: {"model": SeizureDetectionErrorResponse},
        500: {"model": SeizureDetectionErrorResponse}
    }
)
async def get_prediction_report_json(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get prediction report in JSON format from saved CSV_BI file
    
    - Requires authentication
    - Returns detailed annotation data in JSON format
    - Includes metadata, all segments, and filtered seizure/background segments
    - Same permission rules as other prediction endpoints
    - Endpoint: GET /api/v1/detection/{file_id}
    
    **Permission Rules:**
    - Doctors and assistants can view reports for their own patients' files
    - Admins can view reports for patients of doctors in their organization
    - Root can view any report
    """
    # Get EEG file
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same logic as download endpoint)
    if current_user.role != "root":
        if current_user.role == "admin":
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.services.users import UserService
                from app.core.security import validate_organization_access
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if doctor:
                    validate_organization_access(
                        current_user,
                        doctor.org_id,
                        "You can only view reports for patients of doctors in your organization"
                    )
        elif current_user.role in ["doctor", "assistant"]:
            from app.models.users import DoctorAssistant
            from sqlalchemy import select
            
            if current_user.role == "assistant":
                doc_assistant = await db.execute(
                    select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                )
                assistant_record = doc_assistant.scalar_one_or_none()
                if not assistant_record:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not assigned to any doctor"
                    )
                doctor_id_to_check = assistant_record.doctor_id
            else:
                doctor_id_to_check = current_user.id
            
            if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only view reports for your assigned doctor's patients"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to view reports"
            )
    
    # Look for output file
    reports_dir = Path(settings.resolved_upload_dir).parent / "reports"
    file_stem = Path(eeg_file.filename).stem
    output_file = reports_dir / f"{file_stem}.csv_bi"
    
    if not output_file.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction report file not found. Please run prediction first with save_output=true"
        )
    
    # Parse CSV_BI file
    try:
        parsed_data = parse_csv_bi_file(output_file)
        
        # Convert to response format
        return ReportJSONResponse(
            metadata=ReportMetadata(**parsed_data["metadata"]),
            segments=[AnnotationSegment(**s) for s in parsed_data["segments"]],
            seizure_segments=[AnnotationSegment(**s) for s in parsed_data["seizure_segments"]],
            background_segments=[AnnotationSegment(**s) for s in parsed_data["background_segments"]],
            seizure_count=parsed_data["seizure_count"],
            total_seizure_time=parsed_data["total_seizure_time"],
            seizure_percentage=parsed_data["seizure_percentage"]
        )
        
    except Exception as e:
        logger.error(f"Error parsing CSV_BI file: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to parse report file: {str(e)}"
        )
