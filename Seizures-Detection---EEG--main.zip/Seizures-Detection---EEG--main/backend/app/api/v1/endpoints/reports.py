"""
Report endpoints for managing EEG analysis reports
"""
from typing import List, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
import json
from datetime import datetime
from pathlib import Path

from app.core.security import get_current_user
from app.models.users import User
from app.models.eeg_files import EEGFile
from app.core.database import get_db
from app.services.reports import ReportService
from app.services.eeg_files import EEGFileService
from app.schemas.reports import (
    ReportCreateRequest,
    ReportUpdateRequest,
    ReportResponse,
    ReportListResponse,
    ReportDetailedResponse
)
import logging

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/", response_model=ReportResponse, status_code=status.HTTP_201_CREATED)
async def create_report(
    report_data: ReportCreateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a new report from seizure detection results"""
    try:
        # Verify EEG file exists and user has access
        eeg_file = await EEGFileService.get_eeg_file(db, report_data.eeg_file_id)
        if not eeg_file:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="EEG file not found"
            )
        
        # Create report
        report = await ReportService.create_report(db, str(current_user.id), report_data)
        
        # Update patient_id if eeg_file has a patient
        if eeg_file.patient_id:
            report.patient_id = str(eeg_file.patient_id)
            await db.commit()
        
        return report
    except Exception as e:
        logger.error(f"Error creating report: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create report"
        )


@router.get("/", response_model=List[ReportListResponse])
async def list_reports(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    report_type: Optional[str] = None,
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List reports created by the current user"""
    try:
        reports = await ReportService.list_reports(
            db,
            user_id=str(current_user.id),
            skip=skip,
            limit=limit,
            report_type=report_type,
            status=status
        )
        return reports
    except Exception as e:
        logger.error(f"Error listing reports: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list reports"
        )


@router.get("/{report_id}", response_model=ReportDetailedResponse)
async def get_report(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get a specific report"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization - user can view their own reports or if admin
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view this report"
        )
    
    return report


@router.patch("/{report_id}", response_model=ReportResponse)
async def update_report(
    report_id: str,
    update_data: ReportUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update a report"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this report"
        )
    
    updated_report = await ReportService.update_report(db, report_id, update_data)
    return updated_report


@router.delete("/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_report(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete a report"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to delete this report"
        )
    
    success = await ReportService.delete_report(db, report_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete report"
        )


@router.get("/eeg-file/{eeg_file_id}")
async def get_reports_for_eeg_file(
    eeg_file_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all reports for a specific EEG file"""
    reports = await ReportService.list_reports_by_eeg_file(db, eeg_file_id)
    return reports


@router.post("/{report_id}/export/pdf")
async def export_report_pdf(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Export report as PDF"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to export this report"
        )
    
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib import colors
        from io import BytesIO
        
        # Create PDF in memory
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1E40AF'),
            spaceAfter=30
        )
        elements.append(Paragraph(report.title, title_style))
        elements.append(Spacer(1, 0.2*inch))
        
        # Report Info
        info_data = [
            ['Report Type:', report.report_type],
            ['Generated:', report.generated_at.strftime('%Y-%m-%d %H:%M:%S')],
            ['Status:', report.status],
        ]
        info_table = Table(info_data, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E0E7FF')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
        ]))
        elements.append(info_table)
        elements.append(Spacer(1, 0.3*inch))
        
        # Analysis Summary
        elements.append(Paragraph('Analysis Summary', styles['Heading2']))
        summary_data = [
            ['Seizure Count:', str(report.seizure_count)],
            ['Total Duration:', f"{report.total_seizure_duration_seconds:.1f} seconds"],
            ['Seizure Percentage:', f"{report.seizure_percentage:.1f}%"],
        ]
        if report.recording_duration_minutes:
            summary_data.append(['Recording Duration:', f"{report.recording_duration_minutes:.1f} minutes"])
        
        summary_table = Table(summary_data, colWidths=[2*inch, 4*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#DBEAFE')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 0.3*inch))
        
        # Seizure Events Table
        if report.seizure_events:
            elements.append(Paragraph('Seizure Events', styles['Heading2']))
            seizure_data = [['Start (s)', 'End (s)', 'Duration (s)', 'Channels', 'Confidence']]
            for event in report.seizure_events:
                seizure_data.append([
                    f"{event.get('start_time', 0):.1f}",
                    f"{event.get('end_time', 0):.1f}",
                    f"{event.get('duration', 0):.1f}",
                    ', '.join(event.get('channels', [])),
                    f"{event.get('confidence', 0):.0f}%"
                ])
            
            seizure_table = Table(seizure_data, colWidths=[1.2*inch, 1.2*inch, 1.2*inch, 1.5*inch, 1.2*inch])
            seizure_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#93C5FD')),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
            ]))
            elements.append(seizure_table)
            elements.append(Spacer(1, 0.2*inch))
        
        # Clinical Notes
        if report.clinical_notes:
            elements.append(Paragraph('Clinical Notes', styles['Heading2']))
            elements.append(Paragraph(report.clinical_notes, styles['Normal']))
            elements.append(Spacer(1, 0.2*inch))
        
        # Clinical Recommendations
        if report.clinical_recommendations:
            elements.append(Paragraph('Clinical Recommendations', styles['Heading2']))
            elements.append(Paragraph(report.clinical_recommendations, styles['Normal']))
            elements.append(Spacer(1, 0.2*inch))
        
        # Footer
        elements.append(Spacer(1, 0.3*inch))
        footer_text = "This report was generated automatically by the EEG Seizure Detection System. Results should be interpreted by a qualified healthcare professional."
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=8,
            textColor=colors.grey,
            alignment=1
        )
        elements.append(Paragraph(footer_text, footer_style))
        
        # Build PDF
        doc.build(elements)
        pdf_buffer.seek(0)
        
        return FileResponse(
            pdf_buffer,
            media_type="application/pdf",
            filename=f"report_{report_id}.pdf"
        )
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PDF export not available. Please install reportlab: pip install reportlab"
        )
    except Exception as e:
        logger.error(f"Error exporting PDF: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export report as PDF"
        )


@router.post("/{report_id}/export/csv")
async def export_report_csv(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Export report data as CSV"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to export this report"
        )
    
    try:
        import csv
        from io import StringIO
        
        csv_buffer = StringIO()
        writer = csv.writer(csv_buffer)
        
        # Header
        writer.writerow(['Report Title', report.title])
        writer.writerow(['Report Type', report.report_type])
        writer.writerow(['Generated Date', report.generated_at])
        writer.writerow(['Status', report.status])
        writer.writerow([])
        
        # Analysis Summary
        writer.writerow(['Analysis Summary'])
        writer.writerow(['Seizure Count', report.seizure_count])
        writer.writerow(['Total Seizure Duration (seconds)', report.total_seizure_duration_seconds])
        writer.writerow(['Seizure Percentage', f"{report.seizure_percentage:.2f}%"])
        writer.writerow([])
        
        # Seizure Events
        if report.seizure_events:
            writer.writerow(['Seizure Events'])
            writer.writerow(['Start (s)', 'End (s)', 'Duration (s)', 'Channels', 'Confidence (%)'])
            for event in report.seizure_events:
                writer.writerow([
                    f"{event.get('start_time', 0):.2f}",
                    f"{event.get('end_time', 0):.2f}",
                    f"{event.get('duration', 0):.2f}",
                    ', '.join(event.get('channels', [])),
                    f"{event.get('confidence', 0):.0f}"
                ])
            writer.writerow([])
        
        # Clinical Notes
        if report.clinical_notes:
            writer.writerow(['Clinical Notes'])
            writer.writerow([report.clinical_notes])
            writer.writerow([])
        
        # Clinical Recommendations
        if report.clinical_recommendations:
            writer.writerow(['Clinical Recommendations'])
            writer.writerow([report.clinical_recommendations])
        
        csv_buffer.seek(0)
        
        return FileResponse(
            StringIO(csv_buffer.getvalue()),
            media_type="text/csv",
            filename=f"report_{report_id}.csv"
        )
    except Exception as e:
        logger.error(f"Error exporting CSV: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export report as CSV"
        )


@router.get("/{report_id}/export/json")
async def export_report_json(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Export report data as JSON"""
    report = await ReportService.get_report(db, report_id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Check authorization
    if str(report.created_by_id) != str(current_user.id) and current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to export this report"
        )
    
    from fastapi.responses import JSONResponse
    
    report_dict = {
        'id': report.id,
        'title': report.title,
        'report_type': report.report_type,
        'generated_at': report.generated_at.isoformat(),
        'status': report.status,
        'seizure_count': report.seizure_count,
        'total_seizure_duration_seconds': report.total_seizure_duration_seconds,
        'seizure_percentage': report.seizure_percentage,
        'seizure_events': report.seizure_events,
        'clinical_notes': report.clinical_notes,
        'clinical_recommendations': report.clinical_recommendations,
    }
    
    return JSONResponse(report_dict)
