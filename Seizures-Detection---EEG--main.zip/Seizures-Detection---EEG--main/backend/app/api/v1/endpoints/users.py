"""
User management endpoints and doctor-assistant relationship endpoints
"""
from typing import List
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import (
    get_current_user,
    require_role,
    get_user_service,
    validate_organization_access,
)
from app.core.database import get_db
from app.models.users import User
from app.schemas.users import (
    UserCreate,
    UserResponse,
    UserUpdate,
    DoctorAssistantCreate,
    DoctorAssistantResponse
)
from app.services.users import UserService
from app.utils.constants import VALID_USER_ROLES

router = APIRouter()


def user_to_response(user: User) -> dict:
    """Convert User model to UserResponse dict"""
    return {
        "id": user.id,
        "org_id": user.org_id,
        "email": user.email,
        "username": user.username,
        "full_name": user.full_name,
        "title": user.title,
        "role": user.role,
        "organization": user.organization.name if user.organization else None,
        "is_active": user.is_active,
        "created_at": user.created_at,
        "updated_at": user.updated_at,
    }


# User management endpoints
@router.post("/register", status_code=status.HTTP_200_OK)
async def register(
    user_data: UserCreate,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service)
):
    """
    Register a new user with role-based authorization:
    - Only Admin can register doctors and assistants of the same organization
    - Only Root can register admins of any organization
    """
    # Check if user already exists
    if await user_service.get_by_email(user_data.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    if await user_service.get_by_username(user_data.username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken"
        )
    
    # Validate role if provided
    if user_data.role and user_data.role not in VALID_USER_ROLES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid role. Must be one of {VALID_USER_ROLES}"
        )
    
    # Only admin or root can register users
    if current_user.role not in ["admin", "root"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins or root can register users"
        )
    
    # Check if trying to register an admin
    if user_data.role == "admin":
        # Only root can register other admins
        if current_user.role != "root":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can register other admins"
            )
        # Organization must be provided when registering an admin
        if not user_data.org_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Organization is required when registering an admin"
            )
        # Validate organization exists
        org = await user_service.get_organization_by_id(user_data.org_id)
        if not org:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Organization not found"
            )
    else:
        # Regular admins can only register doctors and assistants
        if user_data.role not in ["doctor", "assistant"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin can only register doctors and assistants"
            )
        
        # Root users can register users for any organization
        if current_user.role == "root":
            # Root can register for any organization, but organization must be provided
            if not user_data.org_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Organization is required when registering users"
                )
            # Validate organization exists
            org = await user_service.get_organization_by_id(user_data.org_id)
            if not org:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Organization not found"
                )
        else:
            # Regular admins: validate organization access
            if user_data.org_id and user_data.org_id != current_user.org_id:
                validate_organization_access(
                    current_user, 
                    user_data.org_id,
                    "You can only register users for your organization"
                )
            # Set organization from current user if not provided
            if not user_data.org_id:
                user_data.org_id = current_user.org_id
    
    user = await user_service.create_user(user_data)
    return {
        "message": "User registered successfully",
        "data": UserResponse(**user_to_response(user))
    }


@router.get("/", response_model=List[UserResponse])
async def get_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(require_role(["admin", "root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Get list of users
    - Root users can see all users
    - Admins can only see users from their own organization
    """
    # Root users can see all users, admins only see their organization
    org_id = None if current_user.role == "root" else current_user.org_id
    users = await user_service.get_all(skip=skip, limit=limit, org_id=org_id)
    return [UserResponse(**user_to_response(user)) for user in users]


@router.get("/doctors", response_model=List[UserResponse])
async def get_doctors(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service)
):
    """
    Get list of all doctors with pagination
    - Root users can see all doctors
    - Admins can only see doctors from their own organization
    - Assistants can see doctors from their organization
    """
    # Get all users and filter by doctor role
    org_id = None if current_user.role == "root" else current_user.org_id
    all_users = await user_service.get_all(skip=0, limit=10000, org_id=org_id)
    
    # Filter only doctors
    doctors = [user for user in all_users if user.role == "doctor"]
    
    # Apply pagination
    total_doctors = doctors
    doctors = doctors[skip:skip + limit]
    
    return [UserResponse(**user_to_response(doctor)) for doctor in doctors]


@router.get("/assistants", response_model=List[UserResponse])
async def get_assistants(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(require_role(["admin", "root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Get list of all assistants with pagination
    - Root users can see all assistants
    - Admins can only see assistants from their own organization
    """
    # Get all users and filter by assistant role
    org_id = None if current_user.role == "root" else current_user.org_id
    all_users = await user_service.get_all(skip=0, limit=10000, org_id=org_id)
    
    # Filter only assistants
    assistants = [user for user in all_users if user.role == "assistant"]
    
    # Apply pagination
    assistants = assistants[skip:skip + limit]
    
    return [UserResponse(**user_to_response(assistant)) for assistant in assistants]


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service)
):
    """Get user by ID"""
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Users can always view their own profile
    if current_user.id == user_id:
        return UserResponse(**user_to_response(user))
    
    # Root users can view anyone
    if current_user.role == "root":
        return UserResponse(**user_to_response(user))
    
    # Admins can only view users from their own organization
    if current_user.role == "admin":
        validate_organization_access(
            current_user,
            user.org_id,
            "Access denied. You can only view users from your organization"
        )
        return UserResponse(**user_to_response(user))
    
    # Doctor can view their assistants
    if current_user.role == "doctor" and user.role == "assistant":
        relationship = await user_service.get_doctor_assistant_by_assistant_id(user_id)
        if relationship and relationship.doctor_id == current_user.id:
            validate_organization_access(
                current_user,
                user.org_id,
                "Access denied. User is not in your organization"
            )
            return UserResponse(**user_to_response(user))
    
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Not enough permissions"
    )


@router.put("/{user_id}", status_code=status.HTTP_200_OK)
async def update_user(
    user_id: UUID,
    user_update: UserUpdate,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service)
):
    """
    Update user information
    - All users can update themselves
    - Admins can update doctors and assistants in their organization
    - Root can update all users
    """
    # Get the user to update
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Check permissions
    can_update = False
    
    # Users can always update themselves
    if current_user.id == user_id:
        can_update = True
        # Users cannot update their own role or is_active status
        if user_update.role is not None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You cannot change your own role"
            )
        if user_update.is_active is not None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You cannot change your own active status"
            )
        # Users cannot change their own organization (can only keep it the same or leave it unchanged)
        if user_update.org_id is not None:
            if user_update.org_id != user.org_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You cannot change your own organization"
                )
    
    # Root users can update anyone
    elif current_user.role == "root":
        can_update = True
    
    # Admins can only update doctors and assistants in their organization
    elif current_user.role == "admin":
        # Validate organization access
        validate_organization_access(
            current_user,
            user.org_id,
            "You can only update users from your organization"
        )
        # Admins can only update doctors and assistants
        if user.role not in ["doctor", "assistant"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admins can only update doctors and assistants"
            )
        can_update = True
    
    if not can_update:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to update this user"
        )
    
    # Validate role if being updated (only root/admin can update roles)
    if user_update.role is not None:
        if current_user.role not in ["root", "admin"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admins and root can change user roles"
            )
        # Only root can change role to admin
        if user_update.role == "admin" and current_user.role != "root":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can change role to admin"
            )
    
    # Validate org_id if being updated
    if user_update.org_id is not None:
        org = await user_service.get_organization_by_id(user_update.org_id)
        if not org:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Organization not found"
            )
    
    # Update the user
    updated_user = await user_service.update_user(
        user_id=user_id,
        email=user_update.email,
        username=user_update.username,
        password=user_update.password,
        role=user_update.role,
        full_name=user_update.full_name,
        title=user_update.title,
        org_id=user_update.org_id,
        is_active=user_update.is_active
    )
    
    if not updated_user:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update user"
        )
    
    return {
        "message": "User updated successfully",
        "data": UserResponse(**user_to_response(updated_user))
    }


@router.delete("/{user_id}", status_code=status.HTTP_200_OK)
async def delete_user(
    user_id: UUID,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service)
):
    """
    Delete a user
    - Admins can delete doctors and assistants in their organization
    - Root can delete all users
    """
    # Get the user to delete
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Check permissions
    can_delete = False
    
    # Root users can delete anyone
    if current_user.role == "root":
        can_delete = True
    
    # Admins can only delete doctors and assistants in their organization
    elif current_user.role == "admin":
        # Validate organization access
        validate_organization_access(
            current_user,
            user.org_id,
            "You can only delete users from your organization"
        )
        # Admins can only delete doctors and assistants
        if user.role not in ["doctor", "assistant"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admins can only delete doctors and assistants"
            )
        can_delete = True
    
    if not can_delete:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to delete this user"
        )
    
    # Clean up doctor-assistant relationships
    if user.role == "assistant":
        # If deleting an assistant, delete the doctor-assistant relationship
        relationship = await user_service.get_doctor_assistant_by_assistant_id(user_id)
        if relationship:
            await user_service.delete_doctor_assistant_relationship(user_id)
    elif user.role == "doctor":
        # If deleting a doctor, delete all their assistant relationships
        relationships = await user_service.get_doctor_assistants_by_doctor_id(user_id)
        for relationship in relationships:
            await user_service.delete_doctor_assistant_relationship(relationship.assistant_id)
    
    # Delete the user
    if not await user_service.delete_user(user_id):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete user"
        )
    
    return {
        "message": "User deleted successfully",
        "user_id": str(user_id),
        "username": user.username,
        "email": user.email
    }


# Doctor-Assistant relationship endpoints
@router.post("/doctor-assistants", status_code=status.HTTP_200_OK)
async def assign_assistant_to_doctor(
    relationship_data: DoctorAssistantCreate,
    current_user: User = Depends(require_role(["admin"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Assign an assistant to a doctor.
    - Only admins can assign assistants to doctors in their organization
    """
    # Get and validate assistant
    assistant = await user_service.get_by_id(relationship_data.assistant_id)
    if not assistant or assistant.role != "assistant":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND if not assistant else status.HTTP_400_BAD_REQUEST,
            detail="Assistant not found" if not assistant else "User is not an assistant"
        )
    
    # Get and validate doctor
    doctor = await user_service.get_by_id(relationship_data.doctor_id)
    if not doctor or doctor.role != "doctor":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND if not doctor else status.HTTP_400_BAD_REQUEST,
            detail="Doctor not found" if not doctor else "User is not a doctor"
        )
    
    # Validate organization access
    validate_organization_access(
        current_user,
        doctor.org_id,
        "Doctor must be in the same organization"
    )
    validate_organization_access(
        current_user,
        assistant.org_id,
        "Assistant must be in the same organization"
    )
    
    # Create the relationship
    try:
        relationship = await user_service.create_doctor_assistant_relationship(
            doctor_id=relationship_data.doctor_id,
            assistant_id=relationship_data.assistant_id
        )
        return {
            "message": "Assistant assigned to doctor successfully",
            "data": {
                "id": relationship.id,
                "doctor_id": relationship.doctor_id,
                "assistant_id": relationship.assistant_id,
                "created_at": relationship.created_at,
                "updated_at": relationship.updated_at
            }
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/doctor-assistants/my-assistants", response_model=List[UserResponse])
async def get_my_assistants(
    current_user: User = Depends(require_role(["doctor"])),
    user_service: UserService = Depends(get_user_service)
):
    """Get all assistants assigned to the current doctor"""
    relationships = await user_service.get_doctor_assistants_by_doctor_id(current_user.id)
    assistants = []
    for rel in relationships:
        assistant = await user_service.get_by_id(rel.assistant_id)
        if assistant:
            assistants.append(UserResponse(**user_to_response(assistant)))
    return assistants


@router.get("/doctor-assistants/by-doctor/{doctor_id}", response_model=List[UserResponse])
async def get_doctor_assistants(
    doctor_id: UUID,
    current_user: User = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service),
    db: AsyncSession = Depends(get_db)
):
    """
    Get all assistants assigned to a specific doctor
    - Root can get assistants for any doctor
    - Admins can only get assistants for doctors in their organization
    - Doctors can only get assistants assigned to themselves
    """
    # Validate doctor exists
    doctor = await user_service.get_by_id(doctor_id)
    if not doctor or doctor.role != "doctor":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND if not doctor else status.HTTP_400_BAD_REQUEST,
            detail="Doctor not found" if not doctor else "User is not a doctor"
        )
    
    # Check access based on role
    if current_user.role == "root":
        # Root can access any doctor's assistants
        pass
    elif current_user.role == "admin":
        # Admin can only access doctors in their organization
        validate_organization_access(
            current_user,
            doctor.org_id,
            "Doctor must be in the same organization"
        )
    elif current_user.role == "doctor":
        # Doctor can only access their own assistants
        if current_user.id != doctor_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only view your own assigned assistants"
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You don't have permission to view doctor assistants"
        )
    
    # Get all assistants assigned to this doctor
    relationships = await user_service.get_doctor_assistants_by_doctor_id(doctor_id)
    assistants = []
    for rel in relationships:
        assistant = await user_service.get_by_id(rel.assistant_id)
        if assistant:
            assistants.append(UserResponse(**user_to_response(assistant)))
    return assistants


@router.get("/doctor-assistants/my-doctor", response_model=UserResponse)
async def get_my_doctor(
    current_user: User = Depends(require_role(["assistant"])),
    user_service: UserService = Depends(get_user_service)
):
    """Get the doctor assigned to the current assistant"""
    doctor = await user_service.get_doctor_by_assistant_id(current_user.id)
    if not doctor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No doctor assigned to you"
        )
    return UserResponse(**user_to_response(doctor))


@router.delete("/doctor-assistants/{assistant_id}", status_code=status.HTTP_200_OK)
async def remove_assistant_from_doctor(
    assistant_id: UUID,
    current_user: User = Depends(require_role(["admin"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Remove an assistant from a doctor.
    - Only admins can remove assistants in their organization
    """
    # Get the relationship
    relationship = await user_service.get_doctor_assistant_by_assistant_id(assistant_id)
    if not relationship:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Relationship not found"
        )
    
    # Get and validate assistant
    assistant = await user_service.get_by_id(assistant_id)
    if not assistant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Assistant not found"
        )
    
    # Get doctor information
    doctor = await user_service.get_by_id(relationship.doctor_id)
    if not doctor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Doctor not found"
        )
    
    # Validate organization access
    validate_organization_access(
        current_user,
        assistant.org_id,
        "Assistant is not in your organization"
    )
    
    # Delete the relationship
    if not await user_service.delete_doctor_assistant_relationship(assistant_id):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to remove relationship"
        )
    
    return {
        "message": "Assistant removed from doctor successfully",
        "assistant_id": str(assistant_id),
        "assistant_username": assistant.username,
        "assistant_email": assistant.email,
        "doctor_id": str(relationship.doctor_id),
        "doctor_username": doctor.username,
        "doctor_email": doctor.email
    }

