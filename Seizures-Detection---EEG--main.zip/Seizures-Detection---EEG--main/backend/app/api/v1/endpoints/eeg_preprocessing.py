"""
EEG preprocessing endpoints for signal analysis and visualization
"""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import JSONResponse
from app.core.security import get_current_user
from app.models.users import User
from app.models.eeg_files import EEGFile
from app.services.eeg_files import EEGFileService
from app.services.eeg_preprocessing import EEGPreprocessingService
from app.core.database import get_db
from app.core.config import settings
from sqlalchemy.ext.asyncio import AsyncSession
from pathlib import Path

router = APIRouter()


@router.get("/preprocess/{file_id}")
async def preprocess_eeg_file(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Preprocess and analyze an EEG file
    Returns raw signal, filtered signal, ICA-cleaned signal, PSD, and frequency band analysis
    """
    try:
        # Get the EEG file
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
        
        if not eeg_file:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="EEG file not found"
            )
        
        # Check permissions - user should be able to view this file
        if current_user.role == "doctor" or current_user.role == "assistant":
            # Check if it's their patient's file
            if eeg_file.patient and eeg_file.patient.doctor_id != current_user.id:
                if current_user.role == "assistant":
                    # For assistants, check their assigned doctor
                    from app.models.users import DoctorAssistant
                    from sqlalchemy import select
                    doc_assistant = await db.execute(
                        select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
                    )
                    assistant_record = doc_assistant.scalar_one_or_none()
                    if not assistant_record or eeg_file.patient.doctor_id != assistant_record.doctor_id:
                        raise HTTPException(
                            status_code=status.HTTP_403_FORBIDDEN,
                            detail="You don't have permission to view this file"
                        )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You don't have permission to view this file"
                    )
        elif current_user.role == "admin":
            # Admin can only access files from their organization
            if eeg_file.patient and eeg_file.patient.doctor_id:
                from app.services.users import UserService
                user_service = UserService(db)
                doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
                if not doctor or doctor.org_id != current_user.org_id:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You don't have permission to view this file"
                    )
        elif current_user.role != "root":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You don't have permission to preprocess files"
            )
        
        # Get full file path
        file_path = Path(settings.resolved_upload_dir) / eeg_file.file_path
        
        if not file_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="EEG file not found on disk"
            )
        
        # Perform preprocessing
        preprocessor = EEGPreprocessingService(str(file_path))
        
        # Load the EEG file
        if not preprocessor.load_eeg_file():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to load EEG file"
            )
        
        # Get preprocessing report
        report = preprocessor.get_full_preprocessing_report()
        
        return {
            "status": "success",
            "file_id": file_id,
            "file_name": eeg_file.original_filename,
            "preprocessing_report": report
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"Preprocessing error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Preprocessing failed: {str(e)}"
        )


@router.get("/analyze/raw/{file_id}")
async def analyze_raw_signal(
    file_id: UUID,
    duration: int = Query(10, ge=1, le=300),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get raw EEG signal for visualization"""
    try:
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.get_by_id(file_id)
        
        if not eeg_file:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_path = Path(settings.resolved_upload_dir) / eeg_file.file_path
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        preprocessor = EEGPreprocessingService(str(file_path))
        if not preprocessor.load_eeg_file():
            raise HTTPException(status_code=400, detail="Failed to load file")
        
        raw_signal = preprocessor.get_raw_signal(duration=duration)
        return {"file_id": file_id, "raw_signal": raw_signal}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analyze/filtered/{file_id}")
async def analyze_filtered_signal(
    file_id: UUID,
    l_freq: float = Query(0.1, ge=0.01),
    h_freq: float = Query(30.0, le=1000),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get bandpass filtered EEG signal"""
    try:
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.get_by_id(file_id)
        
        if not eeg_file:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_path = Path(settings.resolved_upload_dir) / eeg_file.file_path
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        preprocessor = EEGPreprocessingService(str(file_path))
        if not preprocessor.load_eeg_file():
            raise HTTPException(status_code=400, detail="Failed to load file")
        
        filtered = preprocessor.apply_bandpass_filter(l_freq=l_freq, h_freq=h_freq)
        return {"file_id": file_id, "filtered_signal": filtered}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analyze/psd/{file_id}")
async def analyze_power_spectrum(
    file_id: UUID,
    fmin: float = Query(0.5, ge=0.01),
    fmax: float = Query(30.0, le=1000),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get Power Spectral Density analysis"""
    try:
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.get_by_id(file_id)
        
        if not eeg_file:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_path = Path(settings.resolved_upload_dir) / eeg_file.file_path
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        preprocessor = EEGPreprocessingService(str(file_path))
        if not preprocessor.load_eeg_file():
            raise HTTPException(status_code=400, detail="Failed to load file")
        
        # Apply preprocessing first
        preprocessor.apply_bandpass_filter(0.1, 30)
        preprocessor.apply_ica(exclude=[1, 2])
        
        psd = preprocessor.compute_power_spectral_density(fmin=fmin, fmax=fmax)
        return {"file_id": file_id, "psd": psd}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analyze/bands/{file_id}")
async def analyze_frequency_bands(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get frequency band analysis (Delta, Theta, Alpha, Beta)"""
    try:
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.get_by_id(file_id)
        
        if not eeg_file:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_path = Path(settings.resolved_upload_dir) / eeg_file.file_path
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found on disk")
        
        preprocessor = EEGPreprocessingService(str(file_path))
        if not preprocessor.load_eeg_file():
            raise HTTPException(status_code=400, detail="Failed to load file")
        
        # Apply preprocessing
        preprocessor.apply_bandpass_filter(0.1, 30)
        preprocessor.apply_ica(exclude=[1, 2])
        
        bands = preprocessor.compute_frequency_bands_power()
        return {"file_id": file_id, "frequency_bands": bands}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
