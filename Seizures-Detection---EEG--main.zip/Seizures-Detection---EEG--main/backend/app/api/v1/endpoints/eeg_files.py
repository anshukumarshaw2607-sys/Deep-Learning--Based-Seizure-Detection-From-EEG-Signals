"""
EEG file management endpoints
"""
from typing import List, Optional
from uuid import UUID
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File, Form
from app.core.security import (
    get_current_user,
    validate_organization_access,
)
from app.models.users import User, DoctorAssistant
from app.models.eeg_files import EEGFile
from app.models.patients import Patient
from app.schemas.eeg_files import (
    EEGFileResponse,
    EEGFileUpdate,
    EEGFileUploadResponse,
    EEGFileListResponse,
)
from app.services.eeg_files import EEGFileService
from app.services.patients import PatientService
from app.services.users import UserService
from app.core.database import get_db
from app.core.config import settings
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.orm import selectinload

router = APIRouter()

# Allowed file extensions for EEG files (only .edf format)
ALLOWED_EXTENSIONS = {'.edf'}


def eeg_file_to_response(eeg_file: EEGFile) -> dict:
    """Convert EEGFile model to EEGFileResponse dict"""
    # Safely get uploader name, handling lazy loading
    uploader_name = None
    try:
        if eeg_file.uploader:
            uploader_name = eeg_file.uploader.full_name
    except:
        # In case uploader relationship isn't loaded, fallback to None
        uploader_name = None
    
    # Get patient details if available
    patient_info = None
    try:
        if eeg_file.patient:
            patient_info = {
                "id": eeg_file.patient.id,
                "full_name": eeg_file.patient.full_name,
                "age": eeg_file.patient.age,
                "gender": eeg_file.patient.gender,
                "contact_number": eeg_file.patient.contact_number,
                "email": eeg_file.patient.email,
            }
    except:
        # In case patient relationship isn't loaded, fallback to None
        patient_info = None
    
    return {
        "id": eeg_file.id,
        "patient_id": eeg_file.patient_id,
        "uploaded_by": eeg_file.uploaded_by,
        "filename": eeg_file.filename,
        "original_filename": eeg_file.original_filename,
        "file_path": eeg_file.file_path,
        "file_size": eeg_file.file_size,
        "file_hash": eeg_file.file_hash,
        "recording_duration": eeg_file.recording_duration,
        "sampling_rate": eeg_file.sampling_rate,
        "number_of_channels": eeg_file.number_of_channels,
        "channel_names": eeg_file.channel_names,
        "description": eeg_file.description,
        "notes": eeg_file.notes,
        "is_deleted": eeg_file.is_deleted,
        "created_at": eeg_file.created_at,
        "updated_at": eeg_file.updated_at,
        "uploader_name": uploader_name,
        "patient": patient_info,
    }


async def ensure_uploader_loaded(db: AsyncSession, file: EEGFile) -> None:
    """Ensure uploader relationship is loaded for a file"""
    if file.uploaded_by and not hasattr(file.uploader, '__dict__'):
        # Uploader not loaded, fetch it
        user_service = UserService(db)
        file.uploader = await user_service.get_by_id(file.uploaded_by)


@router.post("/upload", status_code=status.HTTP_200_OK, response_model=EEGFileUploadResponse)
async def upload_eeg_file(
    file: UploadFile = File(..., description="EEG file to upload"),
    patient_id: UUID = Form(..., description="Patient ID to associate the file with"),
    description: Optional[str] = Form(None, description="Optional description of the file"),
    notes: Optional[str] = Form(None, description="Optional notes about the file"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload an EEG file for a patient
    - Doctors and assistants can upload files for their own patients
    - Admins can upload files for patients of doctors in their organization
    - Root can upload files for any patient
    """
    # Validate file extension (only .edf files are allowed)
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Only .edf (European Data Format) files are allowed. Received file with extension '{file_ext}'"
        )
    
    # Validate patient exists and user has access
    patient_service = PatientService(db)
    patient = await patient_service.get_by_id(patient_id, include_deleted=False)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Check permissions
    if current_user.role == "root":
        # Root can upload for any patient
        pass
    elif current_user.role == "admin":
        # Admins can upload for patients of doctors in their organization
        if not current_user.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is not associated with an organization"
            )
        if patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only upload files for patients of doctors in your organization"
                )
    elif current_user.role == "doctor" or current_user.role == "assistant":
        # Doctors and assistants can only upload for their patients
        # For assistants, get the doctor they're assigned to
        if current_user.role == "assistant":
            # Get the doctor this assistant is assigned to
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_check = assistant_record.doctor_id
        else:
            doctor_id_to_check = current_user.id
        
        if patient.doctor_id != doctor_id_to_check:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only upload files for your assigned doctor's patients"
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to upload EEG files"
        )
    
    # Validate file size
    file_content = await file.read()
    if len(file_content) > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File size exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE / (1024*1024):.1f} MB"
        )
    
    # Save file
    try:
        eeg_file_service = EEGFileService(db)
        eeg_file = await eeg_file_service.save_file(
            file_content=file_content,
            original_filename=file.filename,
            patient_id=patient_id,
            uploaded_by=current_user.id,
            description=description,
            notes=notes
        )
        
        return {
            "message": "EEG file uploaded successfully",
            "data": EEGFileResponse(**eeg_file_to_response(eeg_file))
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error uploading file: {str(e)}"
        )


@router.get("", response_model=EEGFileListResponse)
async def get_eeg_files(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    patient_id: Optional[UUID] = Query(None, description="Filter by patient ID"),
    uploaded_by: Optional[UUID] = Query(None, description="Filter by uploader ID"),
    include_deleted: bool = Query(False, description="Include deleted files"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get all EEG files with pagination
    - Doctors and assistants can see files for their own patients
    - Admins can see files for patients of doctors in their organization
    - Root can see all files
    """
    eeg_file_service = EEGFileService(db)
    
    # Apply role-based filtering
    if current_user.role == "root":
        # Root can see all files
        files, total = await eeg_file_service.get_all(
            skip=skip,
            limit=limit,
            patient_id=patient_id,
            uploaded_by=uploaded_by,
            include_deleted=include_deleted
        )
    elif current_user.role == "admin":
        # Admins can see files for patients in their organization
        if not current_user.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is not associated with an organization"
            )
        # Filter by organization through patient's doctor
        # Get all files with relationships properly loaded
        all_files, _ = await eeg_file_service.get_all(
            skip=0,
            limit=10000,  # Get all to filter
            patient_id=patient_id,
            uploaded_by=uploaded_by,
            include_deleted=include_deleted
        )
        # Filter by organization
        user_service = UserService(db)
        filtered_files = []
        for f in all_files:
            # Ensure patient and doctor relationships are loaded
            if f.patient and f.patient.doctor_id:
                doctor = await user_service.get_by_id(f.patient.doctor_id)
                if doctor and doctor.org_id == current_user.org_id:
                    filtered_files.append(f)
        total = len(filtered_files)
        files = filtered_files[skip:skip + limit]
    elif current_user.role == "doctor" or current_user.role == "assistant":
        # Doctors and assistants can only see files for their own patients
        # For assistants, get the doctor they're assigned to
        user_service = UserService(db)
        
        # Determine which doctor's patients to show
        if current_user.role == "assistant":
            # Get the doctor this assistant is assigned to
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_filter = assistant_record.doctor_id
        else:
            # For doctors, use their own ID
            doctor_id_to_filter = current_user.id
        
        if patient_id:
            # Validate patient belongs to the doctor/assistant's doctor
            patient_service = PatientService(db)
            patient = await patient_service.get_by_id(patient_id)
            if not patient or patient.doctor_id != doctor_id_to_filter:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You can only view files for your assigned doctor's patients"
                )
        files, total = await eeg_file_service.get_all(
            skip=skip,
            limit=limit,
            patient_id=patient_id or None,
            uploaded_by=uploaded_by,
            include_deleted=include_deleted
        )
        # Filter to only doctor's/assistant's doctor's patients
        if not patient_id:
            patient_service = PatientService(db)
            doctor_patients = await patient_service.get_patients_by_doctor(doctor_id_to_filter)
            patient_ids = {p.id for p in doctor_patients}
            files = [f for f in files if f.patient_id in patient_ids]
            total = len(files)
            files = files[skip:skip + limit]
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to view EEG files"
        )
    
    # Ensure all files have uploader information loaded
    for f in files:
        await ensure_uploader_loaded(db, f)
    
    return {
        "files": [EEGFileResponse(**eeg_file_to_response(f)) for f in files],
        "total": total,
        "skip": skip,
        "limit": limit
    }


@router.get("/{file_id}", response_model=EEGFileResponse)
async def get_eeg_file(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get a specific EEG file by ID
    - Doctors can see files for their own patients
    - Admins can see files for patients of doctors in their organization
    - Root can see any file
    """
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions
    if current_user.role == "root":
        return EEGFileResponse(**eeg_file_to_response(eeg_file))
    
    if current_user.role == "admin":
        if eeg_file.patient and eeg_file.patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only view files for patients of doctors in your organization"
                )
        return EEGFileResponse(**eeg_file_to_response(eeg_file))
    
    if current_user.role == "doctor" or current_user.role == "assistant":
        # For assistants, get the doctor they're assigned to
        if current_user.role == "assistant":
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_check = assistant_record.doctor_id
        else:
            doctor_id_to_check = current_user.id
        
        if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only view files for your assigned doctor's patients"
            )
        return EEGFileResponse(**eeg_file_to_response(eeg_file))
    
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have permission to view this file"
    )


@router.get("/{file_id}/download")
async def download_eeg_file(
    file_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Download an EEG file
    - Same permission rules as get_eeg_file
    """
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=False)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same as get_eeg_file)
    if current_user.role == "doctor" or current_user.role == "assistant":
        # For assistants, get the doctor they're assigned to
        if current_user.role == "assistant":
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_check = assistant_record.doctor_id
        else:
            doctor_id_to_check = current_user.id
        
        if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only download files for your assigned doctor's patients"
            )
    elif current_user.role == "admin":
        if eeg_file.patient and eeg_file.patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only download files for patients of doctors in your organization"
                )
    elif current_user.role != "root":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to download this file"
        )
    
    # Get file path
    file_path = eeg_file_service.get_file_path(eeg_file)
    
    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found on server"
        )
    
    from fastapi.responses import FileResponse
    return FileResponse(
        path=str(file_path),
        filename=eeg_file.original_filename,
        media_type="application/octet-stream"  # EDF files use this MIME type
    )


@router.put("/{file_id}", status_code=status.HTTP_200_OK)
async def update_eeg_file(
    file_id: UUID,
    file_update: EEGFileUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Update EEG file metadata
    - Same permission rules as get_eeg_file
    """
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=True)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions (same as get_eeg_file)
    if current_user.role == "doctor" or current_user.role == "assistant":
        # For assistants, get the doctor they're assigned to
        if current_user.role == "assistant":
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_check = assistant_record.doctor_id
        else:
            doctor_id_to_check = current_user.id
        
        if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only update files for your assigned doctor's patients"
            )
    elif current_user.role == "admin":
        if eeg_file.patient and eeg_file.patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only update files for patients of doctors in your organization"
                )
    elif current_user.role != "root":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to update this file"
        )
    
    updated_file = await eeg_file_service.update_file(
        file_id=file_id,
        description=file_update.description,
        notes=file_update.notes,
        is_deleted=file_update.is_deleted
    )
    
    if not updated_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    return {
        "message": "EEG file updated successfully",
        "data": EEGFileResponse(**eeg_file_to_response(updated_file))
    }


@router.delete("/{file_id}", status_code=status.HTTP_200_OK)
async def delete_eeg_file(
    file_id: UUID,
    hard_delete: bool = Query(False, description="Permanently delete the file"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Delete an EEG file (soft delete by default, hard delete if specified)
    - Same permission rules as get_eeg_file
    - Only root can perform hard deletes
    """
    eeg_file_service = EEGFileService(db)
    eeg_file = await eeg_file_service.get_by_id(file_id, include_deleted=True)
    
    if not eeg_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    # Check permissions
    if current_user.role == "doctor" or current_user.role == "assistant":
        # For assistants, get the doctor they're assigned to
        if current_user.role == "assistant":
            doc_assistant = await db.execute(
                select(DoctorAssistant).filter(DoctorAssistant.assistant_id == current_user.id)
            )
            assistant_record = doc_assistant.scalar_one_or_none()
            if not assistant_record:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to any doctor"
                )
            doctor_id_to_check = assistant_record.doctor_id
        else:
            doctor_id_to_check = current_user.id
        
        if not eeg_file.patient or eeg_file.patient.doctor_id != doctor_id_to_check:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only delete files for your assigned doctor's patients"
            )
        if hard_delete:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can perform hard deletes"
            )
    elif current_user.role == "admin":
        if eeg_file.patient and eeg_file.patient.doctor_id:
            user_service = UserService(db)
            doctor = await user_service.get_by_id(eeg_file.patient.doctor_id)
            if doctor:
                validate_organization_access(
                    current_user,
                    doctor.org_id,
                    "You can only delete files for patients of doctors in your organization"
                )
        if hard_delete:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only root can perform hard deletes"
            )
    elif current_user.role != "root":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to delete this file"
        )
    
    deleted = await eeg_file_service.delete_file(file_id, hard_delete=hard_delete)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="EEG file not found"
        )
    
    return {
        "message": "EEG file deleted successfully",
        "file_id": str(file_id),
        "deletion_type": "hard" if hard_delete else "soft"
    }

