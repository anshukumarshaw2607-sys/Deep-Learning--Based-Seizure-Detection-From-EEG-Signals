"""
Organization management endpoints
"""
from typing import List
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from app.core.security import (
    get_current_user,
    require_role,
    get_user_service,
)
from app.models.users import User
from app.schemas.users import (
    OrganizationCreate,
    OrganizationResponse,
    OrganizationUpdate,
)
from app.services.users import UserService

router = APIRouter()


# Organization management endpoints
@router.post("/", status_code=status.HTTP_200_OK)
async def create_organization(
    org_data: OrganizationCreate,
    current_user: User = Depends(require_role(["root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Create a new organization
    - Only root users can create organizations
    """
    try:
        organization = await user_service.create_organization(
            name=org_data.name,
            contact=org_data.contact,
            address=org_data.address,
            description=org_data.description
        )
        return {
            "message": "Organization created successfully",
            "data": {
                "id": organization.id,
                "name": organization.name,
                "contact": organization.contact,
                "address": organization.address,
                "description": organization.description,
                "created_at": organization.created_at,
                "updated_at": organization.updated_at
            }
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/", response_model=List[OrganizationResponse])
async def get_organizations(
    current_user: User = Depends(require_role(["root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Get list of all organizations
    - Only root users can see all organizations
    """
    organizations = await user_service.get_all_organizations()
    return organizations


@router.get("/{organization_id}", response_model=OrganizationResponse)
async def get_organization(
    organization_id: UUID,
    current_user: User = Depends(require_role(["root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Get organization by ID
    - Only root users can view organizations
    """
    organization = await user_service.get_organization_by_id(organization_id)
    if not organization:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization not found"
        )
    return organization


@router.put("/{organization_id}", status_code=status.HTTP_200_OK)
async def update_organization(
    organization_id: UUID,
    org_update: OrganizationUpdate,
    current_user: User = Depends(require_role(["root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Update organization information
    - Only root users can update organizations
    """
    # Check if organization exists
    organization = await user_service.get_organization_by_id(organization_id)
    if not organization:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization not found"
        )
    
    try:
        updated_organization = await user_service.update_organization(
            organization_id=organization_id,
            name=org_update.name,
            contact=org_update.contact,
            address=org_update.address,
            description=org_update.description
        )
        
        if not updated_organization:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update organization"
            )
        
        return {
            "message": "Organization updated successfully",
            "data": {
                "id": updated_organization.id,
                "name": updated_organization.name,
                "contact": updated_organization.contact,
                "address": updated_organization.address,
                "description": updated_organization.description,
                "created_at": updated_organization.created_at,
                "updated_at": updated_organization.updated_at
            }
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete("/{organization_id}", status_code=status.HTTP_200_OK)
async def delete_organization(
    organization_id: UUID,
    current_user: User = Depends(require_role(["root"])),
    user_service: UserService = Depends(get_user_service)
):
    """
    Delete an organization
    - Only root users can delete organizations
    - Note: This will set org_id to NULL for all users in this organization
    """
    # Check if organization exists
    organization = await user_service.get_organization_by_id(organization_id)
    if not organization:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization not found"
        )
    
    # Check if organization has users
    users = await user_service.get_all(org_id=organization_id)
    user_count = len(users)
    
    # Store organization name before deletion
    org_name = organization.name
    
    # Delete the organization (users.org_id will be set to NULL due to ondelete="SET NULL")
    if not await user_service.delete_organization(organization_id):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete organization"
        )
    
    return {
        "message": "Organization deleted successfully",
        "organization_id": str(organization_id),
        "organization_name": org_name,
        "users_affected": user_count,
        "note": f"Organization ID has been set to NULL for {user_count} user(s)"
    }

