"""
Main API router that includes all endpoint routers
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, users, organizations, patients, eeg_files, eeg_preprocessing, seizure_detection, reports

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(organizations.router, prefix="/organizations", tags=["organizations"])
api_router.include_router(patients.router, prefix="/patients", tags=["patients"])
api_router.include_router(eeg_files.router, prefix="/eeg-files", tags=["eeg-files"])
api_router.include_router(eeg_preprocessing.router, prefix="/analysis", tags=["analysis"])
api_router.include_router(seizure_detection.router, prefix="/detection", tags=["seizure-detection"])
api_router.include_router(reports.router, prefix="/reports", tags=["reports"])

