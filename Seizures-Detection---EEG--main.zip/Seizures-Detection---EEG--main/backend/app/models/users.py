"""
User model for authentication and user management
"""
from sqlalchemy import TIMESTAMP, Column, Text, Boolean, ForeignKey, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from uuid import uuid4

from app.core.database import Base


class Organization(Base):
    """Organization model"""
    __tablename__ = "organizations"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    name = Column(Text, unique=True, nullable=False)
    contact = Column(Text, nullable=True)
    address = Column(Text, nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationships
    users = relationship("User", back_populates="organization")


class User(Base):
    """User model"""
    __tablename__ = "users"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    org_id = Column(UUID, ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True)
    email = Column(Text, unique=True, nullable=False)
    username = Column(Text, unique=True, nullable=False)
    password = Column(Text, nullable=False)  # bcrypt hashed password
    role = Column(Text, nullable=False)
    full_name = Column(Text, nullable=True)
    title = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationships
    organization = relationship("Organization", back_populates="users")
    reports = relationship("Report", back_populates="created_by")


class DoctorAssistant(Base):
    """Model to manage which assistant is under which doctor"""
    __tablename__ = "doctor_assistants"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    assistant_id = Column(UUID, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    doctor_id = Column(UUID, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationships
    assistant = relationship("User", foreign_keys=[assistant_id], backref="supervising_doctor")
    doctor = relationship("User", foreign_keys=[doctor_id], backref="managed_assistants")


class Token(Base):
    """Model to store and track JWT tokens for revocation"""
    __tablename__ = "tokens"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    user_id = Column(UUID, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token_hash = Column(Text, nullable=False, unique=True, index=True)  # Hash of the token for lookup
    token_type = Column(Text, nullable=False)  # "access" or "refresh"
    is_revoked = Column(Boolean, default=False, nullable=False, index=True)
    expires_at = Column(TIMESTAMP, nullable=False, index=True)
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationship
    user = relationship("User", backref="tokens")
    
    # Index for efficient lookups and unique constraint for one token per type per user
    __table_args__ = (
        Index("idx_tokens_user_type_revoked", "user_id", "token_type", "is_revoked"),
        Index("idx_tokens_user_type_unique", "user_id", "token_type", unique=True),
    )

