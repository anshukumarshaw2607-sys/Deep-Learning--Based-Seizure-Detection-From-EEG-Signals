"""
Patient model for managing patient information
"""
from sqlalchemy import TIMESTAMP, Column, Text, Integer, Date, ForeignKey, Index, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from uuid import uuid4

from app.core.database import Base


class Patient(Base):
    """Patient model"""
    __tablename__ = "patients"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    doctor_id = Column(UUID, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    full_name = Column(Text, nullable=False)
    date_of_birth = Column(Date, nullable=True)
    age = Column(Integer, nullable=True)
    gender = Column(Text, nullable=True)  # e.g., "Male", "Female"
    contact_number = Column(Text, nullable=True)
    email = Column(Text, nullable=True)
    medical_history = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)  # For soft delete
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationships
    doctor = relationship("User", foreign_keys=[doctor_id], backref="patients")
    reports = relationship("Report", back_populates="patient")
    
    # Indexes for efficient queries
    __table_args__ = (
        Index("idx_patients_doctor_id", "doctor_id"),
        Index("idx_patients_full_name", "full_name"),
        Index("idx_patients_is_deleted", "is_deleted"),
    )

