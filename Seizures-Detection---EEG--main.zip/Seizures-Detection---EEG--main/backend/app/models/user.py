from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime

class User:
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default='Doctor')
    created_at = Column(DateTime, default=datetime.utcnow)