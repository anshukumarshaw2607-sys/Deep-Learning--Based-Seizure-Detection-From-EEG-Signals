"""
Report model for EEG analysis reports
"""
from sqlalchemy import Column, String, Integer, Float, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from uuid import uuid4

from app.core.database import Base


class Report(Base):
    """Model for storing EEG analysis reports"""
    __tablename__ = "reports"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    title = Column(String, nullable=False, index=True)
    report_type = Column(String, nullable=False)  # "Seizure Detection", "Spectral Analysis", etc.
    description = Column(Text, nullable=True)
    
    # Patient and Recording Information
    patient_id = Column(String, ForeignKey("patients.id"), nullable=True)
    eeg_file_id = Column(String, ForeignKey("eeg_files.id"), nullable=True)
    created_by_id = Column(String, ForeignKey("users.id"), nullable=False)
    
    # Recording Details
    recording_date = Column(DateTime, nullable=True)
    recording_duration_minutes = Column(Float, nullable=True)
    num_channels = Column(Integer, default=19)
    
    # Analysis Results
    seizure_count = Column(Integer, default=0)
    total_seizure_duration_seconds = Column(Float, default=0.0)
    seizure_percentage = Column(Float, default=0.0)
    
    # Raw seizure data and clinical notes
    seizure_events = Column(JSON, nullable=True)  # Array of seizure events
    clinical_notes = Column(Text, nullable=True)
    clinical_recommendations = Column(Text, nullable=True)
    
    # Analysis Metadata
    analysis_timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    generated_at = Column(DateTime, default=datetime.utcnow)
    
    # Status and flags
    status = Column(String, default="completed")  # "pending", "processing", "completed", "failed"
    
    # Relationships
    patient = relationship("Patient", back_populates="reports")
    eeg_file = relationship("EEGFile", back_populates="reports")
    created_by = relationship("User", back_populates="reports")
    
    def __repr__(self):
        return f"<Report {self.id}: {self.title}>"
