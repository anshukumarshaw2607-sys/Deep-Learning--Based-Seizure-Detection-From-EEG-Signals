"""
EEG file model for managing EEG file metadata
"""
from sqlalchemy import TIMESTAMP, Column, Text, Integer, ForeignKey, Index, Boolean, Float
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from uuid import uuid4

from app.core.database import Base


class EEGFile(Base):
    """EEG file model"""
    __tablename__ = "eeg_files"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    patient_id = Column(UUID, ForeignKey("patients.id", ondelete="SET NULL"), nullable=False, index=True)
    uploaded_by = Column(UUID, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    
    # File metadata
    filename = Column(Text, nullable=False)
    original_filename = Column(Text, nullable=False)
    file_path = Column(Text, nullable=False)  # Relative path from upload directory
    file_size = Column(Integer, nullable=False)  # Size in bytes
    file_hash = Column(Text, nullable=True)  # SHA256 hash for deduplication
    
    # EEG-specific metadata
    recording_duration = Column(Float, nullable=True)  # Duration in seconds
    sampling_rate = Column(Float, nullable=True)  # Sampling rate in Hz
    number_of_channels = Column(Integer, nullable=True)
    channel_names = Column(Text, nullable=True)  # JSON string or comma-separated
    
    # Additional metadata
    description = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)  # For soft delete
    
    # Timestamps
    created_at = Column(TIMESTAMP, server_default=func.now(), nullable=False)
    updated_at = Column(TIMESTAMP, server_default=None, onupdate=func.now(), nullable=True)
    
    # Relationships
    patient = relationship("Patient", foreign_keys=[patient_id], backref="eeg_files")
    uploader = relationship("User", foreign_keys=[uploaded_by], backref="uploaded_eeg_files")
    reports = relationship("Report", back_populates="eeg_file")
    
    # Indexes for efficient queries
    __table_args__ = (
        Index("idx_eeg_files_patient_id", "patient_id"),
        Index("idx_eeg_files_uploaded_by", "uploaded_by"),
        Index("idx_eeg_files_is_deleted", "is_deleted"),
    )

