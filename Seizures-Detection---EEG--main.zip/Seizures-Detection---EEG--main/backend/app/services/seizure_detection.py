"""
Seizure detection service using NEDC ResNet model
Wraps the seizure_detector_api for integration with FastAPI backend
"""
import os
import sys
import tempfile
from pathlib import Path
from typing import Optional, Dict, Any
import logging
import torch

from app.core.config import settings

logger = logging.getLogger(__name__)

# Add NEDC library path to sys.path if needed
# NEDC libraries are now in app/utils/prediction
BACKEND_DIR = Path(__file__).parent.parent.parent  # Points to backend/
PREDICTION_DIR = BACKEND_DIR / "app" / "utils" / "prediction"
if str(PREDICTION_DIR) not in sys.path:
    sys.path.insert(0, str(PREDICTION_DIR))

# Set NEDC_NFC environment variable for parameter file path resolution
# This allows the parameter file to use $NEDC_NFC paths
if "NEDC_NFC" not in os.environ:
    os.environ["NEDC_NFC"] = str(BACKEND_DIR)

# Import the prediction package to apply Windows compatibility fixes for os.EX_SOFTWARE
# This must happen before importing NEDC tools
try:
    import app.utils.prediction  # noqa: F401
except Exception as e:
    logger.warning(f"Failed to import prediction package compatibility shim: {e}")

# Lazy import NEDC tools - they'll be loaded on first use, not at startup
nrt = None
nft = None

def _load_nedc_tools():
    """Lazy load NEDC tools on first use"""
    global nrt, nft
    if nrt is not None and nft is not None:
        return True
    
    try:
        import eeg_ml_resnet_tools as _nrt
        import file_tools as _nft
        nrt = _nrt
        nft = _nft
        return True
    except ImportError as e:
        logger.error(f"Failed to import NEDC tools: {e}")
        logger.error(f"Make sure NEDC libraries are available. Checked path: {PREDICTION_DIR}")
        return False


class SeizureDetectionService:
    """Service for detecting seizures in EEG files using NEDC ResNet model"""
    
    def __init__(self, param_file: Optional[str] = None):
        """
        Initialize the seizure detection service
        
        Args:
            param_file: Path to parameter file. If None, uses default from NEDC package
        """
        # Note: NEDC tools are loaded lazily on first detect_seizures() call
        
        # Default parameter file path
        if param_file is None:
            # Parameter file is now in app/utils/prediction
            BACKEND_DIR = Path(__file__).parent.parent.parent  # Points to backend/
            default_param = BACKEND_DIR / "app" / "utils" / "prediction" / "eeg_resnet_decode_params_v00.toml"
            
            if default_param.exists():
                param_file = str(default_param)
            else:
                raise RuntimeError(
                    f"Default parameter file not found at: {default_param}. "
                    "Please ensure app/utils/prediction/eeg_resnet_decode_params_v00.toml exists."
                )
        
        self.param_file = param_file
        self.decoder = None
        self._initialized = False
    
    def _initialize_decoder(self):
        """Lazy initialization of decoder"""
        if self._initialized:
            return
        
        # Load NEDC tools if not already loaded
        if not _load_nedc_tools():
            raise RuntimeError(
                "NEDC EEG ResNet tools not available. "
                "Please ensure the NEDC libraries are in app/utils/prediction/"
            )
        
        try:
            # Load parameters from TOML file
            param_fpath = nft.get_fullpath(self.param_file)
            if not os.path.isfile(param_fpath):
                raise FileNotFoundError(f"Parameter file not found: {param_fpath}")
            
            # Load parameters using the RESNET_DECODE section
            RESNET_DECODE = "RESNET_DECODE"
            params = nft.load_parameters(param_fpath, RESNET_DECODE)
            
            # Extract parameter keys (matching nedc_eeg_resnet_decode.py)
            DECODE_PARAM_KEY_BATCH_SIZE = "batch_size"
            DECODE_PARAM_KEY_COMP_DEVICE = "device"
            DECODE_PARAM_KEY_FRAME_DURATION = "frame_duration"
            DECODE_PARAM_KEY_WINDOW_DURATION = "window_duration"
            DECODE_PARAM_KEY_MIN_BCKG = "minimum_background_duration"
            DECODE_PARAM_KEY_MIN_SEIZ = "minimum_seizure_duration"
            DECODE_PARAM_KEY_MODEL_WEIGHTS = "model_weights"
            DECODE_PARAM_KEY_MODEL_PATH = "model_path"
            DECODE_PARAM_KEY_MONTAGE = "montage"
            DECODE_PARAM_KEY_NUM_THREADS = "num_threads"
            DECODE_PARAM_KEY_NUM_WORKERS = "num_workers"
            DECODE_PARAM_KEY_SAMPLE_FREQUENCY = "sample_frequency"
            DECODE_PARAM_KEY_SEIZ_TH = "seizure_threshold"
            
            # Get model weights path
            mdl_weight_fname = params[DECODE_PARAM_KEY_MODEL_WEIGHTS]
            if mdl_weight_fname is None:
                raise ValueError("Model weights must be specified in parameter file")
            mdl_weight_path = nft.get_fullpath(mdl_weight_fname)
            if not os.path.isfile(mdl_weight_path):
                raise FileNotFoundError(f"Model weights file not found: {mdl_weight_path}")
            
            # Get montage path
            mont_fname = params[DECODE_PARAM_KEY_MONTAGE]
            if mont_fname is None:
                raise ValueError("Montage file must be specified in parameter file")
            mont_path = nft.get_fullpath(mont_fname)
            if not os.path.isfile(mont_path):
                raise FileNotFoundError(f"Montage file not found: {mont_path}")
            
            # Get optional model path
            input_mdl_fname = params.get(DECODE_PARAM_KEY_MODEL_PATH)
            input_mdl_path = None
            if input_mdl_fname:
                input_mdl_path = nft.get_fullpath(input_mdl_fname)
                if not os.path.isfile(input_mdl_path):
                    input_mdl_path = None
            
            # Calculate frame and window sizes
            samp_rate = int(float(params[DECODE_PARAM_KEY_SAMPLE_FREQUENCY]))
            frame_duration = float(params[DECODE_PARAM_KEY_FRAME_DURATION])
            window_duration = float(params[DECODE_PARAM_KEY_WINDOW_DURATION])
            frmsize = int(frame_duration * samp_rate)
            winsize = int(window_duration * samp_rate)
            
            # Get other parameters
            seiz_ths = float(params[DECODE_PARAM_KEY_SEIZ_TH])
            min_seiz = float(params[DECODE_PARAM_KEY_MIN_SEIZ])
            min_bckg = float(params[DECODE_PARAM_KEY_MIN_BCKG])
            num_workers = int(params[DECODE_PARAM_KEY_NUM_WORKERS])
            batch_size = int(params[DECODE_PARAM_KEY_BATCH_SIZE])
            num_threads = int(params[DECODE_PARAM_KEY_NUM_THREADS])
            
            # Set device
            device_str = params[DECODE_PARAM_KEY_COMP_DEVICE]
            DEVICE_CPU = nrt.DEVICE_CPU
            DEVICE_GPU = nrt.DEVICE_GPU
            device = torch.device(device_str if torch.cuda.is_available() and device_str == "cuda" else DEVICE_CPU)
            
            # Create EEGResNetDecode instance
            self.decoder = nrt.EEGResNetDecode(
                frmsize, winsize, device, mont_path,
                samp_rate, seiz_ths, min_seiz,
                min_bckg, num_workers, num_threads,
                input_mdl_path, mdl_weight_path, batch_size
            )
            
            self._initialized = True
            logger.info(f"Seizure detection decoder initialized with param file: {self.param_file}")
        except Exception as e:
            logger.error(f"Failed to initialize decoder: {e}", exc_info=True)
            raise RuntimeError(f"Failed to initialize seizure detection decoder: {str(e)}")
    
    def _normalize_edf_channels(self, edf_file_path: str) -> tuple:
        """
        Create a temporary EDF file with normalized channel names and bipolar montage.
        The NEDC model expects specific bipolar channels in the TCP_AR montage format.
        
        Returns:
            Tuple of (temp_file_path, needs_cleanup) or (original_path, False) if no changes needed
        """
        import mne
        import numpy as np
        
        # Expected bipolar channels by the NEDC model (TCP_AR montage)
        EXPECTED_BIPOLAR = [
            'FP1-F7', 'F7-T3', 'T3-T5', 'T5-O1',
            'FP2-F8', 'F8-T4', 'T4-T6', 'T6-O2',
            'T3-C3', 'C3-CZ', 'CZ-C4', 'C4-T4',
            'FP1-F3', 'F3-C3', 'C3-P3', 'P3-O1',
            'FP2-F4', 'F4-C4', 'C4-P4', 'P4-O2'
        ]
        
        # Monopolar channel name mappings (10-10 -> 10-20 convention, case normalization)
        CHANNEL_MAPPINGS = {
            # Case variations for Fp
            'Fp1': 'FP1', 'Fp2': 'FP2',
            'fp1': 'FP1', 'fp2': 'FP2',
            # 10-10 to 10-20 temporal mappings
            'T7': 'T3', 'T8': 'T4',
            't7': 'T3', 't8': 'T4',
            'P7': 'T5', 'P8': 'T6',
            'p7': 'T5', 'p8': 'T6',
            # Case normalizations
            'Cz': 'CZ', 'cz': 'CZ',
            'Fz': 'FZ', 'fz': 'FZ',
            'Pz': 'PZ', 'pz': 'PZ',
            'f7': 'F7', 'f3': 'F3', 'f4': 'F4', 'f8': 'F8',
            'c3': 'C3', 'c4': 'C4',
            'p3': 'P3', 'p4': 'P4',
            'o1': 'O1', 'o2': 'O2',
            't3': 'T3', 't4': 'T4', 't5': 'T5', 't6': 'T6',
        }
        
        try:
            raw = mne.io.read_raw_edf(edf_file_path, preload=True, verbose=False)
            original_names = raw.ch_names
            upper_names = [ch.upper() for ch in original_names]
            
            # Check if file already has bipolar channels
            has_bipolar = any(bp.upper() in upper_names for bp in EXPECTED_BIPOLAR)
            
            if has_bipolar:
                # File already has bipolar channels - just do case normalization if needed
                rename_dict = {}
                for ch_name in original_names:
                    upper_ch = ch_name.upper()
                    if upper_ch != ch_name and upper_ch in [bp.upper() for bp in EXPECTED_BIPOLAR]:
                        rename_dict[ch_name] = upper_ch
                
                if not rename_dict:
                    return edf_file_path, False
                
                raw.rename_channels(rename_dict)
                logger.info(f"Normalized bipolar channel case: {rename_dict}")
            else:
                # File has monopolar channels - need to create bipolar derivations
                # First, normalize monopolar channel names
                rename_dict = {}
                for ch_name in original_names:
                    if ch_name in CHANNEL_MAPPINGS:
                        rename_dict[ch_name] = CHANNEL_MAPPINGS[ch_name]
                
                if rename_dict:
                    raw.rename_channels(rename_dict)
                    logger.info(f"Renamed monopolar channels: {rename_dict}")
                
                # Now create bipolar derivations
                current_channels = raw.ch_names
                upper_current = {ch.upper(): ch for ch in current_channels}
                
                # Build bipolar channels
                bipolar_data = []
                bipolar_names = []
                sfreq = raw.info['sfreq']
                
                for bp_name in EXPECTED_BIPOLAR:
                    parts = bp_name.split('-')
                    if len(parts) != 2:
                        continue
                    
                    ch1_upper, ch2_upper = parts[0].upper(), parts[1].upper()
                    
                    # Find matching channels (case-insensitive)
                    ch1_actual = upper_current.get(ch1_upper)
                    ch2_actual = upper_current.get(ch2_upper)
                    
                    if ch1_actual and ch2_actual:
                        # Get data for both channels
                        data1 = raw.get_data(picks=[ch1_actual])[0]
                        data2 = raw.get_data(picks=[ch2_actual])[0]
                        # Compute bipolar derivation (difference)
                        bipolar_signal = data1 - data2
                        bipolar_data.append(bipolar_signal)
                        bipolar_names.append(bp_name)
                    else:
                        logger.warning(f"Cannot create {bp_name}: missing {ch1_upper if not ch1_actual else ch2_upper}")
                
                if not bipolar_names:
                    logger.error("Could not create any bipolar channels from monopolar data")
                    return edf_file_path, False
                
                logger.info(f"Created {len(bipolar_names)} bipolar channels: {bipolar_names}")
            
            # Save to temporary file using edfio directly (avoids MNE's annotation channel)
            import edfio
            
            temp_fd, temp_path = tempfile.mkstemp(suffix='.edf')
            os.close(temp_fd)
            
            if has_bipolar:
                # For files that already have bipolar channels, just re-export
                data = raw.get_data()
                signals = []
                for i, ch_name in enumerate(raw.ch_names):
                    sig = edfio.EdfSignal(data[i], sampling_frequency=sfreq, label=ch_name)
                    signals.append(sig)
            else:
                # For monopolar files converted to bipolar
                signals = []
                for i, ch_name in enumerate(bipolar_names):
                    sig = edfio.EdfSignal(bipolar_data[i], sampling_frequency=sfreq, label=ch_name)
                    signals.append(sig)
            
            edf = edfio.Edf(signals)
            edf.write(temp_path)
            logger.info(f"Created normalized EDF at: {temp_path}")
            
            return temp_path, True
            
        except Exception as e:
            logger.warning(f"Channel normalization failed: {e}. Using original file.")
            return edf_file_path, False
    
    def detect_seizures(self, edf_file_path: str, save_output: Optional[str] = None) -> Dict[str, Any]:
        """
        Detect seizures in an EDF file
        
        Args:
            edf_file_path: Path to the EDF file
            save_output: Optional path to save output CSV_BI file
            
        Returns:
            Dictionary containing detection results
        """
        if not os.path.isfile(edf_file_path):
            raise FileNotFoundError(f"EDF file not found: {edf_file_path}")
        
        # Initialize decoder if not already done
        self._initialize_decoder()
        
        # Normalize channel names for compatibility with NEDC model
        normalized_path, needs_cleanup = self._normalize_edf_channels(edf_file_path)
        
        try:
            # Create a temporary log file for the decoder
            # The decode method requires a file pointer for logging
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.log') as log_file:
                log_file_path = log_file.name
            
            try:
                # Open log file for writing
                with open(log_file_path, 'w') as fp:
                    # Decode the EDF file (decode method signature: decode(argfile, fp))
                    annotation = self.decoder.decode(normalized_path, fp)
                
                # Parse results - use get_file_duration() method to get duration
                duration = annotation.get_file_duration()
            finally:
                # Clean up log file
                try:
                    os.unlink(log_file_path)
                except Exception:
                    pass
                # Clean up normalized temp file if created
                if needs_cleanup:
                    try:
                        os.unlink(normalized_path)
                        logger.info(f"Cleaned up temporary normalized EDF file")
                    except Exception:
                        pass
            
            # Parse segments - get() returns list of [start, stop, labels_dict]
            seizures = []
            background_segments = []
            
            events = annotation.get()
            if events is False or events is None:
                events = []
            
            for event in events:
                # Event format: [start, stop, labels_dict]
                start = float(event[0])
                stop = float(event[1])
                labels_dict = event[2]  # Dictionary like {'seiz': probability} or {'bckg': probability}
                duration_seg = stop - start
                
                segment_info = {
                    'start': start,
                    'stop': stop,
                    'duration': duration_seg
                }
                
                # Check labels dictionary for seizure or background
                if labels_dict:
                    labels = list(labels_dict.keys())
                    if 'seiz' in labels:
                        seizures.append(segment_info)
                    elif 'bckg' in labels:
                        background_segments.append(segment_info)
            
            # Calculate statistics
            seizure_count = len(seizures)
            total_seizure_time = sum(sz['duration'] for sz in seizures)
            seizure_percentage = (total_seizure_time / duration * 100) if duration > 0 else 0.0
            
            # Save output if requested
            output_file = None
            if save_output:
                try:
                    annotation.write(save_output)
                    output_file = save_output
                    logger.info(f"Saved detection results to: {save_output}")
                except Exception as e:
                    logger.warning(f"Failed to save output file: {e}")
            
            return {
                'input_file': edf_file_path,
                'output_file': output_file,
                'duration': float(duration),
                'seizure_count': seizure_count,
                'total_seizure_time': float(total_seizure_time),
                'seizure_percentage': float(seizure_percentage),
                'has_seizures': seizure_count > 0,
                'seizures': seizures,
                'background_segments': background_segments
            }
            
        except Exception as e:
            logger.error(f"Error during seizure detection: {e}")
            raise RuntimeError(f"Seizure detection failed: {str(e)}")
    
    def detect_seizures_from_file_id(
        self, 
        file_path: str, 
        output_dir: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Detect seizures from a file path (used by endpoint)
        
        Args:
            file_path: Full path to EDF file
            output_dir: Optional directory to save output CSV_BI file
            
        Returns:
            Dictionary containing detection results
        """
        save_output = None
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            file_stem = Path(file_path).stem
            save_output = os.path.join(output_dir, f"{file_stem}.csv_bi")
        
        return self.detect_seizures(file_path, save_output=save_output)

