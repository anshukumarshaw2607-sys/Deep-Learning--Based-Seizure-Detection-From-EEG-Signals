"""
Patient service for patient management operations (Async)
"""
from typing import Optional, List
from uuid import UUID
from datetime import date
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.orm import selectinload

from app.models.patients import Patient
from app.models.users import User
from app.schemas.patients import PatientCreate


class PatientService:
    """Service for patient-related operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_by_id(self, patient_id: UUID, include_deleted: bool = False) -> Optional[Patient]:
        """Get patient by ID with doctor relationship loaded"""
        query = (
            select(Patient)
            .options(selectinload(Patient.doctor))
            .filter(Patient.id == patient_id)
        )
        if not include_deleted:
            query = query.filter(Patient.is_deleted == False)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_all(
        self, 
        skip: int = 0, 
        limit: int = 100, 
        doctor_id: Optional[UUID] = None,
        org_id: Optional[UUID] = None,
        include_deleted: bool = False
    ) -> List[Patient]:
        """Get all patients with pagination, optionally filtered by doctor_id or org_id"""
        query = select(Patient).options(selectinload(Patient.doctor))
        
        # Filter by doctor_id if provided
        if doctor_id is not None:
            query = query.filter(Patient.doctor_id == doctor_id)
        
        # Filter by organization_id if provided (through doctor's org_id)
        if org_id is not None:
            # Join with User table to filter by organization
            # Use left join to include patients without doctors, but filter them out
            query = query.join(User, Patient.doctor_id == User.id, isouter=False).filter(User.org_id == org_id)
        
        # Filter out deleted patients unless explicitly requested
        if not include_deleted:
            query = query.filter(Patient.is_deleted == False)
        
        result = await self.db.execute(query.offset(skip).limit(limit))
        return result.scalars().all()
    
    async def create_patient(self, patient_data: PatientCreate, doctor_id: Optional[UUID] = None) -> Patient:
        """Create a new patient"""
        # Use doctor_id from patient_data if provided, otherwise use the passed doctor_id
        final_doctor_id = patient_data.doctor_id if patient_data.doctor_id else doctor_id
        
        # Validate doctor exists if doctor_id is provided
        if final_doctor_id:
            doctor = await self.db.execute(
                select(User).filter(User.id == final_doctor_id)
            )
            doctor = doctor.scalar_one_or_none()
            if not doctor:
                raise ValueError(f"Doctor with ID {final_doctor_id} not found")
            # Optionally validate that the user is actually a doctor
            if doctor.role != "doctor":
                raise ValueError(f"User with ID {final_doctor_id} is not a doctor")
        
        db_patient = Patient(
            doctor_id=final_doctor_id,
            full_name=patient_data.full_name,
            date_of_birth=patient_data.date_of_birth,
            age=patient_data.age,
            gender=patient_data.gender,
            contact_number=patient_data.contact_number,
            email=patient_data.email,
            medical_history=patient_data.medical_history,
            notes=patient_data.notes,
        )
        self.db.add(db_patient)
        await self.db.commit()
        await self.db.refresh(db_patient)
        # Reload with doctor relationship
        return await self.get_by_id(db_patient.id, include_deleted=True)
    
    async def update_patient(
        self,
        patient_id: UUID,
        doctor_id: Optional[UUID] = None,
        full_name: Optional[str] = None,
        date_of_birth: Optional[date] = None,
        age: Optional[int] = None,
        gender: Optional[str] = None,
        contact_number: Optional[str] = None,
        email: Optional[str] = None,
        medical_history: Optional[str] = None,
        notes: Optional[str] = None,
        is_deleted: Optional[bool] = None
    ) -> Optional[Patient]:
        """Update patient information"""
        patient = await self.get_by_id(patient_id, include_deleted=True)
        if not patient:
            return None
        
        # Validate doctor exists if doctor_id is being updated
        if doctor_id is not None:
            doctor = await self.db.execute(
                select(User).filter(User.id == doctor_id)
            )
            doctor = doctor.scalar_one_or_none()
            if not doctor:
                raise ValueError(f"Doctor with ID {doctor_id} not found")
            # Optionally validate that the user is actually a doctor
            if doctor.role != "doctor":
                raise ValueError(f"User with ID {doctor_id} is not a doctor")
            patient.doctor_id = doctor_id
        
        # Update fields if provided
        if full_name is not None:
            patient.full_name = full_name
        if date_of_birth is not None:
            patient.date_of_birth = date_of_birth
        if age is not None:
            patient.age = age
        if gender is not None:
            patient.gender = gender
        if contact_number is not None:
            patient.contact_number = contact_number
        if email is not None:
            patient.email = email
        if medical_history is not None:
            patient.medical_history = medical_history
        if notes is not None:
            patient.notes = notes
        if is_deleted is not None:
            patient.is_deleted = is_deleted
        
        await self.db.commit()
        await self.db.refresh(patient)
        # Reload with doctor relationship
        return await self.get_by_id(patient.id, include_deleted=True)
    
    async def delete_patient(self, patient_id: UUID, hard_delete: bool = False) -> bool:
        """Delete a patient (soft delete by default, hard delete if specified)"""
        patient = await self.get_by_id(patient_id, include_deleted=True)
        if not patient:
            return False
        
        if hard_delete:
            await self.db.delete(patient)
        else:
            patient.is_deleted = True
        
        await self.db.commit()
        return True
    
    async def get_patients_by_doctor(self, doctor_id: UUID, include_deleted: bool = False) -> List[Patient]:
        """Get all patients for a specific doctor"""
        return await self.get_all(doctor_id=doctor_id, include_deleted=include_deleted)

