"""
EEG preprocessing service for signal processing and analysis
Applies filtering, ICA, and frequency domain analysis following standard neuroscience practices
"""
import mne
import numpy as np
from typing import Dict, List, Optional
from scipy import signal
import io
import base64
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt


class EEGPreprocessingService:
    """Service for EEG signal preprocessing and analysis"""
    
    def __init__(self, file_path: str):
        """Initialize with EEG file path"""
        self.file_path = file_path
        self.raw = None
        self.raw_filtered = None
        self.raw_ica = None
        
    def load_eeg_file(self) -> bool:
        """Load EEG file (EDF format)"""
        try:
            self.raw = mne.io.read_raw_edf(self.file_path, preload=True)
            return True
        except Exception as e:
            print(f"Error loading EEG file: {e}")
            return False
    
    def get_raw_signal(self, duration: int = None) -> Dict:
        """Get raw EEG signal data. If duration is None, returns full recording."""
        if not self.raw:
            return {"error": "EEG file not loaded"}
        
        # Get signal data - full length if duration not specified
        if duration is None:
            data, times = self.raw[:, :]
        else:
            data, times = self.raw[:, :int(self.raw.info['sfreq'] * duration)]
        
        return {
            "channels": self.raw.ch_names,
            "data": data.tolist(),
            "times": times.tolist(),
            "sampling_rate": self.raw.info['sfreq'],
            "n_channels": self.raw.info['nchan'],
        }
    
    def apply_bandpass_filter(self, l_freq: float = 0.1, h_freq: float = None) -> Dict:
        """Apply bandpass filter to EEG signal"""
        if not self.raw:
            return {"error": "EEG file not loaded"}
        
        try:
            # Get sampling rate and calculate maximum safe frequency
            sfreq = self.raw.info['sfreq']
            nyquist_freq = sfreq / 2
            
            # If h_freq not specified or exceeds Nyquist, use safe default
            if h_freq is None:
                h_freq = min(30.0, nyquist_freq - 1)
            else:
                h_freq = min(h_freq, nyquist_freq - 1)
            
            # Make a copy and apply filter
            self.raw_filtered = self.raw.copy()
            self.raw_filtered.filter(l_freq, h_freq)
            
            # Get filtered signal data (full length)
            data, times = self.raw_filtered[:, :]
            
            return {
                "status": "success",
                "message": f"Bandpass filter applied ({l_freq}-{h_freq} Hz)",
                "channels": self.raw_filtered.ch_names,
                "data": data.tolist(),
                "times": times.tolist(),
                "sampling_rate": self.raw_filtered.info['sfreq'],
            }
        except Exception as e:
            return {"error": f"Filter error: {e}"}
    
    def _generate_ica_component_topomap(self, ica, component_idx: int, ch_names: List[str]) -> str:
        """Generate a clean topomap image for a single ICA component"""
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            from matplotlib.patches import Circle, Wedge
            
            # Get the component weights
            components = ica.get_components()
            weights = components[component_idx]
            
            fig, ax = plt.subplots(1, 1, figsize=(2.5, 2.5), facecolor='#1e293b')
            ax.set_facecolor('#1e293b')
            
            # Create head outline
            head_circle = Circle((0, 0), 1.0, fill=False, color='#475569', linewidth=1.5)
            ax.add_patch(head_circle)
            
            # Add nose (subtle)
            nose_x = [0, -0.08, 0.08]
            nose_y = [1.1, 1.0, 1.0]
            ax.fill(nose_x, nose_y, color='#475569')
            
            # Add ears (subtle)
            left_ear = Wedge((-1.02, 0), 0.1, 60, 300, width=0.03, color='#475569')
            right_ear = Wedge((1.02, 0), 0.1, 240, 480, width=0.03, color='#475569')
            ax.add_patch(left_ear)
            ax.add_patch(right_ear)
            
            # Create channel positions in a brain-like layout
            positions = self._create_brain_layout(ch_names)
            
            # Normalize weights for colormap (centered at 0)
            max_abs = np.max(np.abs(weights))
            if max_abs == 0:
                max_abs = 1
            
            # Create diverging colormap (RdBu_r - red for positive, blue for negative)
            cmap = plt.cm.RdBu_r
            
            # Plot channels as colored circles - no labels for cleaner look
            for i, (ch_name, pos) in enumerate(zip(ch_names, positions)):
                # Normalize to 0-1 range centered at 0.5
                normalized = (weights[i] / max_abs + 1) / 2
                color = cmap(normalized)
                circle = Circle(pos, 0.10, color=color, ec='white', linewidth=1, zorder=10)
                ax.add_patch(circle)
            
            ax.set_xlim(-1.2, 1.2)
            ax.set_ylim(-1.15, 1.2)
            ax.set_aspect('equal')
            ax.axis('off')
            
            plt.tight_layout(pad=0.2)
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#1e293b', edgecolor='none', 
                       bbox_inches='tight', dpi=100)
            buf.seek(0)
            
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating ICA component topomap: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def apply_ica(self, n_components: int = 15, exclude: List[int] = None) -> Dict:
        """Apply Independent Component Analysis (ICA) for artifact removal"""
        if not self.raw_filtered:
            self.raw_filtered = self.raw.copy() if self.raw else None
        
        if not self.raw_filtered:
            return {"error": "Filtered EEG data not available"}
        
        try:
            # Create and fit ICA
            ica = mne.preprocessing.ICA(n_components=n_components, random_state=42)
            ica.fit(self.raw_filtered)
            
            # Apply ICA
            self.raw_ica = self.raw_filtered.copy()
            if exclude:
                ica.exclude = exclude
            ica.apply(self.raw_ica)
            
            # Get ICA-processed signal data (full length)
            data, times = self.raw_ica[:, :]
            
            # Extract ICA components for visualization with topomap images
            ica_components = ica.get_components()
            component_data = []
            component_images = {}
            
            for i in range(min(10, n_components)):
                # Generate topomap image for this component
                topomap_img = self._generate_ica_component_topomap(
                    ica, i, self.raw_filtered.ch_names
                )
                
                component_data.append({
                    "id": f"ICA{i:03d}",
                    "values": ica_components[i].tolist(),
                    "channel_names": self.raw_filtered.ch_names
                })
                
                if topomap_img:
                    component_images[f"ICA{i:03d}"] = topomap_img
            
            return {
                "status": "success",
                "message": f"ICA applied with {n_components} components",
                "excluded_components": exclude or [],
                "channels": self.raw_ica.ch_names,
                "data": data.tolist(),
                "times": times.tolist(),
                "sampling_rate": self.raw_ica.info['sfreq'],
                "ica_components": component_data,
                "ica_component_images": component_images,
                "n_components": n_components,
            }
        except Exception as e:
            return {"error": f"ICA error: {str(e)}"}
    
    def compute_power_spectral_density(self, fmin: float = 0.5, fmax: float = 30.0) -> Dict:
        """Compute Power Spectral Density (PSD) for all channels"""
        eeg_data = self.raw_ica if self.raw_ica is not None else self.raw_filtered if self.raw_filtered is not None else self.raw
        
        if not eeg_data:
            return {"error": "EEG data not available"}
        
        try:
            # Compute PSD using multitaper method
            psd, freqs = mne.time_frequency.psd_array_multitaper(
                eeg_data.get_data(),
                sfreq=eeg_data.info['sfreq'],
                fmin=fmin,
                fmax=fmax
            )
            
            # Prepare per-channel data for visualization
            psd_by_channel = {}
            channel_stats = {}
            
            for i, ch_name in enumerate(eeg_data.ch_names):
                psd_values = psd[i].tolist()
                psd_by_channel[ch_name] = psd_values
                
                # Calculate statistics for each channel
                channel_stats[ch_name] = {
                    "max": float(np.max(psd[i])),
                    "min": float(np.min(psd[i])),
                    "mean": float(np.mean(psd[i])),
                    "peak_freq": float(freqs[np.argmax(psd[i])]),
                    "total_power": float(np.trapz(psd[i], freqs)),
                }
            
            # Generate PSD overlay plot as base64 image
            psd_image = self._generate_psd_plot(psd, freqs, eeg_data.ch_names)
            
            return {
                "status": "success",
                "frequencies": freqs.tolist(),
                "psd_by_channel": psd_by_channel,
                "mean_psd": psd.mean(axis=0).tolist(),
                "channels": eeg_data.ch_names,
                "channel_stats": channel_stats,
                "psd_image": psd_image,  # Base64 encoded image
            }
        except Exception as e:
            return {"error": f"PSD computation error: {str(e)}"}
    
    def _generate_psd_plot(self, psd: np.ndarray, freqs: np.ndarray, ch_names: List[str]) -> str:
        """Generate PSD overlay plot as base64 PNG image"""
        try:
            fig, ax = plt.subplots(figsize=(12, 6), dpi=100)
            fig.patch.set_facecolor('#0f172a')
            ax.set_facecolor('#1e293b')
            
            # Define colors for channels
            colors = plt.cm.tab20(np.linspace(0, 1, len(ch_names)))
            
            for i, ch_name in enumerate(ch_names):
                ax.plot(freqs, psd[i], label=ch_name, color=colors[i], linewidth=1.5, alpha=0.8)
            
            # Add frequency band shading
            bands = [
                ('Delta', 0.5, 4, '#ef444433'),
                ('Theta', 4, 8, '#f9731633'),
                ('Alpha', 8, 12, '#eab30833'),
                ('Beta', 12, 30, '#3b82f633'),
            ]
            
            for name, fmin, fmax, color in bands:
                ax.axvspan(fmin, fmax, alpha=0.15, color=color[:-2], label=f'{name} ({fmin}-{fmax} Hz)')
            
            ax.set_xlabel('Frequency (Hz)', fontsize=12, color='#e2e8f0')
            ax.set_ylabel('Power Spectral Density (V²/Hz)', fontsize=12, color='#e2e8f0')
            ax.set_title('Power Spectral Density - All Channels', fontsize=14, color='white', fontweight='bold')
            
            # Style axes
            ax.tick_params(colors='#94a3b8')
            ax.spines['bottom'].set_color('#475569')
            ax.spines['top'].set_color('#475569')
            ax.spines['left'].set_color('#475569')
            ax.spines['right'].set_color('#475569')
            ax.grid(True, alpha=0.3, color='#475569')
            
            # Add legend
            ax.legend(loc='upper right', fontsize=8, ncol=2, facecolor='#1e293b', 
                     edgecolor='#475569', labelcolor='#e2e8f0')
            
            plt.tight_layout()
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#0f172a', edgecolor='none', bbox_inches='tight')
            buf.seek(0)
            
            # Encode to base64
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating PSD plot: {e}")
            return None
    
    def compute_frequency_bands_power(self) -> Dict:
        """Compute power in frequency bands (Delta, Theta, Alpha, Beta)"""
        eeg_data = self.raw_ica if self.raw_ica is not None else self.raw_filtered if self.raw_filtered is not None else self.raw
        
        if not eeg_data:
            return {"error": "EEG data not available"}
        
        try:
            # Define frequency bands
            bands = {
                "delta": (0.5, 4),
                "theta": (4, 8),
                "alpha": (8, 12),
                "beta": (12, 30),
            }
            
            # Compute PSD once for the full range (more efficient)
            psd_full, freqs_full = mne.time_frequency.psd_array_multitaper(
                eeg_data.get_data(),
                sfreq=eeg_data.info['sfreq'],
                fmin=0.1,
                fmax=40,
                verbose=0
            )
            
            band_data = {}
            for band_name, (fmin, fmax) in bands.items():
                # Create frequency mask for this band
                freq_mask = (freqs_full >= fmin) & (freqs_full <= fmax)
                
                band_power = {}
                band_powers_list = []
                
                # Compute power in band for each channel
                for i, ch_name in enumerate(eeg_data.ch_names):
                    # Get PSD values in this band
                    psd_band = psd_full[i][freq_mask]
                    
                    # Integrate power in band using trapezoidal rule
                    # This gives power in V²/Hz, so multiply by band width for total power
                    band_width = fmax - fmin
                    # Convert to proper units: mean PSD * bandwidth * scale for visibility
                    band_pow = float(np.mean(psd_band) * band_width * 1e12)  # Scale to pV²
                    
                    band_power[ch_name] = max(band_pow, 0)  # Ensure non-negative
                    band_powers_list.append(band_pow)
                
                # Mean power across channels
                mean_power = float(np.mean(band_powers_list)) if band_powers_list else 0.0
                
                band_data[band_name] = {
                    "freq_range": [fmin, fmax],
                    "power_by_channel": band_power,
                    "mean_power": mean_power,
                }
            
            return {
                "status": "success",
                "bands": band_data,
                "channels": eeg_data.ch_names,
            }
        except Exception as e:
            print(f"Frequency band computation error: {e}")
            import traceback
            traceback.print_exc()
            return {"error": f"Frequency band error: {str(e)}"}
    
    def get_channel_info(self) -> Dict:
        """Get EEG channel information"""
        eeg_data = self.raw_ica if self.raw_ica is not None else self.raw_filtered if self.raw_filtered is not None else self.raw
        
        if not eeg_data:
            return {"error": "EEG data not available"}
        
        return {
            "channels": eeg_data.ch_names,
            "n_channels": len(eeg_data.ch_names),
            "sampling_rate": eeg_data.info['sfreq'],
            "duration": eeg_data.times[-1],
            "n_samples": len(eeg_data.times),
        }
    
    def compute_topomaps(self) -> Dict:
        """Compute topographic maps for each frequency band with visualization"""
        eeg_data = self.raw_ica if self.raw_ica is not None else self.raw_filtered if self.raw_filtered is not None else self.raw
        
        if not eeg_data:
            return {"error": "EEG data not available"}
        
        try:
            # Define frequency bands with display colors
            bands = {
                "delta": {"range": (0.5, 4), "color": "#ef4444", "label": "Delta (0.5-4 Hz)"},
                "theta": {"range": (4, 8), "color": "#f97316", "label": "Theta (4-8 Hz)"},
                "alpha": {"range": (8, 12), "color": "#eab308", "label": "Alpha (8-12 Hz)"},
                "beta": {"range": (12, 30), "color": "#3b82f6", "label": "Beta (12-30 Hz)"},
            }
            
            # Compute PSD once for all bands
            psd_full, freqs_full = mne.time_frequency.psd_array_multitaper(
                eeg_data.get_data(),
                sfreq=eeg_data.info['sfreq'],
                fmin=0.1,
                fmax=40,
                verbose=0
            )
            
            ch_names = eeg_data.ch_names
            n_channels = len(ch_names)
            
            topomap_data = {}
            topomap_images = {}
            
            for band_name, band_info in bands.items():
                fmin, fmax = band_info["range"]
                
                # Create frequency mask
                freq_mask = (freqs_full >= fmin) & (freqs_full <= fmax)
                
                # Get mean PSD values for each channel in this band
                band_psd = psd_full[:, freq_mask]
                
                # Compute mean power per channel
                channel_powers = np.mean(band_psd, axis=1)
                
                # Generate topomap image (custom visualization for bipolar montage)
                topomap_img = self._generate_custom_topomap(
                    channel_powers, 
                    ch_names,
                    band_info["label"],
                    band_info["color"]
                )
                
                # Also keep channel position data for fallback SVG
                channel_positions = self._get_channel_positions(eeg_data, channel_powers)
                
                topomap_data[band_name] = {
                    "freq_range": [fmin, fmax],
                    "label": band_info["label"],
                    "channel_positions": channel_positions,
                    "min_power": float(np.min(channel_powers)),
                    "max_power": float(np.max(channel_powers)),
                    "mean_power": float(np.mean(channel_powers)),
                }
                
                if topomap_img:
                    topomap_images[band_name] = topomap_img
            
            # Generate combined topomap figure with all bands
            combined_image = self._generate_combined_custom_topomaps(psd_full, freqs_full, bands, ch_names)
            
            return {
                "status": "success",
                "topomaps": topomap_data,
                "topomap_images": topomap_images,  # Individual band images
                "combined_topomap_image": combined_image,  # All bands in one figure
                "channels": eeg_data.ch_names,
            }
        except Exception as e:
            print(f"Topomap computation error: {e}")
            import traceback
            traceback.print_exc()
            return {"error": f"Topomap error: {str(e)}"}
    
    def _get_channel_positions(self, eeg_data, channel_powers) -> List[Dict]:
        """Get channel 2D positions for fallback visualization"""
        try:
            montage = eeg_data.get_montage()
            if montage is None:
                # Create circular layout
                n_channels = len(eeg_data.ch_names)
                angles = np.linspace(0, 2 * np.pi, n_channels, endpoint=False)
                pos_x = np.cos(angles)
                pos_y = np.sin(angles)
            else:
                pos_2d = mne.viz.topomap.get_pos_2d(montage, eeg_data.ch_names)
                pos_x = pos_2d[:, 0]
                pos_y = pos_2d[:, 1]
            
            # Normalize positions
            if np.max(np.abs(pos_x)) > 0:
                pos_x = pos_x / np.max(np.abs(pos_x))
            if np.max(np.abs(pos_y)) > 0:
                pos_y = pos_y / np.max(np.abs(pos_y))
            
            channel_positions = []
            for i, ch_name in enumerate(eeg_data.ch_names):
                channel_positions.append({
                    "channel": ch_name,
                    "x": float(pos_x[i]),
                    "y": float(pos_y[i]),
                    "power": float(channel_powers[i] * 1e12),  # Scale to pV²
                })
            return channel_positions
        except Exception:
            return []
    
    def _generate_custom_topomap(self, channel_powers: np.ndarray, ch_names: List[str], 
                                  title: str, accent_color: str) -> Optional[str]:
        """Generate a clean topomap visualization without labels"""
        try:
            from matplotlib.patches import Circle, Wedge
            from matplotlib.collections import PatchCollection
            import matplotlib.colors as mcolors
            
            n_channels = len(ch_names)
            
            # Create figure with dark theme - clean and minimal
            fig, ax = plt.subplots(figsize=(4, 4), dpi=100)
            fig.patch.set_facecolor('#0f172a')
            ax.set_facecolor('#0f172a')
            
            # Create head outline
            head_circle = Circle((0, 0), 1.0, fill=False, color='#475569', linewidth=2)
            ax.add_patch(head_circle)
            
            # Add nose (subtle)
            nose_x = [0, -0.08, 0.08]
            nose_y = [1.12, 1.0, 1.0]
            ax.fill(nose_x, nose_y, color='#475569')
            
            # Add ears (subtle)
            left_ear = Wedge((-1.03, 0), 0.12, 60, 300, width=0.04, color='#475569')
            right_ear = Wedge((1.03, 0), 0.12, 240, 480, width=0.04, color='#475569')
            ax.add_patch(left_ear)
            ax.add_patch(right_ear)
            
            # Create channel positions in a brain-like layout
            positions = self._create_brain_layout(ch_names)
            
            # Normalize power for colormap
            power_min = np.min(channel_powers)
            power_max = np.max(channel_powers)
            power_range = power_max - power_min if power_max > power_min else 1
            normalized_powers = (channel_powers - power_min) / power_range
            
            # Create colormap (RdBu_r - red for high, blue for low)
            cmap = plt.cm.RdBu_r
            
            # Plot channels as colored circles - larger, no labels
            for i, (ch_name, pos) in enumerate(zip(ch_names, positions)):
                color = cmap(normalized_powers[i])
                circle = Circle(pos, 0.10, color=color, ec='white', linewidth=1.5, zorder=10)
                ax.add_patch(circle)
            
            ax.set_xlim(-1.25, 1.25)
            ax.set_ylim(-1.2, 1.25)
            ax.set_aspect('equal')
            ax.axis('off')
            
            plt.tight_layout(pad=0.5)
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#0f172a', edgecolor='none', 
                       bbox_inches='tight', dpi=120)
            buf.seek(0)
            
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating custom topomap: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _create_brain_layout(self, ch_names: List[str]) -> List[tuple]:
        """Create brain-like 2D positions for channels based on their names"""
        # Standard 10-20 positions (approximate)
        standard_positions = {
            'Fp1': (-0.3, 0.9), 'Fp2': (0.3, 0.9), 'Fpz': (0, 0.9),
            'F7': (-0.8, 0.5), 'F3': (-0.4, 0.55), 'Fz': (0, 0.55), 'F4': (0.4, 0.55), 'F8': (0.8, 0.5),
            'T7': (-0.95, 0), 'T3': (-0.95, 0), 'C3': (-0.45, 0), 'Cz': (0, 0), 'C4': (0.45, 0), 'T4': (0.95, 0), 'T8': (0.95, 0),
            'T5': (-0.8, -0.5), 'P7': (-0.8, -0.5), 'P3': (-0.4, -0.55), 'Pz': (0, -0.55), 'P4': (0.4, -0.55), 'P8': (0.8, -0.5), 'T6': (0.8, -0.5),
            'O1': (-0.3, -0.9), 'Oz': (0, -0.9), 'O2': (0.3, -0.9),
            'A1': (-1.1, 0), 'A2': (1.1, 0),
        }
        
        positions = []
        n_channels = len(ch_names)
        
        for i, ch_name in enumerate(ch_names):
            ch_upper = ch_name.upper().replace(' ', '')
            
            # Try to find exact match
            found = False
            for std_name, pos in standard_positions.items():
                if std_name.upper() in ch_upper or ch_upper in std_name.upper():
                    positions.append(pos)
                    found = True
                    break
            
            if not found:
                # For bipolar montage (e.g., "FP1-F3"), try to interpolate between electrodes
                if '-' in ch_name:
                    parts = ch_name.upper().replace(' ', '').split('-')
                    pos1 = None
                    pos2 = None
                    for std_name, pos in standard_positions.items():
                        if std_name.upper() in parts[0] or parts[0] in std_name.upper():
                            pos1 = pos
                        if len(parts) > 1 and (std_name.upper() in parts[1] or parts[1] in std_name.upper()):
                            pos2 = pos
                    
                    if pos1 and pos2:
                        # Midpoint between the two electrodes
                        positions.append(((pos1[0] + pos2[0]) / 2, (pos1[1] + pos2[1]) / 2))
                        found = True
                    elif pos1:
                        positions.append(pos1)
                        found = True
                    elif pos2:
                        positions.append(pos2)
                        found = True
            
            if not found:
                # Fall back to circular layout
                angle = 2 * np.pi * i / n_channels - np.pi / 2
                radius = 0.7
                positions.append((radius * np.cos(angle), radius * np.sin(angle)))
        
        return positions
    
    def _generate_combined_custom_topomaps(self, psd_full: np.ndarray, freqs: np.ndarray, 
                                            bands: Dict, ch_names: List[str]) -> Optional[str]:
        """Generate combined figure with all frequency band topomaps"""
        try:
            from matplotlib.patches import Circle, Wedge
            
            n_channels = len(ch_names)
            positions = self._create_brain_layout(ch_names)
            
            fig, axes = plt.subplots(1, 4, figsize=(18, 5), dpi=100)
            fig.patch.set_facecolor('#0f172a')
            
            for idx, (band_name, band_info) in enumerate(bands.items()):
                ax = axes[idx]
                ax.set_facecolor('#0f172a')
                
                fmin, fmax = band_info["range"]
                freq_mask = (freqs >= fmin) & (freqs <= fmax)
                band_psd = psd_full[:, freq_mask]
                channel_powers = np.mean(band_psd, axis=1)
                
                # Create head outline
                head_circle = Circle((0, 0), 1.0, fill=False, color='#64748b', linewidth=2)
                ax.add_patch(head_circle)
                
                # Add nose
                ax.fill([0, -0.1, 0.1], [1.15, 1.0, 1.0], color='#64748b')
                
                # Add ears
                left_ear = Wedge((-1.05, 0), 0.15, 60, 300, width=0.05, color='#64748b')
                right_ear = Wedge((1.05, 0), 0.15, 240, 480, width=0.05, color='#64748b')
                ax.add_patch(left_ear)
                ax.add_patch(right_ear)
                
                # Normalize power
                power_min = np.min(channel_powers)
                power_max = np.max(channel_powers)
                power_range = power_max - power_min if power_max > power_min else 1
                normalized_powers = (channel_powers - power_min) / power_range
                
                cmap = plt.cm.RdBu_r
                
                # Plot channels
                for i, (ch_name, pos) in enumerate(zip(ch_names, positions)):
                    color = cmap(normalized_powers[i])
                    circle = Circle(pos, 0.08, color=color, ec='white', linewidth=1, zorder=10)
                    ax.add_patch(circle)
                
                ax.set_xlim(-1.3, 1.3)
                ax.set_ylim(-1.2, 1.25)
                ax.set_aspect('equal')
                ax.axis('off')
                ax.set_title(band_info["label"], fontsize=11, color='white', fontweight='bold')
                
                # Add colorbar to last plot
                if idx == 3:
                    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(vmin=power_min, vmax=power_max))
                    sm.set_array([])
                    cbar = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
                    cbar.ax.tick_params(colors='#e2e8f0', labelsize=8)
                    cbar.set_label('Power', color='#e2e8f0', fontsize=9)
            
            fig.suptitle('Frequency Band Topographic Maps', fontsize=14, color='white', 
                        fontweight='bold', y=1.02)
            
            plt.tight_layout()
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#0f172a', edgecolor='none', 
                       bbox_inches='tight', dpi=100)
            buf.seek(0)
            
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating combined topomaps: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _generate_topomap_image(self, data: np.ndarray, info, title: str, accent_color: str) -> Optional[str]:
        """Generate a single topomap as base64 PNG image using MNE"""
        try:
            # Check if we have valid channel positions
            try:
                # Try to get positions from info
                pos = mne.channels.layout._find_topomap_coords(info, None)
            except Exception:
                # Fall back to circular layout if positions not available
                return None
            
            fig, ax = plt.subplots(figsize=(4, 4), dpi=120)
            fig.patch.set_facecolor('#0f172a')
            ax.set_facecolor('#0f172a')
            
            # Create topomap using MNE
            im, _ = mne.viz.plot_topomap(
                data,
                info,
                axes=ax,
                cmap='RdBu_r',
                show=False,
                contours=6,
                sensors=True,
                names=None,
            )
            
            # Add colorbar
            cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            cbar.ax.tick_params(colors='#e2e8f0', labelsize=8)
            cbar.set_label('Power (V²/Hz)', color='#e2e8f0', fontsize=9)
            
            ax.set_title(title, fontsize=11, color='white', fontweight='bold', pad=10)
            
            plt.tight_layout()
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#0f172a', edgecolor='none', 
                       bbox_inches='tight', dpi=120)
            buf.seek(0)
            
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating single topomap: {e}")
            return None
    
    def _generate_combined_topomaps(self, psd_full: np.ndarray, freqs: np.ndarray, 
                                     bands: Dict, info) -> Optional[str]:
        """Generate combined figure with all frequency band topomaps"""
        try:
            # Check if we have valid positions
            try:
                pos = mne.channels.layout._find_topomap_coords(info, None)
            except Exception:
                return None
            
            fig, axes = plt.subplots(1, 4, figsize=(16, 4), dpi=100)
            fig.patch.set_facecolor('#0f172a')
            
            for idx, (band_name, band_info) in enumerate(bands.items()):
                ax = axes[idx]
                ax.set_facecolor('#0f172a')
                
                fmin, fmax = band_info["range"]
                freq_mask = (freqs >= fmin) & (freqs <= fmax)
                band_psd = psd_full[:, freq_mask]
                channel_powers = np.mean(band_psd, axis=1)
                
                try:
                    im, _ = mne.viz.plot_topomap(
                        channel_powers,
                        info,
                        axes=ax,
                        cmap='RdBu_r',
                        show=False,
                        contours=4,
                        sensors=True,
                        names=None,
                    )
                    ax.set_title(band_info["label"], fontsize=11, color='white', fontweight='bold')
                except Exception as e:
                    # Fallback: just show text
                    ax.text(0.5, 0.5, f'{band_name.upper()}\nNo positions', 
                           ha='center', va='center', color='white', transform=ax.transAxes)
                    ax.set_title(band_info["label"], fontsize=11, color='white', fontweight='bold')
            
            # Add a single colorbar for all
            fig.subplots_adjust(right=0.92)
            cbar_ax = fig.add_axes([0.94, 0.15, 0.02, 0.7])
            cbar = fig.colorbar(im, cax=cbar_ax)
            cbar.ax.tick_params(colors='#e2e8f0', labelsize=9)
            cbar.set_label('Power (V²/Hz)', color='#e2e8f0', fontsize=10)
            
            fig.suptitle('Frequency Band Topographic Maps', fontsize=14, color='white', 
                        fontweight='bold', y=1.02)
            
            plt.tight_layout()
            
            # Save to bytes
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor='#0f172a', edgecolor='none', 
                       bbox_inches='tight', dpi=100)
            buf.seek(0)
            
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            
            return f"data:image/png;base64,{img_base64}"
        except Exception as e:
            print(f"Error generating combined topomaps: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_full_preprocessing_report(self) -> Dict:
        """Get complete preprocessing report with all analysis"""
        try:
            # Execute processing steps in sequence
            raw_signal = self.get_raw_signal()
            filtered_signal = self.apply_bandpass_filter()
            ica_signal = self.apply_ica(exclude=[1, 2])
            psd = self.compute_power_spectral_density()
            frequency_bands = self.compute_frequency_bands_power()
            topomaps = self.compute_topomaps()
            
            report = {
                "channel_info": self.get_channel_info(),
                "raw_signal": raw_signal,
                "filtered_signal": filtered_signal,
                "ica_signal": ica_signal,
                "psd": psd,
                "frequency_bands": frequency_bands,
                "topomaps": topomaps,
            }
            return report
        except Exception as e:
            return {
                "error": f"Full preprocessing error: {str(e)}",
                "channel_info": self.get_channel_info() if self.raw else None,
            }
