"""
Report service for managing EEG analysis reports
"""
from typing import Optional, List
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from app.models.reports import Report
from app.schemas.reports import ReportCreateRequest, ReportUpdateRequest


class ReportService:
    """Service for managing reports"""
    
    @staticmethod
    async def create_report(
        db: AsyncSession,
        user_id: str,
        report_data: ReportCreateRequest
    ) -> Report:
        """Create a new report"""
        report = Report(
            title=report_data.title,
            report_type=report_data.report_type,
            eeg_file_id=report_data.eeg_file_id,
            created_by_id=user_id,
            seizure_count=report_data.seizure_count,
            total_seizure_duration_seconds=report_data.total_seizure_duration_seconds,
            seizure_percentage=report_data.seizure_percentage,
            seizure_events=report_data.seizure_events,
            clinical_notes=report_data.clinical_notes,
            clinical_recommendations=report_data.clinical_recommendations,
            recording_duration_minutes=report_data.recording_duration_minutes,
            num_channels=report_data.num_channels or 19,
            status="completed"
        )
        
        db.add(report)
        await db.commit()
        await db.refresh(report)
        return report
    
    @staticmethod
    async def get_report(db: AsyncSession, report_id: str) -> Optional[Report]:
        """Get a report by ID"""
        result = await db.execute(
            select(Report)
            .where(Report.id == report_id)
            .options(
                selectinload(Report.eeg_file),
                selectinload(Report.patient),
                selectinload(Report.created_by)
            )
        )
        return result.scalars().first()
    
    @staticmethod
    async def list_reports(
        db: AsyncSession,
        user_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
        report_type: Optional[str] = None,
        status: Optional[str] = None
    ) -> List[Report]:
        """List reports with optional filtering"""
        query = select(Report)
        
        # If user_id provided, filter by created_by_id
        if user_id:
            query = query.where(Report.created_by_id == user_id)
        
        # Filter by report type if provided
        if report_type:
            query = query.where(Report.report_type == report_type)
        
        # Filter by status if provided
        if status:
            query = query.where(Report.status == status)
        
        # Order by most recent first
        query = query.order_by(Report.generated_at.desc())
        
        # Apply pagination
        query = query.offset(skip).limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update_report(
        db: AsyncSession,
        report_id: str,
        update_data: ReportUpdateRequest
    ) -> Optional[Report]:
        """Update a report"""
        report = await ReportService.get_report(db, report_id)
        if not report:
            return None
        
        update_dict = update_data.dict(exclude_unset=True)
        for key, value in update_dict.items():
            setattr(report, key, value)
        
        await db.commit()
        await db.refresh(report)
        return report
    
    @staticmethod
    async def delete_report(db: AsyncSession, report_id: str) -> bool:
        """Delete a report"""
        report = await ReportService.get_report(db, report_id)
        if not report:
            return False
        
        await db.delete(report)
        await db.commit()
        return True
    
    @staticmethod
    async def list_reports_by_eeg_file(
        db: AsyncSession,
        eeg_file_id: str
    ) -> List[Report]:
        """Get all reports for a specific EEG file"""
        result = await db.execute(
            select(Report)
            .where(Report.eeg_file_id == eeg_file_id)
            .order_by(Report.generated_at.desc())
        )
        return result.scalars().all()
    
    @staticmethod
    async def list_reports_by_patient(
        db: AsyncSession,
        patient_id: str
    ) -> List[Report]:
        """Get all reports for a specific patient"""
        result = await db.execute(
            select(Report)
            .where(Report.patient_id == patient_id)
            .order_by(Report.generated_at.desc())
        )
        return result.scalars().all()
