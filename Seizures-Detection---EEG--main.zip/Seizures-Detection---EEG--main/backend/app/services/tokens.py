"""
Token service for managing JWT tokens and revocation
"""
import hashlib
from typing import Optional
from datetime import datetime, timedelta
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.models.users import Token


def hash_token(token: str) -> str:
    """Create a hash of the token for storage (don't store raw tokens)"""
    return hashlib.sha256(token.encode('utf-8')).hexdigest()


class TokenService:
    """Service for token-related operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_token(
        self,
        user_id: UUID,
        token: str,
        token_type: str,
        expires_at: datetime
    ) -> Token:
        """
        Create and store a new token.
        Deletes any existing token of the same type for this user to ensure
        only one token of each type exists per user (regardless of revocation status).
        """
        # Find and delete ALL existing tokens of the same type for this user
        # (including revoked ones, since unique constraint applies to all)
        existing_result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.user_id == user_id,
                    Token.token_type == token_type
                )
            )
        )
        existing_tokens = existing_result.scalars().all()
        for existing_token in existing_tokens:
            # Delete the old token (we only keep one token per type per user)
            await self.db.delete(existing_token)
        
        # Flush to ensure deletions are processed before insert
        await self.db.flush()
        
        # Create new token
        token_hash = hash_token(token)
        db_token = Token(
            user_id=user_id,
            token_hash=token_hash,
            token_type=token_type,
            expires_at=expires_at,
            is_revoked=False
        )
        self.db.add(db_token)
        await self.db.commit()
        await self.db.refresh(db_token)
        return db_token
    
    async def is_token_revoked(self, token: str) -> bool:
        """Check if a token is revoked"""
        token_hash = hash_token(token)
        result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.token_hash == token_hash,
                    Token.is_revoked == True
                )
            )
        )
        return result.scalar_one_or_none() is not None
    
    async def revoke_token(self, token: str) -> bool:
        """Revoke a token"""
        token_hash = hash_token(token)
        result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.token_hash == token_hash,
                    Token.is_revoked == False
                )
            )
        )
        db_token = result.scalar_one_or_none()
        if not db_token:
            return False
        
        db_token.is_revoked = True
        await self.db.commit()
        return True
    
    async def revoke_user_tokens(self, user_id: UUID, token_type: Optional[str] = None) -> int:
        """Revoke all tokens for a user, optionally filtered by type"""
        query = select(Token).filter(
            and_(
                Token.user_id == user_id,
                Token.is_revoked == False
            )
        )
        if token_type:
            query = query.filter(Token.token_type == token_type)
        
        result = await self.db.execute(query)
        tokens = result.scalars().all()
        
        count = 0
        for token in tokens:
            token.is_revoked = True
            count += 1
        
        if count > 0:
            await self.db.commit()
        
        return count
    
    async def revoke_refresh_token_and_related(self, refresh_token: str) -> bool:
        """Revoke a refresh token and its related access token (if any)"""
        token_hash = hash_token(refresh_token)
        result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.token_hash == token_hash,
                    Token.token_type == "refresh",
                    Token.is_revoked == False
                )
            )
        )
        db_token = result.scalar_one_or_none()
        if not db_token:
            return False
        
        # Revoke the refresh token
        db_token.is_revoked = True
        
        # Also revoke any access tokens created around the same time for this user
        # (within a small window, e.g., 5 minutes)
        window_start = db_token.created_at
        window_end = datetime.utcnow()
        
        access_tokens_result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.user_id == db_token.user_id,
                    Token.token_type == "access",
                    Token.is_revoked == False,
                    Token.created_at >= window_start,
                    Token.created_at <= window_end
                )
            )
        )
        access_tokens = access_tokens_result.scalars().all()
        for access_token in access_tokens:
            access_token.is_revoked = True
        
        await self.db.commit()
        return True
    
    async def cleanup_expired_tokens(self) -> int:
        """Remove expired and revoked tokens older than 7 days"""
        cutoff_date = datetime.utcnow() - timedelta(days=7)
        result = await self.db.execute(
            select(Token).filter(
                and_(
                    Token.expires_at < cutoff_date,
                    Token.is_revoked == True
                )
            )
        )
        tokens = result.scalars().all()
        count = len(tokens)
        for token in tokens:
            await self.db.delete(token)
        
        if count > 0:
            await self.db.commit()
        
        return count

