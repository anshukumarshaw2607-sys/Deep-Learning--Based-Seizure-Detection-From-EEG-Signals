"""
PDF Report Generation Service
Generates professional PDF reports from seizure detection analysis results
"""
from io import BytesIO
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import logging

logger = logging.getLogger(__name__)


class PDFReportGenerator:
    """Generate professional PDF reports for seizure detection analysis"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles - HCI compliant and formal"""
        # Title style - Left aligned, professional
        self.styles.add(ParagraphStyle(
            name='ReportTitle',
            parent=self.styles['Heading1'],
            fontSize=22,
            textColor=colors.HexColor('#1a3a52'),
            spaceAfter=6,
            alignment=TA_LEFT,
            fontName='Helvetica-Bold',
            leftIndent=0,
            rightIndent=0
        ))
        
        # Subtitle/Organization info
        self.styles.add(ParagraphStyle(
            name='Subtitle',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#666666'),
            spaceAfter=18,
            alignment=TA_LEFT,
            fontName='Helvetica',
            leftIndent=0
        ))
        
        # Section heading style - Left aligned, formal
        self.styles.add(ParagraphStyle(
            name='SectionHeading',
            parent=self.styles['Heading2'],
            fontSize=12,
            textColor=colors.HexColor('#1a3a52'),
            spaceAfter=10,
            spaceBefore=14,
            fontName='Helvetica-Bold',
            leftIndent=0,
            borderPadding=0,
            textTransform=None
        ))
        
        # Normal text - Left aligned
        self.styles.add(ParagraphStyle(
            name='CustomNormal',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=8,
            alignment=TA_LEFT,
            leftIndent=0,
            leading=14
        ))
        
        # Body text with proper leading for readability
        self.styles.add(ParagraphStyle(
            name='FormalBodyText',
            parent=self.styles['Normal'],
            fontSize=10,
            leading=13,
            spaceAfter=8,
            alignment=TA_LEFT,
            leftIndent=0,
            rightIndent=0
        ))
    
    def generate_report(
        self,
        patient_name: str,
        edf_filename: str,
        analysis_date: datetime,
        doctor_name: str,
        seizure_count: int,
        total_seizure_duration: float,
        total_signal_duration: float,
        seizure_intervals: List[Dict[str, float]],
        clinical_notes: Optional[str] = None
    ) -> bytes:
        """
        Generate a professional PDF report
        
        Args:
            patient_name: Name of the patient
            edf_filename: Name of the EDF file analyzed
            analysis_date: Date/time of analysis
            doctor_name: Name of doctor who performed analysis
            seizure_count: Number of seizures detected
            total_seizure_duration: Total duration of all seizures (seconds)
            total_signal_duration: Total signal duration (seconds)
            seizure_intervals: List of seizure intervals [{'start': float, 'stop': float, 'duration': float}, ...]
            clinical_notes: Optional clinical notes to include in the report
        
        Returns:
            Bytes of the PDF file
        """
        try:
            # Create in-memory PDF with professional margins
            buffer = BytesIO()
            doc = SimpleDocTemplate(
                buffer, 
                pagesize=letter, 
                topMargin=0.75*inch, 
                bottomMargin=0.75*inch,
                leftMargin=0.75*inch,
                rightMargin=0.75*inch
            )
            story = []
            
            # Header: Title and subtitle
            story.append(Paragraph("EEG SEIZURE DETECTION REPORT", self.styles['ReportTitle']))
            story.append(Paragraph("Automated Electroencephalogram Analysis", self.styles['Subtitle']))
            story.append(Spacer(1, 0.15*inch))
            
            # Disclaimer Section - Professional styling
            disclaimer_text = "This analysis is for clinical decision support only and should be reviewed by a qualified healthcare professional."
            disclaimer_style = ParagraphStyle(
                name='Disclaimer',
                parent=self.styles['FormalBodyText'],
                fontSize=9,
                textColor=colors.HexColor('#c62828'),
                fontName='Helvetica-Bold',
                leftIndent=12,
                rightIndent=12,
                spaceAfter=12,
                borderPadding=8,
                borderColor=colors.HexColor('#e57373'),
                borderWidth=1.5,
                backColor=colors.HexColor('#ffebee'),
                alignment=TA_LEFT
            )
            story.append(Paragraph(disclaimer_text, disclaimer_style))
            story.append(Spacer(1, 0.25*inch))
            
            # Patient Information Section
            story.append(Paragraph("Patient Information", self.styles['SectionHeading']))
            patient_data = [
                ["Patient Name:", patient_name],
                ["EDF File Name:", edf_filename],
                ["Analysis Date:", analysis_date.strftime("%B %d, %Y")],
                ["Analysis Time:", analysis_date.strftime("%H:%M:%S")],
                ["Analyzing Doctor:", doctor_name],
            ]
            patient_table = Table(patient_data, colWidths=[2.2*inch, 3.8*inch])
            patient_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f5f5f5')),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1a3a52')),
                ('ALIGN', (0, 0), (0, -1), 'LEFT'),
                ('ALIGN', (1, 0), (1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 10),
                ('RIGHTPADDING', (0, 0), (-1, -1), 10),
                ('LINEBELOW', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc'))
            ]))
            story.append(patient_table)
            story.append(Spacer(1, 0.25*inch))
            
            # Analysis Summary Section
            story.append(Paragraph("Analysis Summary", self.styles['SectionHeading']))
            summary_data = [
                ["Metric", "Value"],
                ["Number of Seizures Detected", str(seizure_count)],
                ["Total Seizure Duration", f"{total_seizure_duration:.2f} seconds ({total_seizure_duration/60:.2f} minutes)"],
                ["Total Signal Duration", f"{total_signal_duration:.2f} seconds ({total_signal_duration/60:.2f} minutes)"],
                ["Seizure Percentage", f"{(total_seizure_duration/total_signal_duration*100):.2f}%"],
            ]
            summary_table = Table(summary_data, colWidths=[2.5*inch, 3.5*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a3a52')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 10),
                ('RIGHTPADDING', (0, 0), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f9f9f9')])
            ]))
            story.append(summary_table)
            story.append(Spacer(1, 0.25*inch))
            
            # Seizure Intervals Section
            if seizure_intervals:
                story.append(Paragraph("Detailed Seizure Intervals", self.styles['SectionHeading']))
                
                # Create seizure intervals table
                intervals_data = [["#", "Start Time (s)", "Stop Time (s)", "Duration (s)"]]
                for idx, interval in enumerate(seizure_intervals, 1):
                    start = interval.get('start', interval.get('start_time', 0))
                    stop = interval.get('stop', interval.get('stop_time', 0))
                    duration = stop - start
                    intervals_data.append([
                        str(idx),
                        f"{start:.2f}",
                        f"{stop:.2f}",
                        f"{duration:.2f}"
                    ])
                
                intervals_table = Table(intervals_data, colWidths=[0.5*inch, 1.7*inch, 1.7*inch, 1.7*inch])
                intervals_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a3a52')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
                    ('TOPPADDING', (0, 0), (-1, -1), 7),
                    ('LEFTPADDING', (0, 0), (-1, -1), 8),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc')),
                    ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f9f9f9')])
                ]))
                story.append(intervals_table)
            
            story.append(Spacer(1, 0.25*inch))
            
            # Clinical Notes Section
            if clinical_notes and clinical_notes.strip():
                story.append(Paragraph("Clinical Notes", self.styles['SectionHeading']))
                notes_paragraph = Paragraph(
                    clinical_notes.replace('\n', '<br/>'),
                    ParagraphStyle(
                        name='ClinicalNotes',
                        parent=self.styles['FormalBodyText'],
                        fontSize=10,
                        leftIndent=10,
                        rightIndent=10,
                        textColor=colors.HexColor('#333333'),
                        leading=13,
                        borderPadding=12,
                        backgroundColor=colors.HexColor('#fafafa'),
                        borderColor=colors.HexColor('#e0e0e0'),
                        borderWidth=0.5,
                        alignment=TA_LEFT
                    )
                )
                story.append(notes_paragraph)
                story.append(Spacer(1, 0.25*inch))
            
            # Footer - Professional and formal
            story.append(Spacer(1, 0.15*inch))
            footer_line_style = ParagraphStyle(
                name='FooterLine',
                parent=self.styles['Normal'],
                fontSize=1,
                textColor=colors.HexColor('#cccccc'),
                alignment=TA_LEFT
            )
            footer_text = f"Report generated on {datetime.now().strftime('%B %d, %Y at %H:%M:%S')}"
            story.append(Paragraph(footer_text, ParagraphStyle(
                name='Footer',
                parent=self.styles['Normal'],
                fontSize=8,
                textColor=colors.HexColor('#888888'),
                alignment=TA_LEFT
            )))
            
            # Build PDF
            doc.build(story)
            
            # Get PDF bytes
            pdf_bytes = buffer.getvalue()
            buffer.close()
            
            logger.info(f"PDF report generated successfully for patient: {patient_name}")
            return pdf_bytes
            
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}", exc_info=True)
            raise RuntimeError(f"Failed to generate PDF report: {str(e)}")
