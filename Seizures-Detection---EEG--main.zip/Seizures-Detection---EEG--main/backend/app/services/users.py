"""
User service for user management operations (Async)
"""
from typing import Optional, List
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.models.users import User, DoctorAssistant, Organization
from app.schemas.users import UserCreate
from app.core.security import get_password_hash
from app.utils.validators import require_valid_role


class UserService:
    """Service for user-related operations and doctor-assistant relationships"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    # User operations
    async def get_by_id(self, user_id: UUID) -> Optional[User]:
        """Get user by ID with organization relationship loaded"""
        result = await self.db.execute(
            select(User)
            .options(selectinload(User.organization))
            .filter(User.id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_email(self, email: str) -> Optional[User]:
        """Get user by email with organization relationship loaded"""
        result = await self.db.execute(
            select(User)
            .options(selectinload(User.organization))
            .filter(User.email == email)
        )
        return result.scalar_one_or_none()
    
    async def get_by_username(self, username: str) -> Optional[User]:
        """Get user by username with organization relationship loaded"""
        result = await self.db.execute(
            select(User)
            .options(selectinload(User.organization))
            .filter(User.username == username)
        )
        return result.scalar_one_or_none()
    
    async def get_all(self, skip: int = 0, limit: int = 100, org_id: Optional[UUID] = None) -> List[User]:
        """Get all users with pagination, optionally filtered by org_id, with organization relationship loaded"""
        query = select(User).options(selectinload(User.organization))
        if org_id is not None:
            query = query.filter(User.org_id == org_id)
        result = await self.db.execute(query.offset(skip).limit(limit))
        return result.scalars().all()
    
    async def create_user(self, user_data: UserCreate) -> User:
        """Create a new user"""
        # Validate role
        if user_data.role:
            require_valid_role(user_data.role)
        else:
            user_data.role = "assistant"  # Default role
        
        hashed_password = get_password_hash(user_data.password)
        db_user = User(
            email=user_data.email,
            username=user_data.username,
            password=hashed_password,
            full_name=user_data.full_name,
            title=user_data.title,
            org_id=user_data.org_id,
            role=user_data.role,
        )
        self.db.add(db_user)
        await self.db.commit()
        await self.db.refresh(db_user)
        return db_user
    
    async def update_user(
        self,
        user_id: UUID,
        email: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        role: Optional[str] = None,
        full_name: Optional[str] = None,
        title: Optional[str] = None,
        org_id: Optional[UUID] = None,
        is_active: Optional[bool] = None
    ) -> Optional[User]:
        """Update user information"""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        # Validate role if being updated
        if role:
            require_valid_role(role)
            user.role = role
        
        # Update fields if provided
        if email is not None:
            user.email = email
        if username is not None:
            user.username = username
        if password is not None:
            user.password = get_password_hash(password)
        if full_name is not None:
            user.full_name = full_name
        if title is not None:
            user.title = title
        if org_id is not None:
            user.org_id = org_id
        if is_active is not None:
            user.is_active = is_active
        
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def delete_user(self, user_id: UUID) -> bool:
        """Delete a user"""
        user = await self.get_by_id(user_id)
        if not user:
            return False
        
        await self.db.delete(user)
        await self.db.commit()
        return True
    
    # Doctor-Assistant relationship operations
    async def create_doctor_assistant_relationship(self, doctor_id: UUID, assistant_id: UUID) -> DoctorAssistant:
        """Create a doctor-assistant relationship"""
        # Check if relationship already exists
        existing = await self.get_doctor_assistant_by_assistant_id(assistant_id)
        if existing:
            raise ValueError("Assistant is already assigned to a doctor")
        
        relationship = DoctorAssistant(
            doctor_id=doctor_id,
            assistant_id=assistant_id
        )
        self.db.add(relationship)
        await self.db.commit()
        await self.db.refresh(relationship)
        return relationship
    
    async def get_doctor_assistant_by_assistant_id(self, assistant_id: UUID) -> Optional[DoctorAssistant]:
        """Get relationship by assistant ID"""
        result = await self.db.execute(
            select(DoctorAssistant).filter(DoctorAssistant.assistant_id == assistant_id)
        )
        return result.scalar_one_or_none()
    
    async def get_doctor_assistants_by_doctor_id(self, doctor_id: UUID) -> List[DoctorAssistant]:
        """Get all assistants under a doctor"""
        result = await self.db.execute(
            select(DoctorAssistant).filter(DoctorAssistant.doctor_id == doctor_id)
        )
        return result.scalars().all()
    
    async def get_doctor_by_assistant_id(self, assistant_id: UUID) -> Optional[User]:
        """Get the doctor for a given assistant"""
        relationship = await self.get_doctor_assistant_by_assistant_id(assistant_id)
        if not relationship:
            return None
        
        return await self.get_by_id(relationship.doctor_id)
    
    async def delete_doctor_assistant_relationship(self, assistant_id: UUID) -> bool:
        """Delete a doctor-assistant relationship"""
        relationship = await self.get_doctor_assistant_by_assistant_id(assistant_id)
        if not relationship:
            return False
        
        await self.db.delete(relationship)
        await self.db.commit()
        return True
    
    # Organization operations
    async def get_organization_by_id(self, organization_id: UUID) -> Optional[Organization]:
        """Get organization by ID"""
        result = await self.db.execute(select(Organization).filter(Organization.id == organization_id))
        return result.scalar_one_or_none()
    
    async def get_organization_by_name(self, name: str) -> Optional[Organization]:
        """Get organization by name"""
        result = await self.db.execute(select(Organization).filter(Organization.name == name))
        return result.scalar_one_or_none()
    
    async def create_organization(
        self, 
        name: str, 
        contact: Optional[str] = None,
        address: Optional[str] = None,
        description: Optional[str] = None
    ) -> Organization:
        """Create a new organization"""
        # Check if organization already exists
        existing = await self.get_organization_by_name(name)
        if existing:
            raise ValueError(f"Organization with name '{name}' already exists")
        
        organization = Organization(
            name=name,
            contact=contact,
            address=address,
            description=description
        )
        self.db.add(organization)
        await self.db.commit()
        await self.db.refresh(organization)
        return organization
    
    async def update_organization(
        self,
        organization_id: UUID,
        name: Optional[str] = None,
        contact: Optional[str] = None,
        address: Optional[str] = None,
        description: Optional[str] = None
    ) -> Optional[Organization]:
        """Update organization information"""
        organization = await self.get_organization_by_id(organization_id)
        if not organization:
            return None
        
        # Check if name is being changed and if new name already exists
        if name is not None and name != organization.name:
            existing = await self.get_organization_by_name(name)
            if existing:
                raise ValueError(f"Organization with name '{name}' already exists")
            organization.name = name
        
        if contact is not None:
            organization.contact = contact
        if address is not None:
            organization.address = address
        if description is not None:
            organization.description = description
        
        await self.db.commit()
        await self.db.refresh(organization)
        return organization
    
    async def get_all_organizations(self) -> List[Organization]:
        """Get all organizations"""
        result = await self.db.execute(select(Organization))
        return result.scalars().all()
    
    async def delete_organization(self, organization_id: UUID) -> bool:
        """Delete an organization"""
        organization = await self.get_organization_by_id(organization_id)
        if not organization:
            return False
        
        await self.db.delete(organization)
        await self.db.commit()
        return True

