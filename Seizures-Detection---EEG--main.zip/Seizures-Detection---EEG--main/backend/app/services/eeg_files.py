"""
EEG file service for file management operations (Async)
"""
from typing import Optional, List
from uuid import UUID, uuid4
from pathlib import Path
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from sqlalchemy.orm import selectinload

from app.models.eeg_files import EEGFile
from app.models.patients import Patient
from app.models.users import User
from app.core.config import settings
from app.utils.file_utils import (
    get_file_hash,
    ensure_directory,
    get_file_size,
    validate_file_extension,
    extract_edf_metadata
)


class EEGFileService:
    """Service for EEG file-related operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.upload_dir = Path(settings.resolved_upload_dir)
        # Ensure upload directory exists
        ensure_directory(self.upload_dir)
    
    async def get_by_id(self, file_id: UUID, include_deleted: bool = False) -> Optional[EEGFile]:
        """Get EEG file by ID with relationships loaded"""
        query = (
            select(EEGFile)
            .options(
                selectinload(EEGFile.patient),
                selectinload(EEGFile.uploader)
            )
            .filter(EEGFile.id == file_id)
        )
        if not include_deleted:
            query = query.filter(EEGFile.is_deleted == False)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        patient_id: Optional[UUID] = None,
        uploaded_by: Optional[UUID] = None,
        include_deleted: bool = False
    ) -> tuple[List[EEGFile], int]:
        """Get all EEG files with pagination and filters"""
        # Base query
        query = select(EEGFile).options(
            selectinload(EEGFile.patient),
            selectinload(EEGFile.uploader)
        )
        
        # Count query
        count_query = select(func.count()).select_from(EEGFile)
        
        # Apply filters
        filters = []
        if patient_id is not None:
            filters.append(EEGFile.patient_id == patient_id)
        if uploaded_by is not None:
            filters.append(EEGFile.uploaded_by == uploaded_by)
        if not include_deleted:
            filters.append(EEGFile.is_deleted == False)
        
        if filters:
            query = query.filter(and_(*filters))
            count_query = count_query.filter(and_(*filters))
        
        # Get total count
        count_result = await self.db.execute(count_query)
        total = count_result.scalar() or 0
        
        # Get paginated results
        result = await self.db.execute(query.order_by(EEGFile.created_at.desc()).offset(skip).limit(limit))
        files = result.scalars().all()
        
        return files, total
    
    async def get_by_patient(
        self,
        patient_id: UUID,
        include_deleted: bool = False
    ) -> List[EEGFile]:
        """Get all EEG files for a specific patient"""
        files, _ = await self.get_all(patient_id=patient_id, include_deleted=include_deleted, limit=1000)
        return files
    
    async def save_file(
        self,
        file_content: bytes,
        original_filename: str,
        patient_id: UUID,
        uploaded_by: Optional[UUID] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None
    ) -> EEGFile:
        """Save uploaded file and create database record"""
        # Validate patient exists
        patient = await self.db.execute(
            select(Patient).filter(Patient.id == patient_id, Patient.is_deleted == False)
        )
        patient = patient.scalar_one_or_none()
        if not patient:
            raise ValueError(f"Patient with ID {patient_id} not found or deleted")
        
        # Generate unique filename to avoid conflicts
        file_ext = Path(original_filename).suffix
        unique_filename = f"{uuid4().hex}{file_ext}"
        
        # Create patient-specific subdirectory
        patient_dir = self.upload_dir / str(patient_id)
        ensure_directory(patient_dir)
        
        # Full file path
        file_path = patient_dir / unique_filename
        relative_path = f"{patient_id}/{unique_filename}"
        
        # Write file
        with open(file_path, "wb") as f:
            f.write(file_content)
        
        # Get file metadata
        file_size = get_file_size(file_path)
        file_hash = get_file_hash(file_path)
        
        # Extract EDF-specific metadata
        edf_metadata = extract_edf_metadata(file_path)
        
        # Create database record
        db_file = EEGFile(
            patient_id=patient_id,
            uploaded_by=uploaded_by,
            filename=unique_filename,
            original_filename=original_filename,
            file_path=relative_path,
            file_size=file_size,
            file_hash=file_hash,
            recording_duration=edf_metadata.get("recording_duration"),
            sampling_rate=edf_metadata.get("sampling_rate"),
            number_of_channels=edf_metadata.get("number_of_channels"),
            channel_names=edf_metadata.get("channel_names"),
            description=description,
            notes=notes,
        )
        
        self.db.add(db_file)
        await self.db.commit()
        await self.db.refresh(db_file)
        
        # Reload with relationships
        return await self.get_by_id(db_file.id, include_deleted=True)
    
    async def update_file(
        self,
        file_id: UUID,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        is_deleted: Optional[bool] = None
    ) -> Optional[EEGFile]:
        """Update EEG file metadata"""
        eeg_file = await self.get_by_id(file_id, include_deleted=True)
        if not eeg_file:
            return None
        
        if description is not None:
            eeg_file.description = description
        if notes is not None:
            eeg_file.notes = notes
        if is_deleted is not None:
            eeg_file.is_deleted = is_deleted
        
        await self.db.commit()
        await self.db.refresh(eeg_file)
        
        return await self.get_by_id(eeg_file.id, include_deleted=True)
    
    async def delete_file(self, file_id: UUID, hard_delete: bool = False) -> bool:
        """Delete an EEG file (soft delete by default, hard delete if specified)"""
        eeg_file = await self.get_by_id(file_id, include_deleted=True)
        if not eeg_file:
            return False
        
        if hard_delete:
            # Delete physical file
            file_path = self.upload_dir / eeg_file.file_path
            if file_path.exists():
                file_path.unlink()
            # Delete database record
            await self.db.delete(eeg_file)
        else:
            # Soft delete
            eeg_file.is_deleted = True
        
        await self.db.commit()
        return True
    
    def get_file_path(self, eeg_file: EEGFile) -> Path:
        """Get full file system path for an EEG file"""
        return self.upload_dir / eeg_file.file_path

