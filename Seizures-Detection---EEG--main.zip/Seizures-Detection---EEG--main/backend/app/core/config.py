"""
Application configuration settings with environment-based auto-configuration
"""
import os
from typing import List, Optional, Union
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field, field_validator, computed_field


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Environment Configuration
    ENVIRONMENT: str = Field(default="development", env="ENVIRONMENT")
    
    # Project Information
    PROJECT_NAME: str = "EEG Seizure Detection API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Server Configuration
    HOST: str = Field(default="0.0.0.0", env="HOST")
    PORT: int = Field(default=8000, env="PORT")
    
    # Security
    SECRET_KEY: Optional[str] = Field(default=None, env="SECRET_KEY")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=1, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, env="REFRESH_TOKEN_EXPIRE_DAYS")
    
    # CORS - Will be auto-configured based on environment
    BACKEND_CORS_ORIGINS: Optional[Union[List[str], str]] = Field(
        default=None,
        env="BACKEND_CORS_ORIGINS"
    )
    FRONTEND_URL: Optional[str] = Field(default=None, env="FRONTEND_URL")
    ALLOWED_HOSTS: Optional[Union[List[str], str]] = Field(
        default=None,
        env="ALLOWED_HOSTS"
    )
    
    # Database
    DATABASE_URL: Optional[str] = Field(default=None, env="DATABASE_URL")
    
    # File Storage
    UPLOAD_DIR: Optional[str] = Field(default=None, env="UPLOAD_DIR")
    MAX_UPLOAD_SIZE: int = Field(default=100 * 1024 * 1024, env="MAX_UPLOAD_SIZE")  # 100MB
    
    # ML Model
    MODEL_PATH: Optional[str] = Field(default=None, env="MODEL_PATH")
    MODEL_TYPE: str = Field(default="resnet", env="MODEL_TYPE")
    
    # Render-specific (automatically detected)
    RENDER: bool = Field(default=False, env="RENDER")
    RENDER_EXTERNAL_HOSTNAME: Optional[str] = Field(default=None, env="RENDER_EXTERNAL_HOSTNAME")
    
    # Email (optional, for future use)
    SMTP_HOST: Optional[str] = Field(default=None, env="SMTP_HOST")
    SMTP_PORT: Optional[int] = Field(default=None, env="SMTP_PORT")
    SMTP_USER: Optional[str] = Field(default=None, env="SMTP_USER")
    SMTP_PASSWORD: Optional[str] = Field(default=None, env="SMTP_PASSWORD")
    
    @field_validator("BACKEND_CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            # Parse comma-separated string or JSON array string
            if v.startswith("[") and v.endswith("]"):
                import json
                return json.loads(v)
            return [origin.strip() for origin in v.split(",")]
        return v
    
    @field_validator("ALLOWED_HOSTS", mode="before")
    @classmethod
    def parse_allowed_hosts(cls, v):
        if isinstance(v, str):
            if v.startswith("[") and v.endswith("]"):
                import json
                return json.loads(v)
            return [host.strip() for host in v.split(",")]
        return v
    
    @computed_field
    @property
    def DEBUG(self) -> bool:
        """Auto-configure DEBUG based on environment"""
        return self.ENVIRONMENT.lower() == "development"
    
    @computed_field
    @property
    def is_production(self) -> bool:
        """Check if running in production"""
        return self.ENVIRONMENT.lower() == "production" or self.RENDER
    
    @computed_field
    @property
    def is_development(self) -> bool:
        """Check if running in development"""
        return self.ENVIRONMENT.lower() == "development" and not self.RENDER
    
    @computed_field
    @property
    def resolved_cors_origins(self) -> List[str]:
        """Auto-configure CORS origins based on environment"""
        if self.BACKEND_CORS_ORIGINS:
            if isinstance(self.BACKEND_CORS_ORIGINS, str):
                return [origin.strip() for origin in self.BACKEND_CORS_ORIGINS.split(",")]
            return self.BACKEND_CORS_ORIGINS
        
        # Auto-configure based on environment
        if self.is_production:
            if self.FRONTEND_URL:
                return [self.FRONTEND_URL]
            if self.RENDER_EXTERNAL_HOSTNAME:
                # Assume frontend is on same domain or configured separately
                return [f"https://{self.RENDER_EXTERNAL_HOSTNAME}"]
            return []  # Production should explicitly set CORS
        else:
            # Development defaults
            return [
                "http://localhost:3000",
                "http://localhost:5173",
                "http://localhost:5174",
                "http://127.0.0.1:5173",
                "http://127.0.0.1:5174",
            ]
    
    @computed_field
    @property
    def resolved_allowed_hosts(self) -> List[str]:
        """Auto-configure allowed hosts based on environment"""
        if self.ALLOWED_HOSTS:
            if isinstance(self.ALLOWED_HOSTS, str):
                return [host.strip() for host in self.ALLOWED_HOSTS.split(",")]
            return self.ALLOWED_HOSTS
        
        # Auto-configure based on environment
        if self.is_production:
            hosts = ["*"]  # Render handles this
            if self.RENDER_EXTERNAL_HOSTNAME:
                hosts.append(self.RENDER_EXTERNAL_HOSTNAME)
            return hosts
        else:
            return ["localhost", "127.0.0.1", "0.0.0.0"]
    
    @computed_field
    @property
    def resolved_secret_key(self) -> str:
        """Get or generate secret key"""
        if self.SECRET_KEY:
            return self.SECRET_KEY
        
        if self.is_production:
            raise ValueError(
                "SECRET_KEY must be set in production environment. "
                "Generate one with: python -c 'import secrets; print(secrets.token_urlsafe(32))'"
            )
        
        # Development fallback (not secure, but convenient)
        return "dev-secret-key-change-in-production-please"
    
    @computed_field
    @property
    def resolved_database_url(self) -> str:
        """Get database URL with fallback"""
        if self.DATABASE_URL:
            return self.DATABASE_URL
        
        if self.is_production:
            raise ValueError("DATABASE_URL must be set in production environment")
        
        # Development default (using asyncpg)
        return "postgresql+asyncpg://postgres:101325@localhost:5432/eeg_seizure_db"
    
    @computed_field
    @property
    def resolved_upload_dir(self) -> str:
        """Get upload directory path"""
        if self.UPLOAD_DIR:
            return self.UPLOAD_DIR
        
        # Render persistent disk path
        if self.RENDER:
            return "/opt/render/project/src/data/uploads"
        
        # Development default
        return str(Path(__file__).parent.parent.parent / "data" / "uploads")
    
    def ensure_directories(self):
        """Ensure upload directory exists"""
        Path(self.resolved_upload_dir).mkdir(parents=True, exist_ok=True)
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Create settings instance
settings = Settings()

# Ensure directories exist on startup
settings.ensure_directories()
