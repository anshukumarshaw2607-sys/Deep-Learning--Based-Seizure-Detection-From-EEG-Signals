"""
Database connection and session management (Async)
"""
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import declarative_base
from contextlib import asynccontextmanager

from app.utils.db import get_database_url

DATABASE_URL = get_database_url()

# Create async database engine
engine = create_async_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    echo=False,  # Set to True for SQL query logging
)

# Create async session factory
async_session = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)

# Base class for models
Base = declarative_base()


# Dependency to get DB session
# For FastAPI dependency
async def get_db():
    """
    Dependency function to get async database session
    """
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()


# For scripts and manual usage
@asynccontextmanager
async def get_db_ctx():
    """
    Context manager to get async database session for scripts
    """
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()