"""
Security utilities for authentication and password hashing
"""
import base64
import hashlib
from datetime import datetime, timedelta
from typing import Optional, List
from uuid import UUID
from jose import JWTError, jwt
import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.models.users import User

# Use resolved secret key
SECRET_KEY = settings.resolved_secret_key

# Bcrypt configuration
BCRYPT_ROUNDS = 12

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")


def _prehash_password(password: str) -> str:
    """
    Pre-hash password with SHA-256 to support passwords longer than bcrypt's 72-byte limit.
    This allows long secure passwords while maintaining bcrypt security.
    Uses base64 encoding to get 44 characters (44 bytes when UTF-8 encoded), well under bcrypt's 72-byte limit.
    Returns base64 string which passlib can handle correctly.
    """
    # Use base64 encoding to get a 44-character string (more compact than hex)
    # When encoded as UTF-8, this is exactly 44 bytes, well under bcrypt's 72-byte limit
    prehashed_bytes = hashlib.sha256(password.encode('utf-8')).digest()
    prehashed = base64.b64encode(prehashed_bytes).decode('utf-8')
    # Ensure it's within bcrypt's limit (should always be 44 bytes, but double-check)
    prehashed_utf8_bytes = prehashed.encode('utf-8')
    if len(prehashed_utf8_bytes) > 72:
        # This should never happen, but truncate if it does
        prehashed = prehashed_utf8_bytes[:72].decode('utf-8', errors='ignore')
    return prehashed


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash"""
    # Pre-hash the password to support long passwords
    prehashed = _prehash_password(plain_password)
    # Use bcrypt directly to verify
    try:
        return bcrypt.checkpw(prehashed.encode('utf-8'), hashed_password.encode('utf-8'))
    except (ValueError, TypeError):
        return False


def get_password_hash(password: str) -> str:
    """
    Hash a password using SHA-256 + bcrypt to support passwords of any length.
    This allows long secure passwords while maintaining bcrypt's security benefits.
    """
    # Pre-hash with SHA-256 to support passwords longer than bcrypt's 72-byte limit
    prehashed = _prehash_password(password)
    # SHA-256 base64 is always 44 characters (44 bytes when UTF-8 encoded, well under bcrypt's 72-byte limit)
    # Use bcrypt directly to hash
    prehashed_bytes = prehashed.encode('utf-8')
    # Ensure it's within bcrypt's limit (should always be 44 bytes, but double-check)
    if len(prehashed_bytes) > 72:
        prehashed_bytes = prehashed_bytes[:72]
    hashed = bcrypt.hashpw(prehashed_bytes, bcrypt.gensalt(rounds=BCRYPT_ROUNDS))
    return hashed.decode('utf-8')


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT refresh token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def decode_access_token(token: str) -> Optional[dict]:
    """Decode and verify a JWT access token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[settings.ALGORITHM])
        # Verify it's an access token
        if payload.get("type") != "access":
            return None
        return payload
    except JWTError:
        return None


def decode_refresh_token(token: str) -> Optional[dict]:
    """Decode and verify a JWT refresh token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[settings.ALGORITHM])
        # Verify it's a refresh token
        if payload.get("type") != "refresh":
            return None
        return payload
    except JWTError:
        return None


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    """
    Dependency to get current authenticated user from token
    Checks if token is revoked before authenticating
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    
    # Check if token is revoked
    from app.services.tokens import TokenService
    token_service = TokenService(db)
    if await token_service.is_token_revoked(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user_id: str = payload.get("sub")
    if user_id is None:
        raise credentials_exception
    
    # Fetch user from database (import here to avoid circular dependency)
    from app.services.users import UserService
    user_service = UserService(db)
    user = await user_service.get_by_id(UUID(user_id))
    
    if user is None:
        raise credentials_exception
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive"
        )
    
    return user


def require_role(allowed_roles: List[str]):
    """
    Dependency factory to require specific roles
    """
    async def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {allowed_roles}"
            )
        return current_user
    
    return role_checker


def require_same_organization():
    """
    Dependency factory to require same organization
    Root users can access resources from any organization
    """
    async def org_checker(
        target_organization_id: UUID,
        current_user: User = Depends(get_current_user)
    ) -> User:
        # Root users can access any organization
        if current_user.role == "root":
            return current_user
        
        if not current_user.org_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is not associated with an organization"
            )
        
        if current_user.org_id != target_organization_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. You can only access resources from your organization"
            )
        
        return current_user
    
    return org_checker


def get_user_service(db: AsyncSession = Depends(get_db)):
    """Dependency to get UserService instance"""
    from app.services.users import UserService
    return UserService(db)


def get_token_service(db: AsyncSession = Depends(get_db)):
    """Dependency to get TokenService instance"""
    from app.services.tokens import TokenService
    return TokenService(db)


def get_patient_service(db: AsyncSession = Depends(get_db)):
    """Dependency to get PatientService instance"""
    from app.services.patients import PatientService
    return PatientService(db)


def validate_organization_access(current_user: User, target_organization_id: Optional[UUID], error_message: str = "Access denied"):
    """
    Helper to validate organization access
    Root users can access resources from any organization
    """
    # Root users can access any organization
    if current_user.role == "root":
        return
    
    if not current_user.org_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account is not associated with an organization"
        )
    if target_organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Target resource is not associated with an organization"
        )
    if current_user.org_id != target_organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=error_message
        )

