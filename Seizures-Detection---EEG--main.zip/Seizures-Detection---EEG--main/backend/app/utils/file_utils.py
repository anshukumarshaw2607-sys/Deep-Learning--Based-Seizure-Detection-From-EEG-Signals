"""
File utility functions
"""
from pathlib import Path
from typing import Optional, Dict, Union
import hashlib

try:
    import pyedflib.edfreader as edfreader
    PYEEDFLIB_AVAILABLE = True
except ImportError:
    PYEEDFLIB_AVAILABLE = False


def get_file_hash(file_path: Path) -> str:
    """Calculate SHA256 hash of a file"""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def ensure_directory(path: Path) -> Path:
    """Ensure a directory exists, create if it doesn't"""
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_file_size(file_path: Path) -> int:
    """Get file size in bytes"""
    return file_path.stat().st_size


def validate_file_extension(filename: str, allowed_extensions: list) -> bool:
    """Validate file extension"""
    return Path(filename).suffix.lower() in allowed_extensions


def extract_edf_metadata(file_path: Path) -> Dict[str, Optional[Union[float, int, str]]]:
    """
    Extract metadata from an EDF (European Data Format) file.
    
    Returns a dictionary with:
    - recording_duration: Duration in seconds (float)
    - sampling_rate: Sampling rate in Hz (float) - uses first channel's rate
    - number_of_channels: Number of channels (int)
    - channel_names: Comma-separated channel names (str)
    
    Returns empty dict with None values if pyedflib is not available or file cannot be read.
    """
    if not PYEEDFLIB_AVAILABLE:
        return {
            "recording_duration": None,
            "sampling_rate": None,
            "number_of_channels": None,
            "channel_names": None
        }
    
    try:
        # Open EDF file using pyedflib.edfreader API
        edf_file = edfreader.EdfReader(str(file_path))
        
        # Get number of channels
        number_of_channels = edf_file.signals_in_file
        
        # Get channel names using getSignalLabels() which returns a list
        channel_names_list = edf_file.getSignalLabels()
        channel_names = ",".join(channel_names_list) if channel_names_list else None
        
        # Get recording duration (in seconds)
        recording_duration = edf_file.getFileDuration()
        
        # Get sampling rate (use first channel's sampling rate)
        sampling_rate = edf_file.getSampleFrequency(0) if number_of_channels > 0 else None
        
        edf_file.close()
        
        return {
            "recording_duration": float(recording_duration) if recording_duration else None,
            "sampling_rate": float(sampling_rate) if sampling_rate else None,
            "number_of_channels": int(number_of_channels) if number_of_channels else None,
            "channel_names": channel_names
        }
    except Exception:
        # Return None values if metadata extraction fails
        # This allows the upload to succeed even if metadata extraction fails
        return {
            "recording_duration": None,
            "sampling_rate": None,
            "number_of_channels": None,
            "channel_names": None
        }

