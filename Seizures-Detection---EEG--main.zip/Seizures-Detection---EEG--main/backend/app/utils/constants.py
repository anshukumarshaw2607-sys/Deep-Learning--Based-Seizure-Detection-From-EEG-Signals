"""
Application constants
"""

# List of valid user roles
VALID_USER_ROLES = ["root", "admin", "doctor", "assistant"]
