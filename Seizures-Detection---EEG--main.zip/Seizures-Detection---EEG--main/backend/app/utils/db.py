"""
Database URL utility
"""
from app.core.config import settings


def get_database_url() -> str:
    """
    Get database URL with asyncpg format conversion
    
    Returns:
        str: Database URL in postgresql+asyncpg:// format
    """
    database_url = settings.resolved_database_url
    
    # Convert postgresql:// to postgresql+asyncpg:// for async
    if database_url.startswith("postgresql://"):
        return database_url.replace("postgresql://", "postgresql+asyncpg://", 1)
    
    return database_url

