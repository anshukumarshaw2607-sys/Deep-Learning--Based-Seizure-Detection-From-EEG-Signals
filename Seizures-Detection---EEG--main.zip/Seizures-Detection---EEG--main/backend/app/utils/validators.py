"""
Validation utility functions
"""
from app.utils.constants import VALID_USER_ROLES


def is_valid_role(role: str) -> bool:
    """Check if a role is valid"""
    return role in VALID_USER_ROLES


def require_valid_role(role: str) -> None:
    """Raise ValueError if role is not valid"""
    if not is_valid_role(role):
        raise ValueError(f"Invalid role: {role}. Must be one of {VALID_USER_ROLES}")

