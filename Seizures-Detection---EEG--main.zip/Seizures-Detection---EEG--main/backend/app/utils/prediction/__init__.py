"""
NEDC EEG ResNet prediction utilities
Contains all NEDC library modules and configuration files for seizure detection
"""

import os
import sys

# Windows compatibility: os.EX_SOFTWARE doesn't exist on Windows
# NEDC tools use this constant for exit codes, but it's only defined on Unix systems
if not hasattr(os, 'EX_SOFTWARE'):
    os.EX_SOFTWARE = 70  # Standard Unix exit code for software error

# Ensure sys.exit codes work across platforms
if not hasattr(sys, 'EX_SOFTWARE'):
    sys.EX_SOFTWARE = 70

