#!/usr/bin/env python
#
# file: $NEDC_NFC/class/python/nedc_eeg_image_tools.py
#
# revision history:
#
# 20241228 (DH): first generalized version
# 20211118 (PM): refactored code
# 20210426 (VK): added a new class to handle single EEG pickle
#                for decoding purpose.
# 20210422 (VK): initial release
# 20221020 (ML): refactored code
# 20240825 (DH): updated class documentation
#
# This file contains a class for making image datasets from a single EDF file,
# and a class for making an image dataset from EDF and csvbi data.
#------------------------------------------------------------------------------

# import system modules
#
import os
import sys
import numpy as np
from PIL import Image
import torch
import torch.utils as utils
import numpy as np

# import nedc_modules
#
import edf_tools as net
import debug_tools as ndt
import mont_tools as nmt

#------------------------------------------------------------------------------
#
# global variables are listed here
#
#------------------------------------------------------------------------------

# define a constant to scale the signal data to [0, 255]
# in order to create a gray scale image
#
EPSILON = 1e-6

# declare a global debug object so we can use it in functions
#
dbgl = ndt.Dbgl()

# declare a string to determine whether we want to scale via vahids method
#
DEF_ROW_NORMALIZATION = "row_scale"

#------------------------------------------------------------------------------
#
# helper functions listed here
#
#------------------------------------------------------------------------------
def row_scale(sig_mat, winsize):
    """
    method: row_scale

    arguments:
     sig_mat: a frame (numpy array of arrays)
     winsize: the window size

    return:
     scaled: a scaled rgb image

    description:
     this function scales a frame based off of vahids scaling logic

    """

    # Transpose so shape => (frmsize, channels)
    #
    sig_mat = sig_mat.T - sig_mat.min(axis=1)

    # Vahid's max-scaling approach => scale each channel independently
    #
    scaled = np.uint8(
        np.transpose(
            sig_mat / (sig_mat.max(axis=0) + EPSILON) * winsize
        )
    )

    # exit gracefully
    #  return scaled frame
    #
    return scaled
#
# end of function

def dict_to_matrix(sig_dict):
    """
    method: dict_to_matrix

    arguments:
     sig_dict : dictionary whose keys are channel labels and whose
      values are one-dimensional NumPy arrays of equal length

    return:
     sig_mat : 2-D NumPy array shaped (n_channels, n_samples)

    description:
     Converts the dictionary returned by read_segment into a matrix
     with a deterministic channel order. The order is the channel
     labels sorted in ascending ASCII order.
    """

    # get a reproducible ordering of the channel labels
    #
    ordered_labels = sorted(sig_dict.keys())

    # stack the channel vectors into a matrix following that order
    #
    sig_mat = np.stack([sig_dict[label] for label in ordered_labels])

    # exit gracefully
    #  return the matrix
    #
    return sig_mat
#
# end of function

#------------------------------------------------------------------------------
#
# classes are listed here
#
#------------------------------------------------------------------------------

class TrainImages(utils.data.Dataset):
    """
    class: TrainImages

    description:
     this class handles the data fetching operations for the training algorithm
     using I/O based signal fetching
    """

    def __init__(self,
                 samples,
                 window_size,
                 transform=None,
                 scale=None,
                 index_map=None):

        """
        method: __init__

        arguments:
         samples : a list of tuples containing the following
           (edf_path, start_sample, label_string)
         window_size : number of samples that constitute one frame
         transform : optional torchvision-style transform applied to the
          PIL image
         scale : if equal to DEF_ROW_NORMALIZATION apply Vahid row scaling
         index_map : dict to map from strings to idx
           {label_string: numeric_class_id}

        return: None

        description:
         Stores the tuples, builds numeric labels, and prepares one lazy EDF
         handle that is re-used across calls to __getitem__.
        """
        # call the parent constructor
        #
        super().__init__()

        # store the window size
        #
        self.window_size = window_size

        # store the optional transform callable
        #
        self.transform = transform

        # store the optional scaling flag
        #
        self.scale_flag = scale

        # save the list of tuples exactly as received
        #
        self.samples = samples

        # build or copy the mapping from label strings to numeric indices
        #
        self.label_to_index = index_map

        # create a list of unique class names
        #
        self.classes = [lab for lab, _ in sorted(self.label_to_index.items(),
                                                 key=lambda kv: kv[1])]

        # generate the numeric target list in the order of the tuples
        #
        self.targets = np.asarray([self.label_to_index[tpl[-1]]
                                   for tpl in self.samples])

        # create placeholders for a cached EDF object
        #
        self.edf_tool = net.Edf()
    #
    # end of method

    def __len__(self):
        """
        method: __len__

        arguments:
         none

        return:
         integer count of tuples (one per frame)

        description:
         Lets torch.utils.data.DataLoader know how many items exist.
        """

        # return the number of tuples stored
        #
        return len(self.samples)
    #
    # end of method

    def __getitem__(self, window_index):
        """
        method: __getitem__

        arguments:
         window_index : zero-based index supplied by the DataLoader

        return:
         (PIL_RGB_image, numeric_class_id)

        description:
         Uses the tuple at window_index to read exactly one segment,
         converts it to an RGB image, applies optional processing,
         and returns it together with its numeric label.
        """

        # unpack the tuple that corresponds to this index
        #
        edf_fpath, start_sample, label_string = \
            self.samples[window_index]

        # read exactly the requested segment
        #
        _, sig_dict = self.edf_tool.read_segment(
            edf_fpath,
            int(start_sample),
            int(start_sample + self.window_size)
        )

        # convert dictionary -> matrix with deterministic channel order
        #
        window_buffer = dict_to_matrix(sig_dict)

        # apply optional per-row scaling if requested
        #
        if self.scale_flag == DEF_ROW_NORMALIZATION:
            window_buffer = row_scale(window_buffer, self.window_size)

        # apply transforms
        #
        image = self.transform(window_buffer)
                
        # fetch the numeric label from the mapping
        #
        numeric_label = self.label_to_index[label_string]

        # return the image together with its numeric target
        #
        return image, numeric_label
    #
    # end of method

    def __del__(self):
        """
        method: __del__

        arguments:
         none

        return:
         none

        description:
         Ensures that any open EDF handle is closed when the dataset
         object is destroyed.
        """

        # attempt to close the cached EDF object if one exists
        #
        try:

            # close only if the handle is valid
            #
            if self.edf_tool is not None:
                self.edf_tool.close()

        # silently ignore all exceptions during object destruction
        #
        except Exception:
            pass

    #
    # end of method
#
# end of class

class DecodeImages(utils.data.Dataset):
    """
    method: class_decode_image

    arguments:
     samples: a paded 2d numpy array respresenting the full signal
     window_intervals: list start_samples
      one tuple per window
     transform: optional torchvision-style transform
     scale: if equal to DEF_ROW_NORMALIZATION, apply scaling

    return: none

    description:
     Provides a minimal DataSet interface needed by the decoder, with
     no class labels because the task is inference.
    """

    def __init__(self,
                 samples,
                 window_intervals,
                 window_size,
                 transform=None,
                 scale=None):

        # invoke the parent class constructor
        #
        super().__init__()

        # store the EDF pathname for later use
        #
        self.samples = samples

        # store the window size
        #
        self.window_size = window_size

        # store the list that contains start_samples
        #
        self.window_intervals = window_intervals

        # store the optional transform callable
        #
        self.transform = transform

        # store the scale flag
        #
        self.scale_flag = scale

    #
    # end of method

    def __len__(self):
        """
        method: __len__

        arguments:
         none

        return:
         integer count of windows available for decoding

        description:
         Returns the length so that callers know the iteration bounds.
        """

        # return the count of tuples supplied during construction
        #
        return len(self.window_intervals)
    #
    # end of method

    def __getitem__(self, window_index):
        """
        method: __getitem__

        arguments:
         window_index: zero-based index of the window to retrieve

        return:
         PIL RGB image corresponding to the requested window

        description:
         Reads exactly the samples described by the stored interval,
         converts them to an RGB image, and applies the optional
         transform. No label is returned because the decoder runs in
         an unsupervised context.
        """

        # unpack the tuple that corresponds to the supplied index
        #
        start = self.window_intervals[int(window_index)]

        # fetch the next window to evaluate
        #
        window_buffer = self.samples[:, start : start + self.window_size]

        # apply optional per-row scaling if the flag is set
        #
        if self.scale_flag == DEF_ROW_NORMALIZATION:
            window_buffer = row_scale(window_buffer, self.window_size)

        # apply the optional transform if one was supplied
        #
        if self.transform:
            image = self.transform(window_buffer)

        # return only the image because decoding produces no labels
        #
        return image

    #
    # end of method

#
# end of class

#
# end of file
