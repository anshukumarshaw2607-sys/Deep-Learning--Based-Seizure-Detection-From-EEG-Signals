#!/usr/bin/env python
#
# file: NEDC_NFC/class/python/nedc_eeg_ml_resnet_tools.py
#
# revision history:
#
# 20250810 (DH): rewrote training algorithm, added more options and added
#                multi-class training support
# 20250324 (JP): reviewed and refactored
# 20240928 (DH): combined and refactored train and decode tools
# 20220703 (ML): initial version
# 20220705 (PM): code review
#
# This file contains a Python implementation of our ResNet18 decoder and
# trainer. Details  about this system can be found here:
#
#  Khalkhali, V., Shawki, N., Shah, V., Golmohammadi, M., Obeid, I., &
#  Picone, J. (2021). Low Latency Real-Time Seizure Detection Using
#  Transfer Deep Learning. In I. Obeid, I. Selesnick, & J. Picone (Eds.),
#  Proceedings of the IEEE Signal Processing in Medicine and Biology
#  Symposium (SPMB) (pp. 1-7). IEEE.
#  https://doi.org/10.1109/SPMB52430.2021.9672285
#  https://www.isip.piconepress.com/publications/conference_proceedings/2021/ieee_spmb/eeg_transfer_learning/
#
# The API for the decoder is very simple:
#  constructor: creates the class (called at the top of the program)
#  decode: runs the entire decoding system (should be called after init)
#
# The API for the trainer is very simple:
#  constructor: creates the class (called at the top of the program)
#  setup_train_env: parses train/dev file lists and sets the weights
#  train: the main method of the class, will run the entire model
#   training process (should be called after init)
#  read_stats: this method will decode a dataset and compute the confusion
#   matrix and accuracy (last method to be called to test model performance)
#
#------------------------------------------------------------------------------

# import system modules
#
import os
import copy
import numpy as np
import random
import scipy.signal
import sys
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# import non-torch reliant nedc modules
#
import debug_tools as ndt
import edf_tools as net
import eeg_ann_tools as nae
import file_tools as nft
import mont_tools as nmt

# import torch and set seeding/deterministic settings
#
import torch
SEED = int(ndt.RANDSEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
np.random.seed(SEED)
random.seed(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
    
# import the rest of the torch modules
#
import torch.nn as nn
from torch.optim import lr_scheduler
import torch.utils as utils
from torchvision import models
from torch.utils.data import Subset

# import torch reliant NEDC modules
#
import eeg_image_tools as nri

#------------------------------------------------------------------------------
#
# global variables are listed here
#
#------------------------------------------------------------------------------

# define the version of EEG ResNet
#
NEDC_EEG_RESNET_VERSION = "v2.0.2"

#------------------------------------------------------------------------------
# decoder variables are located here:
#

# set signal convolution options
#
DEF_CONVOLVE_SET_FULL = 'full'
DEF_CONVOLVE_SET_VALID = 'valid'

#------------------------------------------------------------------------------
# trainer variables are located here:
#

# define values for common strings needed
#
TRAIN, DEV= 'train', 'dev'
TRANSFORM = 'transform'

# define the momentum of the stochastic gradient descent function
#
DEF_MOMENTUM = 0.900

# define a variable for after how many epochs to decrease learning rate
# of the stochastic gradient descent function
#
DEF_STEP_SIZE = 7

# define a variable for how much to decrease the learning rate after
# STEP_SIZE amount of epochs
#
DEF_GAMMA = 0.100

# set a variable for infinity
#
DEF_WORST_LOSS_INIT = 'inf'

#------------------------------------------------------------------------------
# variables used by both the trainer and decoder are located here:
#

# define a string to determine what device we are using
#
DEVICE_CPU = 'cpu'
DEVICE_GPU = 'cuda'

# declare a string to determine the scaling method
#
DEF_ROW_NORMALIZATION = nri.DEF_ROW_NORMALIZATION

# create a constant for accessing the eeg label map
#
EEG_LABEL_MAP = "EEG_LABEL_MAP"
PARMA_KEY_LABEL_MAP = "label_map"

# define keys for dpath's models class to index mapping
#
ATTR_MODEL_CLASS_TO_IDX_MAP = "class_to_idx"
ATTR_MODEL_STATE_DICT = "state_dict"
ATTR_MODEL_MODULE = "module."
ATTR_MODEL_DEV_TRANSFORMS = "dev_transforms"

# set the filename using basename
#
__FILE__ = os.path.basename(__file__)

# declare a global debug object so we can use it in functions
#
dbgl = ndt.Dbgl()

#------------------------------------------------------------------------------
#
# helper functions listed here
#
#------------------------------------------------------------------------------

def worker_init_fn(worker_id):
    """
    function: worker_init_fn

    arguments:
     worker_id: The unique ID of the worker

    return: None

    description:
     Generates and applies a deterministic seed for each
     worker to ensure reproducible results across different runs.
    """

    
    # create worker seed
    #
    worker_seed = worker_id + ndt.RANDSEED

    # Set random seeds
    #
    random.seed(worker_seed)
    np.random.seed(worker_seed)
    torch.manual_seed(worker_seed)
    
#
# end of method

#------------------------------------------------------------------------------
#
# classes are listed here
#
#------------------------------------------------------------------------------

class EEGResNetDecode:
    """
    class: EEGResNetDecode

    arguments:
     none

    description:
     This class can decode edf files using a given resnet18 model and weights
    """

    def __init__(self, frmsize, winsize, device, mont_fpath, samp_rate,
                 seiz_ths, min_seiz, min_bckg, num_workers, num_threads,
                 mdl_path, mdl_weight_path, batch_size):
        """
        method: constructor

        arguments:
         frmsize: the frame size
         winsize: the window size
         device: the device that the decoding will occur on
         mont_fpath: the montage file path
         samp_rate: the sample rate of each file
         seiz_ths: the seizure threshold
         min_seiz: the minimum number of seconds for seizure events
         min_bckg: the minimum number of seconds for background events
         num_workers: the number of workers to use for data loader
         num_threads: determine the number of threads to use
          (for cpu decoding)
         mdl_path: the model path ( a file pointer to an nn.module)
         mdl_weight_path: the model of choices trained weight matrix
         batch_size: size of array input into resnet model

        returns:
         None

        description:
         this simple method is the constructor for the class
        """

        # set the class name
        #
        EEGResNetDecode.__CLASS_NAME__ = self.__class__.__name__

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: creating resnet decode object" %
                  (__FILE__, ndt.__LINE__, EEGResNetDecode.__CLASS_NAME__,
                   ndt.__NAME__))

        # store the sample rate
        #
        self.samp_rate = samp_rate

        # get values we need to derive other variables
        #
        self.frmsize = frmsize
        self.winsize = winsize

        # set the montage file path
        #
        self.montage = mont_fpath

        # set the device information
        #
        self.device = device

        # set the seizure threshold
        #
        self.seiz_threshold = seiz_ths

        # set the minimum background time
        #
        self.min_bckg = min_bckg

        # set the minimum seizure time
        #
        self.min_seiz = min_seiz

        # set the batch size
        #
        self.batch_size = batch_size

        # set the number of workers
        #
        self.num_workers = num_workers

        # if the device that will be utilized is a cpu
        # limit the number of threads PyTorch can use
        # Note: These settings can only be set before PyTorch operations start
        # If they've already been set or PyTorch is initialized, skip silently
        #
        if self.device.type == DEVICE_CPU:
            try:
                torch.set_num_threads(num_threads)
                torch.set_num_interop_threads(num_threads)
            except RuntimeError:
                # Thread settings can't be changed after PyTorch has started
                # This is fine - use existing settings
                pass

        # load the saved model data
        #
        bundle = torch.load(
            mdl_weight_path,
            map_location=DEVICE_CPU,
            weights_only=False
        )

        # get the index label map
        #
        class_to_idx = bundle[ATTR_MODEL_CLASS_TO_IDX_MAP]
        self.idx_to_label = {v:k for k,v in class_to_idx.items()}

        # temporarily ensure binary class prediction
        #
        if len(list(self.idx_to_label.keys())) != 2:
            print("Error: %s (line: %s) %s: %s (%s)" %
                  (__FILE__, ndt.__LINE__, ndt.__NAME__,
                   "only binary class prediction models supported",
                   list(self.idx_to_label.keys())))
            sys.exit(os.EX_SOFTWARE)

        # fetch dev transforms
        #
        self.transforms = bundle[ATTR_MODEL_DEV_TRANSFORMS]

        # instantiate default resnet 18 model
        #
        model = models.resnet18(weights=None)

        # load an nn.module (pre-trained model) if given
        #
        if mdl_path is not None:
            model = torch.load(mdl_path, weights_only = False)

        # append linear layer
        #
        model.fc = nn.Linear(model.fc.in_features, len(class_to_idx))

        # strip any DataParallel prefixes or noise from state dict
        #
        raw_state = bundle[ATTR_MODEL_STATE_DICT]
        clean = {}
        for k,v in raw_state.items():
            clean_key = k.replace(ATTR_MODEL_MODULE,nft.DELIM_NULL,1) \
                if k.startswith(ATTR_MODEL_MODULE) else k
            clean[clean_key] = v

        # load the models state dict
        #
        model.load_state_dict(clean)
        self.model = model.to(self.device) 

        # exit gracefully
        #
        return None
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # file-based methods
    #
    #--------------------------------------------------------------------------

    def decode(self, argfile, fp):
        """
        method: decode_single_file

        arguments:
         argfile: file name to process
         fp: file pointer to log file

        return:
         ann: the model prediction annotations

        description:
         This function decodes an edf file and writes
         the output to a csv_bi file
        """

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: decoding file (%s)" %
                  (__FILE__, ndt.__LINE__, EEGResNetDecode.__CLASS_NAME__,
                   ndt.__NAME__, argfile))

        # copy the model
        #
        model = copy.deepcopy(self.model)
        model = model.to(self.device)

        # make a dataset
        #
        dataset = self.get_image_dataset(argfile)

        # For decoding, shuffling is not required as we
        # are processing all data sequentially.
        # However, for consistency, we can still set a generator.
        #
        generator = torch.Generator()
        generator.manual_seed(ndt.RANDSEED)

        # create a dataloader for faster processing
        #
        data_loader = torch.utils.data.DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            generator=generator,
            worker_init_fn=worker_init_fn,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=(self.num_workers > 0),
            prefetch_factor=8
        )

        # get probabilities/labels based on the dataset
        #
        labels, all_probs = self.get_detects(data_loader)

        # post-process the probabilities
        #
        # LOOK INTO
        sm_lbls = \
            self.postprocess(labels, all_probs)

        # convert the probabilities to time based detection's
        #
        time_detects = self.convert_to_time_based(sm_lbls)

        # log the time detection's
        #
        fp.write("time detection : %s\n" % time_detects)

        # exit gracefully
        #
        return self.build_ann_graph(argfile, time_detects)
    #
    # end of method

    def build_ann_graph(self, argfile, tdets):
        """
        method: build_ann_graph

        arguments:
         argfile: the edf to decode
         tdets: the time detections

        return: an AnnEeg instance from time-based detections.

        description:
         creates the final annotation prediction graph to return
        """

        # open the edf file to get the file duration
        #
        edf = net.Edf()
        edf.get_header_from_file(argfile)
        duration = edf.get_duration()

        # Clamp segments to [0, duration) and drop invalid ones
        #
        clean = []
        for start, stop, cls_idx in tdets:

            # guard against None
            #
            if stop is None:
                stop = duration

            # skip segments that start at/after EOF
            #
            if start >= duration:
                continue

            # clamp stop to EOF
            #
            stop = min(stop, duration)

            # skip zero/negative spans
            #
            if stop <= start:
                continue

            # append to cleaned up segments
            #
            clean.append([start, stop, cls_idx])

        # Create AnnEeg obj
        #
        ann = nae.AnnEeg(montage_f=self.montage)
        ann.set_type(nft.CSV_NAME)

        # Build a minimal header dict for Csv.write_header():
        #
        csv_hdr = {
            nae.CSV_KEY_BNAME: Path(argfile).stem,
            nae.CSV_KEY_DURATION: duration,
            nae.CSV_KEY_MONTAGE_FILE: Path(self.montage).name,
        }
        ann.set_header(csv_hdr)

        # iterate through the time detections and
        # add to annotation graph
        #
        for start, stop, cls_idx in clean:
            label = self.idx_to_label[cls_idx]
            ann.create(
                lev=0,
                sub=0,
                chan=-1,
                start=float(start),
                stop=float(stop),
                symbols={ label: nae.PROBABILITY }
            )

        # exit gracefully
        #  return prediction annotation
        #
        return ann

    #
    # end of method

    def get_image_dataset(self, edf_path):
        """
        method: get_image_dataset

        arguments:
         edf_path: path name of the EDF file for which a lazy dataset
          should be constructed

        return:
         ds: a DecodeImage instance whose __getitem__ reads data on demand

        description:
         Build a lazy image dataset for a single EDF file. The dataset
         represents each frame only by its start_sample, I/O to be handled
         with Edf.read_segment() inside DecodeImage.
        """

        # create a Montage helper object so we can inspect the channel list
        #
        mont_tool = nmt.Montage()

        # load the montage specification file referenced by self.montage
        #
        mont_tool.load(self.montage)

        # fetch the list of channel labels in the exact order required
        #
        mont_order = mont_tool.get_montage_order()

        # instantiate an Edf object that lets us access the file header
        #
        edf_reader = net.Edf()

        # read only the header of the EDF file (no signal data loaded)
        #
        edf_reader.get_header_from_file(edf_path)

        # build an upper-case list of channel labels present in the EDF
        #
        edf_channels_upper = [
            label.upper() for label in edf_reader.h_d[net.EDF_CHAN_LABELS]
        ]

        # determine which required montage channels are absent in the file
        #
        missing_channels = [
            label for label in mont_order if label.upper() not \
            in edf_channels_upper
        ]

        # abort with a descriptive error message if any channel is missing
        #
        if missing_channels:
            print("Error: %s (line: %s) %s: %s %s (%s)" %
                  (__FILE__, ndt.__LINE__, ndt.__NAME__,
                   edf_path, "missing channel(s) required by montage",
                   missing_channels))
            sys.exit(os.EX_SOFTWARE)

        # obtain the total number of samples in the first signal channel
        #
        total_samples = edf_reader.get_num_samples(0)

        # compute how many frames of length self.frmsize fit in the signal
        #
        number_of_frames = int(np.ceil(total_samples / self.frmsize))

        # build a list describing every frames beginning idx
        #
        frame_intervals = [
            int(frame_index * self.frmsize)
            for frame_index in range(number_of_frames)
        ]

        # build a list describing every windows beginning idx
        #
        window_intervals = [
            int(frame_start + self.frmsize // 2 - self.winsize //2)
            for frame_start in frame_intervals
        ]

        # read full file and convert to a deterministic 2-D array (C, T)
        #
        hdr, sig_dict = edf_reader.read_edf(edf_path, True)
        sig_mat = nri.dict_to_matrix(sig_dict).astype(np.float64, copy=False)

        # compute one-shot padding so all windows are in-bounds after padding
        #
        starts = np.asarray(window_intervals, dtype=np.int32)
        n_samp = sig_mat.shape[1]
        left_pad  = int(max(0, -starts.min()))
        right_pad = int(max(0, starts.max() + self.winsize - n_samp))

        # pad once; dataset will slice from this buffer
        #
        buf = np.pad(sig_mat, ((0, 0), (left_pad, right_pad)), mode="constant")
        starts_pad = starts + left_pad

        # construct the lazy dataset that will fetch data via read_segment()
        #
        ds = nri.DecodeImages(
            buf,
            starts_pad,
            self.winsize,
            transform=self.transforms,
            scale=DEF_ROW_NORMALIZATION
        )

        # return the newly created dataset object to the caller
        #
        return ds
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # processing-based methods
    #
    #--------------------------------------------------------------------------

    def get_detects(self, data_loader):
        """
        method: get_detects

        arguments:
         data_loader: DataLoader yielding batches of images (Tensor[B,C,H,W])

        return:
         lbls:  list of predicted class indices per sample
         probs: list of predicted class probabilities per sample

        description:
         Runs the model in evaluation mode and, for each frame, selects the class
         with the maximum softmax probability. If that maximum probability is
         below the threshold (seiz_threshold), the frame is reassigned to the
         background class.
        """

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: computing frame-wise detections" %
                  (__FILE__, ndt.__LINE__,
                   EEGResNetDecode.__CLASS_NAME__, ndt.__NAME__))

        # switch model to evaluation mode
        #
        self.model.eval()

        # resolve background index from the stored label map
        #
        idx_to_label = self.idx_to_label
        label_to_idx = {lab: idx for idx, lab in idx_to_label.items()}
        bkg_lab = nae.DEF_BCKG
        bkg_idx = label_to_idx.get(bkg_lab, 0)

        # prepare output containers
        #
        out_labels = list()
        out_probs = list()

        # disable gradient computation
        #
        with torch.inference_mode():

            # iterate over DataLoader batches
            #
            for batch_images in data_loader:

                # send inputs to device
                #
                batch_images = batch_images.to(
                    self.device, dtype=torch.float32, non_blocking=True
                )

                # forward pass -> logits [B, C]
                #
                logits = self.model(batch_images)

                # softmax probabilities [B, C]
                #
                prob_mat = torch.softmax(logits, dim=1)

                # top class per sample
                #
                top_prob, top_idx = torch.max(prob_mat, dim=1)

                # background probability (used when falling back to background)
                #
                p_bkg = prob_mat[:, bkg_idx]

                # if the best class confidence is below threshold
                # force background
                #
                below_th = (top_prob <= self.seiz_threshold)
                final_idx = torch.where(
                    below_th,
                    torch.full_like(top_idx, bkg_idx),
                    top_idx)
                final_prob = torch.where(below_th, p_bkg, top_prob)

                # collect on CPU
                #
                out_labels.extend(final_idx.cpu().tolist())
                out_probs.extend(final_prob.cpu().tolist())

        # guard against empty output
        #
        if len(out_labels) == 0:
            out_labels = [int(bkg_idx)]
            out_probs  = [1.0]

        # exit gracefully
        #
        return out_labels, out_probs
    #
    # end of method

    def postprocess(self, lbls, probs):
        """
        method: postprocess

        arguments:
        lbls:  list of predicted class indices per sample (argmax after
         thresholding in get_detects)
        probs: list of the corresponding top-class probabilities per
         sample (same length as lbls)

        return:
        sm_lbls: list of post-processed class indices per sample

        description:
         Per-class morphology + distance-to-seed tie-break:
         1) Build a binary mask for each NON-background class where that
            class originally won (seeds).
         2) Apply morphology (closing, opening, min-duration) to EACH
            class mask separately to fill gaps.
        """

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print(("%s (line: %s) %s::%s: beginning multi-class "
                   "post processing (per-class morphology + "
                   "Voronoi tie-break)") %
                  (__FILE__, ndt.__LINE__,
                   EEGResNetDecode.__CLASS_NAME__, ndt.__NAME__))

        # number of frames in the input sequences
        #
        num_frames = len(lbls)

        # quick exit if the labels list is empty
        #
        if num_frames == 0:
            return [], []

        # Build string<->index mappings from the model bundle (loaded in
        # __init__)
        #
        idx_to_label = self.idx_to_label
        label_to_idx = {lab: idx for idx, lab in idx_to_label.items()}

        # ensure background label exists in mapping
        #
        if nae.DEF_BCKG not in label_to_idx:
            print(("Error: %s (line: %s) %s::%s: %s, %s %s %s (%s)") %
                  (__FILE__, ndt.__LINE__, EEGResNetDecode.__CLASS_NAME__,
                   ndt.__NAME__, "bckg not found in class to idx map",
                   "a background class named \"bckg\"",
                   "must be a target class in the mapping file",
                   "at model training time", label_to_idx))
            sys.exit(os.EX_SOFTWARE)

        # fetch background label's numeric index (used for defaulting and
        # comparisons)
        #
        bkg_idx = label_to_idx[nae.DEF_BCKG]

        # Convert numeric predictions to label strings for easier per-class
        # masking
        #
        lbls_np_idx = np.asarray(lbls, dtype=int)
        lbls_np_lab = np.array(
            [idx_to_label.get(int(i), nae.DEF_BCKG) for i in lbls_np_idx],
            dtype=object
        )

        # convert probs list to a numpy array (probability of the chosen
        # top-class per frame)
        #
        probs_np = np.asarray(probs, dtype=float)

        # Gather the list of non-background classes we will post-process
        # independently
        #
        fg_classes = [lab for lab in label_to_idx.keys()
                      if lab != nae.DEF_BCKG]

        # Morphology window sizes (expressed in frames)
        #   window_b: used by closing/opening (gap fill / spike removal)
        #   window_s: used by minimum-duration removal (drop very short runs)
        #
        window_b = int(np.round(self.min_bckg * self.samp_rate /
                                self.frmsize))
        window_s = int(np.round(self.min_seiz * self.samp_rate /
                                self.frmsize))

        # Create per-class masks (seeds) and apply per-class morphology to
        # get smoothed masks.
        #   seeds[lab] : numpy array of integer indices where the label
        #   originally won (pre-morph argmax)
        #   masks[lab] : numpy array [N] with the smoothed binary mask
        #   (post-morph), values in {0.0, 1.0}
        #
        masks = {}
        seeds = {}
        for lab in fg_classes:

            # binary mask where this class originally won
            # (1.0 if lbls_np_lab == lab else 0.0)
            #
            raw_mask = (lbls_np_lab == lab).astype(float)

            # copy the mask so we don't mutate raw data
            #
            m = raw_mask.copy()

            # apply closing/opening to fill small gaps and remove small
            # spikes for current class
            #
            if window_b > 0:
                m = self.pp_closing(m, window_b)
                m = self.pp_opening(m, window_b)

            # apply minimum-duration removal to drop very short runs for
            # current class
            #
            if window_s > 0:
                m = self.pp_rm_seiz(m, window_s)

            # store the smoothed mask for this class
            #
            masks[lab] = m

            # store the original seed positions (indices where this class
            # won BEFORE morphology)
            #
            seeds[lab] = np.where(raw_mask > 0.5)[0]


        # exit gracefully
        #  return binary seiz mask
        #
        sm_lbls = masks["seiz"]
        return sm_lbls
    #
    # end of method

    def convert_to_time_based(self, lbls):
        """
        method: convert_to_time_based

        arguments:
         lbls: list of class indices per sample
 
        return:
         tdets: list of [start_sec, end_sec, class_idx, mean_conf] segments

        description:
         Collapses frame-wise labels into time-based segments.
        """

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: converting labels to time based" %
                  (__FILE__, ndt.__LINE__,
                   EEGResNetDecode.__CLASS_NAME__, ndt.__NAME__))

        # guard against empty input to avoid index errors
        #
        if len(lbls) == 0:
            return []

        # convert labels to numpy arrays for speed
        #
        lbls_np = np.asarray(lbls, dtype=int)

        # initialize the output list of segments
        #
        tdets = []

        # set the starting label for the first segment
        #
        curr_lbl = lbls_np[0]

        # set the starting time (seconds) for the first segment
        #
        seg_start = 0.0

        # initialize running frame count for the current segment
        #
        seg_count = 1

        # iterate over frames starting from the second index
        #
        for idx in range(1, len(lbls_np)):

            # fetch the label at the current frame
            #
            lbl = lbls_np[idx]

            # if the label changes, we should close the current segment
            #
            if lbl != curr_lbl:

                # compute the segment end time in seconds
                #
                tstep = idx * self.frmsize / self.samp_rate

                # append the closed segment to the output list
                #
                tdets.append([seg_start, tstep, int(curr_lbl)])

                # reset the segment start time to the current frame time
                #
                seg_start = tstep

                # reset the current label to the new label
                #
                curr_lbl = lbl

                # reset the running frame count for the new segment
                #
                seg_count = 1

            # if the label did not change, accumulate stats for the segment
            #
            else:

                # increment the running frame count
                #
                seg_count += 1

        # after the loop, close the final segment to reach the file end
        #
        file_end = len(lbls_np) * self.frmsize / self.samp_rate

        # append the final segment to the output list
        #
        tdets.append([seg_start, file_end, int(curr_lbl)])

        # exit gracefully
        #  return the list of time-based segments with confidences
        #
        return tdets
    #
    # end of method

    def pp_rm_seiz(self, dets, mins):
        """
        method: pp_rm_seiz

        arguments:
         dets: sequence of binary detection's
         mins: minimum acceptable seizure duration

        return:
         dets: the processed binary detection

        description:
         This function removes noisy seizure events
        """

        # removes labels with length out of the range [mins, maxs]
        #
        conv_win = np.ones(mins)
        dets = 1.0 * (scipy.signal.convolve(dets, conv_win,
                                            mode=DEF_CONVOLVE_SET_FULL) == mins)
        dets = 1.0 * (scipy.signal.convolve(dets, conv_win,
                                            mode=DEF_CONVOLVE_SET_VALID) > 0)

        # exit gracefully
        #  return binary detection
        #
        return dets
    #
    # end of method

    def pp_closing(self, dets, diameter):
        """
        method: pp_closing

        arguments:
         dets: sequence of binary detection's
         diameter: adds [diameter/2] to left and right side

        return:
         dets: the processed binary detection

        description:
         This function adds [diameter/2] to left and right side of every
         seizure event.
        """

        # adds [diameter/2] to left and right side
        #
        conv_win = np.ones(diameter)
        dets = 1.0 * (scipy.signal.convolve(dets, conv_win,
                                            mode=DEF_CONVOLVE_SET_FULL) > 0)
        dets = 1.0 * (scipy.signal.convolve(dets, conv_win,
                                            mode=DEF_CONVOLVE_SET_VALID) > 0)

        # exit gracefully
        #  return binary detection
        #
        return dets
    #
    # end of method

    def pp_opening(self, dets, diameter):
        """
        method: pp_opening

        arguments:
         dets: sequence of binary detection's
         diameter: removes [diameter-1] from left and right side

        return:
         dets: the processed binary detection

        description:
         This function removes [diameter-1] from left and right side of every
         seizure event.
        """

        # removes [diameter-1] from left and right side
        #
        conv_win = np.ones(diameter)

        dets = 1.0 * (scipy.signal.convolve(
            dets, conv_win, mode=DEF_CONVOLVE_SET_FULL) == diameter)

        dets = 1.0 * (scipy.signal.convolve(
            dets, conv_win, mode=DEF_CONVOLVE_SET_VALID) == diameter)

        # exit gracefully
        #  return binary detection
        #
        return dets
    #
    # end of method

#
# end of class

class EEGResNetTrain:
    """
    class: EEGResNetTrain

    arguments:
     none

    description:
     This class can train a ResNet18 Model
    """
    def __init__(self, frmsize, winsize, train_transforms,
                 dev_transforms, device, mont_fpath, samp_rate,
                 save_epoch_model, num_workers, num_threads,
                 lbl_map, num_gpus):
        """
        method: __init__

        arguments:
         frmsize: number of samples per frame
         winsize: the number of samples per windows
         train_transforms: the image transformations on the train dataset
         dev_transforms: the image transformations on the dev dataset
         device: the device that the training will be run on
         mont_path: the montage file path with operations to apply to signal data
         samp_rate: the sample rate of the EDF files
         save_epoch_model: a boolean value to determine whether to save a model
          every epoch
         num_workers: number of workers for dataloader
         num_threads: number of threads to use for dataset building and training
         lbl_map: a label map
         num_gpus: the number of gpus to use for training

        returns: none

        description:
         This method constructs an EEGResNet object.
        """

        # set the class name
        #
        EEGResNetTrain.__CLASS_NAME__ = self.__class__.__name__

        # display debug information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: creating resnet train object" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__))

        # save the label map
        #
        self.label_map = lbl_map

        # store the number of gpus to use
        #
        self.num_gpus = num_gpus

        # store the number of threads to use
        #
        self.num_threads = num_threads

        # set the frame size
        #
        self.frmsize = frmsize

        # set the window size
        #
        self.winsize = winsize

        # create a variable to store the epoch model saving preferences
        #
        self.save_epoch_model = save_epoch_model

        # set the device training will be run on
        #
        self.device = device

        # store montage file path
        #
        self.montage = mont_fpath

        # set the new sample rate to down sample to
        #
        self.samp_rate = samp_rate

        # store the number of workers
        #
        self.num_workers = num_workers

        # set the dev/train transforms
        #
        self.transforms = dict()
        self.transforms[TRAIN] = train_transforms
        self.transforms[DEV] = dev_transforms

        # create a variable to hold the datasets (i.e. train or dev)
        #
        self.data_sets = dict()

        # create a variable to hold the image datasets (i.e. train or dev)
        #
        self.image_sets = dict()

        # create a variable to store the number of samples within
        # a data set
        #
        self.num_samples = dict()

        # create a variable to hold the data weights
        #
        self.weights = dict()

        # create a variable to hold the torch data loaders
        #
        self.data_loaders = dict()

        # limit the number of threads/cores to num_threads if using
        # cpu
        #
        if self.device.type == DEVICE_CPU:
            torch.set_num_threads(self.num_threads)
            torch.set_num_interop_threads(1)

        # exit gracefully
        #
        return None
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # training set up based methods
    #
    #--------------------------------------------------------------------------

    def setup_train_env(self, train_edf_list, train_csv_list, dev_edf_list,
                        dev_csv_list, out_model_path, input_model_path,
                        input_model_weight_path, num_samps_train,
                        num_samps_dev, fp):
        """
        method: setup_train_env

        arguments:
         train_edf_list: list of all training edf files
         train_csvbi_list: list of all training csv_bi files
         dev_edf_list: list of all dev edf files
         dev_csvbi_list: list of all dev csv_bi files
         out_model_path: the output model file path
         input_model_path: optional initial input model to load data from
         input_model_weight_path: a pytorch weight matrix (state) path
         num_samps_train: the number of samples to randomly choose for train's
          lbl events
         num_samps_dev: the number of samples to randomly choose for dev's lbl
          events
         fp: file pointer to a log file

        return: boolean value indicating status

        description:
         This method has three functions: 1. generate and process the train/dev
         data sets, 2. calculates the weights for train/dev data sets, 3. loads
         model file path information for future use in the train method
        """

        # create a variable to store the output path of the final model
        #
        self.out_model_path = out_model_path

        # set the input model
        #
        self.input_model_path = input_model_path

        # set the input model weights (state) path
        #
        self.input_model_weight_path = input_model_weight_path

        # build the training dataset
        #
        self.data_sets[TRAIN] = \
            self.build_dataset(train_edf_list, train_csv_list, fp)

        # build the dev dataset
        #
        self.data_sets[DEV] = \
            self.build_dataset(dev_edf_list, dev_csv_list, fp)

        # create a custom defined class to index map to pass to the datasets
        #
        train_classes = list(samp[-1] for samp in self.data_sets[TRAIN])
        dev_classes = list(samp[-1] for samp in self.data_sets[DEV])
        self.class_names = sorted(set(train_classes) | set(dev_classes))

        # Deterministic class-to-index map
        #
        self.index_map = {cls: idx for idx, cls in enumerate(self.class_names)}

        # temporarily ensure binary class prediction
        #
        if len(list(self.index_map.keys())) != 2:
            print("Error: %s (line: %s) %s: %s (%s)" %
                  (__FILE__, ndt.__LINE__, ndt.__NAME__,
                   "only binary class prediction models supported",
                   list(self.index_map.keys())))
            sys.exit(os.EX_SOFTWARE)

        # create the train image dataset
        #
        self.image_sets[TRAIN] = \
            nri.TrainImages(
                self.data_sets[TRAIN],
                self.winsize,
                self.transforms[TRAIN],
                scale = DEF_ROW_NORMALIZATION,
                index_map = self.index_map
            )

        # create the dev image dataset
        #
        self.image_sets[DEV] = \
            nri.TrainImages(
                self.data_sets[DEV],
                self.winsize,
                self.transforms[DEV],
                scale = DEF_ROW_NORMALIZATION,
                index_map = self.index_map
            )

        # select the number of class events/samples randomly
        # for the train dataset
        #
        self.image_sets[TRAIN], self.num_samples[TRAIN] = \
            self.__select_samples(self.image_sets[TRAIN],
                                  num_samps_train)

        # select the number of class events/samples randomly
        # for the dev dataset
        #
        self.image_sets[DEV], self.num_samples[DEV] = \
            self.__select_samples(self.image_sets[DEV],
                                  num_samps_dev)

        # assign the train image transformations
        #
        if hasattr(self.image_sets[TRAIN], TRANSFORM):
            self.image_sets[TRAIN].transform = self.transforms[TRAIN]
        else:
            self.image_sets[TRAIN].dataset.transform = self.transforms[TRAIN]

        # assign the dev image transformations
        #
        if hasattr(self.image_sets[DEV], TRANSFORM):
            self.image_sets[DEV].transform = self.transforms[DEV]
        else:
            self.image_sets[DEV].dataset.transform = self.transforms[DEV]

        # Build tensors of per-class sample counts, ordered the same way
        # that CrossEntropyLoss expects (self.class_names).
        #
        train_counts = torch.tensor(
            [self.num_samples[TRAIN][str(cls)] for cls in self.class_names],
            dtype=torch.float32,
        )
        dev_counts = torch.tensor(
            [self.num_samples[DEV][str(cls)] for cls in self.class_names],
            dtype=torch.float32,
        )

        # Guard against division-by-zero in case a class is absent.
        #
        train_counts = torch.clamp(train_counts, min=1.0)
        dev_counts = torch.clamp(dev_counts, min=1.0)

        # Inverse-frequency weighting
        #
        self.weights[TRAIN] = (train_counts.max() / train_counts)
        self.weights[DEV] = (dev_counts.max() / dev_counts)

        # normalize
        #
        self.weights[TRAIN] /= self.weights[TRAIN].sum()
        self.weights[DEV] /= self.weights[DEV].sum()

        # take tensor weights to device
        #
        self.weights[TRAIN].to(self.device, dtype=torch.float32)
        self.weights[DEV].to(self.device, dtype=torch.float32)

        # display debugging information
        #
        if dbgl > ndt.BRIEF:

            print("%s (line: %s) %s::%s: resnet training object loaded" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__))
            print("training weights = %s" % self.weights[TRAIN])
            print("development weights = %s" % self.weights[DEV])

        # exit gracefully
        #
        return True
    #
    # end of method

    def build_dataset(self, edf_file_list, csv_file_list, fp):
        """
        method: build_dataset

        arguments:
         edf_file_list : a list containing full paths of EDF files
         csv_file_list : a list containing full paths of CSV-BI annotation files
         fp : an open stream where progress information will be logged

        return:
         global_dataset : a list of tuples of the following form
          [(edf_path, start_sample, label), ...]

        description:
         Assemble a training dataset

         (1) Make sure every EDF has a partner CSV and vice-versa.
         (2) Confirm each EDF contains all channels required by the training
             montage.
         (3) For every EDF/CSV pair
               - cut the recording into fixed-size, non-overlapping frames
                 (self.frame_size samples each)
                 If the file length is not an integer multiple of
                 self.frame_size, append one last frame whose right edge
                 exceeds the nominal EOF.
               - parse the CSV with find_event_intervals
               - add a frame to the dataset only when it overlaps at least
                 one annotated event interval
         (4) Merge the per-file results into the final dataset_map
        """

        # print debug info
        #
        fp.write("training was conducted on the following files :\n")
        for edf_path in edf_file_list:
            fp.write(f"{edf_path}\n")

        # allocate the final structure: one empty list per label
        #
        global_dataset = list()

        # check that the lists are the same length
        #
        if len(edf_file_list) != len(csv_file_list):
            print("Error: %s (line: %s) %s: %s" %
                  (__FILE__, ndt.__LINE__, ndt.__NAME__,
                   "EDF list and CSV list differ in length"))
            sys.exit(os.EX_SOFTWARE)

        # get the csv base names
        #
        csv_base_to_path = {
            os.path.splitext(os.path.basename(csv_path))[0]: csv_path
            for csv_path in csv_file_list
        }

        # iterate over edf file list
        #
        for edf_path in edf_file_list:

            # get the edf base name
            #
            edf_base = os.path.splitext(os.path.basename(edf_path))[0]

            # ensure base name is present in csv list
            #
            if edf_base not in csv_base_to_path:
                 print("Error: %s (line: %s) %s: Csv file matching (%s) no found" %
                       (__FILE__, ndt.__LINE__, ndt.__NAME__, edf_path))
                 sys.exit(os.EX_SOFTWARE)

            # read the edf header
            #
            edf_reader = net.Edf()
            edf_reader.get_header_from_file(edf_path)

            # fetch the channel names
            #
            edf_channels_upper = [
                label.upper() for label in edf_reader.h_d[net.EDF_CHAN_LABELS]
            ]

            # load the montage
            #
            mont_tool = nmt.Montage()
            mont_tool.load(self.montage)
            montage_channels = mont_tool.get_montage_order()

            # ensure no channels are missing/added
            #
            missing_channels = [
                label for label in montage_channels
                if label.upper() not in edf_channels_upper
            ]
            if missing_channels:
                print("Error: %s (line: %s) %s: %s %s (%s)" %
                      (__FILE__, ndt.__LINE__, ndt.__NAME__, edf_path,
                       "missing channel(s) required by montage",
                       missing_channels))
                sys.exit(os.EX_SOFTWARE)

        # also verify that every CSV has a partner EDF
        #
        edf_basenames = {
            os.path.splitext(os.path.basename(path))[0]
            for path in edf_file_list
        }
        for csv_path in csv_file_list:
            csv_base = os.path.splitext(os.path.basename(csv_path))[0]
            if csv_base not in edf_basenames:
                 print("Error: %s (line: %s) %s: Edf file matching (%s) no found" %
                       (__FILE__, ndt.__LINE__, ndt.__NAME__, csv_path))
                 sys.exit(os.EX_SOFTWARE)

        # run the helper in parallel
        #
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:

            # send to executor the helper function to obtain local dataset
            #
            future_to_index = {
                executor.submit(
                    self._gather_frames,
                    edf_path,
                    csv_base_to_path[
                        os.path.splitext(os.path.basename(edf_path))[0]
                    ]
                ): idx
                for idx, edf_path in enumerate(edf_file_list)
            }

            # building global dataset
            #
            for fut in as_completed(future_to_index):
                global_dataset.extend(fut.result())

        # sort for determinism
        #
        global_dataset.sort(key=lambda t: (t[0], t[1]))
        
        # done return lazy dataset
        #
        return global_dataset
    #
    # end of method

    def _gather_frames(self, edf_file, csv_file):
        """
        method: _gather_frames

        arguments:
         edf_file : full path to an EDF recording
         csv_file : full path to its partner CSV annotation file

        return:
         local_map : [(edf_file_path, start_sample, label), ...]

        description:
         Cuts the recording into fixed-length frames and assigns
         exactly one label to each frame/window:

         1. choose the event that overlaps the largest amount
            of the frame;
         2. if that event is bckg and some other event
            covers at least DEF_BCKG_OVERRIDE_FRAC of the frame,
            re-assign the frame to that foreground label.

         This guarantees that no frame appears in more than one
         class bucket.
        """

        # prepare empty per-label buckets
        #
        local_dataset = list()

        # inspect the EDF once to get total sample count
        #
        edf_reader = net.Edf()
        edf_reader.get_header_from_file(edf_file)
        total_samp = edf_reader.get_num_samples(0)

        # build non-overlapping frame start indices (stride = frame_len)
        #
        frame_starts = list(range(0, total_samp, self.frmsize))

        # generate the window starting points
        #
        win_starts = \
            [int(frm_start + self.frmsize // 2 - self.winsize // 2) for
             frm_start in frame_starts]

        # parse CSV -> [(start, stop, label), ...] - already in samples
        #
        events = list(self.find_event_intervals(csv_file))
        
        # iterate over every frame
        #
        for w_start in win_starts:

            # calculate the window end
            #
            w_end = w_start + self.winsize

            # predefined best_lbl, best_ovlp
            #
            best_lbl, best_olen = nae.DEF_BCKG, 0
 
            # iterate over the annotation intervals
            #
            for e_start, e_end, e_lbl in events:

                # if a windows starting idx is less than the events end
                # and the windows ending idx is greater than the events
                # start we have some overlap
                #
                if (w_start < e_end) and (w_end > e_start):

                    # calculate the overlap
                    #
                    olen = min(w_end, e_end) - max(w_start, e_start)

                    # chance best overlap and label if necessary
                    #
                    if olen > best_olen:
                        best_olen, best_lbl = olen, e_lbl

            # store exactly one sample for this frame
            #
            local_dataset.append(
                (edf_file, w_start, best_lbl)
            )

        # exit gracefully
        #  return map
        #
        return local_dataset
    #
    # end of method

    def find_event_intervals(self, csvbi_fpath):
        """
        method: find_event_intervals

        arguments:
         csvbi_fpath: csv_bi full file path and filename

        return:
         events: list of (start_idx, stop_idx, label_string)

        description:
         This method reads a csv_bi file, fetches its event's time intervals,
         fills in un-annotated gaps as background, and returns index-based
         intervals for all classes.
        """

        # ensure the file exists
        #
        csvbi_fpath = nft.get_fullpath(csvbi_fpath)
        if not os.path.isfile(csvbi_fpath):
            print("Error: %s (line: %s) %s: csv file path doesn't exist (%s)" %
                  (__FILE__, ndt.__LINE__, ndt.__NAME__, csvbi_fpath))
            sys.exit(os.EX_SOFTWARE)

        # debug load
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: fetching csv bi information (%s)" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__, csvbi_fpath))

        # load annotations
        #
        ann = nae.AnnEeg(montage_f=self.montage)
        ann.load(csvbi_fpath, montage_f=self.montage)
        ann.set_graph(nae.remap_labels(ann.get_graph(), self.label_map))

        # Build one flat, time-ordered list of every event in the graph.
        #
        # Flatten to (start_sec, stop_sec, label_str) and sort deterministically
        #
        raw_events = []
        for lvl_dict in ann.get_graph().values():
            for sub_dict in lvl_dict.values():
                for ev_list in sub_dict.values():
                    for (s, t, lbl) in ev_list:
                        lab = list(lbl.keys())[0]
                        raw_events.append((float(s), float(t), lab))
        
        # stable total order: start, then stop, then label
        #
        raw_events.sort(key=lambda e: (e[0], e[1], e[2]))

        intervals = []
        prev_stop = 0

        # walk annotated events, insert background gaps
        #
        for start_sec, stop_sec, lbl in raw_events:
            cur_start = int(start_sec * self.samp_rate)
            cur_stop = int(stop_sec * self.samp_rate)

            # un-annotated gap -> background
            #
            if cur_start > prev_stop:
                intervals.append((prev_stop, cur_start, nae.DEF_BCKG))

            # annotated event
            #
            intervals.append((cur_start, cur_stop, lbl))
            prev_stop = cur_stop

        # trailing gap -> background
        #
        file_dur = \
            int(float(ann.get_header()[nae.CSV_KEY_DURATION])) * self.samp_rate
        if prev_stop < file_dur:
            intervals.append((prev_stop, file_dur, nae.DEF_BCKG))

        # exit gracefully
        #  return list of (start, stop, label)
        #
        return intervals
    #
    # end of method

    def __select_samples(self, image_set, nsamples_per_class):
        """
        method: __select_samples

        arguments:
         image_set: Dataset with .classes (list of class names)
           and .targets (list of ints)
         nsamples_per_class: dict mapping class name -> desired sample count

        return:
         subset: torch.utils.data.Subset of image_set
         nsamples_subdataset: dict mapping class name -> actual selected count

        description:
         Selects up to a specified number of samples per class from a dataset
         and logs the requested, available, and selected counts.
        """

        # get list of class names and convert targets to numpy
        #
        classes = list(image_set.classes)
        targets = np.array(image_set.targets)

        # compute how many are available per class
        #
        available = {cls: int((targets == idx).sum())
                     for idx, cls in enumerate(classes)}

        # determine how many to select per class (min(requested, available))
        #
        nsamples_subdataset = {}
        for cls in classes:
            req = nsamples_per_class.get(cls, 0)
            avail = available.get(cls, 0)
            if req == int(-1):
                sel = avail
            else:
                sel = min(req, avail)
            nsamples_subdataset[cls] = sel

        
        # collect indices for selected samples
        #
        selected_indices = []
        for idx, cls in enumerate(classes):
            count = nsamples_subdataset[cls]
            if count > 0:
                cls_idx = np.where(targets == idx)[0]
                chosen = np.random.choice(cls_idx, count, replace = False)
                selected_indices.extend(chosen.tolist())

        # exit gracefully
        # return the Subset and the per-class counts
        #
        return Subset(image_set, selected_indices), nsamples_subdataset
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # training methods
    #
    #--------------------------------------------------------------------------
    def train(self, batch_size, num_epochs, lr_rate, fp):
        """
        method: train

        arguments:
         batch_size: the training batch size
         num_epochs: the number of epochs for training
         lr_rate: the optimizer learning rate
         fp: file pointer to log file

        return:
         model: the trained model

        description
         this method is the main method of this class, this method will
         run the model training process num_epochs times
        """

        # display debugging information
        #
        if dbgl > ndt.BRIEF:

            print("%s (line: %s) %s::%s: preparing to train the model" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__))
            print("number of workers = %s" % self.num_workers)
            print("model file name = %s" % self.input_model_path)
            print("batch size = %s" % batch_size)
            print("number of epochs = %s" % num_epochs)
            print("save each epoch model = %s" % self.save_epoch_model)

        # keep the batch size for later
        #
        self.batch_size = batch_size

        # Set a random seed for the DataLoader shuffle
        #
        generator = torch.Generator()
        generator.manual_seed(ndt.RANDSEED)

        # create the train dataloader, this function creates an iterable
        # type that will allow us to iterate over the dataset
        #
        self.data_loaders[TRAIN] = torch.utils.data.DataLoader(
            self.image_sets[TRAIN], batch_size,
            shuffle=True,
            num_workers = self.num_workers,
            generator = generator,
            worker_init_fn=worker_init_fn,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=False,
            prefetch_factor=(4 if self.num_workers > 0 else None),
        )

        # create the dev dataloader, this function creates an iterable
        # type that will allow us to iterate over the dataset
        #
        self.data_loaders[DEV] = torch.utils.data.DataLoader(
            self.image_sets[DEV], batch_size,
            shuffle=False,
            num_workers = self.num_workers,
            worker_init_fn=worker_init_fn,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=False,
            prefetch_factor=(4 if self.num_workers > 0 else None),
        )
        
        
        # instantiate resnet18 model
        #
        model_ft = models.resnet18(weights=None)

        # load an nn.module (pre-trained model) if given
        #
        if self.input_model_path is not None:
            model_ft = torch.load(self.input_model_path, weights_only = False)

        # append linear layer
        #
        num_ftrs = model_ft.fc.in_features
        model_ft.fc = nn.Linear(num_ftrs, len(self.class_names))
        model_ft = model_ft.to(self.device)

        # load the model weights path
        #
        if self.input_model_weight_path is not None:

            # load the raw state dict (weights)
            #
            bundle = torch.load(
                self.input_model_weight_path, weights_only = True
            )

            if hasattr(bundle, ATTR_MODEL_STATE_DICT):
                raw_state = bundle[ATTR_MODEL_STATE_DICT]
            else:
                raw_state = bundle

            # clean up state dict naming issues caused by dataparallel if
            # present
            #
            clean = {}
            for k,v in raw_state.items():
                clean_key = k.replace(ATTR_MODEL_MODULE,nft.DELIM_NULL,1) \
                    if k.startswith(ATTR_MODEL_MODULE) else k
                clean[clean_key] = v

            # load the state dict
            #
            model_ft.load_state_dict(clean)

        # multi-gpu training support
        #
        if (self.device.type == DEVICE_GPU) and (self.num_gpus > 1):

            # fetch the number of available cuda gpus
            #
            available = torch.cuda.device_count()

            # clamp num_gpus depending on the amount actually
            # available
            #
            if available < self.num_gpus:
                self.num_gpus = available

            # instantiate a dataparallel model
            #
            model_ft = nn.DataParallel(
                model_ft,
                device_ids=list(range(self.num_gpus))
            )

        # send model to device
        #
        model_ft = model_ft.to(self.device) 

        # define the cross entropy loss function for the dev and train datasets,
        # this will allow us to calculate the error the model is generating,
        # and allow the model to adjust weights to find a better performance
        #
        train_criterion = \
            nn.CrossEntropyLoss(
                weight=self.weights[TRAIN].to(self.device),
                label_smoothing = 0.05
            )

        dev_criterion = \
            nn.CrossEntropyLoss(
                weight=self.weights[DEV].to(self.device)
            )

        # observe that all parameters are being optimized by using a stochastic
        # gradient descent algorithm, which will allow us to find optimum points
        # of a function by testing values, lr (learning rate) is the distance
        # between each point tested, momentum will monitor the values so that
        # we are moving in the correct direction to find the optimum point
        #
        optimizer_ft = \
            torch.optim.SGD(model_ft.parameters(),
                            lr = lr_rate,
                            momentum = DEF_MOMENTUM,
                            weight_decay = 1e-2,
                            nesterov = True )

        # lr_scheduler.StepLR will allow us to adjust the learning rate of the
        # stochastic gradient descent algorithm by subtracting 0.1 (the gamma
        # value) every 7 epochs (the step_size)
        #
        exp_lr_scheduler = lr_scheduler.StepLR(optimizer_ft,
                                               step_size = DEF_STEP_SIZE,
                                               gamma = DEF_GAMMA)

        # save loss function, optimizer, and lr scheduler names
        #
        loss_fn_name = type(train_criterion).__name__
        optimizer_name = type(optimizer_ft).__name__
        sched_name = type(exp_lr_scheduler).__name__

        # grab optimizer hyper-params from its .defaults dict
        #
        opt_hparams = optimizer_ft.defaults.copy()

        # pull scheduler settings from its attributes
        #
        sched_hparams = {
            "step_size": exp_lr_scheduler.step_size,
            "gamma":  exp_lr_scheduler.gamma,
        }

        # display debugging information
        #
        if dbgl > ndt.BRIEF:
            print("loss function = %s" % loss_fn_name)
            print("optimizer= %s" % optimizer_name)
            print("learning rate scheduler = %s" % sched_name)
            print("optimizer hyperparameters = %s" % opt_hparams)
            print("learning rate scheduler params = %s\n" % sched_hparams)

        # write debug info to log file
        #
        fp.write("loss function = %s" % loss_fn_name)
        fp.write("optimizer= %s" % optimizer_name)
        fp.write("learning rate scheduler = %s" % sched_name)
        fp.write("optimizer hyperparameters = %s" % opt_hparams)
        fp.write("learning rate scheduler params = %s\n" % sched_hparams)

        # train the model
        #
        model = \
            self.__train_model(model_ft, train_criterion, dev_criterion,
                               optimizer_ft, exp_lr_scheduler, fp, num_epochs)
        # exit gracefully
        #  return the trained model
        #
        return model
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # training methods
    #
    #--------------------------------------------------------------------------

    def __train_model(self, model, train_criterion, dev_criterion, optimizer,
                      scheduler, fp, num_epochs=16):
        """
        method: __train_model

        arguments:
         model: the neural network model which should be trained
         train_criterion: loss function for training (such as mse or
          cross entropy)
         dev_criterion: loss function for development (such as mse or
          cross entropy)
         optimizer: optimizer function (such as SGD or Adam)
         scheduler: scheduler object to change the optimizers parameters
         num_epochs: number of epochs which neural network will be trained
         fp: file pointer to log file

        return:
         model: the trained model

        description:
         This function accepts a model and trains it.
        """

        # display debugging information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: training model" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__))

        # compute batch sizes for the train and dev dataloader
        #
        train_len = len(self.data_loaders[TRAIN]) * \
            self.data_loaders[TRAIN].batch_size

        dev_len = len(self.data_loaders[DEV]) * \
            self.data_loaders[DEV].batch_size

        # keep track of the start time
        #
        since = time.time()

        # store the state_dict using deepcopy
        #
        best_model_wts = copy.deepcopy(model.state_dict())

        # set the initial accuracy as 0.0
        #
        best_acc = 0.0

        # set the initial loss as infinity
        #
        best_loss = float(DEF_WORST_LOSS_INIT)

        # iterate through amount of epochs
        #
        for epoch in range(num_epochs):
    
            # keep track of the time for each epoch
            #
            start_train = time.time()

            # print out which epoch is currently running
            #
            print(f'Epoch {epoch+1}/{num_epochs}')

            # write results to log file
            #
            fp.write(f'Epoch {epoch+1}/{num_epochs}\n')

            # print out a line to make the output look nice
            #
            print(nft.DELIM_DASH * 10)

            # Each epoch has a training and validation phase
            # set the model to training mode for the training phase
            #
            model.train()

            # preform all necessary operations to the train
            # data set and fetch its loss and corrects
            #
            running_loss , running_corrects = \
                self.train_loop(optimizer, model, train_criterion)

            # execute the scheduler to update learning rate
            #
            scheduler.step()

            # calculate the loss and accuracy for this epoch
            #
            train_loss = running_loss / train_len
            train_acc = running_corrects.double() / train_len

            # print a message with the elapsed time, the loss, and
            # the accuracy for this epoch
            #
            print(f'Train \t Elapsed: {time.time()-start_train:.2f} sec '
                  + f'Loss: {train_loss:.4f} Acc: {train_acc:.4f}')

            # write results to log file
            #
            fp.write(f'Train \t Elapsed: {time.time()-start_train:.2f} sec '
                     + f'Loss: {train_loss:.4f} Acc: {train_acc:.4f}\n')

            # log dev start time
            #
            start_dev = time.time()

            # check if we want to save model parameters for each epoch
            #
            if self.save_epoch_model:

                # save the epoch model
                #
                self.save_epoch_model_m(model, epoch)

            # set the model to eval mode for the validation phase
            #
            model.eval()

            # preform all necessary operations to the train data
            # set and fetch its loss and corrects
            #
            running_loss, running_corrects = \
                self.dev_loop(model, dev_criterion)

            # calculate the loss and accuracy for this epoch
            #
            dev_loss = running_loss / dev_len
            dev_acc = running_corrects.double() / dev_len

            # print a message with the elapsed time, the loss, and
            # the accuracy for this epoch
            #
            print(f'Devel \t Elapsed: {time.time()-start_dev:.2f} sec '
                  + f'Loss: {dev_loss:.4f} Acc: {dev_acc:.4f}\n')

            # write results to log file
            #
            fp.write(f'Devel \t Elapsed: {time.time()-start_dev:.2f} sec '
                     + f'Loss: {dev_loss:.4f} Acc: {dev_acc:.4f}\n')

            # check if this epoch improved the model by seeing if this
            # epoch decreased the loss
            #
            if dev_loss < best_loss:

                # set values for best accuracy and loss to this
                # epoch's values
                #
                best_acc = dev_acc
                best_loss = dev_loss

                # store the best model's weights by using deepcopy
                #
                best_model_wts = copy.deepcopy(model.state_dict())

        # calculate the total time
        #
        time_elapsed = time.time() - since

        # print a final message with total training time
        #
        print(f'Training completed in {time_elapsed // 60:.0f}m ' +
              f'{time_elapsed % 60:.0f}s')

        # write results to log file
        #
        fp.write(f'Training completed in {time_elapsed // 60:.0f}m ' +
                 f'{time_elapsed % 60:.0f}s\n')

        # load the best model weights
        #
        model.load_state_dict(best_model_wts)

        # exit gracefully
        #  return the best model
        #
        return model
    #
    # end of method

    def train_loop(self, optimizer, model, criterion):
        """
        method: train_loop

        arguments:
         optimizer: the chosen optimizer for training the model
         model: the model to train
         criterion: the loss function (cross entropy loss)

        return:
         running loss: the output of the loss function
         running corrects: the accuracy

        description:
         This function encompasses all train data set
         operations needed for and epoch of training in
         the train_model method
        """

        # set initial value for the running loss as 0
        #
        running_loss = 0.0

        # set initial value for running correct answers as 0
        #
        running_corrects = 0

        # iterate over the train dataloader
        #
        for inputs, labels in self.data_loaders[TRAIN]:

            # send the inputs and labels to the device
            #
            inputs = inputs.to(self.device, non_blocking=True)
            labels = labels.to(self.device, non_blocking=True)

            # zero the parameter gradients
            #
            optimizer.zero_grad()

            # start the forward pass (flow of information
            # from the input to the output of the neural network)
            # set set_grad_enabled to true to allow torch to
            # calculate the gradients
            #
            with torch.set_grad_enabled(True):

                # send the inputs to the model
                #
                outputs = model(inputs)

                # get the maximum confidence
                #
                _, preds = torch.max(outputs, 1)

                # calculate the loss using the cross entropy loss function
                #
                loss = criterion(outputs, labels)

                # start the backward pass (adjusting model weights)
                #
                # use loss.backward() to compute gradients
                #
                loss.backward()

                # update the model parameters
                #
                optimizer.step()

            # calculate the statistics, running loss, and the running
            # corrects
            #
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

        # exit gracefully
        #  return the running loss and corrects
        #
        return running_loss, running_corrects
    #
    # end of method

    def dev_loop(self, model, criterion):
        """
        method: dev_loop

        arguments:
         model: the model to develop
         criterion: the loss function (cross entropy loss)

        return:
         running loss: the output of the loss function
         running corrects: the accuracy

        description:
         This method encompasses all the dev data set operations
         needed for and epoch of training in the train_model method
        """

        # reset running loss
        #
        running_loss = 0.0

        # reset running corrects
        #
        running_corrects = 0

        # iterate over the dev dataloader
        #
        for inputs, labels in self.data_loaders[DEV]:

            # send the inputs and labels to the device
            #
            inputs = inputs.to(self.device, non_blocking=True)
            labels = labels.to(self.device, non_blocking=True)

            # set grad enabled to false as we won't be changing gradients
            #
            with torch.set_grad_enabled(False):

                # send the inputs to the model
                #
                outputs = model(inputs)

                # get the maximum confidence
                #
                _, preds = torch.max(outputs, 1)

                # calculate the loss using the cross entropy loss function
                #
                loss = criterion(outputs, labels)

            # calculate the statistics, running loss, and the running
            # corrects
            #
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

        # exit gracefully
        #  return running loss and corrects
        #
        return running_loss, running_corrects
    #
    # end of method

    #--------------------------------------------------------------------------
    #
    # model-based methods
    #
    #--------------------------------------------------------------------------

    def save_epoch_model_m(self, model, epoch):
        """
        method: save_epoch_model_m

        arguments:
         model: model to save
         epoch: current epoch number

        return:
         boolean value indicating status

        description:
         This method saves an epoch model to the file
         specified by the out_model_path
        """

        # get the output model file path
        #
        file_path = os.path.dirname(self.out_model_path)

        # extract the file extension
        #
        file_ext = os.path.splitext(self.out_model_path)[1][1:]

        # get the output model basename
        #
        file_bname = \
            os.path.splitext(os.path.basename(self.out_model_path))[0]

        # append the basename to include the epoch value
        #
        file_bname = file_bname + nft.DELIM_USCORE + str(epoch + 1)

        # create the final model filename for this epoch
        #
        epoch_fname = nft.create_filename(file_bname, file_path,
                                          file_ext, None)

        # save epoch model
        #
        if isinstance(model, torch.nn.DataParallel):
            state_dict = model.module.state_dict()
        else:
            state_dict = model.state_dict()
        torch.save(
            {
                ATTR_MODEL_STATE_DICT: state_dict,
                ATTR_MODEL_CLASS_TO_IDX_MAP: self.index_map,
                ATTR_MODEL_DEV_TRANSFORMS: self.transforms[TRAIN]
            },
            epoch_fname
        )

        # exit gracefully
        #
        return True
    #
    # end of method

    def read_stats(self, model, dataloader):
        """
        method: read_stats

        arguments:
         model: neural network model
         dataloader: the dataloaders dictionary

        return:
         all_labels: list of correct classifications (bckg or indc)
         all_preds: list of predicted classifications (bckg or indc)
         accuracy: the total classification accuracy

        description:
         This function will compute the values needed to compute the
         confusion matrix and accuracy
        """

        # display debugging information
        #
        if dbgl > ndt.BRIEF:
            print("%s (line: %s) %s::%s: fetching confusion matrix statistics" %
                  (__FILE__, ndt.__LINE__, EEGResNetTrain.__CLASS_NAME__,
                   ndt.__NAME__))

        # save the model state to restore it at the end
        #
        model.eval()

        # create helper variables to help create confusion matrix
        #
        all_labels, all_preds = [], []

        # loop over all epochs
        #
        lcounter = 0

        # use torch.no_grad() to specify torch to not calculate the gradients
        #
        with torch.no_grad():

            # iterate through the dataloader
            #
            for i, (inputs, labels) in enumerate(dataloader):

                # send the inputs and labels to the device
                #
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)

                # send the inputs to the model
                #
                outputs = model(inputs)

                # get the maximum confidence
                #
                _, preds = torch.max(outputs, 1)

                # append pred/label predictions
                #
                all_labels.extend(labels.cpu().numpy())
                all_preds.extend(preds.cpu().numpy())

                # increment lcounter
                #
                lcounter += len(labels)

        # convert lists to numpy
        #
        all_labels = np.asarray(all_labels)
        all_preds  = np.asarray(all_preds)

        # computing accuracy based on simple mean absolute error
        #
        accuracy = np.mean(all_labels == all_preds)

        # exit gracefully
        #  return all necessary statistics
        #
        return all_labels, all_preds, accuracy

    #
    # end of method

#
# end of class

#
# end of file
