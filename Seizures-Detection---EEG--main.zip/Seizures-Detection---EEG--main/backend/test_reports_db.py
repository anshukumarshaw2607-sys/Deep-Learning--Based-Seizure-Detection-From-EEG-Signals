#!/usr/bin/env python3
"""
Verify the reports API with proper authentication
Tests the complete flow of creating and fetching reports
"""
import asyncio
import sys
sys.path.insert(0, '/Users/fabir/Desktop/UNI/EEG _Project_FYP/eeg-seizure-detection/backend')

async def test_reports_database():
    """Test reports in the database directly"""
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.orm import sessionmaker
    from app.core.config import settings
    from app.models.reports import Report
    from sqlalchemy import select
    
    print("=" * 70)
    print("TESTING REPORTS DATABASE")
    print("=" * 70)
    
    try:
        # Create engine and session
        print(f"\n1. Connecting to database...")
        engine = create_async_engine(settings.database_url, echo=False)
        async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
        
        async with async_session() as session:
            # Check existing reports
            print(f"\n2. Checking existing reports...")
            query = select(Report)
            result = await session.execute(query)
            reports = result.scalars().all()
            print(f"   ✓ Found {len(reports)} reports in database")
            
            if reports:
                print(f"\n3. Existing reports:")
                for report in reports[:3]:
                    print(f"   - {report.id[:8]}... | {report.title} | Seizures: {report.seizure_count}")
                if len(reports) > 3:
                    print(f"   ... and {len(reports) - 3} more")
            
            # Check report fields that will be populated
            print(f"\n4. Checking report data structure...")
            if reports:
                sample = reports[0]
                print(f"   Report ID: {sample.id}")
                print(f"   Title: {sample.title}")
                print(f"   Type: {sample.report_type}")
                print(f"   Seizure Count: {sample.seizure_count}")
                print(f"   Seizure Percentage: {sample.seizure_percentage}")
                print(f"   Patient ID: {sample.patient_id}")
                print(f"   EEG File ID: {sample.eeg_file_id}")
                print(f"   Status: {sample.status}")
                print(f"   Created: {sample.analysis_timestamp}")
            else:
                print(f"   ℹ No reports yet - will be created when analysis completes")
        
        await engine.dispose()
        
    except Exception as e:
        print(f"   ✗ Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 70)
    print("DATABASE TEST COMPLETE")
    print("=" * 70)
    print("\nFlow Summary:")
    print("1. User runs seizure detection on Analysis page")
    print("2. Backend ML model processes EEG file")
    print("3. AnalysisContext receives results")
    print("4. createReportFromAnalysis() sends data to backend")
    print("5. Backend creates Report record in database")
    print("6. Reports page fetches and displays all reports")
    print("\nTo test the complete flow:")
    print("- Go to Analysis page")
    print("- Select a patient and EEG file")
    print("- Click 'Run Analysis'")
    print("- Wait for notification")
    print("- Go to Reports page to see the new report")

if __name__ == "__main__":
    asyncio.run(test_reports_database())
