#!/usr/bin/env python3
"""Debug frequency band calculation"""
import sys
sys.path.insert(0, r'c:\Users\fabir\Desktop\UNI\EEG _Project_FYP\eeg-seizure-detection\backend')

import mne
import numpy as np

test_file = r"c:\Users\fabir\Desktop\EEG python\EDF_EEG.edf"

# Load and preprocess
raw = mne.io.read_raw_edf(test_file, preload=True)
raw_filt = raw.copy().filter(0.1, 30)

# Compute PSD
print("Computing PSD for debugging...")
psd, freqs = mne.time_frequency.psd_array_multitaper(
    raw_filt.get_data(),
    sfreq=raw_filt.info['sfreq'],
    fmin=0.1,
    fmax=40,
    verbose=0
)

print(f"PSD shape: {psd.shape}")
print(f"Freqs shape: {freqs.shape}")
print(f"Freq range: {freqs[0]:.2f} - {freqs[-1]:.2f} Hz")
print(f"Freq resolution: {freqs[1] - freqs[0]:.4f} Hz")
print(f"PSD min: {psd.min():.6f}, max: {psd.max():.6f}, mean: {psd.mean():.6f}")

# Check a specific band
delta_idx = (freqs >= 0.5) & (freqs <= 4)
print(f"\nDelta band ({sum(delta_idx)} freq bins):")
print(f"  Freqs in band: {freqs[delta_idx][:5]}...")
print(f"  PSD in band (ch0): {psd[0, delta_idx][:5]}")
print(f"  Sum: {np.sum(psd[0, delta_idx]):.6f}")
print(f"  Mean: {np.mean(psd[0, delta_idx]):.6f}")
