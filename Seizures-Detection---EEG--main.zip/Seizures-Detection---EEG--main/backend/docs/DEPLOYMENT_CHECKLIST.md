# ✅ Render Deployment Checklist

Quick checklist for deploying EEG Seizure Detection on Render.

## Pre-Deployment

- [ ] Code is pushed to GitHub repository
- [ ] All tests pass locally
- [ ] `.env` files are NOT committed (check `.gitignore`)
- [ ] Database migrations are tested locally
- [ ] Frontend builds successfully (`npm run build`)
- [ ] Backend starts successfully (`uvicorn main:app`)

## Step 1: Create PostgreSQL Database

- [ ] Logged into Render dashboard
- [ ] Created PostgreSQL database service
- [ ] Saved Internal Database URL
- [ ] Saved External Database URL (for local testing)
- [ ] Database is running and accessible

## Step 2: Deploy Backend

- [ ] Created Web Service for backend
- [ ] Connected GitHub repository
- [ ] Set Root Directory: `backend`
- [ ] Set Build Command: `pip install -r requirements.txt && alembic upgrade head`
- [ ] Set Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- [ ] Set Health Check Path: `/health`
- [ ] Added environment variables:
  - [ ] `ENVIRONMENT=production`
  - [ ] `DATABASE_URL=<internal-database-url>`
  - [ ] `SECRET_KEY=<generated-secure-key>`
  - [ ] `RENDER=true`
  - [ ] `FRONTEND_URL=<will-update-after-frontend>`
- [ ] Service deployed successfully
- [ ] Health check passes: `curl https://your-backend.onrender.com/health`
- [ ] API docs accessible: `https://your-backend.onrender.com/docs`

## Step 3: Deploy Frontend

- [ ] Created Static Site for frontend
- [ ] Connected GitHub repository
- [ ] Set Root Directory: `frontend`
- [ ] Set Build Command: `npm install && npm run build`
- [ ] Set Publish Directory: `dist`
- [ ] Added environment variables:
  - [ ] `VITE_ENVIRONMENT=production`
  - [ ] `VITE_BACKEND_URL=https://your-backend.onrender.com`
- [ ] Service deployed successfully
- [ ] Frontend loads in browser

## Step 4: Configure CORS

- [ ] Updated backend `FRONTEND_URL` with frontend URL
- [ ] Or set `BACKEND_CORS_ORIGINS` with frontend URL
- [ ] Backend redeployed
- [ ] Frontend can connect to backend API (check browser console)

## Step 5: Upload ML Models to Render Disk

- [ ] Accessed backend Shell on Render
- [ ] Created models directory: `mkdir -p /opt/render/project/src/models`
- [ ] Uploaded model files to persistent disk (using one of the methods from guide)
- [ ] Verified models exist: `ls -lh /opt/render/project/src/models/`
- [ ] Set MODEL_PATH environment variable in backend service
- [ ] Verified model path: `python -c "from app.core.config import settings; print(settings.resolved_model_path)"`
- [ ] Tested model loading (check backend logs for errors)

## Step 6: Post-Deployment

- [ ] Database migrations applied (check backend logs)
- [ ] Created initial admin user
- [ ] Tested user registration/login
- [ ] Tested file upload (if applicable)
- [ ] Verified file storage directories exist (uploads/, reports/, models/)
- [ ] Tested ML inference/prediction endpoints (if applicable)
- [ ] Tested API endpoints from frontend
- [ ] Checked error logs for any issues

## Step 7: Security & Production

- [ ] `SECRET_KEY` is strong and secure (32+ characters)
- [ ] CORS origins are specific (not `*`)
- [ ] HTTPS is enabled (automatic on Render)
- [ ] Environment variables are set correctly
- [ ] No sensitive data in logs
- [ ] Database backups configured (if on paid plan)

## Step 7: Monitoring

- [ ] Health checks are passing
- [ ] Service metrics are being collected
- [ ] Logs are accessible and readable
- [ ] Error tracking is working (if configured)

## Testing Checklist

- [ ] Backend root endpoint: `GET /`
- [ ] Backend health check: `GET /health`
- [ ] Frontend loads without errors
- [ ] User can register new account
- [ ] User can login
- [ ] API calls from frontend work
- [ ] CORS is configured correctly
- [ ] File uploads work (if applicable)
- [ ] Database operations work

## Troubleshooting

If something fails:

1. [ ] Check Render service logs
2. [ ] Verify environment variables
3. [ ] Test database connection
4. [ ] Check build logs for errors
5. [ ] Verify file paths and permissions
6. [ ] Review CORS configuration
7. [ ] Check service status in dashboard

## Quick Commands Reference

```bash
# Generate SECRET_KEY
python -c 'import secrets; print(secrets.token_urlsafe(32))'

# Test backend health
curl https://your-backend.onrender.com/health

# Test backend API
curl https://your-backend.onrender.com/

# Check frontend
# Open in browser: https://your-frontend.onrender.com
```

## Environment Variables Summary

### Backend Required:
- `ENVIRONMENT=production`
- `DATABASE_URL=<from-postgres-service>`
- `SECRET_KEY=<generated-key>`
- `RENDER=true`
- `FRONTEND_URL=<frontend-url>`

### Frontend Required:
- `VITE_ENVIRONMENT=production`
- `VITE_BACKEND_URL=<backend-url>`

## Next Steps After Deployment

- [ ] Set up custom domain (optional)
- [ ] Configure monitoring alerts
- [ ] Set up automated backups
- [ ] Document API endpoints for users
- [ ] Create user documentation
- [ ] Plan for scaling (if needed)

---

**Deployment Date:** _______________
**Backend URL:** https://________________.onrender.com
**Frontend URL:** https://________________.onrender.com
**Database:** eeg-seizure-db

---

For detailed instructions, see [RENDER_DEPLOYMENT.md](./RENDER_DEPLOYMENT.md)

