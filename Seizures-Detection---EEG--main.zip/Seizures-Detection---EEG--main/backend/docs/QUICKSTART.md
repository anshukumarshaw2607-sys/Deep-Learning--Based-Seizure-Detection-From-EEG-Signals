# Backend Quick Start Guide

Get the EEG Seizure Detection backend up and running in minutes!

## ⚡ Prerequisites

- **Python 3.10+** installed
- **PostgreSQL** database server running
- **pip** package manager

## 🚀 Quick Setup (5 minutes)

### Step 1: Navigate to Backend Directory
```bash
cd backend
```

### Step 2: Create Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment
```bash
# Copy the example environment file
cp env.example .env

# Edit .env and set at minimum:
# ENVIRONMENT=development
# DATABASE_URL=postgresql+asyncpg://postgres:101325@localhost:5432/eeg_seizure_db
```

**Minimal `.env` for development:**
```bash
ENVIRONMENT=development
DATABASE_URL=postgresql+asyncpg://postgres:101325@localhost:5432/eeg_seizure_db
```

> 💡 **Tip:** The system auto-configures most settings based on `ENVIRONMENT=development`. See `ENV_SETUP.md` for details.

### Step 5: Set Up Database
```bash
# Create PostgreSQL database (if not exists)
createdb eeg_seizure_db

# Or using psql:
psql -U postgres
CREATE DATABASE eeg_seizure_db;
\q

# Run database migrations
alembic upgrade head
```

### Step 6: Start the Server
```bash
# Option 1: Using Python directly
python main.py

# Option 2: Using uvicorn directly
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Option 3: Using Invoke (recommended)
invoke dev
```

### Step 7: Verify It's Running
Open your browser and visit:
- **API Root:** http://localhost:8000
- **Interactive Docs:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/health

## ✅ Success Checklist

- [ ] Virtual environment created and activated
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] `.env` file created with `ENVIRONMENT=development`
- [ ] PostgreSQL database created
- [ ] Database migrations applied (`alembic upgrade head`)
- [ ] Server running on http://localhost:8000
- [ ] API docs accessible at http://localhost:8000/docs

## 🛠️ Common Commands

### Development
```bash
# Start development server with auto-reload
invoke dev

# Or using uvicorn
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Database Migrations
```bash
# Create a new migration
invoke migrations-auto --message "description of changes"

# Apply migrations
invoke migrate

# Rollback last migration
invoke rollback
```

### Maintenance
```bash
# Clean Python cache files
invoke clean-pyc
```

## 🔧 Troubleshooting

### Issue: "Module not found" errors
**Solution:** Make sure virtual environment is activated and dependencies are installed:
```bash
pip install -r requirements.txt
```

### Issue: Database connection errors
**Solution:** 
1. Verify PostgreSQL is running
2. Check `DATABASE_URL` in `.env` matches your database credentials
3. Ensure database exists: `createdb eeg_seizure_db`

### Issue: Port 8000 already in use
**Solution:** Change the port in `.env`:
```bash
PORT=8001
```

### Issue: CORS errors
**Solution:** For development, CORS is auto-configured. If issues persist, check `FRONTEND_URL` in `.env`.

## 📚 Next Steps

- **Read Full Documentation:** See `README.md` for complete API documentation
- **Environment Setup:** See `ENV_SETUP.md` for detailed environment configuration
- **API Endpoints:** Visit http://localhost:8000/docs for interactive API documentation
- **Frontend Setup:** See `../frontend/docs/QUICKSTART.md` to set up the frontend

## 🚢 Production Deployment

For production deployment on Render, see the deployment section in `README.md` or set:
```bash
ENVIRONMENT=production
SECRET_KEY=<generate-secure-key>
FRONTEND_URL=https://your-frontend-domain.com
```

Generate a secure secret key:
```bash
python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

### Render Database Compatibility

**Yes, Render's PostgreSQL databases work with both connection formats:**

- **`postgresql://`** - Uses psycopg2 (synchronous, current setup)
- **`postgresql+asyncpg://`** - Uses asyncpg (asynchronous, requires async SQLAlchemy)

Render provides standard PostgreSQL databases that support both drivers. The `DATABASE_URL` provided by Render will be in the format `postgresql://...`, but you can change it to `postgresql+asyncpg://...` if you're using async SQLAlchemy.

> **Note:** The current codebase uses synchronous SQLAlchemy. To use `postgresql+asyncpg://`, you'll need to migrate to async SQLAlchemy (`create_async_engine`, `AsyncSession`).

## 💡 Tips

- Use `invoke dev` for development - it includes auto-reload
- Check `http://localhost:8000/docs` for interactive API testing
- Environment variables prefixed with `VITE_` are for frontend only
- The system auto-detects Render deployment and configures accordingly

---

**Need Help?** Check the other documentation files:
- `README.md` - Complete backend documentation
- `ENV_SETUP.md` - Detailed environment setup guide
- `CONFIGURATION_SUMMARY.md` - Configuration overview

