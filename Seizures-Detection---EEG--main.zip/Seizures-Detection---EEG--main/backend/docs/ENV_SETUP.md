# Environment Configuration Guide

## Quick Start

This backend uses **environment-based auto-configuration**. You only need to set `ENVIRONMENT=development` or `ENVIRONMENT=production`, and most settings are automatically configured!

## Required Environment Variables

### Minimum Setup

**For Development:**
```bash
ENVIRONMENT=development
DATABASE_URL=postgresql://user:password@localhost:5432/eeg_seizure_db
```

**For Production (Render):**
```bash
ENVIRONMENT=production
SECRET_KEY=<generate-secure-key-here>
FRONTEND_URL=https://your-frontend-domain.com
```

## Environment Variables Reference

### Core Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ENVIRONMENT` | ✅ | `development` | Set to `development` or `production` - auto-configures everything |
| `DATABASE_URL` | ✅ (prod) | Dev default | PostgreSQL connection string |
| `SECRET_KEY` | ✅ (prod) | Dev default | JWT secret key (generate secure one for prod) |

### Auto-Configured (Based on ENVIRONMENT)

These are automatically set based on `ENVIRONMENT` and `RENDER` detection:

- **DEBUG**: `True` for dev, `False` for prod
- **CORS Origins**: Localhost for dev, production URLs for prod
- **File Storage Paths**: Local dirs for dev, Render disk for prod
- **Allowed Hosts**: Localhost for dev, Render hostname for prod

### Optional Overrides

| Variable | Description | When to Set |
|----------|-------------|-------------|
| `FRONTEND_URL` | Frontend domain | Production (for CORS) |
| `BACKEND_CORS_ORIGINS` | Custom CORS origins | If auto-configuration insufficient |
| `ALLOWED_HOSTS` | Custom allowed hosts | If auto-configuration insufficient |
| `UPLOAD_DIR` | Custom upload directory | If default paths don't work |
| `REPORTS_DIR` | Custom reports directory | If default paths don't work |
| `MODEL_PATH` | Path to ML model | When you have a trained model |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | JWT expiration | If default 30 min not suitable |

## Generating SECRET_KEY

For production, generate a secure secret key:

```bash
python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

## Render Deployment

### Automatic Detection

The system automatically detects Render deployment via the `RENDER` environment variable (set by Render).

### Render Auto-Configuration

When `RENDER=true`:
- Uses `/opt/render/project/src/uploads` for file storage
- Uses `/opt/render/project/src/reports` for reports
- Uses `RENDER_EXTERNAL_HOSTNAME` for CORS (if FRONTEND_URL not set)
- Uses `PORT` from Render environment
- Uses `DATABASE_URL` from linked PostgreSQL service

### Render Environment Variables

**Required:**
- `ENVIRONMENT=production`
- `SECRET_KEY=<secure-key>`
- `FRONTEND_URL=https://your-frontend.onrender.com`

**Auto-provided by Render:**
- `DATABASE_URL` (from PostgreSQL service)
- `PORT` (from Render)
- `RENDER=true`
- `RENDER_EXTERNAL_HOSTNAME` (your service URL)

## Examples

### Development .env
```bash
ENVIRONMENT=development
DATABASE_URL=postgresql://postgres:password@localhost:5432/eeg_seizure_db
# SECRET_KEY optional - uses insecure default
```

### Production .env (Render)
```bash
ENVIRONMENT=production
SECRET_KEY=your-super-secure-key-generated-above
FRONTEND_URL=https://eeg-frontend.onrender.com
# DATABASE_URL provided by Render
# PORT provided by Render
```

## Validation

The system will:
- ✅ Warn if `SECRET_KEY` missing in production
- ✅ Warn if `DATABASE_URL` missing in production
- ✅ Auto-configure CORS for development
- ✅ Auto-configure file paths for Render

## Troubleshooting

**Issue**: "SECRET_KEY must be set in production"
- **Solution**: Generate and set `SECRET_KEY` in your environment

**Issue**: "DATABASE_URL must be set in production"
- **Solution**: Ensure PostgreSQL service is linked on Render, or set `DATABASE_URL` manually

**Issue**: CORS errors in production
- **Solution**: Set `FRONTEND_URL` or `BACKEND_CORS_ORIGINS` explicitly

**Issue**: Files not persisting on Render
- **Solution**: Enable Persistent Disk in Render dashboard

