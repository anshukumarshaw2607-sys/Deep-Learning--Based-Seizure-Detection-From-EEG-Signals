# 🚀 Render Deployment Guide - EEG Seizure Detection System

Complete step-by-step guide to deploy your EEG Seizure Detection application on Render.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Overview](#project-overview)
3. [Deployment Architecture](#deployment-architecture)
4. [Step-by-Step Deployment](#step-by-step-deployment)
5. [Environment Variables Configuration](#environment-variables-configuration)
6. [Post-Deployment Setup](#post-deployment-setup)
7. [Troubleshooting](#troubleshooting)
8. [Continuous Deployment](#continuous-deployment)

---

## Prerequisites

Before starting, ensure you have:

- ✅ GitHub account with your project repository
- ✅ Render account (sign up at [render.com](https://render.com))
- ✅ PostgreSQL database (we'll create this on Render)
- ✅ Basic understanding of environment variables

---

## Project Overview

Your project consists of:

| Component | Technology | Location | Purpose |
|-----------|-----------|----------|---------|
| **Backend** | FastAPI (Python) | `backend/` | REST API, ML inference, file processing |
| **Frontend** | React + Vite | `frontend/` | User interface |
| **Database** | PostgreSQL | Render PostgreSQL | User data, metadata |
| **Storage** | Render Persistent Disk | `/opt/render/project/src/` | EEG files, reports, ML models |

---

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Render Platform                       │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────┐      ┌──────────────┐                 │
│  │  Frontend    │──────│   Backend    │                 │
│  │  (Web)       │      │  (Web)       │                 │
│  │  React/Vite  │      │  FastAPI     │                 │
│  └──────────────┘      └──────┬───────┘                 │
│                               │                          │
│                       ┌───────▼───────┐                 │
│                       │  PostgreSQL   │                 │
│                       │   Database    │                 │
│                       └───────────────┘                 │
│                                                           │
│  ┌──────────────────────────────────────┐              │
│  │   Persistent Disk                     │              │
│  │   /opt/render/project/src/            │              │
│  │   - models/ (ML prediction models)    │              │
│  │   - uploads/ (EEG files)              │              │
│  │   - reports/ (Generated reports)      │              │
│  └──────────────────────────────────────┘              │
│                                                           │
└─────────────────────────────────────────────────────────┘
```

---

## Step-by-Step Deployment

### Step 1: Prepare Your Repository

1. **Ensure your code is pushed to GitHub:**
   ```bash
   git add .
   git commit -m "Prepare for Render deployment"
   git push origin main
   ```

2. **Verify important files exist:**
   - ✅ `backend/requirements.txt`
   - ✅ `backend/main.py`
   - ✅ `frontend/package.json`
   - ✅ `backend/env.example`
   - ✅ `frontend/env.example`

---

### Step 2: Create PostgreSQL Database on Render

1. **Log in to Render Dashboard:**
   - Go to [dashboard.render.com](https://dashboard.render.com)

2. **Create New PostgreSQL Database:**
   - Click **"New +"** → **"PostgreSQL"**
   - Configure:
     - **Name:** `eeg-seizure-db` (or your preferred name)
     - **Database:** `eeg_seizure_db`
     - **User:** (auto-generated)
     - **Region:** Choose closest to your users
     - **PostgreSQL Version:** 15 or 16 (recommended)
     - **Plan:** Free tier available (upgrade for production)

3. **Save Connection Details:**
   - After creation, note the **Internal Database URL** and **External Database URL**
   - Format: `postgresql://user:password@host:port/database`
   - You'll need this for the backend service

---

### Step 3: Deploy Backend Service

1. **Create New Web Service:**
   - Click **"New +"** → **"Web Service"**
   - Connect your GitHub repository

2. **Configure Backend Service:**

   **Basic Settings:**
   - **Name:** `eeg-seizure-backend` (or your preferred name)
   - **Region:** Same as database
   - **Branch:** `main`
   - **Root Directory:** `backend`
   - **Runtime:** `Python 3`
   - **Build Command:** 
     ```bash
     pip install -r requirements.txt && alembic upgrade head
     ```
   - **Start Command:**
     ```bash
     uvicorn main:app --host 0.0.0.0 --port $PORT
     ```

   **Environment Variables:**
   Add these in the Render dashboard (see [Environment Variables](#environment-variables-configuration) section below):
   ```
   ENVIRONMENT=production
   DATABASE_URL=<from PostgreSQL service>
   SECRET_KEY=<generate secure key>
   FRONTEND_URL=<will set after frontend deployment>
   RENDER=true
   ```

3. **Advanced Settings:**
   - **Auto-Deploy:** `Yes` (for continuous deployment)
   - **Health Check Path:** `/health`
   - **Plan:** Free tier available (upgrade for production)

4. **Create Service:**
   - Click **"Create Web Service"**
   - Wait for initial deployment (5-10 minutes)

---

### Step 4: Deploy Frontend Service

1. **Create New Static Site:**
   - Click **"New +"** → **"Static Site"**
   - Connect your GitHub repository

2. **Configure Frontend Service:**

   **Basic Settings:**
   - **Name:** `eeg-seizure-frontend` (or your preferred name)
   - **Branch:** `main`
   - **Root Directory:** `frontend`
   - **Build Command:**
     ```bash
     npm install && npm run build
     ```
   - **Publish Directory:** `dist`

   **Environment Variables:**
   Add these in the Render dashboard:
   ```
   VITE_ENVIRONMENT=production
   VITE_BACKEND_URL=https://eeg-seizure-backend.onrender.com
   ```

   **Note:** Replace `eeg-seizure-backend.onrender.com` with your actual backend URL from Step 3.

3. **Create Service:**
   - Click **"Create Static Site"**
   - Wait for initial deployment (3-5 minutes)

---

### Step 5: Update Backend CORS Configuration

After frontend deployment:

1. **Get Frontend URL:**
   - From your frontend service dashboard, copy the URL
   - Format: `https://eeg-seizure-frontend.onrender.com`

2. **Update Backend Environment Variables:**
   - Go to backend service → **Environment** tab
   - Update `FRONTEND_URL`:
     ```
     FRONTEND_URL=https://eeg-seizure-frontend.onrender.com
     ```
   - Or set `BACKEND_CORS_ORIGINS`:
     ```
     BACKEND_CORS_ORIGINS=https://eeg-seizure-frontend.onrender.com
     ```

3. **Redeploy Backend:**
   - Click **"Manual Deploy"** → **"Deploy latest commit"**
   - Or push a new commit to trigger auto-deploy

---

## Environment Variables Configuration

### Backend Environment Variables

Add these in your **Backend Service** → **Environment** tab:

| Variable | Value | Required | Description |
|----------|-------|----------|-------------|
| `ENVIRONMENT` | `production` | ✅ Yes | Sets production mode |
| `DATABASE_URL` | `postgresql://...` | ✅ Yes | From PostgreSQL service (Internal URL) |
| `SECRET_KEY` | `your-secret-key` | ✅ Yes | Generate with: `python -c 'import secrets; print(secrets.token_urlsafe(32))'` |
| `FRONTEND_URL` | `https://...` | ✅ Yes | Your frontend URL |
| `RENDER` | `true` | ✅ Yes | Enables Render-specific paths |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | `30` | ❌ Optional | JWT token expiration |
| `REFRESH_TOKEN_EXPIRE_DAYS` | `7` | ❌ Optional | Refresh token expiration |
| `MAX_UPLOAD_SIZE` | `104857600` | ❌ Optional | Max file size (100MB) |
| `MODEL_PATH` | `/opt/render/project/src/models/your_model.h5` | ❌ Optional | ML model file path (auto-configured to `/opt/render/project/src/models` if RENDER=true) |
| `MODEL_TYPE` | `resnet` | ❌ Optional | Model type identifier |
| `UPLOAD_DIR` | `/opt/render/project/src/uploads` | ❌ Optional | Auto-configured if RENDER=true |
| `REPORTS_DIR` | `/opt/render/project/src/reports` | ❌ Optional | Auto-configured if RENDER=true |

**Generate SECRET_KEY:**
```bash
python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

### Frontend Environment Variables

Add these in your **Frontend Service** → **Environment** tab:

| Variable | Value | Required | Description |
|----------|-------|----------|-------------|
| `VITE_ENVIRONMENT` | `production` | ✅ Yes | Sets production mode |
| `VITE_BACKEND_URL` | `https://eeg-seizure-backend.onrender.com` | ✅ Yes | Your backend URL |

**Note:** All Vite environment variables must be prefixed with `VITE_` to be accessible in the frontend.

---

## Post-Deployment Setup

### 1. Run Database Migrations

The backend build command includes `alembic upgrade head`, but you can verify:

1. **Check Backend Logs:**
   - Go to backend service → **Logs** tab
   - Look for: `INFO [alembic.runtime.migration] Running upgrade ...`

2. **Manual Migration (if needed):**
   - Use Render Shell:
     - Go to backend service → **Shell** tab
     - Run: `alembic upgrade head`

### 2. Upload ML Models to Render Disk

Your prediction models need to be stored on Render's persistent disk. The models directory is automatically created at `/opt/render/project/src/models` when `RENDER=true`.

**Option A: Using Render Shell (Recommended)**

1. **Access Backend Shell:**
   - Go to backend service → **Shell** tab

2. **Create models directory (if not exists):**
   ```bash
   mkdir -p /opt/render/project/src/models
   ```

3. **Upload your model files:**
   
   **Method 1: Using `scp` or `rsync` (if you have SSH access):**
   ```bash
   # From your local machine
   scp path/to/your/model.h5 user@your-service.onrender.com:/opt/render/project/src/models/
   ```
   
   **Method 2: Using Render Shell with file upload:**
   - Render Shell doesn't support direct file upload
   - Use Method 3 or 4 instead

   **Method 3: Using a temporary API endpoint (create one-time upload endpoint):**
   - Create a temporary admin endpoint to upload models
   - Upload via HTTP POST with authentication
   - Remove endpoint after upload

   **Method 4: Using Git LFS or include in repository (for small models):**
   - If models are < 100MB, you can commit them to a private branch
   - Push to GitHub
   - Pull in Render Shell:
     ```bash
     cd /opt/render/project/src
     git pull origin your-branch
     cp backend/models/*.h5 /opt/render/project/src/models/
     ```

4. **Verify models are uploaded:**
   ```bash
   ls -lh /opt/render/project/src/models/
   ```

5. **Set MODEL_PATH environment variable:**
   - Go to backend service → **Environment** tab
   - Add or update:
     ```
     MODEL_PATH=/opt/render/project/src/models/your_model.h5
     ```
   - Or if you have multiple models in the directory:
     ```
     MODEL_PATH=/opt/render/project/src/models
     ```

**Option B: Using Build Script (For Models in Repository)**

If your models are in your repository (using Git LFS for large files):

1. **Update build command:**
   ```
   pip install -r requirements.txt && alembic upgrade head && mkdir -p /opt/render/project/src/models && cp -r backend/models/* /opt/render/project/src/models/ 2>/dev/null || true
   ```

2. **Set MODEL_PATH:**
   ```
   MODEL_PATH=/opt/render/project/src/models/your_model.h5
   ```

**Option C: Download Models During Build**

If your models are stored externally (S3, Google Drive, etc.):

1. **Update build command:**
   ```
   pip install -r requirements.txt && mkdir -p /opt/render/project/src/models && curl -L https://your-model-url.com/model.h5 -o /opt/render/project/src/models/model.h5 && alembic upgrade head
   ```

2. **Set MODEL_PATH:**
   ```
   MODEL_PATH=/opt/render/project/src/models/model.h5
   ```

**Important Notes:**
- Models stored on Render persistent disk persist across deployments
- Model files are NOT included in Git (see `.gitignore`)
- Ensure your disk has enough space (check disk size in Render dashboard)
- Default model path on Render: `/opt/render/project/src/models`
- The `resolved_model_path` in config automatically uses this path when `RENDER=true`

### 3. Create Initial Admin User

1. **Access Backend Shell:**
   - Go to backend service → **Shell** tab

2. **Create Admin User:**
   ```python
   python -c "
   from app.services.users import create_user
   from app.schemas.users import UserCreate
   import asyncio
   
   async def main():
       user_data = UserCreate(
           email='admin@example.com',
           password='SecurePassword123!',
           full_name='Admin User',
           is_admin=True
       )
       user = await create_user(user_data)
       print(f'Admin user created: {user.email}')
   
   asyncio.run(main())
   "
   ```

   Or use the API endpoint after deployment:
   ```bash
   curl -X POST https://your-backend.onrender.com/api/v1/auth/register \
     -H "Content-Type: application/json" \
     -d '{"email":"admin@example.com","password":"SecurePassword123!","full_name":"Admin User"}'
   ```

### 4. Verify Deployment

1. **Backend Health Check:**
   ```bash
   curl https://your-backend.onrender.com/health
   # Expected: {"status":"healthy"}
   ```

2. **Backend API Root:**
   ```bash
   curl https://your-backend.onrender.com/
   # Expected: {"message":"EEG Seizure Detection API",...}
   ```

3. **Frontend:**
   - Visit your frontend URL in browser
   - Should load the React application

4. **Test API Connection:**
   - Open browser console on frontend
   - Check for API connection errors
   - Verify CORS is working

---

## Troubleshooting

### Common Issues

#### 1. Backend Fails to Start

**Symptoms:** Service shows "Failed" status

**Solutions:**
- Check **Logs** tab for error messages
- Verify `DATABASE_URL` is correct (use Internal URL)
- Ensure `SECRET_KEY` is set
- Check Python version compatibility
- Verify `requirements.txt` is correct

#### 2. Database Connection Errors

**Symptoms:** `psycopg2.OperationalError` or connection timeout

**Solutions:**
- Use **Internal Database URL** (not External) for `DATABASE_URL`
- Ensure database service is running
- Check database credentials
- Verify network connectivity (should work automatically on Render)

#### 3. CORS Errors

**Symptoms:** Frontend can't connect to backend API

**Solutions:**
- Verify `FRONTEND_URL` in backend environment variables
- Check `BACKEND_CORS_ORIGINS` includes frontend URL
- Ensure frontend URL has no trailing slash
- Check browser console for specific CORS error

#### 4. Migration Errors

**Symptoms:** `alembic` fails during build

**Solutions:**
- Check database is accessible
- Verify `DATABASE_URL` format (should be `postgresql://`, not `postgresql+asyncpg://` for Alembic)
- Check migration files are in `backend/alembic/versions/`
- Review migration logs in build output

#### 5. File Upload/Storage Issues

**Symptoms:** Files not saving or reports not generating

**Solutions:**
- Verify directories exist: `/opt/render/project/src/uploads` and `/opt/render/project/src/reports`
- Check file permissions (Render handles this automatically)
- Ensure `UPLOAD_DIR` and `REPORTS_DIR` are set correctly
- Check disk space on Render plan

#### 6. ML Model Loading Issues

**Symptoms:** Model not found or model loading errors

**Solutions:**
- Verify model file exists: `ls -lh /opt/render/project/src/models/`
- Check `MODEL_PATH` environment variable is set correctly
- Ensure model file is uploaded to persistent disk (not lost on redeploy)
- Verify model file format matches your ML framework (TensorFlow/PyTorch)
- Check disk space for model files
- Review backend logs for specific model loading errors
- Test model path: `python -c "from app.core.config import settings; print(settings.resolved_model_path)"`

#### 7. Frontend Build Fails

**Symptoms:** Build command fails

**Solutions:**
- Check Node.js version (Render auto-detects)
- Verify `package.json` is valid
- Check for missing dependencies
- Review build logs for specific errors

#### 8. Environment Variables Not Working

**Symptoms:** Frontend can't access backend URL

**Solutions:**
- Ensure variables are prefixed with `VITE_` for frontend
- Rebuild frontend after adding variables
- Check variable names match exactly (case-sensitive)
- Verify variables are set in correct service

### Getting Help

1. **Check Render Logs:**
   - Backend: Service → **Logs** tab
   - Frontend: Service → **Logs** tab

2. **Render Documentation:**
   - [Render Docs](https://render.com/docs)
   - [Python on Render](https://render.com/docs/python)
   - [Static Sites on Render](https://render.com/docs/static-sites)

3. **Test Locally:**
   - Reproduce issues in local development
   - Check environment variable configuration

---

## Continuous Deployment

### Automatic Deployments

Render automatically deploys when you push to your connected branch:

1. **Push to GitHub:**
   ```bash
   git add .
   git commit -m "Your changes"
   git push origin main
   ```

2. **Render Detects Changes:**
   - Automatically starts new build
   - Shows progress in dashboard

3. **Deployment Complete:**
   - Service updates with new code
   - Zero downtime (for web services)

### Manual Deployments

To deploy a specific commit:

1. Go to service dashboard
2. Click **"Manual Deploy"**
3. Select commit or branch
4. Click **"Deploy"**

### Deployment Settings

Configure in service → **Settings**:

- **Auto-Deploy:** Enable/disable automatic deployments
- **Branch:** Change deployment branch
- **Pull Request Previews:** Enable for PR testing

---

## Production Checklist

Before going live, ensure:

- [ ] All environment variables are set correctly
- [ ] Database migrations are applied
- [ ] Admin user is created
- [ ] CORS is configured properly
- [ ] SECRET_KEY is strong and secure
- [ ] Frontend and backend URLs are correct
- [ ] Health checks are passing
- [ ] File storage directories exist
- [ ] ML model is uploaded (if applicable)
- [ ] SSL certificates are active (automatic on Render)
- [ ] Monitoring is set up (Render provides basic monitoring)
- [ ] Backup strategy is in place (for database)

---

## Cost Optimization

### Free Tier Limits

- **Web Services:** 750 hours/month (enough for 24/7 on one service)
- **PostgreSQL:** 90 days free, then $7/month
- **Static Sites:** Free, unlimited

### Upgrade Considerations

Upgrade to paid plans for:
- More resources (CPU, RAM)
- Better performance
- Longer database retention
- Priority support

---

## Security Best Practices

1. **Never commit `.env` files** (already in `.gitignore`)
2. **Use strong SECRET_KEY** (32+ characters, random)
3. **Enable HTTPS only** (automatic on Render)
4. **Set proper CORS origins** (don't use `*` in production)
5. **Regular database backups** (Render provides automatic backups on paid plans)
6. **Monitor logs** for suspicious activity
7. **Keep dependencies updated** (security patches)

---

## Next Steps

After successful deployment:

1. **Set up monitoring:**
   - Use Render's built-in metrics
   - Set up external monitoring (optional)

2. **Configure custom domain:**
   - Add custom domain in Render dashboard
   - Update DNS records
   - Update `FRONTEND_URL` and CORS settings

3. **Set up backups:**
   - Enable automatic database backups
   - Configure backup retention

4. **Performance optimization:**
   - Enable caching
   - Optimize database queries
   - Use CDN for static assets (Render provides this)

---

## Support & Resources

- **Render Documentation:** https://render.com/docs
- **Render Community:** https://community.render.com
- **Render Status:** https://status.render.com
- **Project Repository:** Your GitHub repo

---

## Quick Reference

### Backend Service URLs
- **API Root:** `https://your-backend.onrender.com/`
- **Health Check:** `https://your-backend.onrender.com/health`
- **API Docs:** `https://your-backend.onrender.com/docs`
- **ReDoc:** `https://your-backend.onrender.com/redoc`

### Frontend Service URL
- **Application:** `https://your-frontend.onrender.com`

### Database Connection
- **Internal URL:** Use for `DATABASE_URL` in backend
- **External URL:** Use for local development/testing

---

**Last Updated:** 2024
**Project:** EEG Seizure Detection System
**Platform:** Render

