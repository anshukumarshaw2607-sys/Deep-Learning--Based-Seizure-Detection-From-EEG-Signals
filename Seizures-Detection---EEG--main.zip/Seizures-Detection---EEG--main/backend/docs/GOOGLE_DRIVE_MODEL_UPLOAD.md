# 📤 Uploading Models to Google Drive & Downloading on Render

This guide explains how to upload your model files to Google Drive and configure Render to download them automatically.

## Step 1: Upload Models to Google Drive

### Option A: Using Google Drive Web Interface

1. **Go to Google Drive:**
   - Visit [drive.google.com](https://drive.google.com)
   - Sign in with your Google account

2. **Create a Folder (Optional but Recommended):**
   - Click "New" → "Folder"
   - Name it: `EEG-Seizure-Models` (or your preferred name)
   - This keeps your models organized

3. **Upload Model Files:**
   - Navigate to your folder (or root)
   - Click "New" → "File upload"
   - Select all 3 model files from `backend/data/models/`:
     - `resnet-18_pretrained.pth`
     - `model.pckl`
     - `model_tusz.pckl` (optional)
   - Wait for upload to complete

4. **Get Shareable Links:**
   For each file:
   - Right-click the file → "Share" → "Get link"
   - OR right-click → "Get link"
   - Set access to "Anyone with the link" (Viewer permission)
   - Copy the link

### Option B: Using Google Drive Desktop App

1. **Install Google Drive Desktop:**
   - Download from [Google Drive for Desktop](https://www.google.com/drive/download/)

2. **Sync Files:**
   - Copy your model files to the Google Drive folder
   - Files will sync automatically

3. **Get Shareable Links:**
   - Right-click files in Google Drive web interface
   - Follow same steps as Option A

## Step 2: Get Individual File IDs from the Shared Folder

Since all your files are in one folder, you need to get individual file links/IDs for each file:

### Method 1: Get Individual File Links (Recommended)

1. **Open your shared folder link** in a web browser
   - The folder link looks like: `https://drive.google.com/drive/folders/FOLDER_ID`

2. **For each file** (resnet-18_pretrained.pth, model.pckl, model_tusz.pckl):
   - **Right-click** on the file name
   - Select **"Get link"** or **"Share"**
   - Make sure it's set to **"Anyone with the link"** (Viewer permission)
   - **Copy the link** that appears
   - The link will look like: `https://drive.google.com/file/d/FILE_ID/view?usp=sharing`

3. **Extract the File ID** (or use the full link - both work!):
   - The **FILE_ID** is the long string between `/d/` and `/view`
   - **Example:**
     - Link: `https://drive.google.com/file/d/1a2b3c4d5e6f7g8h9i0j/view?usp=sharing`
     - File ID: `1a2b3c4d5e6f7g8h9i0j`

### Method 2: Click Each File to Get Its Link

1. **Open your shared folder**
2. **Click on each file** to open it in Google Drive viewer
3. **Look at the browser URL** - it will show the file ID
4. **Or right-click the file** → "Get link" → Copy

### Quick Tip

You can use **either**:
- Just the file ID: `1a2b3c4d5e6f7g8h9i0j`
- Or the full shareable link: `https://drive.google.com/file/d/1a2b3c4d5e6f7g8h9i0j/view?usp=sharing`

The script will automatically extract the file ID from full links!

## Step 3: Set Environment Variables on Render

1. **Go to Render Dashboard:**
   - Navigate to your backend service
   - Click on "Environment" tab

2. **Add Environment Variables:**

   Add these variables with your Google Drive file IDs or full shareable links:

   **Option A: Using File IDs Only**
   ```
   GOOGLE_DRIVE_RESNET_MODEL_ID=1a2b3c4d5e6f7g8h9i0j
   GOOGLE_DRIVE_MODEL_WEIGHTS_ID=2b3c4d5e6f7g8h9i0j1k
   GOOGLE_DRIVE_MODEL_TUSZ_ID=3c4d5e6f7g8h9i0j1k2l
   ```

   **Option B: Using Full Shareable Links** (also works!)
   ```
   GOOGLE_DRIVE_RESNET_MODEL_ID=https://drive.google.com/file/d/1a2b3c4d5e6f7g8h9i0j/view?usp=sharing
   GOOGLE_DRIVE_MODEL_WEIGHTS_ID=https://drive.google.com/file/d/2b3c4d5e6f7g8h9i0j1k/view?usp=sharing
   GOOGLE_DRIVE_MODEL_TUSZ_ID=https://drive.google.com/file/d/3c4d5e6f7g8h9i0j1k2l/view?usp=sharing
   ```

   **Note:** 
   - `GOOGLE_DRIVE_MODEL_TUSZ_ID` is optional. Only add it if you have the `model_tusz.pckl` file.
   - The script automatically extracts file IDs from full links, so either format works!
   - Make sure each file in your folder has "Anyone with the link" permission

## Step 4: Update Build Command (Optional - For Automatic Download)

If you want models to download automatically during deployment:

1. **Go to Render Dashboard:**
   - Navigate to your backend service
   - Click on "Settings" tab

2. **Update Build Command:**
   
   Add the download script to your build command:
   
   ```bash
   pip install -r requirements.txt && mkdir -p /mnt/data/models && python -m app.scripts.download_models_from_drive && alembic upgrade head
   ```

   This will:
   - Install dependencies
   - Create the models directory
   - Download models from Google Drive
   - Run database migrations

## Step 5: Manual Download (Alternative)

If you prefer to download models manually after deployment:

1. **Access Render Shell:**
   - Go to your backend service → "Shell" tab

2. **Run the download script:**
   ```bash
   cd /opt/render/project/src
   python -m app.scripts.download_models_from_drive
   ```

3. **Verify files:**
   ```bash
   ls -lh /mnt/data/models/
   ```

   You should see:
   - `resnet-18_pretrained.pth`
   - `model.pckl`
   - `model_tusz.pckl` (if you uploaded it)

## Step 6: Set MODEL_PATH Environment Variable

1. **Go to Render Dashboard:**
   - Navigate to your backend service
   - Click on "Environment" tab

2. **Add/Update:**
   ```
   MODEL_PATH=/mnt/data/models
   ```

## Alternative: Using Direct Download URLs

If you prefer to use direct download URLs instead of file IDs:

1. **Get Direct Download URLs:**
   - For a file with ID `FILE_ID`, the direct download URL is:
     ```
     https://drive.google.com/uc?export=download&id=FILE_ID
     ```

2. **Set Environment Variables:**
   ```
   GOOGLE_DRIVE_RESNET_MODEL_URL=https://drive.google.com/uc?export=download&id=your_file_id
   GOOGLE_DRIVE_MODEL_WEIGHTS_URL=https://drive.google.com/uc?export=download&id=your_file_id
   GOOGLE_DRIVE_MODEL_TUSZ_URL=https://drive.google.com/uc?export=download&id=your_file_id
   ```

## Troubleshooting

### Download Fails

1. **Check file permissions:**
   - Ensure files are set to "Anyone with the link" (Viewer)
   - Try accessing the link in a private browser window

2. **Verify file IDs:**
   - Double-check the file IDs in environment variables
   - Make sure there are no extra spaces

3. **Check disk space:**
   - Verify your persistent disk has enough space
   - Model files can be large (100MB+ each)

4. **Check logs:**
   - View Render service logs for error messages
   - The download script will show specific errors

### Files Not Found After Download

1. **Verify download location:**
   ```bash
   ls -lh /mnt/data/models/
   ```

2. **Check environment variables:**
   - Ensure `MODEL_PATH=/mnt/data/models` is set
   - Verify Google Drive file IDs are correct

3. **Re-run download:**
   ```bash
   python -m app.scripts.download_models_from_drive
   ```

### Large File Downloads Timeout

If your model files are very large (>500MB):

1. **Use Google Drive Desktop:**
   - Upload via desktop app for better reliability

2. **Consider alternative storage:**
   - AWS S3
   - Dropbox
   - OneDrive
   - (Modify script to support these)

3. **Increase timeout:**
   - The script has a 10-minute timeout
   - For larger files, you may need to modify the timeout in the script

## Security Notes

- ✅ Google Drive links with "Anyone with the link" are fine for public model files
- ✅ File IDs don't expose your Google account
- ⚠️ Don't commit environment variables to Git
- ⚠️ Consider using Render's encrypted environment variables for sensitive data

## Quick Reference

**Required Environment Variables:**
```
GOOGLE_DRIVE_RESNET_MODEL_ID=<file_id_or_full_link>
GOOGLE_DRIVE_MODEL_WEIGHTS_ID=<file_id_or_full_link>
MODEL_PATH=/mnt/data/models
```

**Optional:**
```
GOOGLE_DRIVE_MODEL_TUSZ_ID=<file_id_or_full_link>
```

**Examples:**
```
# Using just file IDs:
GOOGLE_DRIVE_RESNET_MODEL_ID=1a2b3c4d5e6f7g8h9i0j

# OR using full shareable links (script extracts ID automatically):
GOOGLE_DRIVE_RESNET_MODEL_ID=https://drive.google.com/file/d/1a2b3c4d5e6f7g8h9i0j/view?usp=sharing
```

**Note:** If all files are in one shared folder, you still need to get individual file links/IDs for each file. Right-click each file in the folder → "Get link" → Copy.

**Build Command (with auto-download):**
```bash
pip install -r requirements.txt && mkdir -p /mnt/data/models && python -m app.scripts.download_models_from_drive && alembic upgrade head
```

**Manual Download Command:**
```bash
python -m app.scripts.download_models_from_drive
```

