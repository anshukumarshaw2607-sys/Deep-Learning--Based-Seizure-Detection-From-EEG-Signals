# 🤖 ML Model Storage on Render Disk

Quick guide for storing and managing ML prediction models on Render's persistent disk.

## 📍 Model Storage Location

### Automatic Configuration

When `RENDER=true`, models are automatically stored at:
```
/opt/render/project/src/models/
```

This path is automatically configured via `settings.resolved_model_path` in `backend/app/core/config.py`.

### Environment Variable

Set `MODEL_PATH` to specify your model file:
```bash
MODEL_PATH=/opt/render/project/src/models/your_model.h5
```

If `MODEL_PATH` is not set, it defaults to `/opt/render/project/src/models` on Render.

## 📤 Uploading Models

### Method 1: Render Shell (Recommended for First Upload)

1. **Access Shell:**
   - Go to backend service → **Shell** tab

2. **Create directory:**
   ```bash
   mkdir -p /opt/render/project/src/models
   ```

3. **Upload via temporary API endpoint:**
   - Create a one-time admin endpoint for model upload
   - Upload via HTTP POST with authentication
   - Remove endpoint after upload

### Method 2: Build Script (For Models in Repository)

If models are in your repository (using Git LFS for large files):

**Update build command:**
```bash
pip install -r requirements.txt && alembic upgrade head && mkdir -p /opt/render/project/src/models && cp -r backend/models/* /opt/render/project/src/models/ 2>/dev/null || true
```

### Method 3: Download During Build

If models are stored externally (S3, Google Drive, etc.):

**Update build command:**
```bash
pip install -r requirements.txt && mkdir -p /opt/render/project/src/models && curl -L https://your-model-url.com/model.h5 -o /opt/render/project/src/models/model.h5 && alembic upgrade head
```

## ✅ Verification

### Check Models Exist

```bash
# In Render Shell
ls -lh /opt/render/project/src/models/
```

### Verify Model Path Configuration

```bash
# In Render Shell
python -c "from app.core.config import settings; print(settings.resolved_model_path)"
```

### Test Model Loading

Check backend logs after deployment for model loading messages or errors.

## 📝 Important Notes

1. **Persistent Storage:** Models on Render disk persist across deployments
2. **Not in Git:** Model files are excluded from Git (see `.gitignore`)
3. **Disk Size:** Ensure your Render disk has enough space for models
   - Free tier: 1GB
   - Paid plans: Up to 100GB
   - Update `sizeGB` in `render.yaml` if needed
4. **Auto-Creation:** The models directory is automatically created on startup if `RENDER=true`
5. **Path Resolution:** Use `settings.resolved_model_path` in your code, not hardcoded paths

## 🔧 Configuration

### In Code

```python
from app.core.config import settings

model_path = settings.resolved_model_path
# On Render: /opt/render/project/src/models
# In dev: ./models (relative to backend/)
```

### Environment Variables

```bash
# Optional - auto-configured if not set
MODEL_PATH=/opt/render/project/src/models/your_model.h5
MODEL_TYPE=resnet
```

## 📊 Directory Structure

```
/opt/render/project/src/
├── models/          # ML prediction models (.h5, .pth, .pt, .pkl)
├── uploads/         # EEG files uploaded by users
└── reports/         # Generated diagnostic reports
```

## 🚨 Troubleshooting

### Model Not Found

1. Check model file exists: `ls -lh /opt/render/project/src/models/`
2. Verify `MODEL_PATH` environment variable
3. Check disk space: Models might not upload if disk is full
4. Review backend logs for loading errors

### Model Loading Errors

1. Verify model file format matches your ML framework
2. Check model file is not corrupted
3. Ensure model dependencies are in `requirements.txt`
4. Test model loading locally first

### Disk Space Issues

1. Check current disk usage in Render dashboard
2. Increase disk size in `render.yaml` or Render dashboard
3. Remove old/unused models if needed

## 📚 Related Documentation

- [RENDER_DEPLOYMENT.md](./RENDER_DEPLOYMENT.md) - Full deployment guide
- [DEPLOYMENT_CHECKLIST.md](./DEPLOYMENT_CHECKLIST.md) - Deployment checklist
- `backend/app/core/config.py` - Configuration implementation

---

**Last Updated:** 2024  
**Storage Path:** `/opt/render/project/src/models/`

