#!/usr/bin/env python3
"""
Test script to verify the reports API endpoint is working
"""
import asyncio
import httpx
import json

async def test_reports_flow():
    """Test the complete reports flow"""
    
    BASE_URL = "http://localhost:8000"
    
    print("=" * 60)
    print("TESTING REPORTS API FLOW")
    print("=" * 60)
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        # Step 1: Check if backend is running
        print("\n1. Checking backend health...")
        try:
            response = await client.get(f"{BASE_URL}/health")
            print(f"   ✓ Backend is running: {response.status_code}")
        except Exception as e:
            print(f"   ✗ Backend not responding: {e}")
            return
        
        # Step 2: Get auth token (test user)
        print("\n2. Getting auth token...")
        try:
            token_response = await client.post(
                f"{BASE_URL}/api/v1/auth/login",
                data={
                    "username": "testuser",
                    "password": "testpass123"
                }
            )
            if token_response.status_code == 200:
                token_data = token_response.json()
                access_token = token_data.get("access_token")
                print(f"   ✓ Got token: {access_token[:20]}...")
            else:
                print(f"   ℹ Could not get token (may not have test user): {token_response.status_code}")
                # Try to use a generic token for testing
                access_token = "test-token"
                print(f"   ℹ Using placeholder token for testing")
        except Exception as e:
            print(f"   ✗ Error getting token: {e}")
            access_token = "test-token"
        
        # Step 3: Check if reports endpoint exists
        print("\n3. Checking reports endpoint...")
        headers = {"Authorization": f"Bearer {access_token}"}
        try:
            response = await client.get(
                f"{BASE_URL}/api/v1/reports",
                headers=headers,
                timeout=10.0
            )
            print(f"   ✓ Reports endpoint exists: {response.status_code}")
            if response.status_code == 200:
                reports = response.json()
                print(f"   ✓ Found {len(reports) if isinstance(reports, list) else '?'} reports")
        except Exception as e:
            print(f"   ✗ Error accessing reports: {e}")
        
        # Step 4: Check database connection
        print("\n4. Checking database connection...")
        try:
            response = await client.get(
                f"{BASE_URL}/api/v1/patients",
                headers=headers,
                timeout=10.0
            )
            print(f"   ✓ Database is accessible: {response.status_code}")
        except Exception as e:
            print(f"   ✗ Database not accessible: {e}")
        
        # Step 5: Try to create a test report
        print("\n5. Testing report creation...")
        test_report_data = {
            "title": "Test Report - API Flow Verification",
            "report_type": "Seizure Detection",
            "eeg_file_id": "test-file-id",  # Will fail but tests endpoint
            "patient_id": "test-patient-id",
            "seizure_count": 3,
            "total_seizure_duration_seconds": 45.5,
            "seizure_percentage": 15.2,
            "num_channels": 19,
            "seizure_events": [
                {
                    "start_time": 10.5,
                    "end_time": 20.3,
                    "duration": 9.8,
                    "confidence": 95.2
                }
            ],
            "status": "completed"
        }
        
        try:
            response = await client.post(
                f"{BASE_URL}/api/v1/reports",
                json=test_report_data,
                headers=headers,
                timeout=10.0
            )
            print(f"   Status: {response.status_code}")
            print(f"   Response: {response.text[:200]}...")
            
            if response.status_code in [201, 200]:
                print(f"   ✓ Report creation endpoint is working!")
            else:
                print(f"   ℹ Report creation returned {response.status_code} (expected due to test data)")
        except Exception as e:
            print(f"   ✗ Error creating report: {e}")
    
    print("\n" + "=" * 60)
    print("TESTING COMPLETE")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_reports_flow())
