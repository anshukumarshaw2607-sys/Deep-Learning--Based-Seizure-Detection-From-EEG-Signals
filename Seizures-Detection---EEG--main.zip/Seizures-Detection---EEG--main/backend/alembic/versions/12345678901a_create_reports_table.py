"""Create reports table

Revision ID: 12345678901a
Revises: df11a2c601bf
Create Date: 2026-01-11 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '12345678901a'
down_revision = 'df11a2c601bf'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create reports table
    op.create_table(
        'reports',
        sa.Column('id', sa.String(), nullable=False),
        sa.Column('title', sa.String(), nullable=False),
        sa.Column('report_type', sa.String(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('eeg_file_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('created_by_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('recording_date', sa.DateTime(), nullable=True),
        sa.Column('recording_duration_minutes', sa.Float(), nullable=True),
        sa.Column('num_channels', sa.Integer(), nullable=False),
        sa.Column('seizure_count', sa.Integer(), nullable=False),
        sa.Column('total_seizure_duration_seconds', sa.Float(), nullable=False),
        sa.Column('seizure_percentage', sa.Float(), nullable=False),
        sa.Column('seizure_events', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('clinical_notes', sa.Text(), nullable=True),
        sa.Column('clinical_recommendations', sa.Text(), nullable=True),
        sa.Column('analysis_timestamp', sa.DateTime(), nullable=False),
        sa.Column('generated_at', sa.DateTime(), nullable=False),
        sa.Column('status', sa.String(), nullable=False),
        sa.ForeignKeyConstraint(['created_by_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['eeg_file_id'], ['eeg_files.id'], ),
        sa.ForeignKeyConstraint(['patient_id'], ['patients.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_reports_eeg_file_id'), 'reports', ['eeg_file_id'], unique=False)
    op.create_index(op.f('ix_reports_patient_id'), 'reports', ['patient_id'], unique=False)
    op.create_index(op.f('ix_reports_title'), 'reports', ['title'], unique=False)
    op.create_index(op.f('ix_reports_generated_at'), 'reports', ['generated_at'], unique=False)
    op.create_index(op.f('ix_reports_created_by_id'), 'reports', ['created_by_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_reports_created_by_id'), table_name='reports')
    op.drop_index(op.f('ix_reports_generated_at'), table_name='reports')
    op.drop_index(op.f('ix_reports_title'), table_name='reports')
    op.drop_index(op.f('ix_reports_patient_id'), table_name='reports')
    op.drop_index(op.f('ix_reports_eeg_file_id'), table_name='reports')
    op.drop_table('reports')
