"""Merge migration heads

Revision ID: 8430c76b90a3
Revises: 12345678901a, 98957e9d37d8
Create Date: 2026-01-11 15:52:10.242419

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8430c76b90a3'
down_revision: Union[str, None] = ('12345678901a', '98957e9d37d8')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

