"""
Invoke tasks for backend development and maintenance
"""
from invoke import task


@task
def dev(c):
    """Run the development server with auto-reload."""
    c.run("uvicorn main:app --reload --host localhost --port 8000")
    # Usage: invoke dev


@task
def clean_pyc(c):
    """Remove all __pycache__ directories recursively."""
    import os
    import shutil
    for root, dirs, files in os.walk("."):
        if "__pycache__" in dirs:
            dirpath = os.path.join(root, "__pycache__")
            shutil.rmtree(dirpath, ignore_errors=True)
    print("All __pycache__ directories removed.")
    # Usage: invoke clean-pyc


@task
def migrations_auto(c, message="auto migration"):
    """Generate a new Alembic migration with autogenerate."""
    c.run(f'alembic revision --autogenerate -m "{message}"')
    # Usage: invoke migrations-auto --message "your message"


@task
def migrations_blank(c, message="manual migration"):
    """Generate a new blank Alembic migration (no autogenerate)."""
    c.run(f'alembic revision -m "{message}"')
    # Usage: invoke migrations-blank --message "your message"


@task
def migrate(c):
    """Apply Alembic migrations."""
    c.run('alembic upgrade head')
    # Usage: invoke migrate


@task
def rollback(c, revision="-1"):
    """Undo Alembic migration. By default, undoes the last migration. Specify revision for custom target."""
    c.run(f'alembic downgrade {revision}')
    # Usage: invoke rollback --revision <revision>


@task
def test(c):
    """Run tests (when test suite is added)."""
    c.run("pytest")
    # Usage: invoke test


@task
def lint(c):
    """Run linting checks (when linters are configured)."""
    c.run("ruff check .")
    # Usage: invoke lint


@task
def format_code(c):
    """Format code with black (when formatter is configured)."""
    c.run("black .")
    # Usage: invoke format-code

