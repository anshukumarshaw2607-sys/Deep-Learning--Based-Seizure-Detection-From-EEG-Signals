# EEG Seizure Detection - Backend API

FastAPI backend for EEG-based epilepsy and seizure detection system.

## 🚀 Getting Started

### Prerequisites

- Python 3.10+
- PostgreSQL database
- (Optional) ML model file for inference

### Installation

1. **Create a virtual environment:**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables:**
```bash
cp env.example .env
# Edit .env - at minimum, set ENVIRONMENT=development
# Everything else is auto-configured based on ENVIRONMENT
```

4. **Set up database:**
```bash
# Create PostgreSQL database
createdb eeg_seizure_db

# Run migrations
alembic upgrade head
```

**Note**: The database schema includes:
- Organizations table
- Users table (with roles: root, admin, doctor, assistant)
- Doctor-Assistant relationships table
- Token revocation table
- Patients table
- EEG Files table

5. **Run the server:**
```bash
python main.py
# Or with uvicorn directly:
uvicorn main:app --reload --host 0.0.0.0 --port 8000
# Or using invoke:
invoke dev
```

The API will be available at `http://localhost:8000`

**Root Endpoints:**
- `GET /` - API information and status
- `GET /health` - Health check endpoint

## 🛠️ Development Tasks (Invoke)

This project uses [Invoke](http://www.pyinvoke.org/) for task automation. Available tasks:

- **`invoke dev`** - Run the development server with auto-reload
- **`invoke clean-pyc`** - Remove all `__pycache__` directories recursively
- **`invoke migrations-auto --message "description"`** - Generate a new Alembic migration with autogenerate
- **`invoke migrations-blank --message "description"`** - Generate a new blank Alembic migration
- **`invoke migrate`** - Apply Alembic migrations
- **`invoke rollback [--revision <revision>]`** - Undo Alembic migration (default: last migration)

Example usage:
```bash
# Start development server
invoke dev

# Create a new migration
invoke migrations-auto --message "add user verification field"

# Apply migrations
invoke migrate

# Rollback last migration
invoke rollback
```

## 📁 Project Structure

```
backend/
├── app/
│   ├── api/                 # API routes
│   │   └── v1/
│   │       ├── endpoints/   # Endpoint modules
│   │       │   ├── auth.py
│   │       │   ├── users.py
│   │       │   ├── organizations.py
│   │       │   ├── patients.py
│   │       │   ├── eeg_files.py
│   │       │   ├── eeg_preprocessing.py
│   │       │   └── seizure_detection.py
│   │       └── api.py       # Main API router
│   ├── core/                # Core configuration
│   │   ├── config.py        # Settings
│   │   ├── database.py      # DB connection
│   │   └── security.py      # Auth utilities
│   ├── models/              # SQLAlchemy models
│   │   ├── users.py         # User, Organization, DoctorAssistant, Token
│   │   ├── patients.py      # Patient model
│   │   └── eeg_files.py     # EEGFile model
│   ├── schemas/             # Pydantic schemas
│   │   ├── users.py
│   │   ├── patients.py
│   │   ├── eeg_files.py
│   │   └── seizure_detection.py
│   ├── services/            # Business logic
│   │   ├── users.py
│   │   ├── tokens.py
│   │   ├── patients.py
│   │   ├── eeg_files.py
│   │   ├── eeg_preprocessing.py
│   │   └── seizure_detection.py
│   ├── utils/               # Utility functions
│   │   ├── file_utils.py
│   │   ├── validators.py
│   │   ├── constants.py
│   │   ├── db.py
│   │   └── prediction/      # ML prediction utilities
│   └── scripts/             # Utility scripts
├── alembic/                 # Database migrations
│   ├── versions/            # Migration files
│   ├── env.py               # Alembic environment
│   └── script.py.mako       # Migration template
├── data/                    # Data storage
│   ├── models/              # ML model files
│   ├── uploads/             # Uploaded EEG files
│   └── reports/             # Generated reports
├── docs/                    # Documentation
├── main.py                  # Application entry point
├── tasks.py                 # Invoke tasks
├── alembic.ini              # Alembic configuration
├── requirements.txt         # Python dependencies
├── env.example             # Environment variables template
└── README.md               # This file
```

## 🔌 API Endpoints

### Authentication (`/api/v1/auth`)
- `POST /api/v1/auth/login` - Login and get access/refresh tokens
- `GET /api/v1/auth/me` - Get current user info
- `POST /api/v1/auth/logout` - Logout and revoke tokens
- `POST /api/v1/auth/refresh` - Refresh access token using refresh token
- `POST /api/v1/auth/verify` - Verify token validity
- `GET /api/v1/auth/token-info` - Get current token information

### Users (`/api/v1/users`)
- `POST /api/v1/users/register` - Register new user (admin/root only)
- `GET /api/v1/users/` - List users (admin/root only)
- `GET /api/v1/users/doctors` - List all doctors
- `GET /api/v1/users/assistants` - List all assistants (admin/root only)
- `GET /api/v1/users/{user_id}` - Get user by ID
- `PUT /api/v1/users/{user_id}` - Update user
- `DELETE /api/v1/users/{user_id}` - Delete user
- `POST /api/v1/users/doctor-assistants` - Assign assistant to doctor (admin only)
- `GET /api/v1/users/doctor-assistants/my-assistants` - Get my assistants (doctor only)
- `GET /api/v1/users/doctor-assistants/by-doctor/{doctor_id}` - Get doctor's assistants
- `GET /api/v1/users/doctor-assistants/my-doctor` - Get my assigned doctor (assistant only)
- `DELETE /api/v1/users/doctor-assistants/{assistant_id}` - Remove assistant from doctor (admin only)

### Organizations (`/api/v1/organizations`)
- `POST /api/v1/organizations/` - Create organization (root only)
- `GET /api/v1/organizations/` - List all organizations (root only)
- `GET /api/v1/organizations/{organization_id}` - Get organization by ID (root only)
- `PUT /api/v1/organizations/{organization_id}` - Update organization (root only)
- `DELETE /api/v1/organizations/{organization_id}` - Delete organization (root only)

### Patients (`/api/v1/patients`)
- `POST /api/v1/patients` - Create patient
- `GET /api/v1/patients` - List patients (with filters)
- `GET /api/v1/patients/{patient_id}` - Get patient by ID
- `PUT /api/v1/patients/{patient_id}` - Update patient
- `DELETE /api/v1/patients/{patient_id}` - Delete patient (soft/hard delete)

### EEG Files (`/api/v1/eeg-files`)
- `POST /api/v1/eeg-files/upload` - Upload EEG file (.edf format)
- `GET /api/v1/eeg-files` - List EEG files (with filters)
- `GET /api/v1/eeg-files/{file_id}` - Get EEG file details
- `GET /api/v1/eeg-files/{file_id}/download` - Download EEG file
- `PUT /api/v1/eeg-files/{file_id}` - Update EEG file metadata
- `DELETE /api/v1/eeg-files/{file_id}` - Delete EEG file (soft/hard delete)

### EEG Analysis (`/api/v1/analysis`)
- `GET /api/v1/analysis/preprocess/{file_id}` - Preprocess and analyze EEG file
- `GET /api/v1/analysis/analyze/raw/{file_id}` - Get raw EEG signal
- `GET /api/v1/analysis/analyze/filtered/{file_id}` - Get filtered EEG signal
- `GET /api/v1/analysis/analyze/psd/{file_id}` - Get Power Spectral Density
- `GET /api/v1/analysis/analyze/bands/{file_id}` - Get frequency band analysis

### Seizure Detection (`/api/v1/detection`)
- `POST /api/v1/detection/{file_id}` - Run seizure detection on EEG file
- `GET /api/v1/detection/{file_id}` - Get prediction report in JSON format
- `GET /api/v1/detection/{file_id}/download` - Download CSV_BI prediction output file

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) with refresh tokens for authentication. The system includes token revocation for enhanced security.

### Token Types
- **Access Token**: Short-lived (default: 1 minute, configurable via `ACCESS_TOKEN_EXPIRE_MINUTES`)
- **Refresh Token**: Long-lived (default: 7 days, configurable via `REFRESH_TOKEN_EXPIRE_DAYS`)

### Usage
Include the access token in the Authorization header for all protected endpoints:

```
Authorization: Bearer <your-access-token>
```

### Token Management
- Tokens are stored in the database for revocation tracking
- Use `/api/v1/auth/refresh` to get new tokens when access token expires
- Use `/api/v1/auth/logout` to revoke all tokens
- Use `/api/v1/auth/verify` to check token validity

## 🗄️ Database Models

### Core Models
- **Organization**: Healthcare organizations/clinics
- **User**: User accounts with roles (root, admin, doctor, assistant)
- **DoctorAssistant**: Relationship mapping assistants to doctors
- **Token**: JWT token storage for revocation tracking
- **Patient**: Patient records linked to doctors
- **EEGFile**: Uploaded EEG files metadata (.edf format)

### User Roles & Permissions
- **root**: Full system access, can manage organizations and all users
- **admin**: Organization-level access, can manage doctors and assistants in their organization
- **doctor**: Can manage their own patients and EEG files
- **assistant**: Can access patients and files of their assigned doctor

### Access Control
- Organization-based isolation: Admins can only access resources within their organization
- Doctor-assistant relationships: Assistants can access their assigned doctor's patients
- Role-based permissions enforced at the endpoint level

## 🤖 ML Model Integration

The system uses a ResNet-based model for seizure detection. The ML service (`app/services/seizure_detection.py`) handles:

1. **Model Loading**: Loads pre-trained ResNet model from `data/models/`
2. **EEG Preprocessing**: Signal filtering, ICA cleaning, and feature extraction
3. **Seizure Detection**: Predicts seizure segments in EEG recordings
4. **Output Generation**: Creates CSV_BI annotation files with seizure timestamps

### Model Files
Place your model files in `data/models/`:
- `resnet-18_pretrained.pth` - Main ResNet model
- `model.pckl` / `model_tusz.pckl` - Additional model files

### EEG Preprocessing
The preprocessing service (`app/services/eeg_preprocessing.py`) provides:
- Bandpass filtering (0.1-30 Hz)
- ICA artifact removal
- Power Spectral Density (PSD) analysis
- Frequency band analysis (Delta, Theta, Alpha, Beta)

## 📝 Environment Variables

The configuration system is **environment-based** - set `ENVIRONMENT=development` or `ENVIRONMENT=production` and most settings are auto-configured!

### Quick Setup

**Development (minimal setup):**
```bash
ENVIRONMENT=development
DATABASE_URL=postgresql://user:password@localhost:5432/eeg_seizure_db
# SECRET_KEY optional (uses insecure default for dev only)
```

**Production (Render):**
```bash
ENVIRONMENT=production
SECRET_KEY=<generate-secure-key>
FRONTEND_URL=https://your-frontend-domain.com
# DATABASE_URL, PORT automatically provided by Render
```

### Auto-Configuration

Based on `ENVIRONMENT`, the following are automatically configured:

- **DEBUG**: `True` for development, `False` for production
- **CORS Origins**: Localhost URLs for dev, production URLs for prod
- **File Storage**: Local directories for dev, Render persistent disk for prod
- **Database**: Uses provided DATABASE_URL or sensible defaults
- **Security**: Warns if SECRET_KEY missing in production

See `env.example` for all available variables and detailed documentation.

## 🧪 Development

- The API runs in development mode with auto-reload by default
- Database tables are created via Alembic migrations (run `alembic upgrade head`)
- Use `DEBUG=True` for detailed error messages
- All endpoints require authentication except `/` and `/health`

## 📚 Documentation

- Interactive API docs: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
- OpenAPI JSON: `http://localhost:8000/api/v1/openapi.json`

## 🚢 Deployment on Render

The configuration automatically detects Render deployment and configures accordingly.

### Required Environment Variables on Render:

1. **`ENVIRONMENT=production`** - Sets production mode
2. **`SECRET_KEY`** - Generate with: `python -c 'import secrets; print(secrets.token_urlsafe(32))'`
3. **`FRONTEND_URL`** - Your frontend domain (for CORS)

### Auto-Configured by Render:

- `DATABASE_URL` - Automatically provided when you link a PostgreSQL service
- `PORT` - Automatically provided by Render
- `RENDER=true` - Automatically set by Render
- `RENDER_EXTERNAL_HOSTNAME` - Automatically set by Render
- File storage paths - Automatically use Render persistent disk

### Render Setup Steps:

1. Create a new **Web Service** on Render
2. Connect your GitHub repository
3. Set **Build Command**: `cd backend && pip install -r requirements.txt`
4. Set **Start Command**: `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables:
   - `ENVIRONMENT=production`
   - `SECRET_KEY=<your-generated-key>`
   - `FRONTEND_URL=https://your-frontend.onrender.com`
6. Link a PostgreSQL database (DATABASE_URL auto-configured)
7. Enable **Persistent Disk** for file storage (uploads/reports)

That's it! The system auto-configures everything else.

## 📄 License

Part of Final Year Project - COMSATS University Islamabad, Lahore Campus

