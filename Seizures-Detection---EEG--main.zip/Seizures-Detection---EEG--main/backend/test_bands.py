#!/usr/bin/env python3
"""Quick test of frequency band calculation"""
import sys
sys.path.insert(0, r'c:\Users\fabir\Desktop\UNI\EEG _Project_FYP\eeg-seizure-detection\backend')

from app.services.eeg_preprocessing import EEGPreprocessingService
import os

# Test with a sample EEG file
test_file = r"c:\Users\fabir\Desktop\EEG python\EDF_EEG.edf"

if os.path.exists(test_file):
    print(f"Testing with file: {test_file}")
    service = EEGPreprocessingService(test_file)
    
    if service.load_eeg_file():
        print("[OK] File loaded")
        
        # Get channel info
        ch_info = service.get_channel_info()
        print(f"[OK] Channels: {ch_info['n_channels']}")
        
        # Apply filter
        filtered = service.apply_bandpass_filter()
        print(f"[OK] Filter applied: {filtered.get('status', 'error')}")
        
        # Apply ICA
        ica = service.apply_ica(exclude=[1, 2])
        print(f"[OK] ICA applied: {ica.get('status', 'error')}")
        
        # Compute frequency bands
        bands = service.compute_frequency_bands_power()
        if 'bands' in bands:
            print("[OK] Frequency bands computed successfully!")
            for band_name, band_info in bands['bands'].items():
                powers = list(band_info['power_by_channel'].values())
                max_p = max(powers) if powers else 0
                mean_p = band_info['mean_power']
                print(f"  {band_name.upper()}: max={max_p:.4f}, mean={mean_p:.4f} V^2")
        else:
            print(f"[ERROR] {bands.get('error', 'Unknown error')}")
    else:
        print("[ERROR] Failed to load file")
else:
    print(f"[ERROR] File not found: {test_file}")
