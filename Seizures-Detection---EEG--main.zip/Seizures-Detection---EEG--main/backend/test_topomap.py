"""Test topomap generation"""
import os
import sys

# Find EDF file
uploads_dir = 'data/uploads'
edf_file = None

for root, dirs, files in os.walk(uploads_dir):
    for f in files:
        if f.endswith('.edf'):
            edf_file = os.path.join(root, f)
            break
    if edf_file:
        break

if not edf_file:
    print("No EDF file found!")
    sys.exit(1)

print(f"Testing with: {edf_file}")

from app.services.eeg_preprocessing import EEGPreprocessingService

service = EEGPreprocessingService(edf_file)
result = service.load_eeg_file()
print(f"Load result: {result}")

if service.raw is not None:
    print(f"Channels: {service.raw.ch_names}")
    
    # Test topomap generation
    print("\nGenerating topomaps...")
    topomaps = service.compute_topomaps()
    
    status = topomaps.get('status', topomaps.get('error', 'unknown'))
    print(f"Topomap status: {status}")
    
    if 'topomap_images' in topomaps:
        print(f"Number of topomap images: {len(topomaps['topomap_images'])}")
        for band, img in topomaps['topomap_images'].items():
            if img:
                print(f"  {band}: {len(img)} chars (starts with: {img[:50]}...)")
            else:
                print(f"  {band}: None")
    else:
        print("No topomap_images in result")
    
    if topomaps.get('combined_topomap_image'):
        print(f"Combined image: {len(topomaps['combined_topomap_image'])} chars")
    else:
        print("No combined_topomap_image")
        
    if 'error' in topomaps:
        print(f"Error: {topomaps['error']}")
