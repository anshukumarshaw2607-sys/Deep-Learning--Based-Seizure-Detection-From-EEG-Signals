# EEG Seizure Detection - Frontend

React + Vite frontend for EEG-based epilepsy and seizure detection system.

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and npm/yarn
- Backend API running (see backend README)

### Installation

1. **Install dependencies:**

```bash
npm install
```

2. **Set up environment variables:**

```bash
cp env.example .env
# Edit .env - at minimum, set VITE_ENVIRONMENT=development
# Everything else is auto-configured based on environment
```

3. **Run development server:**

```bash
npm run build
npm run dev
```

The app will be available at `http://localhost:5173`

## 📝 Environment Variables

The frontend uses **environment-based auto-configuration** - set `VITE_ENVIRONMENT=development` or `VITE_ENVIRONMENT=production` and most settings are auto-configured!

### Quick Setup

**Development (minimal setup):**

```bash
VITE_ENVIRONMENT=development
# API automatically points to http://localhost:8000/api
```

**Production (Render):**

```bash
VITE_ENVIRONMENT=production
VITE_BACKEND_URL=https://your-backend.onrender.com
# Or set VITE_API_BASE_URL=https://your-backend.onrender.com/api
```

### Auto-Configuration

Based on `VITE_ENVIRONMENT`, the following are automatically configured:

- **API URL**: `http://localhost:8000/api` for dev, production URL for prod
- **API Base Path**: Automatically uses `/api/v1` endpoints
- **Error Handling**: Development shows detailed errors, production shows user-friendly messages

See `env.example` for all available variables and detailed documentation.

## 🛠️ Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run build:prod` - Build with production mode
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint

### Project Structure

```
frontend/
├── src/
│   ├── config/          # Configuration (env.js)
│   ├── services/        # API services (api.js)
│   ├── pages/           # Page components
│   ├── utils/           # Utility functions and constants
│   ├── App.jsx          # Main app component
│   └── main.jsx         # Entry point
├── public/              # Static assets
├── env.example          # Environment variables template
└── vite.config.js       # Vite configuration
```

## 🔌 API Integration

The frontend uses a centralized API service (`src/services/api.js`) that:

- Automatically uses the correct API URL based on environment
- Handles authentication tokens
- Provides error handling and interceptors
- Supports file uploads with progress tracking

### Using the API

```javascript
import { authAPI, eegAPI, reportsAPI } from "../services/api";

// Login
const response = await authAPI.login(username, password);

// Upload EEG file
const file = event.target.files[0];
const result = await eegAPI.upload(file, (progress) => {
  console.log(`Upload: ${progress}%`);
});

// Get EEG analyses
const analyses = await eegAPI.getAnalyses(eegId);
```

## 🚢 Deployment on Render

### Build Configuration

1. **Build Command:**

```bash
cd frontend && npm install && npm run build
```

2. **Publish Directory:**

```
frontend/dist
```

3. **Environment Variables:**
   - `VITE_ENVIRONMENT=production`
   - `VITE_BACKEND_URL=https://your-backend.onrender.com`
   - Or `VITE_API_BASE_URL=https://your-backend.onrender.com/api`

### Render Setup Steps:

1. Create a new **Static Site** on Render
2. Connect your GitHub repository
3. Set **Build Command**: `cd frontend && npm install && npm run build`
4. Set **Publish Directory**: `frontend/dist`
5. Add environment variables:
   - `VITE_ENVIRONMENT=production`
   - `VITE_BACKEND_URL=https://your-backend.onrender.com`
6. Deploy!

The frontend will automatically detect Render deployment and configure API URLs accordingly.

## 🔐 Authentication

The frontend handles authentication using JWT tokens:

- Tokens are stored in `localStorage`
- Automatically included in API requests
- Redirects to login on 401 errors
- Supports "Remember Me" functionality

## 📚 Documentation

- **API Service**: See `src/services/api.js` for API methods
- **Configuration**: See `src/config/env.js` for environment config
- **Constants**: See `src/utils/constants.js` for app constants

## 🧪 Development Tips

- API requests are automatically proxied to `http://localhost:8000` in development
- Environment variables must be prefixed with `VITE_` to be accessible
- Check browser console for environment configuration in development mode
- Use React DevTools for component debugging

## 📄 License

Part of Final Year Project - COMSATS University Islamabad, Lahore Campus
