/**
 * Environment configuration with auto-detection
 * Automatically configures based on VITE_ENVIRONMENT or NODE_ENV
 */

// Get environment from Vite env vars or default to development
const getEnvironment = () => {
  return import.meta.env.VITE_ENVIRONMENT || 
         (import.meta.env.MODE === 'production' ? 'production' : 'development');
};

const environment = getEnvironment();

// Auto-detect if running on Render
const isRender = import.meta.env.VITE_RENDER === 'true' || 
                 (typeof window !== 'undefined' && (
                   window.location.hostname.includes('render.com') ||
                   window.location.hostname.includes('onrender.com')
                 ));

// API Base URL configuration
const getApiBaseUrl = () => {
  // If explicitly set, use it
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL;
  }

  // Auto-configure based on environment
  if (environment === 'production') {
    if (isRender) {
      // Render deployment - use same domain or configured backend URL
      const backendUrl = import.meta.env.VITE_BACKEND_URL;
      if (backendUrl) {
        // If backend URL already includes /api, use as is, otherwise append /api
        return backendUrl.endsWith('/api') ? backendUrl : `${backendUrl}/api`;
      }
      // Default: assume backend is on same domain with /api prefix
      if (typeof window !== 'undefined') {
        return `${window.location.origin}/api`;
      }
      return '/api';
    }
    // Production with explicit backend URL
    const backendUrl = import.meta.env.VITE_BACKEND_URL;
    if (backendUrl) {
      return backendUrl.endsWith('/api') ? backendUrl : `${backendUrl}/api`;
    }
    return 'https://your-backend-domain.com/api';
  }

  // Development default
  return 'http://localhost:8000/api';
};

// API Version
const API_VERSION = 'v1';

// Full API URL
const API_BASE_URL = getApiBaseUrl();
const API_URL = `${API_BASE_URL}/${API_VERSION}`;

// App configuration
const config = {
  // Environment
  environment,
  isDevelopment: environment === 'development',
  isProduction: environment === 'production',
  isRender,

  // API Configuration
  apiBaseUrl: API_BASE_URL,
  apiUrl: API_URL,
  
  // API Endpoints
  endpoints: {
    auth: {
      login: `${API_URL}/auth/login`,
      register: `${API_URL}/auth/register`,
      me: `${API_URL}/auth/me`,
    },
    users: {
      list: `${API_URL}/users`,
      get: (id) => `${API_URL}/users/${id}`,
    },
    eeg: {
      upload: `${API_URL}/eeg/upload`,
      list: `${API_URL}/eeg`,
      get: (id) => `${API_URL}/eeg/${id}`,
      analyze: (id) => `${API_URL}/eeg/${id}/analyze`,
      analyses: (id) => `${API_URL}/eeg/${id}/analyses`,
    },
    reports: {
      create: `${API_URL}/reports`,
      list: `${API_URL}/reports`,
      get: (id) => `${API_URL}/reports/${id}`,
      download: (id) => `${API_URL}/reports/${id}/download`,
    },
  },

  // App Settings
  app: {
    name: 'EEG Seizure Detection',
    version: '1.0.0',
  },

  // Feature Flags
  features: {
    enableAnalytics: environment === 'production',
    enableErrorReporting: environment === 'production',
  },
};

// Log configuration in development
if (config.isDevelopment) {
  console.log('🔧 Environment Configuration:', {
    environment: config.environment,
    apiUrl: config.apiUrl,
    isRender: config.isRender,
  });
}

export default config;

