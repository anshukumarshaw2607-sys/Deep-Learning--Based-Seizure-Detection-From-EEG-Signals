/**
 * Application constants
 */
import config from '../config/env';

export const APP_NAME = config.app.name;
export const APP_VERSION = config.app.version;

// API Endpoints (use config for dynamic URLs)
export const API_ENDPOINTS = config.endpoints;

// Local Storage Keys
export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'access_token',
  USER: 'user',
  REMEMBER_ME: 'remember_me',
};

// Routes
export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  EEG_DATA: '/eeg-data',
  ANALYSIS: '/analysis',
  REPORTS: '/reports',
  SETTINGS: '/settings',
};

// User Roles
export const USER_ROLES = {
  CLINICIAN: 'clinician',
  RESEARCHER: 'researcher',
  ADMIN: 'admin',
};

// File Upload
export const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
export const ALLOWED_FILE_TYPES = ['.edf', '.csv', '.fif'];

// Pagination
export const DEFAULT_PAGE_SIZE = 10;
export const MAX_PAGE_SIZE = 100;

export default {
  APP_NAME,
  APP_VERSION,
  API_ENDPOINTS,
  STORAGE_KEYS,
  ROUTES,
  USER_ROLES,
  MAX_FILE_SIZE,
  ALLOWED_FILE_TYPES,
  DEFAULT_PAGE_SIZE,
  MAX_PAGE_SIZE,
};

