import React, { useState, useRef, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { PreprocessingProvider } from './context/PreprocessingContext';
import { NotificationProvider } from './context/NotificationContext';
import { AnalysisProvider } from './context/AnalysisContext';
import { authAPI } from './services/api';
import ProtectedRoute from './components/ProtectedRoute';
import UserProtectedRoute from './components/UserProtectedRoute';
import NotificationCenter from './components/NotificationCenter';
import LoginPage from './pages/loginPage';
import RoleBasedDashboard from './pages/RoleBasedDashboard';
import EEGDataPage from './pages/eegdataPage';
import EEGVisualizationPage from './pages/eegVisualizationPage';
import AnalysisPage from './pages/AnalysisPage';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/settingsPage';
import AdminPanel from './pages/adminPanel';

function App() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [expirationWarning, setExpirationWarning] = useState(null);
  const [lastRefreshTime, setLastRefreshTime] = useState(Date.now());
  const [tokenStatus, setTokenStatus] = useState(!!localStorage.getItem('access_token'));

  const [inactivityWarning, setInactivityWarning] = useState(null);

  // Inactivity timeout configuration (in milliseconds)
  const INACTIVITY_WARNING_TIME = 20 * 1000; // 20 seconds - show warning
  const INACTIVITY_LOGOUT_TIME = 10*60* 1000; // 30 seconds - auto logout

  // Use refs to persist timers across renders
  const inactivityTimerRef = useRef(null);
  const inactivityWarningTimerRef = useRef(null);

  // Initialize theme on app mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Cleanup function for timers and listeners
  const cleanupInactivitySystem = () => {
    // Clear all timers
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    if (inactivityWarningTimerRef.current) {
      clearTimeout(inactivityWarningTimerRef.current);
      inactivityWarningTimerRef.current = null;
    }

    // Remove all activity event listeners
    const activityEvents = ['mousedown', 'keydown', 'scroll', 'touchstart', 'click', 'mousemove'];
    activityEvents.forEach(event => {
      document.removeEventListener(event, handleUserActivity, true);
    });

    // Clear state
    setInactivityWarning(null);
  };

  // Auto-refresh token on user activity
  const handleUserActivity = async () => {
    const token = localStorage.getItem('access_token');
    
    if (!token) return;

    // Reset inactivity timers on user activity
    resetInactivityTimers();

    // Don't auto-refresh on every activity - only when explicitly needed
    // This prevents excessive refresh attempts and 401 errors
  };

  // Reset inactivity timers
  const resetInactivityTimers = () => {
    // Clear existing timers
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    if (inactivityWarningTimerRef.current) clearTimeout(inactivityWarningTimerRef.current);

    // Clear warning
    setInactivityWarning(null);

    // Set warning timer (show warning after 20 seconds of inactivity)
    inactivityWarningTimerRef.current = setTimeout(() => {
      setInactivityWarning({
        message: 'You will be logged out in 10 seconds due to inactivity'
      });
    }, INACTIVITY_WARNING_TIME);

    // Set logout timer (logout after 30 seconds of inactivity)
    inactivityTimerRef.current = setTimeout(() => {
      handleInactivityLogout();
    }, INACTIVITY_LOGOUT_TIME);
  };

  // Handle inactivity logout
  const handleInactivityLogout = async () => {
    // Stop the inactivity system immediately before making any API calls
    cleanupInactivitySystem();
    
    try {
      // If access token expired, try to refresh first so logout can authenticate and revoke tokens server-side
      const refreshToken = localStorage.getItem('refresh_token');
      if (refreshToken) {
        try {
          await authAPI.refreshToken();
        } catch (refreshErr) {
          // If refresh fails, continue to attempt logout (may 401) and proceed to cleanup
          console.warn('Silent refresh before inactivity logout failed:', refreshErr);
        }
      }

      // Attempt server-side logout (will revoke tokens if authenticated)
      await authAPI.logout();
    } catch (err) {
      console.error('Logout on inactivity failed:', err);
    } finally {
      // Redirect to login
      window.location.href = '/login';
    }
  };

  // Add global activity listeners (only when authenticated)
  useEffect(() => {
    const token = localStorage.getItem('access_token');
    
    // Only setup inactivity system if user is authenticated
    if (!token) {
      // Clean up if no token
      cleanupInactivitySystem();
      return;
    }

    // List of events that indicate user activity
    const activityEvents = ['mousedown', 'keydown', 'scroll', 'touchstart', 'click', 'mousemove'];
    
    const setupActivityListener = () => {
      activityEvents.forEach(event => {
        document.addEventListener(event, handleUserActivity, true);
      });
    };

    const removeActivityListeners = () => {
      activityEvents.forEach(event => {
        document.removeEventListener(event, handleUserActivity, true);
      });
    };

    setupActivityListener();

    // Start inactivity timer on mount
    resetInactivityTimers();

    return () => {
      removeActivityListeners();
      if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
      if (inactivityWarningTimerRef.current) clearTimeout(inactivityWarningTimerRef.current);
    };
  }, [lastRefreshTime, tokenStatus]);

  useEffect(() => {
    // Initialize app - verify token on load
    const initializeApp = async () => {
      const token = localStorage.getItem('access_token');
      
      if (token) {
        try {
          // Verify token is still valid
          const tokenInfo = await authAPI.getTokenInfo();
          
          if (tokenInfo && tokenInfo.token_expires_in_minutes !== undefined) {
            // Show warning if token expires within 80% of its lifetime (aggressive for short tokens)
            const expirationThreshold = Math.max(0.1, tokenInfo.token_expires_in_minutes * 0.8);
            const timeRemaining = tokenInfo.token_expires_in_minutes;
            
            if (timeRemaining > 0 && timeRemaining <= expirationThreshold) {
              setExpirationWarning({
                minutesLeft: timeRemaining,
                message: `Your session expires in ${Math.ceil(timeRemaining * 60)} seconds. Please save your work.`
              });
            }
          }
        } catch (err) {
          console.error('Token verification failed on app load:', err);
          // Token is invalid, clear it
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
          localStorage.removeItem('user');
        }
      }

      setIsInitialized(true);
    };

    initializeApp();

    // Set up periodic token health check (every 500ms for responsiveness with short tokens)
    const tokenCheckInterval = setInterval(async () => {
      const token = localStorage.getItem('access_token');
      
      if (token) {
        try {
          const tokenInfo = await authAPI.getTokenInfo();
          
          if (tokenInfo && tokenInfo.token_expires_in_minutes !== undefined) {
            // Show warning if token expires within 80% of its lifetime
            const expirationThreshold = Math.max(0.1, tokenInfo.token_expires_in_minutes * 0.8);
            const timeRemaining = tokenInfo.token_expires_in_minutes;
            
            if (timeRemaining > 0 && timeRemaining <= expirationThreshold) {
              setExpirationWarning({
                minutesLeft: timeRemaining,
                message: `Your session expires in ${Math.ceil(timeRemaining * 60)} seconds. Please save your work.`
              });
            } else if (timeRemaining > expirationThreshold) {
              setExpirationWarning(null);
            }
          }
        } catch (err) {
          console.error('Periodic token check failed:', err);
        }
      }
    }, 500); // Check every 500ms for short tokens

    return () => clearInterval(tokenCheckInterval);
  }, []);

  // Monitor token validity - if token becomes invalid, cleanup inactivity system
  useEffect(() => {
    // Set up an interval to monitor if token is still valid
    const tokenMonitorInterval = setInterval(async () => {
      const token = localStorage.getItem('access_token');
      const hadToken = tokenStatus;
      
      // If no token in storage, cleanup
      if (!token) {
        if (hadToken) {
          cleanupInactivitySystem();
          setTokenStatus(false);
        }
        return;
      }

      // If we now have a token but didn't before, reset status
      if (!hadToken && token) {
        setTokenStatus(true);
        return;
      }

      // Verify token is still valid (only check once every 5 seconds to reduce spam)
      try {
        const tokenInfo = await authAPI.getTokenInfo();
        if (!tokenInfo) {
          // Token is no longer valid, cleanup
          cleanupInactivitySystem();
          setTokenStatus(false);
        }
      } catch (err) {
        // Token verification failed, cleanup silently
        cleanupInactivitySystem();
        setTokenStatus(false);
      }
    }, 5000); // Check every 5 seconds instead of 1 second to reduce API calls

    return () => clearInterval(tokenMonitorInterval);
  }, [tokenStatus]);

  // Register cleanup callback with authAPI - called on any logout
  useEffect(() => {
    authAPI.setOnLogoutCallback(cleanupInactivitySystem);
  }, []);

  if (!isInitialized) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <ThemeProvider>
      <PreprocessingProvider>
        <NotificationProvider>
          <AnalysisProvider>
            <Router>
              {/* Notification Center */}
              <NotificationCenter />
          
          {/* Inactivity Warning */}
          {inactivityWarning && (
            <div className="fixed top-0 left-0 right-0 bg-red-50 border-b-2 border-red-300 p-4 z-50">
              <div className="max-w-7xl mx-auto flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  <span className="text-red-800 font-medium">{inactivityWarning.message}</span>
                </div>
                <button
                  onClick={() => setInactivityWarning(null)}
                  className="text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            </div>
          )}

          {/* Token Expiration Warning */}
          {expirationWarning && (
            <div className="fixed top-0 left-0 right-0 bg-yellow-50 border-b-2 border-yellow-300 p-4 z-50">
              <div className="max-w-7xl mx-auto flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <svg className="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  <span className="text-yellow-800 font-medium">{expirationWarning.message}</span>
                </div>
                <button
                  onClick={() => setExpirationWarning(null)}
                  className="text-yellow-600 hover:text-yellow-800"
                >
                  ✕
                </button>
              </div>
            </div>
          )}

          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<LoginPage />} />
        
        {/* Protected Routes - User Pages */}
        <Route 
          path="/dashboard" 
          element={
            <UserProtectedRoute>
              <RoleBasedDashboard />
            </UserProtectedRoute>
          } 
        />
        <Route 
          path="/eeg-data" 
          element={
            <UserProtectedRoute>
              <EEGDataPage />
            </UserProtectedRoute>
          } 
        />
        <Route 
          path="/eeg-visualization" 
          element={
            <UserProtectedRoute>
              <EEGVisualizationPage />
            </UserProtectedRoute>
          } 
        />
        <Route 
          path="/analysis" 
          element={
            <UserProtectedRoute>
              <AnalysisPage />
            </UserProtectedRoute>
          } 
        />
        <Route 
          path="/reports" 
          element={
            <UserProtectedRoute>
              <ReportsPage />
            </UserProtectedRoute>
          } 
        />
        <Route 
          path="/settings" 
          element={
            <UserProtectedRoute>
              <SettingsPage />
            </UserProtectedRoute>
          } 
        />
        
        {/* Protected Routes - Admin Only */}
        <Route 
          path="/admin" 
          element={
            <ProtectedRoute requiredRole="root">
              <AdminPanel />
            </ProtectedRoute>
          } 
        />
        
          {/* Default Route */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
          </Router>
        </AnalysisProvider>
        </NotificationProvider>
      </PreprocessingProvider>
    </ThemeProvider>
  );
}

export default App;
