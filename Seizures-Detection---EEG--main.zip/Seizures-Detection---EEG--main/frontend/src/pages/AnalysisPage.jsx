import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Download, Play, AlertCircle, Clock, Zap, BarChart3, CheckCircle, Loader } from 'lucide-react';
import { authAPI, patientsAPI, eegFilesAPI, seizureDetectionAPI } from '../services/api';
import { useAnalysis } from '../context/AnalysisContext';
import { useNotification } from '../context/NotificationContext';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function AnalysisPage() {
  const navigate = useNavigate();
  const { addNotification } = useNotification();
  const { 
    getAnalysis, 
    startAnalysis, 
    selectedPatientId,
    setSelectedPatientId,
    selectedFileId,
    setSelectedFileId,
    analysisState
  } = useAnalysis();
  const [userName, setUserName] = useState('User');
  const [activeTab, setActiveTab] = useState('Analysis');
  
  // Form states
  const [analysisType, setAnalysisType] = useState('Seizure Detection');
  
  // Analysis states (isAnalyzing is now derived from context)
  const [eegFiles, setEegFiles] = useState([]);
  const [patients, setPatients] = useState([]);
  const [error, setError] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [analysisData, setAnalysisData] = useState(null);
  
  // Clinical notes modal
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  // Derive isAnalyzing from context (must be before useEffect that uses it)
  const isAnalyzing = selectedFileId ? analysisState[selectedFileId]?.status === 'analyzing' : false;

  React.useEffect(() => {
    loadUserName();
    loadPatients();
  }, []);

  React.useEffect(() => {
    console.log('selectedPatientId changed:', selectedPatientId);
    if (selectedPatientId) {
      loadEegFiles(selectedPatientId);
    } else {
      setEegFiles([]);
      setSelectedFileId('');
    }
    // Clear analysis data when patient changes
    setAnalysisData(null);
    setError(null);
  }, [selectedPatientId]);

  // Debug: Log current state when component mounts or analysis state changes
  useEffect(() => {
    console.log('AnalysisPage render state:', {
      selectedPatientId,
      selectedFileId,
      isAnalyzing,
      analysisData,
      analysisState
    });
  }, [selectedPatientId, selectedFileId, isAnalyzing, analysisState]);

  // Load analysis results from context when file is selected or analysis completes
  useEffect(() => {
    if (selectedFileId) {
      const analysis = getAnalysis(selectedFileId);
      console.log('Analysis from context:', analysis);
      if (analysis && analysis.results) {
        console.log('Setting analysisData to:', analysis.results);
        setAnalysisData(analysis.results);
        if (analysis.error) {
          setError(analysis.error);
        } else {
          setError(null);
        }
      } else {
        // No cached analysis for this file - clear the display
        setAnalysisData(null);
        setError(null);
      }
    } else {
      // No file selected - clear everything
      setAnalysisData(null);
      setError(null);
    }
  }, [selectedFileId, analysisState]);

  const loadUserName = async () => {
    try {
      const userData = await authAPI.getCurrentUser();
      if (userData) {
        setUserName(userData.full_name || userData.username || 'User');
      }
    } catch (err) {
      console.error('Failed to fetch user name:', err);
    }
  };

  const loadPatients = async () => {
    try {
      const data = await patientsAPI.list(0, 100);
      console.log('Patients response:', data);
      if (Array.isArray(data)) {
        setPatients(data);
      } else if (data.items && Array.isArray(data.items)) {
        setPatients(data.items);
      }
    } catch (err) {
      console.error('Failed to load patients:', err.response?.data || err.message);
    }
  };

  const loadEegFiles = async (patientId) => {
    try {
      const data = await eegFilesAPI.list(0, 100, patientId);
      if (Array.isArray(data)) {
        setEegFiles(data);
        if (data.length > 0) setSelectedFileId(data[0].id);
      } else if (data.files && Array.isArray(data.files)) {
        setEegFiles(data.files);
        if (data.files.length > 0) setSelectedFileId(data.files[0].id);
      } else if (data.items && Array.isArray(data.items)) {
        setEegFiles(data.items);
        if (data.items.length > 0) setSelectedFileId(data.items[0].id);
      } else {
        console.warn('Unexpected EEG files response format:', data);
        setEegFiles([]);
      }
    } catch (err) {
      console.error('Failed to load EEG files:', err.response?.data || err.message);
      setEegFiles([]);
    }
  };

  const analysisTypes = ['Seizure Detection'];

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'EEG Data', path: '/eeg-data' },
    { name: 'EEG Visualization', path: '/eeg-visualization' },
    { name: 'Analysis', path: '/analysis' },
    { name: 'Reports', path: '/reports' },
    { name: 'Settings', path: '/settings' }
  ];

  const handleRunAnalysis = () => {
    if (!selectedFileId) {
      setError('Please select an EEG file first');
      return;
    }
    
    setError(null);
    
    // Get the filename from selectedFile - try multiple properties
    const fileName = selectedFile?.original_filename || selectedFile?.filename || 'EEG Recording';
    
    // Start analysis in background (non-blocking)
    // This returns immediately, allowing user to navigate
    startAnalysis(selectedFileId, fileName);
  };

  const handleDownloadResults = async () => {
    if (!selectedFileId || !analysisData) {
      setError('No results to download');
      return;
    }
    
    // Open notes modal for clinical notes
    setShowNotesModal(true);
    setClinicalNotes('');
  };

  const handleExportPDF = async () => {
    if (!selectedFileId || !analysisData) {
      addNotification({
        type: 'error',
        title: 'No Results',
        message: 'No analysis results to download. Please run an analysis first.'
      });
      return;
    }
    
    setIsExporting(true);
    try {
      const blob = await seizureDetectionAPI.exportPDF(selectedFileId, clinicalNotes);
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `seizure_report_${selectedFileId}.pdf`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      addNotification({
        type: 'success',
        title: 'Report Downloaded',
        message: 'Your seizure detection report has been downloaded successfully.'
      });
      
      setShowNotesModal(false);
      setClinicalNotes('');
    } catch (err) {
      console.error('Download failed:', err);
      addNotification({
        type: 'error',
        title: 'Download Failed',
        message: 'Failed to download report. Please try again.'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const getSeizureSeverity = (percentage) => {
    if (percentage === 0) return { text: 'None', color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20' };
    if (percentage < 5) return { text: 'Mild', color: 'text-yellow-600', bg: 'bg-yellow-50 dark:bg-yellow-900/20' };
    if (percentage < 15) return { text: 'Moderate', color: 'text-orange-600', bg: 'bg-orange-50 dark:bg-orange-900/20' };
    return { text: 'Severe', color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20' };
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="Analysis" userName={userName} />
        <main className="flex-1 overflow-y-auto min-h-0 p-8 bg-gray-50 dark:bg-gray-900">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">EEG Seizure Detection</h1>
            <p className="text-gray-600 dark:text-gray-400">Run ML-based seizure detection on your EEG recordings using NEDC ResNet model.</p>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-red-800 dark:text-red-300">Error</p>
                <p className="text-sm text-red-700 dark:text-red-400">{error}</p>
              </div>
            </div>
          )}

          {/* Selection Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8 mb-8">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Select Recording for ML Analysis</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              {/* Patient Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                  Select Patient
                </label>
                <select
                  value={selectedPatientId}
                  onChange={(e) => {
                    setSelectedPatientId(e.target.value);
                    setError(null);
                  }}
                  disabled={isAnalyzing}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <option value="">Choose a patient...</option>
                  {patients.map((patient) => (
                    <option key={patient.id} value={patient.id}>
                      {patient.full_name}
                    </option>
                  ))}
                </select>
              </div>

              {/* EEG File Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                  Select EEG File
                </label>
                <select
                  value={selectedFileId}
                  onChange={(e) => {
                    const fileId = e.target.value;
                    setSelectedFileId(fileId);
                    const file = eegFiles.find(f => f.id === fileId);
                    setSelectedFile(file || null);
                    setError(null);
                  }}
                  disabled={!selectedPatientId || isAnalyzing}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <option value="">Choose an EEG file...</option>
                  {eegFiles.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.original_filename || file.filename}
                    </option>
                  ))}
                </select>
              </div>

              {/* Analysis Type Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                  Analysis Type
                </label>
                <select
                  value={analysisType}
                  onChange={(e) => setAnalysisType(e.target.value)}
                  disabled={isAnalyzing}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {analysisTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* File Info */}
            {selectedFile && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  <span className="font-semibold">Channels:</span> {selectedFile.number_of_channels} | 
                  <span className="font-semibold ml-3">Duration:</span> {selectedFile.recording_duration ? `${selectedFile.recording_duration.toFixed(1)}s (${(selectedFile.recording_duration / 60).toFixed(2)} min)` : 'N/A'}
                </p>
              </div>
            )}

            {/* Run Analysis Button */}
            <button
              onClick={handleRunAnalysis}
              disabled={isAnalyzing || !selectedFileId}
              className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition shadow-md hover:shadow-lg flex items-center justify-center gap-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <>
                  <Loader className="w-5 h-5 animate-spin" />
                  Processing... (1-3 minutes)
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  Run Seizure Detection
                </>
              )}
            </button>

            {isAnalyzing && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mt-4">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  <strong>✓ Analysis Started:</strong> The seizure detection model is analyzing your EEG file in the background. This typically takes 1-3 minutes. You will receive a notification when the analysis is complete, and you can safely navigate to other pages.
                </p>
              </div>
            )}
          </div>

          {/* Analysis Results */}
          {analysisData && (
            <div className="space-y-6">
              {/* Results Header */}
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Seizure Detection Results</h2>
                  </div>
                  <button
                    onClick={handleDownloadResults}
                    className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download Report
                  </button>
                </div>

                {/* Key Statistics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {/* Seizure Count */}
                  <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-900/10 border border-red-200 dark:border-red-800 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="w-4 h-4 text-red-600" />
                      <span className="text-xs font-semibold text-red-700 dark:text-red-400">SEIZURE EVENTS</span>
                    </div>
                    <p className="text-2xl font-bold text-red-700 dark:text-red-300">{analysisData.seizure_count}</p>
                    <p className="text-xs text-red-600 dark:text-red-400">Total events detected</p>
                  </div>

                  {/* Total Seizure Time */}
                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-900/10 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-4 h-4 text-orange-600" />
                      <span className="text-xs font-semibold text-orange-700 dark:text-orange-400">SEIZURE DURATION</span>
                    </div>
                    <p className="text-2xl font-bold text-orange-700 dark:text-orange-300">{analysisData.total_seizure_time.toFixed(1)}s</p>
                    <p className="text-xs text-orange-600 dark:text-orange-400">({(analysisData.total_seizure_time / 60).toFixed(2)} min)</p>
                  </div>

                  {/* Seizure Percentage */}
                  <div className={`bg-gradient-to-br rounded-lg p-4 border ${getSeizureSeverity(analysisData.seizure_percentage).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <BarChart3 className={`w-4 h-4 ${getSeizureSeverity(analysisData.seizure_percentage).color}`} />
                      <span className={`text-xs font-semibold ${getSeizureSeverity(analysisData.seizure_percentage).color}`}>
                        SEIZURE PERCENTAGE
                      </span>
                    </div>
                    <p className={`text-2xl font-bold ${getSeizureSeverity(analysisData.seizure_percentage).color}`}>
                      {analysisData.seizure_percentage.toFixed(2)}%
                    </p>
                    <p className={`text-xs ${getSeizureSeverity(analysisData.seizure_percentage).color}`}>
                      {getSeizureSeverity(analysisData.seizure_percentage).text} severity
                    </p>
                  </div>

                  {/* Recording Duration */}
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-900/10 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Zap className="w-4 h-4 text-blue-600" />
                      <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">RECORDING DURATION</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">{analysisData.duration.toFixed(1)}s</p>
                    <p className="text-xs text-blue-600 dark:text-blue-400">({(analysisData.duration / 60).toFixed(2)} min)</p>
                  </div>
                </div>
              </div>

              {/* Seizure Timeline */}
              {analysisData.seizures && analysisData.seizures.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Detected Seizure Events</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-200 dark:border-gray-700">
                          <th className="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Event #</th>
                          <th className="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Start Time (s)</th>
                          <th className="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Stop Time (s)</th>
                          <th className="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Duration (s)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analysisData.seizures.map((seizure, index) => (
                          <tr key={index} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                            <td className="py-3 px-4 text-gray-900 dark:text-gray-300 font-semibold">#{index + 1}</td>
                            <td className="py-3 px-4 text-gray-700 dark:text-gray-400">{seizure.start.toFixed(2)}</td>
                            <td className="py-3 px-4 text-gray-700 dark:text-gray-400">{seizure.stop.toFixed(2)}</td>
                            <td className="py-3 px-4">
                              <span className="px-3 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded font-semibold">
                                {seizure.duration.toFixed(2)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Summary Section */}
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Analysis Summary</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Key Findings:</h4>
                    <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-400">
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 dark:text-blue-400 font-bold mt-0.5">•</span>
                        <span>Detected <strong className="text-gray-900 dark:text-white">{analysisData.seizure_count}</strong> seizure event(s) during recording</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 dark:text-blue-400 font-bold mt-0.5">•</span>
                        <span>Total seizure duration: <strong className="text-gray-900 dark:text-white">{analysisData.total_seizure_time.toFixed(2)} seconds ({(analysisData.total_seizure_time / 60).toFixed(2)} min)</strong></span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 dark:text-blue-400 font-bold mt-0.5">•</span>
                        <span>Recording duration: <strong className="text-gray-900 dark:text-white">{analysisData.duration.toFixed(2)} seconds ({(analysisData.duration / 60).toFixed(2)} min)</strong></span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 dark:text-blue-400 font-bold mt-0.5">•</span>
                        <span>Seizure percentage: <strong className="text-gray-900 dark:text-white">{analysisData.seizure_percentage.toFixed(2)}%</strong> of recording</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Clinical Notes:</h4>
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded p-3 text-sm text-blue-800 dark:text-blue-300">
                      <p>Results generated using NEDC ResNet model trained on TUH EEG dataset. This analysis is for clinical decision support only and should be reviewed by a qualified healthcare professional.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Clinical Notes Modal */}
          {showNotesModal && (
            <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center z-50 p-4">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] flex flex-col">
                {/* Header */}
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add Clinical Notes to Report</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Optional: Add clinical observations and recommendations to the PDF report</p>
                </div>

                {/* Body */}
                <div className="flex-1 overflow-y-auto p-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                      Clinical Notes
                    </label>
                    <textarea
                      value={clinicalNotes}
                      onChange={(e) => setClinicalNotes(e.target.value)}
                      placeholder="Enter any clinical observations, recommendations, or follow-up actions..."
                      className="w-full h-48 p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                      These notes will be included in the exported PDF report.
                    </p>
                  </div>
                </div>

                {/* Footer */}
                <div className="border-t border-gray-200 dark:border-gray-700 p-6 flex items-center justify-end gap-3">
                  <button
                    onClick={() => {
                      setShowNotesModal(false);
                      setClinicalNotes('');
                    }}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition"
                    disabled={isExporting}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleExportPDF}
                    disabled={isExporting}
                    className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:bg-blue-400 transition flex items-center gap-2"
                  >
                    {isExporting ? (
                      <>
                        <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                        Generating...
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        Generate & Download PDF
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}