import React, { useState, useEffect, useCallback } from 'react';
import { Download, Eye, Trash2, FileUp, Loader } from 'lucide-react';
import { eegFilesAPI, patientsAPI, usersAPI, authAPI } from '../services/api';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import EEGFilesList from '../components/EEGFilesList';
import EEGFileUploadModal from '../components/EEGFileUploadModal';
import EEGFileDetailsModal from '../components/EEGFileDetailsModal';

const EEGDataPage = () => {
  const [user, setUser] = useState(null);
  const [userName, setUserName] = useState('User');
  const [loading, setLoading] = useState(false);
  const [userLoading, setUserLoading] = useState(true);
  const [files, setFiles] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [total, setTotal] = useState(0);
  const [skip, setSkip] = useState(0);
  const [limit, setLimit] = useState(10);
  const [filters, setFilters] = useState({
    patientId: null,
    uploadedBy: null,
    includeDeleted: false,
  });
  
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  // Load current user
  useEffect(() => {
    const loadUser = async () => {
      try {
        setUserLoading(true);
        const userData = await authAPI.getCurrentUser();
        setUser(userData);
        setUserName(userData?.full_name || userData?.username || 'User');
      } catch (error) {
        console.error('Failed to load user:', error);
      } finally {
        setUserLoading(false);
      }
    };
    loadUser();
  }, []);


  // Load patients for doctor/admin filter
  const loadPatients = useCallback(async () => {
    try {
      if (user?.role === 'doctor') {
        // Doctors see their own patients
        const response = await patientsAPI.list(0, 1000, user.id);
        setPatients(Array.isArray(response) ? response : response.data || []);
      } else if (user?.role === 'assistant') {
        // Assistants see their assigned doctor's patients
        try {
          const doctor = await usersAPI.getMyAssignedDoctor();
          if (doctor) {
            const response = await patientsAPI.list(0, 1000, doctor.id);
            setPatients(Array.isArray(response) ? response : response.data || []);
          }
        } catch (error) {
          console.error('Failed to get assigned doctor for assistant:', error);
        }
      } else if (user?.role === 'admin' || user?.role === 'root') {
        // Admins and root see all patients
        const response = await patientsAPI.list(0, 1000);
        setPatients(Array.isArray(response) ? response : response.data || []);
      }
    } catch (error) {
      console.error('Failed to load patients:', error);
    }
  }, [user?.id, user?.role]);

  // Load doctors for admin/root filter
  const loadDoctors = useCallback(async () => {
    try {
      if (user?.role === 'admin' || user?.role === 'root') {
        const response = await usersAPI.getDoctors(0, 1000);
        setDoctors(Array.isArray(response) ? response : response.data || []);
      }
    } catch (error) {
      console.error('Failed to load doctors:', error);
    }
  }, [user?.role]);

  // Load EEG files
  const loadFiles = useCallback(async () => {
    try {
      setLoading(true);
      const response = await eegFilesAPI.list(
        skip,
        limit,
        filters.patientId,
        filters.uploadedBy,
        filters.includeDeleted
      );
      
      setFiles(response.files || []);
      setTotal(response.total || 0);
    } catch (error) {
      console.error('Failed to load EEG files:', error);
    } finally {
      setLoading(false);
    }
  }, [skip, limit, filters, user]);

  // Initial load
  useEffect(() => {
    loadPatients();
    loadDoctors();
  }, [loadPatients, loadDoctors]);

  useEffect(() => {
    if (user) {
      loadFiles();
    }
  }, [loadFiles, user]);

  // Handle file upload
  const handleUpload = async (uploadData) => {
    try {
      await eegFilesAPI.upload(
        uploadData.file,
        uploadData.patientId,
        uploadData.description,
        uploadData.notes,
        uploadData.onUploadProgress
      );
      
      setUploadModalOpen(false);
      setSkip(0); // Reset to first page
      await loadFiles();
    } catch (error) {
      console.error('Upload failed:', error);
      throw error;
    }
  };

  // Handle file details view
  const handleViewDetails = async (file) => {
    try {
      const details = await eegFilesAPI.get(file.id);
      setSelectedFile(details);
      setIsEditing(false);
      setDetailsModalOpen(true);
    } catch (error) {
      console.error('Failed to load file details:', error);
    }
  };

  // Handle metadata update
  const handleUpdateMetadata = async (fileId, updateData) => {
    try {
      const response = await eegFilesAPI.update(fileId, updateData);
      setSelectedFile(response.data);
      setIsEditing(false);
      await loadFiles(); // Refresh list
    } catch (error) {
      console.error('Update failed:', error);
      throw error;
    }
  };

  // Handle file download
  const handleDownload = async (file) => {
    try {
      const blob = await eegFilesAPI.download(file.id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.original_filename || `eeg_${file.id}.edf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download failed:', error);
      throw error;
    }
  };

  // Handle file delete
  const handleDelete = async (fileId, hardDelete = false) => {
    if (!window.confirm(`Are you sure you want to ${hardDelete ? 'permanently' : 'delete'} this file?`)) {
      return;
    }

    try {
      await eegFilesAPI.delete(fileId, hardDelete);
      setDetailsModalOpen(false);
      await loadFiles();
    } catch (error) {
      console.error('Delete failed:', error);
      throw error;
    }
  };

  // Handle filter change
  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    setSkip(0); // Reset to first page on filter change
  };

  // Handle pagination
  const handlePageChange = (newSkip) => {
    setSkip(newSkip);
  };

  // Get patient name by ID
  const getPatientName = (patientId) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.full_name || 'Unknown';
  };

  const canUpload = ['doctor', 'assistant', 'admin', 'root'].includes(user?.role);
  const showDeleteOption = user?.role === 'root'; // Only root can hard delete
  const showFilterOptions = ['admin', 'root'].includes(user?.role);

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="EEG Data Management" userName={userName} />
        <main className="flex-1 overflow-y-auto min-h-0 p-8 bg-gray-50 dark:bg-gray-900">
          {/* Header */}
          <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">EEG Data Management</h1>
          <p className="text-slate-400">
            {user?.role === 'doctor' && 'Manage EEG files for your patients'}
            {user?.role === 'admin' && 'Manage EEG files for your organization'}
            {user?.role === 'root' && 'Manage all EEG files in the system'}
          </p>
        </div>

        {/* Upload Button */}
        {canUpload && (
          <div className="mb-6">
            <button
              onClick={() => setUploadModalOpen(true)}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors flex items-center gap-2"
            >
              <FileUp className="w-5 h-5" />
              Upload EEG File
            </button>
          </div>
        )}

        {/* Files List */}
        <EEGFilesList
          files={files}
          patients={patients}
          doctors={doctors}
          loading={loading || userLoading}
          total={total}
          skip={skip}
          limit={limit}
          filters={filters}
          userRole={user?.role}
          onViewDetails={handleViewDetails}
          onDownload={handleDownload}
          onFilterChange={handleFilterChange}
          onPageChange={handlePageChange}
          showFilterOptions={showFilterOptions}
        />

        {/* Upload Modal */}
        {uploadModalOpen && (
          <EEGFileUploadModal
            isOpen={uploadModalOpen}
            onClose={() => setUploadModalOpen(false)}
            onUpload={handleUpload}
            patients={patients}
            userRole={user?.role}
            currentUserId={user?.id}
          />
        )}

        {/* Details Modal */}
        {detailsModalOpen && selectedFile && (
          <EEGFileDetailsModal
            isOpen={detailsModalOpen}
            onClose={() => setDetailsModalOpen(false)}
            file={selectedFile}
            patientName={getPatientName(selectedFile.patient_id)}
            isEditing={isEditing}
            onEdit={() => setIsEditing(true)}
            onCancel={() => setIsEditing(false)}
            onSave={handleUpdateMetadata}
            onDownload={() => handleDownload(selectedFile)}
            onDelete={handleDelete}
            userRole={user?.role}
            showHardDeleteOption={showDeleteOption}
          />
        )}
      </main>
      </div>
    </div>
  );
};

export default EEGDataPage;