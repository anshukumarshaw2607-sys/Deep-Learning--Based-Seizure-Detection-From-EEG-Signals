import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { authAPI } from '../services/api';

export default function AdminLogin() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.username.trim()) newErrors.username = 'Username is required';
    if (!formData.password) newErrors.password = 'Password is required';
    return newErrors;
  };

  const handleSubmit = async () => {
    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);
    try {
      // Call backend /auth/login which returns tokens and user_role
      const loginResp = await authAPI.login(formData.username, formData.password);

      // backend returns `user_role` in the login response (see auth.py)
      const role = (loginResp && (loginResp.user_role || loginResp.role || loginResp.userRole));

      if (role && String(role).toLowerCase() === 'root') {
        // Token is already stored by authAPI.login; fetch user profile to store
        const user = await authAPI.getCurrentUser();
        localStorage.setItem('user', JSON.stringify(user));
        navigate('/admin');
      } else {
        // Not permitted to access admin panel
        authAPI.logout();
        setErrors({ submit: 'Access denied: root role required.' });
      }
    } catch (err) {
      console.error('Admin login failed', err);
      setErrors({ submit: err.response?.data?.detail || 'Login failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => { if (e.key === 'Enter') handleSubmit(); };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-4">
          <h1 className="text-lg font-semibold text-gray-700">Admin Panel</h1>
        </div>

        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Administrator Login</h2>
          <p className="text-gray-600 text-sm">Sign in with your admin account</p>
        </div>

        <div className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">UserName</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              onKeyPress={handleKeyPress}
              className={`w-full px-4 py-3 bg-gray-50 border ${errors.username ? 'border-red-500' : 'border-gray-200'} rounded-lg admin-input`}
              placeholder="Enter username"
            />
            {errors.username && <p className="mt-1 text-sm text-red-500">{errors.username}</p>}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={formData.password}
                onChange={handleChange}
                onKeyPress={handleKeyPress}
                className={`w-full px-4 py-3 bg-gray-50 border ${errors.password ? 'border-red-500' : 'border-gray-200'} rounded-lg pr-12 admin-input`}
                placeholder="Enter password"
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {errors.password && <p className="mt-1 text-sm text-red-500">{errors.password}</p>}
          </div>

          {errors.submit && <div className="p-4 bg-red-100 text-red-700 rounded-lg text-sm">{errors.submit}</div>}

          <button
            onClick={handleSubmit}
            disabled={loading}
            className={`w-full bg-blue-600 text-white font-semibold py-3 rounded-lg ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'}`}>
            {loading ? 'Signing in...' : 'Sign in as admin'}
          </button>
        </div>
      </div>
    </div>
  );
}
