import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { authAPI, eegFilesAPI, eegAnalysisAPI, patientsAPI } from '../services/api';
import { usePreprocessing } from '../context/PreprocessingContext';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import { 
  AlertCircle, Loader, RefreshCw, X, ZoomIn, ZoomOut, 
  Maximize2, Minimize2, Download, Layers, BarChart3, 
  GitCompare, Eye, EyeOff, ChevronLeft, ChevronRight,
  Play, Pause, Settings, Info, CheckCircle2, Brain,
  Activity, Zap, FileText, User, CheckCircle
} from 'lucide-react';

export default function EEGVisualizationPage() {
  const [userName, setUserName] = useState('User');
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFileId, setSelectedFileId] = useState('');
  const [files, setFiles] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [preprocessing, setPreprocessing] = useState(false);
  const [preprocessingData, setPreprocessingData] = useState(null);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('raw');
  const [showModal, setShowModal] = useState(false);
  const [sliderValue, setSliderValue] = useState(0);
  
  // Enhanced visualization controls
  const [zoomLevel, setZoomLevel] = useState(1);
  const [selectedChannels, setSelectedChannels] = useState([]);
  const [showChannelPicker, setShowChannelPicker] = useState(false);
  const [comparisonMode, setComparisonMode] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);
  const [processingSteps] = useState(['Loading file...', 'Applying filters...', 'Running ICA...', 'Computing PSD...', 'Generating topomaps...']);
  const [showTooltip, setShowTooltip] = useState({ visible: false, x: 0, y: 0, content: '' });
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [channelStats, setChannelStats] = useState({});
  const chartRef = useRef(null);
  const playbackRef = useRef(null);
  
  const { preprocessingData: contextData, updatePreprocessingData, clearPreprocessingData } = usePreprocessing();
  
  // Initialize preprocessing data from context on page load
  useEffect(() => {
    if (contextData) {
      setPreprocessingData(contextData);
      setActiveTab('raw');
    }
  }, [contextData]);

  // Initialize selected channels when preprocessing data loads
  useEffect(() => {
    if (preprocessingData?.raw_signal?.channels) {
      const channels = preprocessingData.raw_signal.channels;
      // Select first 8 channels by default
      setSelectedChannels(channels.slice(0, Math.min(8, channels.length)));
      
      // Calculate channel statistics
      calculateChannelStats(preprocessingData.raw_signal);
    }
  }, [preprocessingData]);

  // Playback animation - smooth scrolling using accumulated time
  useEffect(() => {
    let animationId;
    let accumulatedValue = sliderValue;
    let lastTimestamp = null;
    
    const animate = (timestamp) => {
      if (!lastTimestamp) lastTimestamp = timestamp;
      
      // Calculate time since last frame in seconds
      const deltaSeconds = (timestamp - lastTimestamp) / 1000;
      lastTimestamp = timestamp;
      
      // Accumulate slider movement (0.1% per second at 1x speed - very slow)
      accumulatedValue += deltaSeconds * 0.1 * playbackSpeed;
      
      if (accumulatedValue >= 100) {
        setIsPlaying(false);
        setSliderValue(0);
        return;
      }
      
      // Update state with the new value
      setSliderValue(accumulatedValue);
      
      if (isPlaying) {
        animationId = requestAnimationFrame(animate);
      }
    };
    
    if (isPlaying && preprocessingData) {
      lastTimestamp = null;
      accumulatedValue = sliderValue;
      animationId = requestAnimationFrame(animate);
    }
    
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [isPlaying, playbackSpeed, preprocessingData]);

  // Calculate channel statistics
  const calculateChannelStats = useCallback((signalData) => {
    if (!signalData?.data || !signalData?.channels) return;
    
    const stats = {};
    signalData.channels.forEach((channel, idx) => {
      const channelData = signalData.data[idx];
      if (Array.isArray(channelData) && channelData.length > 0) {
        const validData = channelData.filter(v => typeof v === 'number' && !isNaN(v));
        if (validData.length === 0) return;
        
        // Use reduce to avoid stack overflow with large arrays
        let min = validData[0];
        let max = validData[0];
        let sum = 0;
        
        for (let i = 0; i < validData.length; i++) {
          const val = validData[i];
          if (val < min) min = val;
          if (val > max) max = val;
          sum += val;
        }
        
        const mean = sum / validData.length;
        
        // Calculate variance in a second pass
        let varianceSum = 0;
        for (let i = 0; i < validData.length; i++) {
          varianceSum += Math.pow(validData[i] - mean, 2);
        }
        const variance = varianceSum / validData.length;
        const std = Math.sqrt(variance);
        
        stats[channel] = { min, max, mean, std, range: max - min };
      }
    });
    setChannelStats(stats);
  }, []);

  // Get user from API on mount
  useEffect(() => {
    const loadUserName = async () => {
      try {
        const userData = await authAPI.getCurrentUser();
        if (userData) {
          setUserName(userData.full_name || userData.username || 'User');
        }
      } catch (err) {
        console.error('Failed to fetch user name:', err);
      }
    };
    loadUserName();
  }, []);

  // Load patients on mount
  useEffect(() => {
    const loadPatients = async () => {
      try {
        const data = await patientsAPI.list(0, 100);
        if (Array.isArray(data)) {
          setPatients(data);
        } else if (data.items && Array.isArray(data.items)) {
          setPatients(data.items);
        }
      } catch (err) {
        console.error('Failed to load patients:', err.response?.data || err.message);
      }
    };
    loadPatients();
  }, []);

  // Load EEG files when patient is selected
  useEffect(() => {
    if (selectedPatientId) {
      loadEegFiles(selectedPatientId);
    } else {
      setFiles([]);
      setSelectedFileId('');
      setSelectedFile(null);
    }
  }, [selectedPatientId]);

  const loadEegFiles = async (patientId) => {
    try {
      setLoading(true);
      setError(null);
      const data = await eegFilesAPI.list(0, 100, patientId);
      let filesList = [];
      
      if (Array.isArray(data)) {
        filesList = data;
      } else if (data.files && Array.isArray(data.files)) {
        filesList = data.files;
      } else if (data.items && Array.isArray(data.items)) {
        filesList = data.items;
      }
      
      setFiles(filesList);
      
      if (filesList.length > 0) {
        setSelectedFileId(filesList[0].id);
        setSelectedFile(filesList[0]);
      } else {
        setError('No EEG files available for this patient.');
        setSelectedFileId('');
        setSelectedFile(null);
      }
    } catch (err) {
      console.error('Failed to load EEG files:', err.response?.data || err.message);
      setError(`Failed to load EEG files: ${err.message}`);
      setFiles([]);
      setSelectedFileId('');
      setSelectedFile(null);
    } finally {
      setLoading(false);
    }
  };

  // Handle preprocessing
  const handlePreprocess = async () => {
    if (!selectedFile) {
      setError('Please select a file first');
      return;
    }

    try {
      setPreprocessing(true);
      setError(null);
      setProcessingStep(0);
      
      // Simulate progress steps
      const progressInterval = setInterval(() => {
        setProcessingStep(prev => {
          if (prev < processingSteps.length - 1) return prev + 1;
          return prev;
        });
      }, 2000);
      
      const result = await eegAnalysisAPI.preprocess(selectedFile.id);
      
      clearInterval(progressInterval);
      setProcessingStep(processingSteps.length - 1);
      
      const preprocessingReport = result.preprocessing_report;
      setPreprocessingData(preprocessingReport);
      updatePreprocessingData(preprocessingReport, selectedFile.id);
      setActiveTab('raw');
      setZoomLevel(1);
      setSliderValue(0);
    } catch (err) {
      console.error('Preprocessing failed:', err);
      
      // Provide user-friendly error messages
      let errorMessage = 'Preprocessing failed';
      if (err.code === 'ECONNABORTED') {
        errorMessage = 'Processing took too long. The file may be too large or the server is processing slowly. Please try again.';
      } else if (err.response?.data?.detail) {
        errorMessage = `Preprocessing failed: ${err.response.data.detail}`;
      } else if (err.message) {
        errorMessage = `Preprocessing failed: ${err.message}`;
      }
      
      setError(errorMessage);
    } finally {
      setPreprocessing(false);
      setProcessingStep(0);
    }
  };

  // Handle refresh files
  const handleRefresh = async () => {
    if (!selectedPatientId) {
      setError('Please select a patient first');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      const data = await eegFilesAPI.list(0, 100, selectedPatientId);
      let filesList = [];
      
      if (Array.isArray(data)) {
        filesList = data;
      } else if (data.files && Array.isArray(data.files)) {
        filesList = data.files;
      } else if (data.items && Array.isArray(data.items)) {
        filesList = data.items;
      }
      
      setFiles(filesList);
      
      if (filesList.length === 0) {
        setError('No EEG files available for this patient.');
        setSelectedFileId('');
        setSelectedFile(null);
      } else if (!selectedFile) {
        setSelectedFileId(filesList[0].id);
        setSelectedFile(filesList[0]);
      }
    } catch (err) {
      console.error('Failed to refresh files:', err);
      setError(`Failed to refresh files: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Zoom controls
  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev * 1.5, 10));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev / 1.5, 0.5));
  const handleResetZoom = () => setZoomLevel(1);

  // Toggle channel selection
  const toggleChannel = (channel) => {
    setSelectedChannels(prev => {
      if (prev.includes(channel)) {
        return prev.filter(c => c !== channel);
      } else {
        return [...prev, channel];
      }
    });
  };

  // Select/deselect all channels
  const selectAllChannels = () => {
    if (preprocessingData?.raw_signal?.channels) {
      setSelectedChannels(preprocessingData.raw_signal.channels);
    }
  };
  const deselectAllChannels = () => setSelectedChannels([]);

  // Export chart as PNG
  const exportChartAsPNG = async () => {
    if (!chartRef.current) return;
    
    try {
      const svg = chartRef.current.querySelector('svg');
      if (!svg) return;
      
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);
      
      img.onload = () => {
        canvas.width = img.width * 2;
        canvas.height = img.height * 2;
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        const pngUrl = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.download = `eeg_${activeTab}_${new Date().toISOString().slice(0, 10)}.png`;
        link.href = pngUrl;
        link.click();
        
        URL.revokeObjectURL(url);
      };
      
      img.src = url;
    } catch (err) {
      console.error('Failed to export chart:', err);
    }
  };

  // Navigate slider - smaller steps when zoomed in
  const navigateSlider = (direction) => {
    const step = 5 * zoomLevel;
    setSliderValue(prev => {
      const newVal = direction === 'left' ? prev - step : prev + step;
      return Math.max(0, Math.min(100, newVal));
    });
  };

  // Chart rendering helper
  const renderChart = (data, type, useSlider = false, sliderPos = 0) => {
    if (!preprocessingData) return null;

    switch (type) {
      case 'raw':
        return renderWaveform(preprocessingData.raw_signal, useSlider, sliderPos);
      case 'filtered':
        return renderWaveform(preprocessingData.filtered_signal, useSlider, sliderPos);
      case 'ica':
        return renderWaveform(preprocessingData.ica_signal, useSlider, sliderPos);
      case 'ica_components':
        return renderICAComponents(preprocessingData.ica_signal);
      case 'psd':
        return renderPSD(preprocessingData.psd);
      case 'topomaps':
        return renderTopomaps(preprocessingData.topomaps);

      default:
        return null;
    }
  };

  // Memoize slider position to reduce re-renders (round to 2 decimal places)
  const memoizedSliderPos = useMemo(() => Math.round(sliderValue * 100) / 100, [sliderValue]);

  // Render waveform with optional slider support
  const renderWaveform = useCallback((signalData, useSlider = false, sliderPos = 0) => {
    if (!signalData) return <p className="text-gray-500">No signal data</p>;
    if (signalData.error) return <p className="text-gray-500">{signalData.error}</p>;

    const { channels, data, sampling_rate } = signalData;
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      return <p className="text-gray-500">Invalid waveform data structure</p>;
    }
    
    // Calculate visible window based on zoom
    const numSamples = data[0]?.length || 0;
    if (numSamples === 0) {
      return <p className="text-gray-500">No samples in data</p>;
    }

    // Calculate total duration in seconds
    const totalDuration = numSamples / sampling_rate;
    
    // Base window is 10 seconds at zoom level 1, less as we zoom in
    const baseWindowSeconds = 10 / zoomLevel;
    const windowSize = Math.max(100, Math.min(Math.floor(baseWindowSeconds * sampling_rate), numSamples));
    
    let startIdx = 0;
    let endIdx = windowSize;
    
    // Use slider to navigate through the recording
    const maxStartIdx = Math.max(0, numSamples - windowSize);
    startIdx = Math.floor((sliderPos / 100) * maxStartIdx);
    endIdx = Math.min(startIdx + windowSize, numSamples);
    
    // Use selected channels or fallback to first 8
    const visibleChannels = selectedChannels.length > 0 
      ? channels.filter(ch => selectedChannels.includes(ch))
      : channels.slice(0, 8);
    
    if (visibleChannels.length === 0) {
      return (
        <div className="text-center py-12">
          <EyeOff className="w-12 h-12 text-gray-500 mx-auto mb-3" />
          <p className="text-gray-500">No channels selected</p>
          <button 
            onClick={() => setSelectedChannels(channels.slice(0, 8))}
            className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm"
          >
            Show default channels
          </button>
        </div>
      );
    }
    
    // Dynamic channel height - adapts to number of channels for better use of space
    // Use more height per channel when fewer channels are shown
    const baseChannelHeight = visibleChannels.length <= 4 ? 100 : 
                              visibleChannels.length <= 8 ? 70 :
                              visibleChannels.length <= 12 ? 55 :
                              visibleChannels.length <= 16 ? 45 : 35;
    const channelHeight = baseChannelHeight;
    const chartPadding = { top: 40, bottom: 50, left: 70, right: 30 };
    // Minimum total height to ensure visibility
    const minHeight = 500;
    const calculatedHeight = visibleChannels.length * channelHeight + chartPadding.top + chartPadding.bottom;
    const totalHeight = Math.max(minHeight, calculatedHeight);
    const chartWidth = 1200;
    const plotWidth = chartWidth - chartPadding.left - chartPadding.right;
    
    // Calculate time labels for x-axis
    const numTimeLabels = 11;
    const timeLabels = Array.from({ length: numTimeLabels }, (_, i) => {
      const sampleIdx = startIdx + Math.floor((i / (numTimeLabels - 1)) * (endIdx - startIdx));
      const time = sampleIdx / sampling_rate;
      return { x: chartPadding.left + (i * plotWidth) / (numTimeLabels - 1), time: time.toFixed(2) };
    });

    // Calculate amplitude scale - zoom affects vertical scaling
    const amplitudeRange = 100 / zoomLevel; // Smaller range = more detail when zoomed in

    return (
      <div className="w-full h-full flex flex-col">
        {/* Info bar */}
        <div className="text-gray-300 text-xs mb-3 flex-shrink-0 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="px-2 py-1 bg-blue-600/20 rounded text-blue-400">
              {sampling_rate} Hz
            </span>
            <span className="px-2 py-1 bg-green-600/20 rounded text-green-400">
              {visibleChannels.length}/{channels.length} channels
            </span>
            <span className="px-2 py-1 bg-purple-600/20 rounded text-purple-400">
              {((endIdx - startIdx) / sampling_rate).toFixed(2)}s window
            </span>
            <span className="px-2 py-1 bg-orange-600/20 rounded text-orange-400">
              {zoomLevel.toFixed(1)}x zoom
            </span>
          </div>
          <div className="text-gray-400">
            {(startIdx / sampling_rate).toFixed(2)}s - {(endIdx / sampling_rate).toFixed(2)}s
          </div>
        </div>
        
        <svg 
          viewBox={`0 0 ${chartWidth} ${totalHeight}`} 
          className="w-full flex-1 border border-gray-700 rounded-lg bg-gray-950"
          style={{ minHeight: `${Math.max(400, totalHeight * 0.6)}px`, height: 'auto' }}
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Background gradient */}
          <defs>
            <linearGradient id="chartBg" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
          </defs>
          <rect x="0" y="0" width={chartWidth} height={totalHeight} fill="url(#chartBg)" />
          
          {/* Grid lines - vertical */}
          {Array.from({ length: 11 }).map((_, i) => (
            <line
              key={`vgrid-${i}`}
              x1={chartPadding.left + (i * plotWidth) / 10}
              y1={chartPadding.top}
              x2={chartPadding.left + (i * plotWidth) / 10}
              y2={totalHeight - chartPadding.bottom}
              stroke="#374151"
              strokeWidth="0.5"
              opacity="0.3"
            />
          ))}
          
          {/* X-axis */}
          <line 
            x1={chartPadding.left} 
            y1={totalHeight - chartPadding.bottom} 
            x2={chartPadding.left + plotWidth} 
            y2={totalHeight - chartPadding.bottom} 
            stroke="#9CA3AF" 
            strokeWidth="1" 
          />
          
          {/* X-axis label */}
          <text 
            x={chartPadding.left + plotWidth / 2} 
            y={totalHeight - 10} 
            fontSize="12" 
            fill="#9CA3AF" 
            textAnchor="middle"
            fontWeight="bold"
          >
            Time (seconds)
          </text>
          
          {/* X-axis ticks and time labels */}
          {timeLabels.map((label, i) => (
            <g key={`time-${i}`}>
              <line 
                x1={label.x} 
                y1={totalHeight - chartPadding.bottom} 
                x2={label.x} 
                y2={totalHeight - chartPadding.bottom + 5} 
                stroke="#9CA3AF" 
                strokeWidth="1" 
              />
              <text 
                x={label.x} 
                y={totalHeight - chartPadding.bottom + 20} 
                fontSize="11" 
                fill="#9CA3AF" 
                textAnchor="middle"
              >
                {label.time}s
              </text>
            </g>
          ))}
          
          {/* Y-axis label */}
          <text 
            x="15" 
            y={totalHeight / 2} 
            fontSize="12" 
            fill="#9CA3AF" 
            textAnchor="middle"
            transform={`rotate(-90, 15, ${totalHeight / 2})`}
            fontWeight="bold"
          >
            Amplitude (µV)
          </text>
          
          {visibleChannels.map((channel, chIdx) => {
            const originalIdx = channels.indexOf(channel);
            const fullChannelData = data[originalIdx];
            if (!Array.isArray(fullChannelData) || fullChannelData.length === 0) return null;
            
            const channelData = fullChannelData.slice(startIdx, endIdx);
            const yCenter = chartPadding.top + chIdx * channelHeight + channelHeight / 2;
            
            // Calculate scaling for this channel
            const absValues = channelData.map(v => Math.abs(v));
            const maxVal = Math.max(...absValues);
            const minVal = Math.min(...channelData);
            const range = maxVal - minVal || 1;
            
            // Scale to fit in channel height
            const scale = (channelHeight * 0.4) / (range || 1);
            const mean = channelData.reduce((a, b) => a + b, 0) / channelData.length;
            
            // Build points
            const validPoints = [];
            const step = Math.max(1, Math.floor(channelData.length / 1000)); // Downsample for performance
            
            for (let i = 0; i < channelData.length; i += step) {
              const v = channelData[i];
              if (typeof v === 'number' && !isNaN(v)) {
                const x = chartPadding.left + (i / Math.max(channelData.length - 1, 1)) * plotWidth;
                const y = yCenter - (v - mean) * scale;
                validPoints.push(`${x.toFixed(1)},${y.toFixed(1)}`);
              }
            }
            
            const points = validPoints.join(' ');
            const channelColor = `hsl(${(chIdx * 40) % 360}, 70%, 60%)`;
            
            // Get stats for this channel
            const stats = channelStats[channel];
            
            return (
              <g key={chIdx}>
                {/* Channel background band */}
                <rect
                  x={chartPadding.left}
                  y={yCenter - channelHeight / 2 + 5}
                  width={plotWidth}
                  height={channelHeight - 10}
                  fill={chIdx % 2 === 0 ? '#1e293b' : '#0f172a'}
                  opacity="0.5"
                />
                
                {/* Channel label with stats */}
                <g>
                  <rect
                    x="2"
                    y={yCenter - 12}
                    width="60"
                    height="24"
                    fill="#1e293b"
                    rx="4"
                  />
                  <text 
                    x="32" 
                    y={yCenter + 4} 
                    fontSize="11" 
                    fill={channelColor} 
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {channel}
                  </text>
                </g>
                
                {/* Baseline */}
                <line 
                  x1={chartPadding.left} 
                  y1={yCenter} 
                  x2={chartPadding.left + plotWidth} 
                  y2={yCenter} 
                  stroke={channelColor} 
                  strokeWidth="0.5" 
                  opacity="0.2"
                  strokeDasharray="4 4"
                />
                
                {/* Waveform */}
                {validPoints.length > 1 && (
                  <polyline
                    points={points}
                    fill="none"
                    stroke={channelColor}
                    strokeWidth="1.5"
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                )}
                
                {/* Amplitude scale indicators */}
                <text 
                  x={chartPadding.left + plotWidth + 5} 
                  y={yCenter - channelHeight * 0.3} 
                  fontSize="8" 
                  fill="#6B7280"
                >
                  +{(range / 2).toFixed(0)}
                </text>
                <text 
                  x={chartPadding.left + plotWidth + 5} 
                  y={yCenter + channelHeight * 0.3} 
                  fontSize="8" 
                  fill="#6B7280"
                >
                  -{(range / 2).toFixed(0)}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    );
  }, [selectedChannels, zoomLevel, channelStats]);

  // Render PSD - Now with MNE image and per-channel overlay
  const renderPSD = (psdData) => {
    if (!psdData) return <p className="text-gray-500">No PSD data</p>;

    const { frequencies, channels, mean_psd, psd_by_channel, psd_image, channel_stats } = psdData;
    if (!frequencies || !mean_psd) return <p className="text-gray-500">Invalid PSD data</p>;

    const maxPower = Math.max(...mean_psd);
    const minFreq = frequencies[0];
    const maxFreq = frequencies[frequencies.length - 1];
    
    const chartWidth = 900;
    const chartHeight = 450;
    const padding = { top: 40, right: 30, bottom: 60, left: 80 };
    const plotWidth = chartWidth - padding.left - padding.right;
    const plotHeight = chartHeight - padding.top - padding.bottom;

    // Check if we have the MNE-generated PSD image
    const hasPSDImage = psd_image && psd_image.startsWith('data:image');
    
    // Check if we have per-channel PSD data
    const hasChannelPSD = psd_by_channel && Object.keys(psd_by_channel).length > 0;

    // Frequency bands for shading
    const bands = [
      { name: 'Delta', range: [0.5, 4], color: 'rgba(239, 68, 68, 0.15)' },
      { name: 'Theta', range: [4, 8], color: 'rgba(249, 115, 22, 0.15)' },
      { name: 'Alpha', range: [8, 12], color: 'rgba(234, 179, 8, 0.15)' },
      { name: 'Beta', range: [12, 30], color: 'rgba(59, 130, 246, 0.15)' },
    ];

    // X scale (frequency)
    const xScale = (freq) => padding.left + ((freq - minFreq) / (maxFreq - minFreq)) * plotWidth;
    // Y scale (power - log scale for better visualization)
    const yScale = (power) => {
      const logPower = Math.log10(power + 1);
      const logMax = Math.log10(maxPower + 1);
      return chartHeight - padding.bottom - (logPower / logMax) * plotHeight;
    };

    // Generate frequency axis ticks
    const freqTicks = [0, 4, 8, 12, 16, 20, 24, 28, 30].filter(f => f <= maxFreq && f >= minFreq);
    
    // Generate power axis ticks (log scale)
    const powerTicks = [0, maxPower * 0.1, maxPower * 0.25, maxPower * 0.5, maxPower * 0.75, maxPower];

    return (
      <div className="space-y-6">
        {/* MNE-Generated PSD Plot - Professional Output */}
        {hasPSDImage && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-xl p-6 border border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-white">Power Spectral Density - All Channels</h3>
              </div>
              <p className="text-gray-400 text-sm">
                {channels?.length || 0} channels overlaid
              </p>
            </div>
            <div className="relative overflow-hidden rounded-xl border border-slate-700">
              <img 
                src={psd_image} 
                alt="Power Spectral Density - All Channels"
                className="w-full h-auto object-contain"
              />
            </div>
            <p className="text-sm text-slate-400 mt-4 text-center">
              MNE-generated PSD showing all channels with frequency band indicators
            </p>
          </div>
        )}

        {/* Channel Statistics - if available */}
        {channel_stats && Object.keys(channel_stats).length > 0 && (
          <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-xl p-6 border border-slate-700">
            <h3 className="text-lg font-bold text-white mb-4">Per-Channel PSD Statistics</h3>
            <div className="overflow-x-auto">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {Object.entries(channel_stats).map(([channel, stats]) => (
                  <div key={channel} className="bg-gray-800/70 rounded-lg p-3 border border-gray-700">
                    <p className="text-cyan-400 font-mono text-sm font-bold mb-2">{channel}</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Peak:</span>
                        <span className="text-white font-semibold">{stats.peak_freq?.toFixed(1)} Hz</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Max:</span>
                        <span className="text-white">{stats.max?.toExponential(1)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Mean:</span>
                        <span className="text-white">{stats.mean?.toExponential(1)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Total:</span>
                        <span className="text-white">{stats.total_power?.toExponential(1)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SVG Chart - Mean PSD (fallback/additional view) */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-xl p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">
                {hasPSDImage ? 'Mean Power Spectral Density' : 'Power Spectral Density'}
              </h3>
              <p className="text-gray-400 text-sm">
                Frequency Range: {minFreq.toFixed(1)} - {maxFreq.toFixed(1)} Hz | {channels?.length || 0} channels averaged
              </p>
            </div>
            <div className="flex gap-2">
              {bands.map(band => (
                <span key={band.name} className="px-2 py-1 rounded text-xs font-semibold" style={{ backgroundColor: band.color.replace('0.15', '0.4') }}>
                  {band.name}
                </span>
              ))}
            </div>
          </div>
          
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full border border-gray-700 rounded-lg bg-gray-950">
          {/* Background */}
          <rect x="0" y="0" width={chartWidth} height={chartHeight} fill="#0f172a" />
          
          {/* Frequency band shading */}
          {bands.map(band => {
            const x1 = xScale(Math.max(band.range[0], minFreq));
            const x2 = xScale(Math.min(band.range[1], maxFreq));
            if (x2 <= x1) return null;
            return (
              <g key={band.name}>
                <rect
                  x={x1}
                  y={padding.top}
                  width={x2 - x1}
                  height={plotHeight}
                  fill={band.color}
                />
                <text
                  x={(x1 + x2) / 2}
                  y={padding.top + 15}
                  fontSize="10"
                  fill="#9CA3AF"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  {band.name}
                </text>
              </g>
            );
          })}
          
          {/* Grid lines - horizontal */}
          {powerTicks.map((power, i) => (
            <g key={`hgrid-${i}`}>
              <line
                x1={padding.left}
                y1={yScale(power)}
                x2={chartWidth - padding.right}
                y2={yScale(power)}
                stroke="#374151"
                strokeWidth="0.5"
                strokeDasharray="4 4"
              />
              <text
                x={padding.left - 10}
                y={yScale(power) + 4}
                fontSize="10"
                fill="#9CA3AF"
                textAnchor="end"
              >
                {power.toFixed(1)}
              </text>
            </g>
          ))}
          
          {/* Grid lines - vertical (frequency) */}
          {freqTicks.map((freq, i) => (
            <g key={`vgrid-${i}`}>
              <line
                x1={xScale(freq)}
                y1={padding.top}
                x2={xScale(freq)}
                y2={chartHeight - padding.bottom}
                stroke="#374151"
                strokeWidth="0.5"
                strokeDasharray="4 4"
              />
              <text
                x={xScale(freq)}
                y={chartHeight - padding.bottom + 20}
                fontSize="11"
                fill="#9CA3AF"
                textAnchor="middle"
              >
                {freq} Hz
              </text>
            </g>
          ))}
          
          {/* Axes */}
          <line
            x1={padding.left}
            y1={chartHeight - padding.bottom}
            x2={chartWidth - padding.right}
            y2={chartHeight - padding.bottom}
            stroke="#9CA3AF"
            strokeWidth="1.5"
          />
          <line
            x1={padding.left}
            y1={padding.top}
            x2={padding.left}
            y2={chartHeight - padding.bottom}
            stroke="#9CA3AF"
            strokeWidth="1.5"
          />
          
          {/* Axis labels */}
          <text
            x={chartWidth / 2}
            y={chartHeight - 10}
            fontSize="13"
            fill="#D1D5DB"
            textAnchor="middle"
            fontWeight="bold"
          >
            Frequency (Hz)
          </text>
          <text
            x={20}
            y={chartHeight / 2}
            fontSize="13"
            fill="#D1D5DB"
            textAnchor="middle"
            fontWeight="bold"
            transform={`rotate(-90, 20, ${chartHeight / 2})`}
          >
            Power (pV²/Hz)
          </text>
          
          {/* PSD curve with gradient fill */}
          <defs>
            <linearGradient id="psdGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#3B82F6" stopOpacity="0.05" />
            </linearGradient>
          </defs>
          
          {/* Filled area under curve */}
          <path
            d={`M ${xScale(frequencies[0])} ${chartHeight - padding.bottom} ` +
               mean_psd.map((p, i) => `L ${xScale(frequencies[i])} ${yScale(p)}`).join(' ') +
               ` L ${xScale(frequencies[frequencies.length - 1])} ${chartHeight - padding.bottom} Z`}
            fill="url(#psdGradient)"
          />
          
          {/* Main PSD line */}
          <polyline
            points={mean_psd.map((p, i) => `${xScale(frequencies[i])},${yScale(p)}`).join(' ')}
            fill="none"
            stroke="#3B82F6"
            strokeWidth="2.5"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          
          {/* Peak indicator */}
          {(() => {
            const peakIdx = mean_psd.indexOf(maxPower);
            const peakFreq = frequencies[peakIdx];
            return (
              <g>
                <circle
                  cx={xScale(peakFreq)}
                  cy={yScale(maxPower)}
                  r="6"
                  fill="#EF4444"
                  stroke="#fff"
                  strokeWidth="2"
                />
                <text
                  x={xScale(peakFreq)}
                  y={yScale(maxPower) - 15}
                  fontSize="11"
                  fill="#EF4444"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  Peak: {peakFreq.toFixed(1)} Hz
                </text>
              </g>
            );
          })()}
        </svg>
        
        {/* Stats row */}
        <div className="mt-4 grid grid-cols-4 gap-4">
          <div className="bg-gray-800/50 rounded-lg p-3 text-center">
            <p className="text-gray-400 text-xs">Peak Frequency</p>
            <p className="text-white font-bold text-lg">{frequencies[mean_psd.indexOf(maxPower)].toFixed(1)} Hz</p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 text-center">
            <p className="text-gray-400 text-xs">Max Power</p>
            <p className="text-white font-bold text-lg">{maxPower.toFixed(1)} pV²</p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 text-center">
            <p className="text-gray-400 text-xs">Mean Power</p>
            <p className="text-white font-bold text-lg">{(mean_psd.reduce((a, b) => a + b, 0) / mean_psd.length).toFixed(1)} pV²</p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 text-center">
            <p className="text-gray-400 text-xs">Frequency Resolution</p>
            <p className="text-white font-bold text-lg">{((maxFreq - minFreq) / frequencies.length).toFixed(2)} Hz</p>
          </div>
        </div>
        </div>
      </div>
    );
  };

  // Render Topomaps for frequency bands - Now with real MNE images
  const renderTopomaps = (topomapsData) => {
    console.log('renderTopomaps called with:', topomapsData);
    
    if (!topomapsData || topomapsData.error) {
      return <p className="text-gray-500">No topomap data available</p>;
    }

    const { topomaps, topomap_images, combined_topomap_image } = topomapsData;
    console.log('Extracted:', { topomaps: !!topomaps, topomap_images: topomap_images ? Object.keys(topomap_images) : null, combined: !!combined_topomap_image });
    
    if (!topomaps) return <p className="text-gray-500">No topomap data</p>;

    // Check if we have real MNE topomap images
    const hasRealTopomaps = topomap_images && Object.keys(topomap_images).length > 0;
    const hasCombinedImage = combined_topomap_image && combined_topomap_image.startsWith('data:image');
    console.log('hasRealTopomaps:', hasRealTopomaps, 'hasCombinedImage:', hasCombinedImage);

    // Band colors and styling - matching notebook
    const bandColors = {
      delta: { 
        start: '#DC2626', end: '#7F1D1D', 
        light: '#FEE2E2', dark: '#991B1B',
        label: 'Delta Band (0.5-4 Hz)',
        icon: '●'
      },
      theta: { 
        start: '#F97316', end: '#92400E', 
        light: '#FFEDD5', dark: '#B45309',
        label: 'Theta Band (4-8 Hz)',
        icon: '●'
      },
      alpha: { 
        start: '#EAB308', end: '#713F12', 
        light: '#FFFBEB', dark: '#A16207',
        label: 'Alpha Band (8-12 Hz)',
        icon: '●'
      },
      beta: { 
        start: '#2563EB', end: '#1E3A8A', 
        light: '#EFF6FF', dark: '#1E40AF',
        label: 'Beta Band (12-30 Hz)',
        icon: '●'
      },
    };

    return (
      <div className="space-y-8">
        {/* Combined topomap image - if available */}
        {hasCombinedImage && (
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 border border-slate-700 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Brain className="w-6 h-6 text-cyan-400" />
              MNE Topographic Maps - All Frequency Bands
            </h3>
            <div className="relative overflow-hidden rounded-xl">
              <img 
                src={combined_topomap_image} 
                alt="Combined Frequency Band Topomaps"
                className="w-full h-auto object-contain"
              />
            </div>
            <p className="text-sm text-slate-400 mt-4 text-center">
              Professional MNE-generated topographic maps showing power distribution across the scalp
            </p>
          </div>
        )}

        {/* Individual band topomaps */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {Object.entries(topomaps).map(([bandName, bandData]) => {
            const bandColor = bandColors[bandName];
            if (!bandColor) return null;

            const hasImage = hasRealTopomaps && topomap_images[bandName];
            const positions = bandData.channel_positions || [];
            const minPower = bandData.min_power || 0;
            const maxPower = bandData.max_power || 1;
            const powerRange = maxPower - minPower || 1;

            // Create color scale function for fallback SVG
            const getColor = (power) => {
              if (maxPower === minPower) return bandColor.start;
              const normalized = (power - minPower) / powerRange;
              
              const startRGB = hexToRgb(bandColor.start);
              const endRGB = hexToRgb(bandColor.end);
              
              const r = Math.round(startRGB.r + (endRGB.r - startRGB.r) * normalized);
              const g = Math.round(startRGB.g + (endRGB.g - startRGB.g) * normalized);
              const b = Math.round(startRGB.b + (endRGB.b - startRGB.b) * normalized);
              
              return `rgb(${r}, ${g}, ${b})`;
            };

            return (
              <div key={bandName} className="bg-gradient-to-br from-slate-100 to-slate-50 dark:from-slate-900 dark:to-slate-800 rounded-2xl p-8 border border-slate-200 dark:border-slate-700 shadow-2xl">
                {/* Header */}
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                    <span style={{ color: bandColor.start }} className="mr-2">{bandColor.icon}</span>
                    {bandData.label || bandColor.label}
                  </h3>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <p className="text-slate-600 dark:text-slate-400 text-sm">Mean Power</p>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">
                        {(bandData.mean_power || 0).toExponential(2)} V²/Hz
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-600 dark:text-slate-400 text-sm">Range</p>
                      <p className="text-sm text-slate-900 dark:text-white">
                        {minPower.toExponential(2)} - {maxPower.toExponential(2)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Topomap - Real MNE image or SVG fallback */}
                <div className="bg-gradient-to-br from-white to-slate-50 dark:from-slate-950 dark:to-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-700 mb-6">
                  {hasImage ? (
                    // Real MNE topomap image
                    <div className="relative">
                      <img 
                        src={topomap_images[bandName]} 
                        alt={`${bandName} band topomap`}
                        className="w-full h-auto object-contain rounded-lg"
                      />
                    </div>
                  ) : positions.length > 0 ? (
                    // SVG Fallback
                    <svg viewBox="-140 -140 280 280" className="w-full aspect-square">
                      {/* Background circle for head */}
                      <circle
                        cx="0"
                        cy="0"
                        r="110"
                        fill="currentColor"
                        fillOpacity="0.05"
                        stroke="currentColor"
                        strokeOpacity="0.3"
                        strokeWidth="2"
                      />

                      {/* Head outline - thicker */}
                      <circle
                        cx="0"
                        cy="0"
                        r="110"
                        fill="none"
                        stroke="currentColor"
                        strokeOpacity="0.4"
                        strokeWidth="2.5"
                      />

                      {/* Nose - more prominent */}
                      <polygon
                        points="0,-115 -10,-100 10,-100"
                        fill="currentColor"
                        fillOpacity="0.4"
                      />

                      {/* Ears - more defined */}
                      <ellipse cx="-120" cy="0" rx="10" ry="25" fill="none" stroke="currentColor" strokeOpacity="0.4" strokeWidth="2" />
                      <ellipse cx="120" cy="0" rx="10" ry="25" fill="none" stroke="currentColor" strokeOpacity="0.4" strokeWidth="2" />

                      {/* Channel circles with labels */}
                      {positions.map((pos, idx) => {
                        const radius = 100;
                        const x = pos.x * radius;
                        const y = pos.y * radius;
                        const color = getColor(pos.power);
                        
                        return (
                          <g key={idx}>
                            {/* Channel circle */}
                            <circle
                              cx={x}
                              cy={y}
                              r="8"
                              fill={color}
                              stroke="#fff"
                              strokeWidth="1.5"
                              opacity="0.95"
                            />
                            {/* Channel label outside circle */}
                            <text
                              x={x * 1.3}
                              y={y * 1.3}
                              fontSize="10"
                              fill="#e2e8f0"
                              textAnchor="middle"
                              dominantBaseline="middle"
                              fontWeight="600"
                              fontFamily="monospace"
                            >
                              {pos.channel}
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                  ) : (
                    <p className="text-gray-500 text-center py-8">No channel positions available</p>
                  )}
                </div>

                {/* Power Scale Legend - only for fallback */}
                {!hasImage && positions.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 text-xs font-semibold mb-2">
                      <span>Min</span>
                      <span>Power</span>
                      <span>Max</span>
                    </div>
                    <div className="h-8 rounded-lg flex overflow-hidden border border-slate-300 dark:border-slate-600 shadow-lg">
                      {Array.from({ length: 30 }).map((_, i) => {
                        const normalized = i / 29;
                        const power = minPower + normalized * powerRange;
                        return (
                          <div
                            key={i}
                            style={{
                              flex: 1,
                              backgroundColor: getColor(power),
                            }}
                          />
                        );
                      })}
                    </div>
                    <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 text-xs font-semibold mt-2">
                      <span>{minPower.toExponential(1)}</span>
                      <span>{maxPower.toExponential(1)}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Helper function to convert hex to RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16),
        }
      : { r: 0, g: 0, b: 0 };
  };

  // Render ICA Components as topographies
  const renderICAComponents = (icaSignalData) => {
    if (!icaSignalData || !icaSignalData.ica_components) {
      return <p className="text-gray-500">No ICA component data available</p>;
    }

    const components = icaSignalData.ica_components;
    const componentImages = icaSignalData.ica_component_images || {};
    
    return (
      <div className="bg-slate-900 rounded-xl p-6">
        <div className="text-slate-300 text-sm mb-6">
          <p className="font-medium">ICA Components: {icaSignalData.n_components} total components extracted</p>
          <p className="text-xs text-slate-400 mt-1">
            Excluded: {icaSignalData.excluded_components?.length > 0 
              ? icaSignalData.excluded_components.join(', ') 
              : 'None'}
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {components.slice(0, 10).map((comp) => {
            const hasImage = componentImages[comp.id];
            
            return (
              <div key={comp.id} className="bg-slate-800/50 rounded-xl overflow-hidden border border-slate-700/50 hover:border-teal-500/50 transition-colors">
                {hasImage ? (
                  <img 
                    src={componentImages[comp.id]} 
                    alt={`${comp.id} topomap`}
                    className="w-full aspect-square object-contain"
                  />
                ) : (
                  <div className="p-4 text-center">
                    <h4 className="text-white font-semibold mb-3">{comp.id}</h4>
                    {/* Fallback SVG representation */}
                    <svg viewBox="0 0 200 200" className="w-full mx-auto mb-3">
                      <circle cx="100" cy="100" r="90" fill="none" stroke="#9CA3AF" strokeWidth="2" />
                      {Array.from({ length: 8 }).map((_, i) => {
                        const angle = (i / 8) * Math.PI * 2;
                        const x = 100 + Math.cos(angle) * 70;
                        const y = 100 + Math.sin(angle) * 70;
                        const value = Math.abs(comp.values[i] || 0);
                        const maxVal = Math.max(...comp.values.map(v => Math.abs(v)));
                        const intensity = maxVal > 0 ? value / maxVal : 0;
                        const color = intensity > 0.5 ? '#EF4444' : intensity > 0.3 ? '#F97316' : '#3B82F6';
                        return (
                          <circle key={i} cx={x} cy={y} r="8" fill={color} opacity={0.5 + intensity * 0.5} />
                        );
                      })}
                      <polygon points="100,30 95,45 105,45" fill="#9CA3AF" opacity="0.5" />
                    </svg>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="EEG Visualization" userName={userName} />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto min-h-0 bg-slate-50 dark:bg-slate-950">
          <div className="max-w-7xl mx-auto p-6 space-y-6">
            {/* Header Section - Clinical */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-slate-900 dark:text-white flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center shadow-lg shadow-teal-500/20">
                    <Activity className="w-5 h-5 text-white" />
                  </div>
                  EEG Analysis & Visualization
                </h1>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 ml-13">
                  Advanced EEG signal processing and frequency analysis
                </p>
              </div>
              {preprocessingData && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Analysis Complete
                </div>
              )}
            </div>

            {/* Error Alert - Clinical */}
            {error && (
              <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl p-4 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/50 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <p className="font-medium text-red-800 dark:text-red-200 text-sm">Error Occurred</p>
                  <p className="text-red-600 dark:text-red-400 text-xs mt-0.5">{error}</p>
                </div>
              </div>
            )}

            {/* File Selection Card - Clinical */}
            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-3 px-6 py-4 border-b border-slate-200 dark:border-slate-700">
                <div className="w-8 h-8 rounded-lg bg-teal-100 dark:bg-teal-900/50 flex items-center justify-center">
                  <FileText className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-white">Patient & File Selection</h2>
                  <p className="text-xs text-slate-500">Select a patient and EEG recording to analyze</p>
                </div>
              </div>

              <div className="p-6 space-y-4">
                {/* Patient Selection */}
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-2 uppercase tracking-wide">
                    Patient
                  </label>
                  <select
                    value={selectedPatientId}
                    onChange={(e) => {
                      setSelectedPatientId(e.target.value);
                      setError(null);
                    }}
                    disabled={loading}
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 focus:border-transparent transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <option value="">Choose a patient...</option>
                    {patients.map((patient) => (
                      <option key={patient.id} value={patient.id}>
                        {patient.full_name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* File Selection */}
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-2 uppercase tracking-wide">
                    EEG Recording
                  </label>
                  <select
                    value={selectedFileId}
                    onChange={(e) => {
                      const fileId = e.target.value;
                      setSelectedFileId(fileId);
                      const file = files.find(f => f.id === fileId);
                      setSelectedFile(file || null);
                      if (file?.id !== selectedFile?.id) {
                        setPreprocessingData(null);
                        clearPreprocessingData();
                      }
                    }}
                    disabled={!selectedPatientId || loading || files.length === 0}
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 focus:border-transparent transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <option value="">Loading files...</option>
                    ) : files.length === 0 ? (
                      <option value="">{selectedPatientId ? 'No files available for this patient' : 'Select a patient first'}</option>
                    ) : (
                      <>
                        <option value="">Choose an EEG file...</option>
                        {files.map((file) => (
                          <option key={file.id} value={file.id}>
                            {file.original_filename || file.filename}
                          </option>
                        ))}
                      </>
                    )}
                  </select>
                </div>

                {/* Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={handleRefresh}
                    disabled={loading || !selectedPatientId}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 disabled:opacity-50 text-slate-700 dark:text-slate-300 rounded-lg text-sm font-medium transition flex items-center justify-center gap-2 disabled:cursor-not-allowed border border-slate-200 dark:border-slate-700"
                  >
                    {loading ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-4 h-4" />
                        Refresh Files
                      </>
                    )}
                  </button>
                  <button
                    onClick={handlePreprocess}
                    disabled={!selectedFile || preprocessing || loading}
                    className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-400 text-white rounded-lg text-sm font-medium transition flex items-center justify-center gap-2 shadow-sm disabled:cursor-not-allowed"
                  >
                    {preprocessing ? (
                      <div className="flex items-center gap-3">
                        <Loader className="w-4 h-4 animate-spin" />
                        <div className="flex flex-col items-start">
                          <span className="text-xs">{processingSteps[processingStep]}</span>
                          <div className="flex items-center gap-1 mt-1">
                            {processingSteps.map((_, idx) => (
                              <div
                                key={idx}
                                className={`w-1.5 h-1.5 rounded-full transition-all ${
                                  idx <= processingStep ? 'bg-white' : 'bg-white/30'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <>
                        <Zap className="w-4 h-4" />
                        Process File
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* File & Patient Details - Clinical */}
              {selectedFile && (
                <div className="border-t border-slate-200 dark:border-slate-700">
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-700">
                    {/* File Info */}
                    <div className="p-4">
                      <h4 className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                        <FileText className="w-3.5 h-3.5" />
                        Recording Details
                      </h4>
                      <dl className="grid grid-cols-2 gap-3 text-sm">
                        <div><dt className="text-xs text-slate-500 dark:text-slate-400">Filename</dt><dd className="font-medium text-slate-900 dark:text-white truncate text-xs mt-0.5">{selectedFile.original_filename}</dd></div>
                        <div><dt className="text-xs text-slate-500 dark:text-slate-400">Channels</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.number_of_channels || 'N/A'}</dd></div>
                        <div><dt className="text-xs text-slate-500 dark:text-slate-400">Sample Rate</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.sampling_rate ? `${selectedFile.sampling_rate} Hz` : 'N/A'}</dd></div>
                        <div><dt className="text-xs text-slate-500 dark:text-slate-400">Duration</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.recording_duration ? `${(selectedFile.recording_duration / 60).toFixed(2)} min` : 'N/A'}</dd></div>
                      </dl>
                    </div>

                    {/* Patient Info */}
                    {selectedFile.patient && (
                      <div className="p-4">
                        <h4 className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                          <User className="w-3.5 h-3.5" />
                          Patient Information
                        </h4>
                        <dl className="space-y-2">
                          <div><dt className="text-xs text-slate-500 dark:text-slate-400">Name</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.patient.full_name}</dd></div>
                          <div className="grid grid-cols-2 gap-3">
                            {selectedFile.patient.age && <div><dt className="text-xs text-slate-500 dark:text-slate-400">Age</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.patient.age} years</dd></div>}
                            {selectedFile.patient.gender && <div><dt className="text-xs text-slate-500 dark:text-slate-400">Gender</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5 capitalize">{selectedFile.patient.gender}</dd></div>}
                          </div>
                          {selectedFile.patient.contact_number && <div><dt className="text-xs text-slate-500 dark:text-slate-400">Contact</dt><dd className="font-medium text-slate-900 dark:text-white text-xs mt-0.5">{selectedFile.patient.contact_number}</dd></div>}
                        </dl>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Processing State - Clinical */}
            {preprocessing && (
              <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-8">
                <div className="flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center mb-4 animate-pulse">
                    <Activity className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Processing EEG Data</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">{processingSteps[processingStep]}</p>
                  
                  {/* Progress Steps */}
                  <div className="flex items-center gap-2 mb-4">
                    {processingSteps.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                          idx < processingStep ? 'bg-teal-500 text-white' :
                          idx === processingStep ? 'bg-teal-100 dark:bg-teal-900/50 text-teal-600 dark:text-teal-400 ring-2 ring-teal-500' :
                          'bg-slate-100 dark:bg-slate-800 text-slate-400'
                        }`}>
                          {idx < processingStep ? <CheckCircle className="w-4 h-4" /> : idx + 1}
                        </div>
                        {idx < processingSteps.length - 1 && (
                          <div className={`w-8 h-0.5 ${idx < processingStep ? 'bg-teal-500' : 'bg-slate-200 dark:bg-slate-700'}`}></div>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full max-w-md h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-teal-500 to-teal-600 rounded-full transition-all duration-500"
                      style={{ width: `${((processingStep + 1) / processingSteps.length) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            )}

            {/* Analysis Results Section - Full Width Vertical Layout */}
            {preprocessingData && (
              <div className="mt-6 space-y-6">
                
                {/* SECTION 1: Header with Key Metrics - Full Width */}
                <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                  {/* Clinical Header Bar */}
                  <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center">
                        <Brain className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-slate-900 dark:text-white">EEG Analysis Report</h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Signal Processing & Spectral Analysis</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-medium rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                        Processed
                      </span>
                    </div>
                  </div>

                  {/* Metrics Row */}
                  {preprocessingData.channel_info && (
                    <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-slate-200 dark:divide-slate-700">
                      <div className="px-6 py-4">
                        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Channels</p>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{preprocessingData.channel_info.n_channels}</p>
                      </div>
                      <div className="px-6 py-4">
                        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Sample Rate</p>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{preprocessingData.channel_info.sampling_rate}<span className="text-sm font-normal text-slate-500 ml-1">Hz</span></p>
                      </div>
                      <div className="px-6 py-4">
                        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Duration</p>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{preprocessingData.channel_info.duration.toFixed(1)}<span className="text-sm font-normal text-slate-500 ml-1">sec</span></p>
                      </div>
                      <div className="px-6 py-4">
                        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Samples</p>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{(preprocessingData.channel_info.n_samples / 1000).toFixed(0)}<span className="text-sm font-normal text-slate-500 ml-1">K</span></p>
                      </div>
                    </div>
                  )}
                </div>

                {/* SECTION 2: Waveform Visualizations - Full Width */}
                <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
                  {/* Tab Bar - Clean Clinical Style */}
                  <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                    <div className="flex gap-2">
                      {[
                        { id: 'raw', label: 'Raw Signal' },
                        { id: 'filtered', label: 'Filtered' },
                        { id: 'ica', label: 'ICA' },
                        { id: 'ica_components', label: 'Components' },
                        { id: 'psd', label: 'PSD' },
                        { id: 'topomaps', label: 'Topography' }
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setActiveTab(tab.id)}
                          className={`px-5 py-2 text-sm font-semibold rounded-lg transition-all ${
                            activeTab === tab.id
                              ? 'bg-teal-600 text-white shadow-md'
                              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                    
                    {/* Comparison Mode Toggle */}
                    {(activeTab === 'raw' || activeTab === 'filtered' || activeTab === 'ica') && (
                      <button
                        onClick={() => setComparisonMode(!comparisonMode)}
                        className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
                          comparisonMode
                            ? 'bg-indigo-600 text-white'
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                        }`}
                        title="Compare Raw vs Filtered"
                      >
                        <GitCompare className="w-3.5 h-3.5" />
                        Compare
                      </button>
                    )}
                  </div>
                  
                  {/* Enhanced Control Toolbar - Only for waveform tabs */}
                  {(activeTab === 'raw' || activeTab === 'filtered' || activeTab === 'ica') && (
                    <div className="px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/30 flex flex-wrap items-center gap-2">
                      {/* Zoom Controls */}
                      <div className="flex items-center gap-0.5 bg-white dark:bg-slate-800 rounded-md p-0.5 border border-slate-200 dark:border-slate-700">
                        <button
                          onClick={handleZoomOut}
                          disabled={zoomLevel <= 0.5}
                          className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded disabled:opacity-50 disabled:cursor-not-allowed transition"
                          title="Zoom Out"
                        >
                          <ZoomOut className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                        </button>
                        <span className="px-2 text-sm font-semibold text-slate-700 dark:text-slate-300 min-w-[50px] text-center">
                          {zoomLevel.toFixed(1)}x
                        </span>
                        <button
                          onClick={handleZoomIn}
                          disabled={zoomLevel >= 10}
                          className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded disabled:opacity-50 disabled:cursor-not-allowed transition"
                          title="Zoom In"
                            >
                              <ZoomIn className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                            </button>
                            <button
                              onClick={handleResetZoom}
                              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded transition border-l border-slate-200 dark:border-slate-700"
                              title="Reset Zoom"
                            >
                              <RefreshCw className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                            </button>
                          </div>
                          
                          {/* Time Navigation */}
                          <div className="flex items-center gap-1 bg-white dark:bg-slate-800 rounded-lg p-1 border border-slate-200 dark:border-slate-700">
                            <button
                              onClick={() => navigateSlider('left')}
                              disabled={sliderValue <= 0}
                              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded disabled:opacity-50 transition"
                              title="Previous"
                            >
                              <ChevronLeft className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                            </button>
                            <button
                              onClick={() => setIsPlaying(!isPlaying)}
                              className={`p-2 rounded transition ${isPlaying ? 'bg-red-100 dark:bg-red-900/30 text-red-600' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                              title={isPlaying ? 'Pause' : 'Play'}
                            >
                              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-slate-600 dark:text-slate-400" />}
                            </button>
                            <button
                              onClick={() => navigateSlider('right')}
                              disabled={sliderValue >= 100}
                              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded disabled:opacity-50 transition"
                              title="Next"
                            >
                              <ChevronRight className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                            </button>
                          </div>
                          
                          {/* Playback Speed */}
                          {isPlaying && (
                            <select
                              value={playbackSpeed}
                              onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                              className="px-2 py-1 text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300"
                            >
                              <option value="0.5">0.5x</option>
                              <option value="1">1x</option>
                              <option value="2">2x</option>
                              <option value="4">4x</option>
                            </select>
                          )}
                          
                          {/* Time Slider */}
                          <div className="flex-1 flex items-center gap-3">
                            <input
                              type="range"
                              min="0"
                              max="100"
                              value={sliderValue}
                              onChange={(e) => setSliderValue(parseFloat(e.target.value))}
                              className="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full appearance-none cursor-pointer accent-blue-500"
                            />
                            <span className="text-xs text-slate-600 dark:text-slate-400 font-mono w-14 text-right">
                              {sliderValue.toFixed(0)}%
                            </span>
                          </div>
                          
                          {/* Channel Picker */}
                          <button
                            onClick={() => setShowChannelPicker(!showChannelPicker)}
                            className={`px-3 py-2 text-sm font-semibold rounded-lg transition flex items-center gap-2 ${
                              showChannelPicker
                                ? 'bg-green-600 text-white'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                            }`}
                            title="Select Channels"
                          >
                            <Layers className="w-4 h-4" />
                            <span className="hidden sm:inline">{selectedChannels.length} ch</span>
                          </button>
                          
                          {/* Fullscreen */}
                          <button
                            onClick={() => setShowModal(true)}
                            className="p-2 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                            title="Fullscreen"
                          >
                            <Maximize2 className="w-4 h-4" />
                          </button>
                          
                          {/* Export */}
                          <button
                            onClick={exportChartAsPNG}
                            className="p-2 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                            title="Export as PNG"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                      
                      {/* Channel Picker Dropdown */}
                      {showChannelPicker && (activeTab === 'raw' || activeTab === 'filtered' || activeTab === 'ica') && (
                        <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300">Select Channels</h4>
                            <div className="flex gap-2">
                              <button
                                onClick={selectAllChannels}
                                className="text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded hover:bg-blue-200 dark:hover:bg-blue-900/50 transition"
                              >
                                Select All
                              </button>
                              <button
                                onClick={deselectAllChannels}
                                className="text-xs px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400 rounded hover:bg-slate-200 dark:hover:bg-slate-600 transition"
                              >
                                Clear
                              </button>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {preprocessingData?.raw_signal?.channels?.map((channel) => (
                              <button
                                key={channel}
                                onClick={() => toggleChannel(channel)}
                                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                                  selectedChannels.includes(channel)
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                                }`}
                              >
                                {channel}
                              </button>
                            ))}
                          </div>
                          {/* Channel Stats Preview */}
                          {selectedChannels.length > 0 && Object.keys(channelStats).length > 0 && (
                            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
                              <h5 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">Selected Channel Statistics</h5>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                {selectedChannels.slice(0, 4).map((ch) => {
                                  const stats = channelStats[ch];
                                  if (!stats) return null;
                                  return (
                                    <div key={ch} className="bg-white dark:bg-slate-800 rounded p-2 text-xs">
                                      <span className="font-bold text-slate-700 dark:text-slate-300">{ch}</span>
                                      <div className="text-slate-500 dark:text-slate-400 mt-1">
                                        <p>μ: {stats.mean.toFixed(1)}</p>
                                        <p>σ: {stats.std.toFixed(1)}</p>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      
                      {/* Chart Content */}
                      <div ref={chartRef} className="p-6 bg-gradient-to-b from-slate-50 to-white dark:from-slate-900/30 dark:to-slate-900 min-h-80">
                        {comparisonMode && (activeTab === 'raw' || activeTab === 'filtered' || activeTab === 'ica') ? (
                          /* Comparison View - Side by Side */
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                                〰️ Raw Signal
                              </h4>
                              <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                                {renderChart(preprocessingData, 'raw', true, sliderValue)}
                              </div>
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                                ✅ Filtered Signal
                              </h4>
                              <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                                {renderChart(preprocessingData, 'filtered', true, sliderValue)}
                              </div>
                            </div>
                          </div>
                        ) : (
                          /* Standard Single View */
                          renderChart(preprocessingData, activeTab, true, sliderValue) || (
                            <div className="flex items-center justify-center h-64">
                              <p className="text-slate-400 dark:text-slate-500">Loading...</p>
                            </div>
                          )
                        )}
                      </div>
                    </div>

                {/* SECTION 3: Frequency Band Power Summary - Full Width */}
                {preprocessingData.frequency_bands?.bands && (
                  <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700">
                      <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-teal-600" />
                        Frequency Band Power Analysis
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Relative power distribution across EEG frequency bands</p>
                    </div>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                      {Object.entries(preprocessingData.frequency_bands.bands).map(([bandName, bandInfo]) => {
                        const bandConfig = {
                          delta: { label: 'δ Delta', color: 'bg-rose-500', lightBg: 'bg-rose-50 dark:bg-rose-900/20', textColor: 'text-rose-600 dark:text-rose-400' },
                          theta: { label: 'θ Theta', color: 'bg-amber-500', lightBg: 'bg-amber-50 dark:bg-amber-900/20', textColor: 'text-amber-600 dark:text-amber-400' },
                          alpha: { label: 'α Alpha', color: 'bg-emerald-500', lightBg: 'bg-emerald-50 dark:bg-emerald-900/20', textColor: 'text-emerald-600 dark:text-emerald-400' },
                          beta: { label: 'β Beta', color: 'bg-blue-500', lightBg: 'bg-blue-50 dark:bg-blue-900/20', textColor: 'text-blue-600 dark:text-blue-400' }
                        };
                        const config = bandConfig[bandName];
                        const totalPower = Object.values(preprocessingData.frequency_bands.bands).reduce((sum, b) => sum + b.mean_power, 0);
                        const percentage = totalPower > 0 ? (bandInfo.mean_power / totalPower) * 100 : 0;
                        
                        return (
                          <div key={bandName} className={`${config.lightBg} rounded-xl p-5 border border-slate-200 dark:border-slate-700`}>
                            <div className="flex items-center justify-between mb-3">
                              <span className={`text-lg font-bold ${config.textColor}`}>{config.label}</span>
                              <span className="text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 px-2 py-1 rounded">{bandInfo.freq_range[0]}-{bandInfo.freq_range[1]} Hz</span>
                            </div>
                            <div className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{percentage.toFixed(1)}%</div>
                            <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mb-3">
                              <div className={`h-full ${config.color} rounded-full transition-all`} style={{ width: `${Math.min(percentage, 100)}%` }}></div>
                            </div>
                            <p className="text-xs text-slate-600 dark:text-slate-400">Power: {bandInfo.mean_power.toExponential(2)} V²/Hz</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* SECTION 4: Channel Power Distribution - Full Width */}
                {preprocessingData.frequency_bands?.bands && (
                  <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700">
                      <h3 className="text-base font-semibold text-slate-900 dark:text-white">Channel Power Distribution</h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Power levels across all electrodes by frequency band</p>
                    </div>

                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {Object.entries(preprocessingData.frequency_bands.bands).map(([bandName, bandInfo]) => {
                        const bandConfig = {
                          delta: { color: 'bg-rose-500', label: 'δ Delta', lightBg: 'bg-rose-50 dark:bg-rose-900/20' },
                          theta: { color: 'bg-amber-500', label: 'θ Theta', lightBg: 'bg-amber-50 dark:bg-amber-900/20' },
                          alpha: { color: 'bg-emerald-500', label: 'α Alpha', lightBg: 'bg-emerald-50 dark:bg-emerald-900/20' },
                          beta: { color: 'bg-blue-500', label: 'β Beta', lightBg: 'bg-blue-50 dark:bg-blue-900/20' }
                        };
                        const config = bandConfig[bandName];

                        return (
                          <div key={`detail-${bandName}`} className={`${config.lightBg} rounded-xl border border-slate-200 dark:border-slate-700`}>
                            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-700/50">
                              <h4 className="text-sm font-semibold text-slate-900 dark:text-white">{config.label} <span className="font-normal text-slate-500">({bandInfo.freq_range[0]}-{bandInfo.freq_range[1]} Hz)</span></h4>
                            </div>
                            <div className="p-4 space-y-2 max-h-64 overflow-y-auto">
                              {Object.entries(bandInfo.power_by_channel)
                                .sort(([, a], [, b]) => b - a)
                                .slice(0, 8)
                                .map(([channel, power]) => {
                                  const maxPower = Math.max(...Object.values(bandInfo.power_by_channel));
                                  const percent = (power / maxPower) * 100;
                                  
                                  return (
                                    <div key={channel} className="flex items-center gap-3">
                                      <span className="w-10 text-xs font-medium text-slate-600 dark:text-slate-400">{channel}</span>
                                      <div className="flex-1">
                                        <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                          <div
                                            className={`h-full ${config.color} transition-all rounded-full`}
                                            style={{ width: `${percent}%` }}
                                          />
                                        </div>
                                      </div>
                                      <span className="w-16 text-right text-[10px] font-medium text-slate-600 dark:text-slate-400">{power.toExponential(1)}</span>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Empty State - Clinical */}
            {!preprocessingData && !preprocessing && (
              <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-12 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                  <Activity className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-2">No Analysis Results</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Select an EEG file and process it to view analysis results</p>
                <div className="flex items-center justify-center gap-4 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-teal-500"></span> Step 1: Select File</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300"></span> Step 2: Process</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300"></span> Step 3: Analyze</span>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Full Screen Modal - Clinical Theme */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col">
          {/* Header */}
          <div className="bg-slate-900 border-b border-slate-700 px-6 py-4 flex justify-between items-center flex-shrink-0">
            <div className="flex items-center gap-6">
              <div>
                <h2 className="text-white text-lg font-semibold flex items-center gap-2">
                  {activeTab === 'raw' && <><Activity className="w-5 h-5 text-teal-400" /> Raw EEG Signal</>}
                  {activeTab === 'filtered' && <><CheckCircle className="w-5 h-5 text-emerald-400" /> Filtered Signal</>}
                  {activeTab === 'ica' && <><Zap className="w-5 h-5 text-amber-400" /> ICA-Cleaned Signal</>}
                  {activeTab === 'psd' && <><BarChart3 className="w-5 h-5 text-blue-400" /> Power Spectral Density</>}
                  {activeTab === 'topomaps' && <><Brain className="w-5 h-5 text-purple-400" /> Topographic Maps</>}
                  {activeTab === 'ica_components' && <><Settings className="w-5 h-5 text-orange-400" /> ICA Components</>}
                </h2>
                <p className="text-slate-400 text-xs mt-0.5">Fullscreen analysis view</p>
              </div>
              
              {/* Tab switcher in fullscreen */}
              <div className="flex gap-1">
                {['raw', 'filtered', 'ica', 'psd'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition ${
                      activeTab === tab
                        ? 'bg-teal-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {tab === 'raw' ? 'Raw' : tab === 'filtered' ? 'Filtered' : tab === 'ica' ? 'ICA' : 'PSD'}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Zoom controls */}
              <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1 border border-slate-700">
                <button onClick={handleZoomOut} className="p-1.5 hover:bg-slate-700 rounded transition">
                  <ZoomOut className="w-4 h-4 text-slate-300" />
                </button>
                <span className="px-2 text-xs text-slate-300 font-medium">{zoomLevel.toFixed(1)}x</span>
                <button onClick={handleZoomIn} className="p-1.5 hover:bg-slate-700 rounded transition">
                  <ZoomIn className="w-4 h-4 text-slate-300" />
                </button>
              </div>
              
              {/* Export */}
              <button
                onClick={exportChartAsPNG}
                className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition border border-slate-700"
                title="Export as PNG"
              >
                <Download className="w-4 h-4 text-slate-300" />
              </button>
              
              {/* Close */}
              <button
                onClick={() => setShowModal(false)}
                className="p-2 bg-slate-800 hover:bg-red-600/30 text-slate-300 hover:text-red-400 rounded-lg transition border border-slate-700"
                title="Close fullscreen"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Slider Controls */}
          {(activeTab === 'raw' || activeTab === 'filtered' || activeTab === 'ica') && (
            <div className="bg-slate-900 border-b border-slate-700 px-6 py-3 flex-shrink-0">
              <div className="flex items-center gap-4">
                {/* Playback controls */}
                <div className="flex items-center gap-1 bg-gray-700 rounded-lg p-1">
                  <button
                    onClick={() => navigateSlider('left')}
                    className="p-2 hover:bg-gray-600 rounded transition"
                  >
                    <ChevronLeft className="w-4 h-4 text-gray-300" />
                  </button>
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className={`p-2 rounded transition ${isPlaying ? 'bg-red-600 text-white' : 'hover:bg-gray-600 text-gray-300'}`}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => navigateSlider('right')}
                    className="p-2 hover:bg-gray-600 rounded transition"
                  >
                    <ChevronRight className="w-4 h-4 text-gray-300" />
                  </button>
                </div>
                
                {/* Speed control */}
                <div className="flex items-center gap-2 bg-gray-700 rounded-lg px-3 py-1.5">
                  <span className="text-gray-400 text-xs">Speed</span>
                  <select
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                    className="bg-gray-800 text-gray-200 text-sm rounded px-2 py-1 border border-gray-600 focus:outline-none focus:border-teal-500"
                  >
                    <option value="0.25">0.25x</option>
                    <option value="0.5">0.5x</option>
                    <option value="1">1x</option>
                    <option value="2">2x</option>
                    <option value="4">4x</option>
                    <option value="8">8x</option>
                  </select>
                </div>
                
                {/* Current time */}
                <div className="text-gray-300 font-mono text-sm min-w-[80px]">
                  {((sliderValue / 100) * (preprocessingData.raw_signal?.data[0]?.length || 0) / (preprocessingData.raw_signal?.sampling_rate || 1)).toFixed(2)}s
                </div>
                
                {/* Slider */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sliderValue}
                  onChange={(e) => setSliderValue(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-gray-700 rounded-full appearance-none cursor-pointer accent-blue-500"
                />
                
                {/* Percentage */}
                <div className="text-gray-300 font-mono text-sm min-w-[50px] text-right">{sliderValue.toFixed(0)}%</div>
                
                {/* Channel count */}
                <div className="text-gray-400 text-sm">
                  {selectedChannels.length} channels
                </div>
              </div>
            </div>
          )}

          {/* Content Area */}
          <div ref={chartRef} className="flex-1 overflow-auto bg-gray-950 p-4">
            <div className="h-full">
              {renderChart(preprocessingData, activeTab, true, sliderValue)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
