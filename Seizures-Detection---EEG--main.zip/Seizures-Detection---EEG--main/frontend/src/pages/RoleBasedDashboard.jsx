import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, AlertCircle } from 'lucide-react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import PatientForm from '../components/PatientForm';
import DoctorForm from '../components/DoctorForm';
import AssistantForm from '../components/AssistantForm';
import PatientsList from '../components/PatientsList';
import DoctorsList from '../components/DoctorsList';
import AssistantsList from '../components/AssistantsList';
import { authAPI, usersAPI, patientsAPI } from '../services/api';

export default function RoleBasedDashboard() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);

  // Data states
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [assistants, setAssistants] = useState([]);
  const [doctorAssignedAssistants, setDoctorAssignedAssistants] = useState([]);
  const [assignedDoctor, setAssignedDoctor] = useState(null);

  // UI states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [activeTab, setActiveTab] = useState('doctors');

  // Form states
  const [showPatientForm, setShowPatientForm] = useState(false);
  const [showDoctorForm, setShowDoctorForm] = useState(false);
  const [showAssistantForm, setShowAssistantForm] = useState(false);
  const [editingPatient, setEditingPatient] = useState(null);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [editingAssistant, setEditingAssistant] = useState(null);
  const [formLoading, setFormLoading] = useState(false);
  const [assignmentForm, setAssignmentForm] = useState({ doctorId: '', assistantId: '' });

  // Delete confirmation states
  const [deletePatientConfirm, setDeletePatientConfirm] = useState(null);
  const [deleteDoctorConfirm, setDeleteDoctorConfirm] = useState(null);
  const [deleteAssistantConfirm, setDeleteAssistantConfirm] = useState(null);

  // Doctor-Assistant relationship states
  const [doctorAssistantMap, setDoctorAssistantMap] = useState({});
  const [assistantDoctorMap, setAssistantDoctorMap] = useState({});

  // Initialize - Get current user
  useEffect(() => {    
    const initializeUser = async () => {
      try {
        console.log('RoleBasedDashboard: Starting user initialization...');
        const user = await authAPI.getCurrentUser();
        console.log('RoleBasedDashboard: Got user:', user?.role);
        setCurrentUser(user);
        setUserRole(user.role?.toLowerCase());
        
        // Load data based on role
        if (user.role?.toLowerCase() === 'admin') {
          console.log('RoleBasedDashboard: Loading admin data...');
          await loadAdminData();
        } else if (user.role?.toLowerCase() === 'doctor') {
          console.log('RoleBasedDashboard: Loading doctor data...');
          await loadDoctorData(user.id);
        } else if (user.role?.toLowerCase() === 'assistant') {
          console.log('RoleBasedDashboard: Loading assistant data...');
          await loadAssistantData();
        } else {
          console.log('RoleBasedDashboard: Unknown role, skipping data load');
        }
        console.log('RoleBasedDashboard: Initialization complete');
      } catch (err) {
        console.error('Failed to initialize user:', err);
        setError('Failed to load user information');
      } finally {
        setLoading(false);
      }
    };

    initializeUser();
  }, []);

  // Admin data loading (loading state managed by initializeUser)
  const loadAdminData = async () => {
    try {
      setError(null);

      // Load organization doctors, assistants, and patients
      const usersResponse = await usersAPI.list(0, 1000);
      
      const doctorsData = usersResponse.filter((u) => u.role?.toLowerCase() === 'doctor');
      const assistantsData = usersResponse.filter((u) => u.role?.toLowerCase() === 'assistant');

      setDoctors(doctorsData);
      setAssistants(assistantsData);

      // Load all patients
      const patientsResponse = await patientsAPI.list(0, 1000);
      setPatients(patientsResponse);

      // Load doctor-assistant assignments for each doctor
      const assignmentMap = {};
      const reverseAssignmentMap = {}; // Assistant ID -> Doctor
      for (const doctor of doctorsData) {
        try {
          const assistantsList = await usersAPI.getDoctorAssistants(doctor.id);
          assignmentMap[doctor.id] = assistantsList || [];
          
          // Build reverse mapping: assistant ID -> doctor
          if (assistantsList && assistantsList.length > 0) {
            for (const assistant of assistantsList) {
              reverseAssignmentMap[assistant.id] = doctor;
            }
          }
        } catch (err) {
          console.error(`Failed to load assistants for doctor ${doctor.id}:`, err);
          assignmentMap[doctor.id] = [];
        }
      }
      setDoctorAssistantMap(assignmentMap);
      setAssistantDoctorMap(reverseAssignmentMap);
    } catch (err) {
      console.error('Failed to load admin data:', err);
      setError('Failed to load data');
    }
  };

  // Doctor data loading (loading state managed by initializeUser)
  const loadDoctorData = async (doctorId) => {
    try {
      setError(null);

      // Load doctor's patients
      const patientsResponse = await patientsAPI.list(0, 1000, doctorId);
      setPatients(patientsResponse);

      // Load assistants assigned to this doctor
      try {
        const assignedAssistants = await usersAPI.getDoctorAssistants(doctorId);
        setDoctorAssignedAssistants(assignedAssistants || []);
      } catch (err) {
        console.error('Failed to load assigned assistants:', err);
        setDoctorAssignedAssistants([]);
      }
    } catch (err) {
      console.error('Failed to load doctor data:', err);
      setError('Failed to load patients');
    }
  };

  // Assistant data loading (loading state managed by initializeUser)
  const loadAssistantData = async () => {
    try {
      setError(null);

      // Get the assistant's assigned doctor
      try {
        const doctor = await usersAPI.getMyAssignedDoctor();
        setAssignedDoctor(doctor || null);
        // Set doctors array with only the assigned doctor for backward compatibility
        setDoctors(doctor ? [doctor] : []);

        // Load patients for the assigned doctor only
        if (doctor) {
          try {
            const doctorPatients = await patientsAPI.list(0, 1000, doctor.id);
            setPatients(doctorPatients || []);
          } catch (err) {
            console.error('Failed to load doctor patients:', err);
            setPatients([]);
          }
        } else {
          setPatients([]);
        }
      } catch (err) {
        // 404 is expected if no doctor is assigned - don't show as error
        if (err.response?.status === 404) {
          console.log('No doctor assigned yet');
          setAssignedDoctor(null);
          setDoctors([]);
          setPatients([]);
        } else {
          console.error('Failed to load assigned doctor:', err);
          setAssignedDoctor(null);
          setDoctors([]);
          setPatients([]);
        }
      }
    } catch (err) {
      console.error('Failed to load assistant data:', err);
      setError('Failed to load data');
    }
  };

  // Auto-clear success message
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // ==================== PATIENT HANDLERS ====================
  const handleCreatePatient = async (patientData) => {
    try {
      setFormLoading(true);
      const response = await patientsAPI.create(patientData);
      const newPatient = response.data || response;
      setPatients([...patients, newPatient]);
      setSuccessMessage('Patient created successfully');
      setShowPatientForm(false);
    } catch (err) {
      console.error('Failed to create patient:', err);
      setError(err.response?.data?.detail || 'Failed to create patient');
    } finally {
      setFormLoading(false);
    }
  };

  const handleUpdatePatient = async (patientData) => {
    try {
      setFormLoading(true);
      const response = await patientsAPI.update(editingPatient.id, patientData);
      const updatedPatient = response.data || response;
      setPatients(
        patients.map((p) => (p.id === editingPatient.id ? updatedPatient : p))
      );
      setSuccessMessage('Patient updated successfully');
      setShowPatientForm(false);
      setEditingPatient(null);
    } catch (err) {
      console.error('Failed to update patient:', err);
      setError(err.response?.data?.detail || 'Failed to update patient');
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeletePatient = async (confirm) => {
    if (!confirm || !deletePatientConfirm) {
      setDeletePatientConfirm(null);
      return;
    }

    try {
      setFormLoading(true);
      await patientsAPI.delete(deletePatientConfirm.id);
      setPatients(patients.filter((p) => p.id !== deletePatientConfirm.id));
      setSuccessMessage('Patient deleted successfully');
      setDeletePatientConfirm(null);
    } catch (err) {
      console.error('Failed to delete patient:', err);
      setError(err.response?.data?.detail || 'Failed to delete patient');
    } finally {
      setFormLoading(false);
    }
  };

  // ==================== DOCTOR HANDLERS ====================
  const handleCreateDoctor = async (doctorData) => {
    try {
      setFormLoading(true);
      // Create a new user with doctor role
      const userData = {
        ...doctorData,
        role: 'doctor',
        password: 'DefaultPassword123!', // Temporary password, should be set by user
        username: doctorData.email.split('@')[0], // Use email prefix as username
      };
      const response = await usersAPI.create(userData);
      const newDoctor = response.data || response;
      setDoctors([...doctors, newDoctor]);
      setSuccessMessage('Doctor created successfully');
      setShowDoctorForm(false);
    } catch (err) {
      console.error('Failed to create doctor:', err);
      setError(err.response?.data?.detail || 'Failed to create doctor');
    } finally {
      setFormLoading(false);
    }
  };

  const handleUpdateDoctor = async (doctorData) => {
    try {
      setFormLoading(true);
      const response = await usersAPI.update(editingDoctor.id, doctorData);
      const updatedDoctor = response.data || response;
      setDoctors(
        doctors.map((d) => (d.id === editingDoctor.id ? updatedDoctor : d))
      );
      setSuccessMessage('Doctor updated successfully');
      setShowDoctorForm(false);
      setEditingDoctor(null);
    } catch (err) {
      console.error('Failed to update doctor:', err);
      setError(err.response?.data?.detail || 'Failed to update doctor');
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteDoctor = async (confirm) => {
    if (!confirm || !deleteDoctorConfirm) {
      setDeleteDoctorConfirm(null);
      return;
    }

    try {
      setFormLoading(true);
      await usersAPI.delete(deleteDoctorConfirm.id);
      setDoctors(doctors.filter((d) => d.id !== deleteDoctorConfirm.id));
      setSuccessMessage('Doctor deleted successfully');
      setDeleteDoctorConfirm(null);
    } catch (err) {
      console.error('Failed to delete doctor:', err);
      setError(err.response?.data?.detail || 'Failed to delete doctor');
    } finally {
      setFormLoading(false);
    }
  };

  // ==================== ASSISTANT HANDLERS ====================
  const handleCreateAssistant = async (assistantData) => {
    try {
      setFormLoading(true);
      const userData = {
        ...assistantData,
        role: 'assistant',
        password: 'DefaultPassword123!',
        username: assistantData.email.split('@')[0],
      };
      const response = await usersAPI.create(userData);
      const newAssistant = response.data || response;
      setAssistants([...assistants, newAssistant]);
      setSuccessMessage('Assistant created successfully');
      setShowAssistantForm(false);
    } catch (err) {
      console.error('Failed to create assistant:', err);
      setError(err.response?.data?.detail || 'Failed to create assistant');
    } finally {
      setFormLoading(false);
    }
  };

  const handleUpdateAssistant = async (assistantData) => {
    try {
      setFormLoading(true);
      
      // Separate doctor assignment from user data
      const { assigned_doctor_id, ...userUpdateData } = assistantData;
      
      // Update user info
      const response = await usersAPI.update(editingAssistant.id, userUpdateData);
      const updatedAssistant = response.data || response;
      setAssistants(
        assistants.map((a) => (a.id === editingAssistant.id ? updatedAssistant : a))
      );
      
      // Handle doctor assignment if provided
      if (assigned_doctor_id) {
        await usersAPI.assignAssistantToDoctor(assigned_doctor_id, editingAssistant.id);
      }
      
      // Refresh the doctor-assistant relationships
      const doctorsData = doctors;
      const assignmentMap = {};
      const reverseAssignmentMap = {};
      for (const doctor of doctorsData) {
        try {
          const assistantsList = await usersAPI.getDoctorAssistants(doctor.id);
          assignmentMap[doctor.id] = assistantsList || [];
          
          if (assistantsList && assistantsList.length > 0) {
            for (const assistant of assistantsList) {
              reverseAssignmentMap[assistant.id] = doctor;
            }
          }
        } catch (err) {
          console.error(`Failed to load assistants for doctor ${doctor.id}:`, err);
          assignmentMap[doctor.id] = [];
        }
      }
      setDoctorAssistantMap(assignmentMap);
      setAssistantDoctorMap(reverseAssignmentMap);
      
      setSuccessMessage('Assistant updated successfully');
      setShowAssistantForm(false);
      setEditingAssistant(null);
    } catch (err) {
      console.error('Failed to update assistant:', err);
      setError(err.response?.data?.detail || 'Failed to update assistant');
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteAssistant = async (confirm) => {
    if (!confirm || !deleteAssistantConfirm) {
      setDeleteAssistantConfirm(null);
      return;
    }

    try {
      setFormLoading(true);
      await usersAPI.delete(deleteAssistantConfirm.id);
      setAssistants(assistants.filter((a) => a.id !== deleteAssistantConfirm.id));
      setSuccessMessage('Assistant deleted successfully');
      setDeleteAssistantConfirm(null);
    } catch (err) {
      console.error('Failed to delete assistant:', err);
      setError(err.response?.data?.detail || 'Failed to delete assistant');
    } finally {
      setFormLoading(false);
    }
  };

  // ==================== ASSIGNMENT HANDLERS ====================
  const handleAssignAssistant = async () => {
    if (!assignmentForm || !assignmentForm.assistantId || !assignmentForm.doctorId) {
      setError('Please select both an assistant and a doctor');
      setTimeout(() => setError(null), 5000);
      return;
    }

    try {
      setFormLoading(true);
      setError(null);
      
      // Use the correct API endpoint for assigning assistants to doctors
      await usersAPI.assignAssistantToDoctor(
        assignmentForm.doctorId,
        assignmentForm.assistantId
      );
      
      // Refetch assistants to get the updated assignment status
      const usersResponse = await usersAPI.list(0, 1000);
      const updatedAssistants = usersResponse.filter((u) => u.role?.toLowerCase() === 'assistant');
      setAssistants(updatedAssistants);
      
      setSuccessMessage('Assistant assigned to doctor successfully');
      setTimeout(() => setSuccessMessage(null), 5000);
      setAssignmentForm({ doctorId: '', assistantId: '' });
    } catch (err) {
      console.error('Failed to assign assistant:', err);
      const errorMsg = err.response?.data?.detail || err.message || 'Failed to assign assistant';
      setError(errorMsg);
      setTimeout(() => setError(null), 5000);
    } finally {
      setFormLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        <Sidebar userName={currentUser?.full_name || 'User'} />
        <div className="flex-1 flex flex-col overflow-hidden min-h-0">
          <Header pageName="Dashboard" userName={currentUser?.full_name || 'User'} />
          <div className="flex items-center justify-center flex-1">
            <div className="text-center">
              <div className="animate-spin inline-block w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full mb-4"></div>
              <p className="text-gray-600 dark:text-gray-400 text-lg">Loading dashboard...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={currentUser?.full_name || 'User'} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="Dashboard" userName={currentUser?.full_name || 'User'} />
        <main className="flex-1 overflow-y-auto min-h-0 p-6 bg-gray-50 dark:bg-gray-900">
          <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            {userRole === 'admin' && 'Admin Dashboard'}
            {userRole === 'doctor' && 'Doctor Dashboard'}
            {userRole === 'assistant' && 'Assistant Dashboard'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {currentUser && `Welcome, ${currentUser.full_name}`}
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg flex items-start gap-3">
            <AlertCircle className="text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" size={20} />
            <div>
              <p className="text-red-800 dark:text-red-200 font-medium">Error</p>
              <p className="text-red-700 dark:text-red-300 text-sm">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="ml-auto text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
            >
              ✕
            </button>
          </div>
        )}

        {/* Success Message */}
        {successMessage && (
          <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 rounded-lg flex items-center gap-3">
            <div className="w-2 h-2 bg-green-600 rounded-full"></div>
            <p className="text-green-800 dark:text-green-200 font-medium">{successMessage}</p>
            <button
              onClick={() => setSuccessMessage(null)}
              className="ml-auto text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300"
            >
              ✕
            </button>
          </div>
        )}

        {/* ADMIN VIEW */}
        {userRole === 'admin' && (
          <div className="space-y-6">
            {/* Tabs */}
            <div className="flex gap-2 bg-white dark:bg-gray-800 rounded-lg shadow p-1 border border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setActiveTab('doctors')}
                className={`flex-1 py-2 px-4 rounded transition ${
                  activeTab === 'doctors'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                Doctors ({doctors.length})
              </button>
              <button
                onClick={() => setActiveTab('assistants')}
                className={`flex-1 py-2 px-4 rounded transition ${
                  activeTab === 'assistants'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                Assistants ({assistants.length})
              </button>
              <button
                onClick={() => setActiveTab('assignments')}
                className={`flex-1 py-2 px-4 rounded transition ${
                  activeTab === 'assignments'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                Assign Assistants
              </button>
              <button
                onClick={() => setActiveTab('patients')}
                className={`flex-1 py-2 px-4 rounded transition ${
                  activeTab === 'patients'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                Patients ({patients.length})
              </button>
            </div>

            {/* Doctors Tab */}
            {activeTab === 'doctors' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Organization Doctors
                  </h2>
                  <button
                    onClick={() => {
                      setEditingDoctor(null);
                      setShowDoctorForm(true);
                    }}
                    className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 dark:from-blue-600 dark:to-blue-700 dark:hover:from-blue-700 dark:hover:to-blue-800 transition"
                  >
                    <Plus size={20} />
                    Add Doctor
                  </button>
                </div>
                <DoctorsList
                  doctors={doctors}
                  assistants={assistants}
                  patients={patients}
                  doctorAssistantMap={doctorAssistantMap}
                  loading={loading}
                  onEdit={(doctor) => {
                    setEditingDoctor(doctor);
                    setShowDoctorForm(true);
                  }}
                  onDelete={setDeleteDoctorConfirm}
                  showDeleteConfirm={deleteDoctorConfirm}
                  onConfirmDelete={handleDeleteDoctor}
                />
              </div>
            )}

            {/* Assistants Tab */}
            {activeTab === 'assistants' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Organization Assistants
                  </h2>
                  <button
                    onClick={() => {
                      setEditingAssistant(null);
                      setShowAssistantForm(true);
                    }}
                    className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 transition"
                  >
                    <Plus size={20} />
                    Add Assistant
                  </button>
                </div>
                <AssistantsList
                  assistants={assistants}
                  doctors={doctors}
                  assistantDoctorMap={assistantDoctorMap}
                  loading={loading}
                  onEdit={(assistant) => {
                    setEditingAssistant(assistant);
                    setShowAssistantForm(true);
                  }}
                  onDelete={setDeleteAssistantConfirm}
                  showDeleteConfirm={deleteAssistantConfirm}
                  onConfirmDelete={handleDeleteAssistant}
                />
              </div>
            )}

            {/* Assignments Tab */}
            {activeTab === 'assignments' && (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Assign Assistants to Doctors
                </h2>
                
                {/* Assignment Form */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {/* Doctor Dropdown */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Select Doctor *
                      </label>
                      <select
                        value={assignmentForm?.doctorId || ''}
                        onChange={(e) =>
                          setAssignmentForm({
                            ...assignmentForm,
                            doctorId: e.target.value,
                          })
                        }
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">-- Choose a doctor --</option>
                        {doctors.map((doctor) => (
                          <option key={doctor.id} value={doctor.id}>
                            {doctor.full_name} ({doctor.email})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Assistant Dropdown */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Select Assistant *
                      </label>
                      <select
                        value={assignmentForm?.assistantId || ''}
                        onChange={(e) =>
                          setAssignmentForm({
                            ...assignmentForm,
                            assistantId: e.target.value,
                          })
                        }
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">-- Choose an assistant --</option>
                        {assistants.map((assistant) => (
                          <option key={assistant.id} value={assistant.id}>
                            {assistant.full_name} ({assistant.email})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <button
                    onClick={handleAssignAssistant}
                    disabled={formLoading || !assignmentForm?.doctorId || !assignmentForm?.assistantId}
                    className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 disabled:opacity-50 disabled:cursor-not-allowed transition"
                  >
                    {formLoading ? 'Assigning...' : 'Assign Assistant'}
                  </button>
                </div>

                {/* Current Assignments */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                    Current Assignments
                  </h3>
                  {assistants.length === 0 ? (
                    <p className="text-gray-600 dark:text-gray-400">No assistants available</p>
                  ) : (
                    <div className="space-y-3">
                      {assistants.map((assistant) => {
                        const assignedDoctor = assistantDoctorMap[assistant.id];
                        return (
                          <div
                            key={assistant.id}
                            className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 flex items-center justify-between"
                          >
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">
                                {assistant.full_name}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {assistant.email}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Assigned to:
                              </p>
                              <p className="font-medium text-gray-900 dark:text-white">
                                {assignedDoctor ? assignedDoctor.full_name : 'Unassigned'}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Patients Tab */}
            {activeTab === 'patients' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    All Patients
                  </h2>
                  <button
                    onClick={() => {
                      setEditingPatient(null);
                      setShowPatientForm(true);
                    }}
                    className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 transition"
                  >
                    <Plus size={20} />
                    Add Patient
                  </button>
                </div>
                <PatientsList
                  patients={patients}
                  loading={loading}
                  onEdit={(patient) => {
                    setEditingPatient(patient);
                    setShowPatientForm(true);
                  }}
                  onDelete={setDeletePatientConfirm}
                  showDeleteConfirm={deletePatientConfirm}
                  onConfirmDelete={handleDeletePatient}
                />
              </div>
            )}
          </div>
        )}

        {/* DOCTOR VIEW */}
        {userRole === 'doctor' && (
          <div className="space-y-4">
            {/* Assigned Assistants Section */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                My Assigned Assistants
              </h3>
              {doctorAssignedAssistants.length === 0 ? (
                <p className="text-gray-600 dark:text-gray-400">No assistants assigned to you yet</p>
              ) : (
                <div className="space-y-3">
                  {doctorAssignedAssistants.map((assistant) => (
                    <div
                      key={assistant.id}
                      className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800"
                    >
                      <p className="font-medium text-gray-900 dark:text-white">
                        {assistant.full_name}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {assistant.email}
                      </p>
                      {assistant.is_active ? (
                        <span className="inline-block mt-2 px-2 py-1 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 rounded">
                          Active
                        </span>
                      ) : (
                        <span className="inline-block mt-2 px-2 py-1 text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 rounded">
                          Inactive
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">My Patients</h2>
              <button
                onClick={() => {
                  setEditingPatient(null);
                  setShowPatientForm(true);
                }}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 transition"
              >
                <Plus size={20} />
                Add Patient
              </button>
            </div>
            <PatientsList
              patients={patients}
              loading={loading}
              onEdit={(patient) => {
                setEditingPatient(patient);
                setShowPatientForm(true);
              }}
              onDelete={setDeletePatientConfirm}
              showDeleteConfirm={deletePatientConfirm}
              onConfirmDelete={handleDeletePatient}
            />
          </div>
        )}

        {/* ASSISTANT VIEW */}
        {userRole === 'assistant' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Assigned Doctor Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                  My Assigned Doctor
                </h3>
                {assignedDoctor ? (
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="font-medium text-gray-900 dark:text-white text-lg">
                      {assignedDoctor.full_name}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {assignedDoctor.email}
                    </p>
                    {assignedDoctor.title && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {assignedDoctor.title}
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-600 dark:text-gray-400">
                    You are not assigned to any doctor yet
                  </p>
                )}
              </div>

              {/* Stats Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                  Quick Stats
                </h3>
                <div className="space-y-3">
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-800">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Patients</p>
                    <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                      {patients.length}
                    </p>
                  </div>
                  <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded border border-purple-200 dark:border-purple-800">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Assignment Status</p>
                    <p className="text-lg font-bold text-purple-600 dark:text-purple-400">
                      {assignedDoctor ? 'Assigned' : 'Unassigned'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Patients List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Doctor's Patients
                </h2>
              </div>
              {assignedDoctor ? (
                <>
                  {loading ? (
                    <div className="flex items-center justify-center h-64">
                      <div className="text-center">
                        <div className="animate-spin inline-block w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mb-2"></div>
                        <p className="text-gray-600">Loading patients...</p>
                      </div>
                    </div>
                  ) : (
                    <PatientsList
                      patients={patients}
                      loading={loading}
                      onEdit={(patient) => {
                        setEditingPatient(patient);
                        setShowPatientForm(true);
                      }}
                      onDelete={setDeletePatientConfirm}
                      showDeleteConfirm={deletePatientConfirm}
                      onConfirmDelete={handleDeletePatient}
                    />
                  )}
                </>
              ) : (
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-8 text-center">
                  <p className="text-gray-600 dark:text-gray-400">
                    You need to be assigned to a doctor to view patients
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Forms */}
        {showPatientForm && (
          <PatientForm
            patient={editingPatient}
            doctors={doctors}
            isDoctorAdding={userRole === 'doctor'}
            currentDoctorId={currentUser?.id}
            onSubmit={
              editingPatient ? handleUpdatePatient : handleCreatePatient
            }
            onCancel={() => {
              setShowPatientForm(false);
              setEditingPatient(null);
            }}
            isLoading={formLoading}
          />
        )}

        {showDoctorForm && (
          <DoctorForm
            doctor={editingDoctor}
            onSubmit={
              editingDoctor ? handleUpdateDoctor : handleCreateDoctor
            }
            onCancel={() => {
              setShowDoctorForm(false);
              setEditingDoctor(null);
            }}
            isLoading={formLoading}
          />
        )}

        {showAssistantForm && (
          <AssistantForm
            assistant={editingAssistant}
            doctors={doctors}
            onSubmit={
              editingAssistant ? handleUpdateAssistant : handleCreateAssistant
            }
            onCancel={() => {
              setShowAssistantForm(false);
              setEditingAssistant(null);
            }}
            isLoading={formLoading}
          />
        )}
          </div>
        </main>
      </div>
    </div>
  );
}
