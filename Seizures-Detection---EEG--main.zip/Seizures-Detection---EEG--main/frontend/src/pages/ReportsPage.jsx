import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Download,
  Trash2,
  FileText,
  Filter,
  AlertCircle,
  CheckCircle,
  Clock,
  User,
  MessageSquare,
  X,
  Eye,
} from 'lucide-react';
import { authAPI, seizureDetectionAPI, patientsAPI, eegFilesAPI } from '../services/api';
import { useNotification } from '../context/NotificationContext';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function ReportsPage() {
  const { addNotification } = useNotification();
  // State management
  const [userName, setUserName] = useState('User');
  const [reports, setReports] = useState([]);
  const [patients, setPatients] = useState({});
  const [allPatients, setAllPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPatientId, setFilterPatientId] = useState('all');
  const [selectedReport, setSelectedReport] = useState(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [showPDFViewer, setShowPDFViewer] = useState(false);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [isLoadingPDF, setIsLoadingPDF] = useState(false);
  const [pdfReport, setPdfReport] = useState(null);
  const [reportNotes, setReportNotes] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState({});
  const [deleteConfirm, setDeleteConfirm] = useState({ show: false, reportId: null });

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'EEG Data', path: '/eeg-data' },
    { name: 'EEG Visualization', path: '/eeg-visualization' },
    { name: 'Analysis', path: '/analysis' },
    { name: 'Reports', path: '/reports' },
    { name: 'Settings', path: '/settings' },
  ];

  // Load initial data
  useEffect(() => {
    loadUserName();
    loadPatients();
  }, []);

  // Load reports when patients change
  useEffect(() => {
    loadReports();
  }, [allPatients]);

  const loadUserName = async () => {
    try {
      const userData = await authAPI.getCurrentUser();
      if (userData) {
        setUserName(userData.full_name || userData.username || 'User');
      }
    } catch (err) {
      console.error('Failed to fetch user name:', err);
    }
  };

  const loadPatients = async () => {
    try {
      const data = await patientsAPI.list(0, 1000);
      const patientsList = Array.isArray(data) ? data : data.items || [];
      setAllPatients(patientsList);
      console.log('Loaded patients:', patientsList);
    } catch (err) {
      console.error('Failed to load patients:', err);
    }
  };

  const loadReports = async () => {
    setLoading(true);
    try {
      // Load reports from backend CSV_BI files
      const data = await seizureDetectionAPI.listAllReports();
      const reportsList = data.reports || [];
      console.log('Loaded reports from CSV_BI files:', reportsList);
      setReports(reportsList);

      // Build patients map from report data (backend already fetches patient names)
      const patientsData = {};
      for (const report of reportsList) {
        if (report.patient_id) {
          // Backend already provides patient_name from CSV_BI parsing
          patientsData[report.patient_id] = {
            id: report.patient_id,
            full_name: report.patient_name || 'Unknown'
          };
        }
      }

      setPatients(patientsData);
    } catch (err) {
      console.error('Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  };

  // Filter reports based on search and patient filter
  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.patient_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPatient = filterPatientId === 'all' || report.patient_id === filterPatientId;
    return matchesSearch && matchesPatient;
  });

  // Sort by date (newest first)
  const sortedReports = [...filteredReports].sort((a, b) => new Date(b.generated_at) - new Date(a.generated_at));

  const handleDeleteReport = async (reportId) => {
    try {
      // Get the report to find its eeg_file_id
      const report = reports.find((r) => r.id === reportId);
      if (!report || !report.eeg_file_id) {
        console.error('Report or eeg_file_id not found');
        alert('Failed to delete report');
        return;
      }

      // Call backend endpoint to delete CSV_BI file
      await seizureDetectionAPI.deleteReport(report.eeg_file_id);

      // Remove from local state
      const updatedReports = reports.filter((r) => r.id !== reportId);
      setReports(updatedReports);
      setSelectedReport(null);
      setDeleteConfirm({ show: false, reportId: null });
      console.log('Report deleted successfully');
    } catch (err) {
      console.error('Delete failed:', err);
      alert('Failed to delete report');
    }
  };

  const handleExportPDF = async () => {
    if (!selectedReport) return;

    setIsExporting(true);
    try {
      const blob = await seizureDetectionAPI.exportPDF(selectedReport.eeg_file_id, reportNotes);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `seizure_report_${selectedReport.eeg_file_id}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);

      addNotification({
        type: 'success',
        title: 'Report Downloaded',
        message: `Seizure report for ${selectedReport.patient_name} has been downloaded successfully.`
      });

      setShowNotesModal(false);
      setReportNotes('');
    } catch (err) {
      console.error('Export failed:', err);
      addNotification({
        type: 'error',
        title: 'Download Failed',
        message: 'Failed to export report. Please try again.'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleViewPDF = async (report) => {
    if (!report) return;

    setPdfReport(report);
    setIsLoadingPDF(true);
    try {
      const blob = await seizureDetectionAPI.exportPDF(report.eeg_file_id);
      const url = window.URL.createObjectURL(blob);
      setPdfUrl(url);
      setShowPDFViewer(true);
    } catch (err) {
      console.error('Failed to load PDF:', err);
      addNotification({
        type: 'error',
        title: 'PDF Load Failed',
        message: 'Failed to load PDF viewer. Please try again.'
      });
    } finally {
      setIsLoadingPDF(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
      case 'processing':
        return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
      case 'failed':
        return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 inline mr-1" />;
      case 'processing':
        return <Clock className="w-4 h-4 inline mr-1" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 inline mr-1" />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="Reports" userName={userName} />

        <main className="flex-1 overflow-y-auto min-h-0 p-8 bg-gray-50 dark:bg-gray-900">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">Clinical Reports</h1>
            <p className="text-gray-600 dark:text-gray-400">Manage and analyze EEG seizure detection reports</p>
          </div>

          {/* Controls Section */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Search */}
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  <Search className="w-4 h-4 inline mr-2" />
                  Search Reports
                </label>
                <input
                  type="text"
                  placeholder="Search by title or patient..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              {/* Filter by Patient */}
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  <Filter className="w-4 h-4 inline mr-2" />
                  Filter by Patient
                </label>
                <select
                  value={filterPatientId}
                  onChange={(e) => setFilterPatientId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                >
                  <option value="all">All Patients</option>
                  {allPatients.map((patient) => (
                    <option key={patient.id} value={patient.id}>
                      {patient.full_name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Stats */}
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Statistics</label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded p-2">
                    <p className="text-xs text-gray-600 dark:text-gray-400">Total Reports</p>
                    <p className="text-lg font-bold text-blue-600 dark:text-blue-400">{sortedReports.length}</p>
                  </div>
                  <div className="bg-green-50 dark:bg-green-900/20 rounded p-2">
                    <p className="text-xs text-gray-600 dark:text-gray-400">Total Seizures</p>
                    <p className="text-lg font-bold text-green-600 dark:text-green-400">
                      {sortedReports.reduce((sum, r) => sum + (r.seizure_count || 0), 0)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Reports Table */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
            {loading ? (
              <div className="p-8 text-center">
                <p className="text-gray-600 dark:text-gray-400">Loading reports...</p>
              </div>
            ) : sortedReports.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900 dark:text-white">Patient</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900 dark:text-white">EEG File</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-gray-900 dark:text-white">Seizures</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-gray-900 dark:text-white">Duration (s)</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-gray-900 dark:text-white">Confidence %</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900 dark:text-white">Status</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900 dark:text-white">Date</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-gray-900 dark:text-white">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {sortedReports.map((report) => {
                      return (
                        <tr
                          key={report.id}
                          className="hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                        >
                          {/* Patient Name */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4 text-gray-400" />
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">
                                  {report.patient_name || 'Unknown'}
                                </p>
                                {report.patient_id && (
                                  <p className="text-xs text-gray-500 dark:text-gray-400">{report.patient_id}</p>
                                )}
                              </div>
                            </div>
                          </td>

                          {/* Report Title - EDF File Name */}
                          <td className="px-6 py-4">
                            <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">
                              {report.filename}
                            </p>
                          </td>

                          {/* Seizures */}
                          <td className="px-6 py-4 text-center">
                            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 font-semibold text-sm">
                              {report.seizure_count || 0}
                            </span>
                          </td>

                          {/* Duration */}
                          <td className="px-6 py-4 text-center">
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {(report.total_seizure_duration_seconds || 0).toFixed(1)}
                            </p>
                          </td>

                          {/* Confidence */}
                          <td className="px-6 py-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <div className="w-16 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                                <div
                                  className="bg-green-500 h-2 rounded-full"
                                  style={{
                                    width: `${Math.max(0, Math.min(100, (report.seizure_percentage || 0)))}%`,
                                  }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 w-12">
                                {(report.seizure_percentage || 0).toFixed(1)}%
                              </span>
                            </div>
                          </td>

                          {/* Status */}
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                              {getStatusIcon(report.status)}
                              {report.status}
                            </span>
                          </td>

                          {/* Date */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {new Date(report.generated_at).toLocaleDateString()}
                            </p>
                          </td>

                          {/* Actions */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center justify-center gap-2">
                              {/* View PDF */}
                              <button
                                onClick={() => handleViewPDF(report)}
                                className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition"
                                title="View PDF"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              {/* Export PDF with Notes */}
                              <button
                                onClick={() => {
                                  setSelectedReport(report);
                                  setShowNotesModal(true);
                                }}
                                className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition"
                                title="Export PDF"
                              >
                                <Download className="w-4 h-4" />
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => setDeleteConfirm({ show: true, reportId: report.id })}
                                className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"
                                title="Delete Report"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-12 text-center">
                <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400 text-lg mb-2">No reports found</p>
                <p className="text-gray-500 dark:text-gray-500">
                  Run seizure detection on an EEG file to generate reports automatically
                </p>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Report Details Modal */}
      {selectedReport && !showNotesModal && !showPDFViewer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{selectedReport.title}</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Generated on {new Date(selectedReport.generated_at).toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setSelectedReport(null)}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-8">
              {/* Patient Information */}
              {selectedReport.patient_id && patients[selectedReport.patient_id] && (
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 border border-purple-200 dark:border-purple-800">
                  <div className="flex items-center gap-3 mb-4">
                    <User className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    <h3 className="text-lg font-bold text-purple-600 dark:text-purple-400">Patient Information</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Name</p>
                      <p className="text-lg font-semibold text-gray-900 dark:text-white">
                        {patients[selectedReport.patient_id].full_name}
                      </p>
                    </div>
                    {patients[selectedReport.patient_id].date_of_birth && (
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Date of Birth</p>
                        <p className="text-lg font-semibold text-gray-900 dark:text-white">
                          {new Date(patients[selectedReport.patient_id].date_of_birth).toLocaleDateString()}
                        </p>
                      </div>
                    )}
                    {patients[selectedReport.patient_id].age && (
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Age</p>
                        <p className="text-lg font-semibold text-gray-900 dark:text-white">
                          {patients[selectedReport.patient_id].age} years
                        </p>
                      </div>
                    )}
                    {patients[selectedReport.patient_id].gender && (
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Gender</p>
                        <p className="text-lg font-semibold text-gray-900 dark:text-white">
                          {patients[selectedReport.patient_id].gender}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Analysis Summary */}
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
                <h3 className="text-lg font-bold text-blue-600 dark:text-blue-400 mb-4">Analysis Summary</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Seizure Count</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{selectedReport.seizure_count || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Duration</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">
                      {(selectedReport.total_seizure_duration_seconds || 0).toFixed(1)}s
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Seizure Percentage</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">
                      {(selectedReport.seizure_percentage || 0).toFixed(1)}%
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Channels</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{selectedReport.num_channels || 19}</p>
                  </div>
                </div>
              </div>

              {/* Seizure Events */}
              {selectedReport.seizure_events && selectedReport.seizure_events.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Seizure Events</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b-2 border-gray-300 dark:border-gray-600">
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                            Start (s)
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                            End (s)
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                            Duration (s)
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                            Confidence
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedReport.seizure_events.map((event, idx) => (
                          <tr key={idx} className="border border-gray-300 dark:border-gray-700">
                            <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                              {event.start_time?.toFixed(2) || 'N/A'}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                              {event.end_time?.toFixed(2) || 'N/A'}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                              {event.duration?.toFixed(2) || 'N/A'}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                              {event.confidence?.toFixed(0) || 'N/A'}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Clinical Notes */}
              {selectedReport.clinical_notes && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Clinical Notes</h3>
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{selectedReport.clinical_notes}</p>
                </div>
              )}

              {/* Clinical Recommendations */}
              {selectedReport.clinical_recommendations && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Clinical Recommendations</h3>
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{selectedReport.clinical_recommendations}</p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-gray-100 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 px-6 py-4 flex gap-3">
              <button
                onClick={() => {
                  setSelectedReport(null);
                  setShowNotesModal(false);
                }}
                className="flex-1 px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-900 dark:text-white font-medium rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition"
              >
                Close
              </button>
              <button
                onClick={() => setShowNotesModal(true)}
                className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notes Modal for Export */}
      {showNotesModal && selectedReport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full">
            {/* Modal Header */}
            <div className="border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Add Notes to Report</h2>
              </div>
              <button
                onClick={() => {
                  setShowNotesModal(false);
                  setReportNotes('');
                }}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Add clinical notes or additional information before exporting the PDF report.
              </p>
              <textarea
                value={reportNotes}
                onChange={(e) => setReportNotes(e.target.value)}
                placeholder="Enter clinical notes, observations, or recommendations..."
                className="w-full h-40 px-4 py-3 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white resize-none"
              />
            </div>

            {/* Modal Footer */}
            <div className="bg-gray-100 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 px-6 py-4 flex gap-3">
              <button
                onClick={() => {
                  setShowNotesModal(false);
                  setReportNotes('');
                }}
                className="flex-1 px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-900 dark:text-white font-medium rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition"
              >
                Cancel
              </button>
              <button
                onClick={handleExportPDF}
                disabled={isExporting}
                className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                {isExporting ? 'Exporting...' : 'Export PDF'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-sm w-full mx-4 overflow-hidden animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="bg-red-50 dark:bg-red-900/20 border-b border-red-100 dark:border-red-800 px-6 py-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/40 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Delete Report</h3>
              </div>
            </div>

            {/* Modal Body */}
            <div className="px-6 py-4">
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                Are you sure you want to delete this report?
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                This action cannot be undone. The report data will be permanently removed.
              </p>
            </div>

            {/* Modal Footer */}
            <div className="bg-gray-50 dark:bg-gray-900/50 border-t border-gray-200 dark:border-gray-700 px-6 py-4 flex gap-3">
              <button
                onClick={() => setDeleteConfirm({ show: false, reportId: null })}
                className="flex-1 px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white font-medium rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteReport(deleteConfirm.reportId)}
                className="flex-1 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF Viewer Modal */}
      {showPDFViewer && pdfUrl && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          {/* Header */}
          <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between flex-shrink-0">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Seizure Report</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {pdfReport?.patient_name}
              </p>
            </div>
            <div className="flex items-center gap-3">
              {isLoadingPDF && (
                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                  <div className="w-5 h-5 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin"></div>
                  <span>Loading PDF...</span>
                </div>
              )}
              <button
                onClick={() => {
                  setShowPDFViewer(false);
                  setPdfUrl(null);
                  setPdfReport(null);
                }}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* PDF Viewer */}
          <div className="flex-1 overflow-hidden bg-gray-100 dark:bg-gray-900">
            <iframe
              src={pdfUrl}
              title="Seizure Report PDF"
              className="w-full h-full border-none"
              loading="lazy"
            />
          </div>

          {/* Footer */}
          <div className="bg-gray-100 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 px-6 py-4 flex gap-3 flex-shrink-0">
            <button
              onClick={() => {
                setShowPDFViewer(false);
                setPdfUrl(null);
                setPdfReport(null);
              }}
              className="flex-1 px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-900 dark:text-white font-medium rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition"
            >
              Close
            </button>
            <button
              onClick={() => {
                const link = document.createElement('a');
                link.href = pdfUrl;
                link.setAttribute('download', `seizure_report_${pdfReport?.eeg_file_id}.pdf`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                addNotification({
                  type: 'success',
                  title: 'Report Downloaded',
                  message: 'PDF downloaded successfully.'
                });
              }}
              className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download PDF
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
