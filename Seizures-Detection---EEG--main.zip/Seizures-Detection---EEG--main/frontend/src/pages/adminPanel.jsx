import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowUpDown } from 'lucide-react';
import { authAPI, organizationsAPI } from '../services/api';
import apiClient from '../services/api';

export default function AdminPanel() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('org');
  const [orgData, setOrgData] = useState({ name: '', address: '', contact: '', description: '' });
  const [userData, setUserData] = useState({ username: '', email: '', password: '', full_name: '', role: 'doctor', org_id: '' });
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  // Root-only access control with loading state
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAuthChecking, setIsAuthChecking] = useState(true);

  // User management state
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [registerUserSortBy, setRegisterUserSortBy] = useState('role'); // 'username', 'role', 'organization'
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [usersLoading, setUsersLoading] = useState(false);

  // Organizations state
  const [organizations, setOrganizations] = useState([]);
  const [organizationsList, setOrganizationsList] = useState([]);
  const [showOrgForm, setShowOrgForm] = useState(false);
  const [orgsLoading, setOrgsLoading] = useState(false);
  const [editingOrg, setEditingOrg] = useState(null);
  const [showEditOrgForm, setShowEditOrgForm] = useState(false);

  // Scroll position ref (using ref instead of state to avoid re-renders)
  const scrollPositionRef = useRef(0);

  useEffect(() => {
    const check = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) {
          setIsAdmin(false);
          setIsAuthChecking(false);
          navigate('/login', { replace: true });
          return;
        }

        const user = await authAPI.getCurrentUser();
        const isRoot = user?.role?.toLowerCase() === 'root';
        
        if (isRoot) {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
          navigate('/login', { replace: true });
        }
      } catch (err) {
        console.error('Auth check failed:', err);
        setIsAdmin(false);
        navigate('/login', { replace: true });
      } finally {
        setIsAuthChecking(false);
      }
    };
    check();
  }, [navigate]);

  // Load organizations when org tab is active
  useEffect(() => {
    if (activeTab === 'org') {
      loadOrganizations();
    }
  }, [activeTab]);

  // Load users when users tab is active
  useEffect(() => {
    if (activeTab === 'users') {
      loadUsers();
    }
  }, [activeTab]);

  // Filter users when search or role filter changes
  useEffect(() => {
    let filtered = users;
    
    if (searchTerm.trim()) {
      const lower = searchTerm.toLowerCase();
      filtered = filtered.filter(u => 
        u.username?.toLowerCase().includes(lower) ||
        u.email?.toLowerCase().includes(lower) ||
        u.full_name?.toLowerCase().includes(lower)
      );
    }

    if (roleFilter !== 'All') {
      filtered = filtered.filter(u => u.role?.toLowerCase() === roleFilter.toLowerCase());
    }

    setFilteredUsers(filtered);
  }, [searchTerm, roleFilter, users]);

  // Restore scroll position after data loads (check both tabs)
  useEffect(() => {
    if (scrollPositionRef.current > 0 && !loading) {
      const timer = requestAnimationFrame(() => {
        window.scrollTo(0, scrollPositionRef.current);
      });
      return () => cancelAnimationFrame(timer);
    }
  }, [loading, organizationsList, filteredUsers]);

  // Save scroll position before operations
  const saveScrollPosition = () => {
    scrollPositionRef.current = window.scrollY;
  };

  // Auto-clear messages after 5 seconds
  useEffect(() => {
    if (message || error) {
      const timer = setTimeout(() => {
        setMessage(null);
        setError(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [message, error]);

  // Fix autofill styling by removing webkit autofill background
  useEffect(() => {
    const handleAutofill = () => {
      const autofilled = document.querySelectorAll('input:-webkit-autofill');
      autofilled.forEach(input => {
        input.style.WebkitBoxShadow = '0 0 0 1000px white inset !important';
        input.style.WebkitTextFillColor = '#1f2937 !important';
        input.style.color = '#1f2937 !important';
      });
    };

    // Check on mount and on input focus
    handleAutofill();
    document.addEventListener('focus', handleAutofill, true);
    return () => document.removeEventListener('focus', handleAutofill, true);
  }, []);

  const handleOrgChange = (e) => {
    const { name, value } = e.target;
    setOrgData(prev => ({ ...prev, [name]: value }));
    setError(null);
    setMessage(null);
  };

  const handleUserChange = (e) => {
    const { name, value } = e.target;
    setUserData(prev => ({ ...prev, [name]: value }));
    setError(null);
    setMessage(null);
  };

  const submitOrg = async () => {
    if (!orgData.name) {
      setError('Please enter organization name');
      return;
    }

    saveScrollPosition();
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      await organizationsAPI.create({
        name: orgData.name,
        address: orgData.address || null,
        contact: orgData.contact || null,
        description: orgData.description || null,
      });
      setMessage('Organization created successfully!');
      setOrgData({ name: '', address: '', contact: '', description: '' });
      setShowOrgForm(false);
      // Reload organizations and users to update organizations dropdown
      setTimeout(() => {
        loadOrganizations();
        loadUsers();
      }, 500);
    } catch (err) {
      console.error('Create organization failed', err);
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to create organization: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  const submitUpdateOrg = async () => {
    if (!editingOrg.name) {
      setError('Please enter organization name');
      return;
    }

    saveScrollPosition();
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      await organizationsAPI.update(editingOrg.id, {
        name: editingOrg.name,
        address: editingOrg.address || null,
        contact: editingOrg.contact || null,
        description: editingOrg.description || null,
      });
      setMessage('Organization updated successfully!');
      setEditingOrg(null);
      setShowEditOrgForm(false);
      // Reload organizations
      setTimeout(() => {
        loadOrganizations();
      }, 500);
    } catch (err) {
      console.error('Update organization failed', err);
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to update organization: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  const deleteOrgHandler = async (orgId, orgName) => {
    if (!window.confirm(`Are you sure you want to delete organization "${orgName}"? All users in this organization will have their organization set to NULL.`)) {
      return;
    }

    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const response = await organizationsAPI.delete(orgId);
      setMessage(`Organization deleted successfully! ${response.users_affected} user(s) affected.`);
      // Reload organizations
      setTimeout(() => {
        loadOrganizations();
        loadUsers();
      }, 500);
    } catch (err) {
      console.error('Delete organization failed', err);
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to delete organization: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  const submitUser = async () => {
    if (!userData.username || !userData.email || !userData.password) {
      setError('Please fill in all required fields');
      return;
    }

    if (!userData.org_id) {
      setError('Please select an organization');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      setError('Please enter a valid email address (e.g., user@example.com)');
      return;
    }

    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const payload = {
        username: userData.username,
        email: userData.email.trim().toLowerCase(), // Trim and lowercase email
        password: userData.password,
        full_name: userData.full_name || userData.username,
        role: userData.role || 'doctor',
        org_id: userData.org_id,
      };
      
      console.log('Submitting registration payload:', payload);
      const response = await apiClient.post('/users/register', payload);
      console.log('Registration response:', response);
      
      setMessage('User registered successfully!');
      setUserData({ username: '', email: '', password: '', full_name: '', role: 'doctor', org_id: '' });
      setShowRegisterForm(false);
      
      // Reload users
      setTimeout(() => loadUsers(), 500);
    } catch (err) {
      console.error('Register user error:', err);
      console.error('Error status:', err.response?.status);
      console.error('Error data:', err.response?.data);
      
      let errorMsg = 'Unknown error occurred';
      if (err.response?.data) {
        const data = err.response.data;
        console.log('Raw error data:', data);
        
        // Handle Pydantic validation errors (422)
        if (Array.isArray(data.detail)) {
          errorMsg = data.detail.map(d => `${d.loc?.join('.')}: ${d.msg}`).join('; ');
        } else if (typeof data.detail === 'string') {
          errorMsg = data.detail;
        } else if (typeof data === 'string') {
          errorMsg = data;
        } else if (data.message) {
          errorMsg = data.message;
        } else if (data.error) {
          errorMsg = data.error;
        } else {
          errorMsg = JSON.stringify(data);
        }
      } else if (err.message) {
        errorMsg = err.message;
      }
      
      setError('Failed to register user: ' + errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await authAPI.logout();
    navigate('/login', { replace: true });
  };

  // User management functions
  const loadUsers = async () => {
    setUsersLoading(true);
    try {
      const response = await apiClient.get('/users/');
      const usersList = Array.isArray(response.data) ? response.data : response.data.data || [];
      setUsers(usersList);
      
      // Load organizations from API
      try {
        const orgsResponse = await organizationsAPI.list(0, 100);
        const orgsList = Array.isArray(orgsResponse) ? orgsResponse : orgsResponse.data || [];
        // Store full org objects for the dropdown
        setOrganizations(orgsList.sort((a, b) => (a.name || '').localeCompare(b.name || '')));
      } catch (orgErr) {
        console.warn('Failed to load organizations from API:', orgErr);
        setOrganizations([]);
      }
    } catch (err) {
      console.error('Failed to load users:', err);
      setError('Failed to load users');
      setOrganizations([]);
    } finally {
      setUsersLoading(false);
    }
  };

  const loadOrganizations = async () => {
    setOrgsLoading(true);
    try {
      const orgsResponse = await organizationsAPI.list(0, 100);
      const orgsList = Array.isArray(orgsResponse) ? orgsResponse : orgsResponse.data || [];
      setOrganizationsList(orgsList.sort((a, b) => (a.name || '').localeCompare(b.name || '')));
      
      // Also update the organizations state with full objects for dropdown
      setOrganizations(orgsList.sort((a, b) => (a.name || '').localeCompare(b.name || '')));
    } catch (err) {
      console.error('Failed to load organizations:', err);
      setError('Failed to load organizations');
      setOrganizations([]);
    } finally {
      setOrgsLoading(false);
    }
  };

  const submitRegister = async () => {
    if (!userData.username || !userData.email || !userData.password) {
      setError('Please fill in all required fields');
      return;
    }

    if (!userData.org_id) {
      setError('Please select an organization');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      setError('Please enter a valid email address (e.g., user@example.com)');
      return;
    }

    saveScrollPosition();
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const payload = {
        username: userData.username,
        email: userData.email.trim().toLowerCase(),
        password: userData.password,
        full_name: userData.full_name || userData.username,
        role: userData.role || 'doctor',
        org_id: userData.org_id,
      };
      
      const response = await apiClient.post('/users/register', payload);
      setMessage('User registered successfully!');
      setUserData({ username: '', email: '', password: '', full_name: '', role: 'doctor', org_id: '' });
      setShowRegisterForm(false);
      await loadUsers();
    } catch (err) {
      console.error('Register user error:', err);
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to register: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (user) => {
    setEditingUser(user);
    setShowEditForm(true);
  };

  const submitEdit = async () => {
    if (!editingUser?.id) {
      setError('No user selected for editing');
      return;
    }
    
    saveScrollPosition();
    setLoading(true);
    try {
      console.log('Submitting edit for user:', editingUser.id, {
        email: editingUser.email,
        username: editingUser.username,
        full_name: editingUser.full_name,
        is_active: editingUser.is_active,
      });
      
      await apiClient.put(`/users/${editingUser.id}`, {
        email: editingUser.email,
        username: editingUser.username,
        full_name: editingUser.full_name,
        is_active: editingUser.is_active,
      });
      
      setMessage('User updated successfully');
      setShowEditForm(false);
      setEditingUser(null);
      await loadUsers();
    } catch (err) {
      console.error('Edit error:', err);
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to update: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    setLoading(true);
    try {
      await apiClient.delete(`/users/${userId}`);
      setMessage('User deleted successfully');
      await loadUsers();
    } catch (err) {
      const detail = err.response?.data?.detail || err.message;
      setError('Failed to delete: ' + detail);
    } finally {
      setLoading(false);
    }
  };

  if (isAuthChecking) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-gray-600 text-lg">Verifying access...</div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-red-600 mb-4">Access Denied</h2>
          <p className="text-gray-600">You must be logged in as a root user to access this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Admin Panel</h2>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition font-medium"
        >
          Logout
        </button>
      </div>

      <div className="mb-6">
        <button className={`px-4 py-2 mr-2 rounded font-semibold transition ${activeTab === 'org' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-900 hover:bg-gray-300'}`} onClick={() => setActiveTab('org')}>Organizations</button>
        <button className={`px-4 py-2 rounded font-semibold transition ${activeTab === 'users' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-900 hover:bg-gray-300'}`} onClick={() => setActiveTab('users')}>Users</button>
      </div>

      {message && <div className="p-3 bg-green-100 text-green-800 rounded mb-4">{message}</div>}
      {error && <div className="p-3 bg-red-100 text-red-800 rounded mb-4">{error}</div>}

      <div className="min-h-96">
        {activeTab === 'org' && (
        <div className="flex flex-col items-center justify-center py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Add New Organization</h2>
          <p className="text-gray-600 mb-8">Create a new organization in the system</p>
          <button 
            onClick={() => setShowOrgForm(!showOrgForm)}
            className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition shadow-md"
          >
            + Add Organization
          </button>

          {showOrgForm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Add New Organization</h3>
                  <button 
                    onClick={() => setShowOrgForm(false)}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Organization Name *</label>
                    <input 
                      name="name" 
                      value={orgData.name} 
                      onChange={handleOrgChange} 
                      placeholder="Enter organization name" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Address</label>
                    <input 
                      name="address" 
                      value={orgData.address} 
                      onChange={handleOrgChange} 
                      placeholder="Enter address" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Contact</label>
                    <input 
                      name="contact" 
                      value={orgData.contact} 
                      onChange={handleOrgChange} 
                      placeholder="Contact person / phone" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Description (Optional)</label>
                    <textarea 
                      name="description" 
                      value={orgData.description} 
                      onChange={handleOrgChange} 
                      placeholder="Enter organization description" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                      rows="3"
                    />
                  </div>

                  {message && <p className="text-sm text-green-600 font-semibold">{message}</p>}
                  {error && <p className="text-sm text-red-600 font-semibold">{error}</p>}

                  <div className="flex gap-3 pt-4">
                    <button 
                      onClick={() => setShowOrgForm(false)}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-900 rounded-lg hover:bg-gray-50 transition font-semibold"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={submitOrg} 
                      disabled={loading || !orgData.name} 
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition font-semibold"
                    >
                      {loading ? 'Creating...' : 'Create Organization'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Organizations List */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Organizations</h3>
            {orgsLoading ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <p className="text-gray-600">Loading organizations...</p>
              </div>
            ) : organizationsList.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <p className="text-gray-600">No organizations created yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-lg shadow">
                <table className="w-full">
                  <thead>
                    <tr className="bg-blue-600 text-white">
                      <th className="px-6 py-4 text-left font-semibold">Name</th>
                      <th className="px-6 py-4 text-left font-semibold">Address</th>
                      <th className="px-6 py-4 text-left font-semibold">Contact</th>
                      <th className="px-6 py-4 text-left font-semibold">Description</th>
                      <th className="px-6 py-4 text-center font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {organizationsList.map((org, index) => (
                      <tr key={org.id} className={`hover:bg-gray-50 transition ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                        <td className="px-6 py-4 text-gray-900 font-semibold">{org.name}</td>
                        <td className="px-6 py-4 text-gray-700 text-sm">{org.address || '-'}</td>
                        <td className="px-6 py-4 text-gray-700 text-sm">{org.contact || '-'}</td>
                        <td className="px-6 py-4 text-gray-700 text-sm break-words whitespace-normal max-w-md">{org.description || '-'}</td>
                        <td className="px-6 py-4 text-center space-x-2">
                          <button
                            onClick={() => {
                              setEditingOrg(org);
                              setShowEditOrgForm(true);
                            }}
                            className="inline-block px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => deleteOrgHandler(org.id, org.name)}
                            disabled={loading}
                            className="inline-block px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition font-medium"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {showEditOrgForm && editingOrg && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Edit Organization</h3>
                  <button 
                    onClick={() => {
                      setShowEditOrgForm(false);
                      setEditingOrg(null);
                    }}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Organization Name *</label>
                    <input 
                      value={editingOrg.name} 
                      onChange={(e) => setEditingOrg({...editingOrg, name: e.target.value})}
                      placeholder="Enter organization name" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Address</label>
                    <input 
                      value={editingOrg.address || ''} 
                      onChange={(e) => setEditingOrg({...editingOrg, address: e.target.value})}
                      placeholder="Enter address" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Contact</label>
                    <input 
                      value={editingOrg.contact || ''} 
                      onChange={(e) => setEditingOrg({...editingOrg, contact: e.target.value})}
                      placeholder="Contact person / phone" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Description (Optional)</label>
                    <textarea 
                      value={editingOrg.description || ''} 
                      onChange={(e) => setEditingOrg({...editingOrg, description: e.target.value})}
                      placeholder="Enter organization description" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 admin-input" 
                      rows="3"
                    />
                  </div>

                  {message && <p className="text-sm text-green-600 font-semibold">{message}</p>}
                  {error && <p className="text-sm text-red-600 font-semibold">{error}</p>}

                  <div className="flex gap-3 pt-4">
                    <button 
                      onClick={() => {
                        setShowEditOrgForm(false);
                        setEditingOrg(null);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-900 rounded-lg hover:bg-gray-50 transition font-semibold"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={submitUpdateOrg} 
                      disabled={loading || !editingOrg.name} 
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition font-semibold"
                    >
                      {loading ? 'Updating...' : 'Update Organization'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'users' && (
        <div className="bg-white p-6 rounded shadow">
          <div className="flex flex-col items-center justify-center py-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">User Management</h2>
            <p className="text-gray-600 mb-8">Manage and view all users in the system</p>
            <button 
              onClick={() => {
                setShowRegisterForm(!showRegisterForm);
                setShowEditForm(false);
              }}
              className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition shadow-md"
            >
              + Register User
            </button>
          </div>

          {showRegisterForm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Register New User</h3>
                  <button 
                    onClick={() => setShowRegisterForm(false)}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Username</label>
                    <input 
                      autoComplete="off"
                      placeholder="Enter username" 
                      value={userData.username}
                      onChange={(e) => setUserData({...userData, username: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Email</label>
                    <input 
                      autoComplete="off"
                      type="email"
                      placeholder="user@example.com" 
                      value={userData.email}
                      onChange={(e) => setUserData({...userData, email: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Password</label>
                    <input 
                      autoComplete="new-password"
                      type="password"
                      placeholder="Enter password" 
                      value={userData.password}
                      onChange={(e) => setUserData({...userData, password: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Full Name (Optional)</label>
                    <input 
                      placeholder="Enter full name" 
                      value={userData.full_name || ''}
                      onChange={(e) => setUserData({...userData, full_name: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Organization</label>
                    <select 
                      value={userData.org_id}
                      onChange={(e) => setUserData({...userData, org_id: e.target.value})}
                      disabled={usersLoading}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">
                        {usersLoading ? 'Loading organizations...' : 'Select an organization'}
                      </option>
                      {organizations.map((org) => (
                        <option key={org.id} value={org.id}>
                          {org.name}
                        </option>
                      ))}
                    </select>
                    {organizations.length === 0 && !usersLoading && (
                      <p className="mt-1 text-sm text-red-600">
                        No organizations found. Please create organizations first.
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Role</label>
                    <select 
                      value={userData.role}
                      onChange={(e) => setUserData({...userData, role: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="doctor">Doctor</option>
                      <option value="assistant">Assistant</option>
                      <option value="admin">Admin</option>
                    </select>
                  </div>

                  {message && <p className="text-sm text-green-600 font-semibold">{message}</p>}
                  {error && <p className="text-sm text-red-600 font-semibold">{error}</p>}

                  <div className="flex gap-3 pt-4">
                    <button 
                      onClick={() => setShowRegisterForm(false)}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-900 rounded-lg hover:bg-gray-50 transition font-semibold"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={submitRegister}
                      disabled={loading || !userData.org_id}
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition font-semibold"
                    >
                      {loading ? 'Registering...' : 'Register User'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {showEditForm && editingUser && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Edit User</h3>
                  <button 
                    onClick={() => {
                      setShowEditForm(false);
                      setEditingUser(null);
                    }}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Username</label>
                    <input 
                      autoComplete="off"
                      placeholder="Enter username" 
                      value={editingUser.username}
                      onChange={(e) => setEditingUser({...editingUser, username: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Email</label>
                    <input 
                      autoComplete="off"
                      type="email"
                      placeholder="user@example.com" 
                      value={editingUser.email}
                      onChange={(e) => setEditingUser({...editingUser, email: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-1">Full Name</label>
                    <input 
                      placeholder="Enter full name" 
                      value={editingUser.full_name || ''}
                      onChange={(e) => setEditingUser({...editingUser, full_name: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  <div className="space-y-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div>
                      <label className="block font-semibold text-gray-800 mb-2">User Account Status</label>
                      <p className="text-xs text-gray-600 mb-3">
                        {editingUser.is_active 
                          ? '✓ User can log in and access the system' 
                          : '✗ User account is disabled and cannot log in'}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-gray-600 min-w-10">Disabled</span>
                      <button
                        type="button"
                        onClick={() => setEditingUser({...editingUser, is_active: !editingUser.is_active})}
                        className={`relative inline-flex h-7 w-14 items-center rounded-full transition-all shadow-md hover:shadow-lg active:scale-95 ${
                          editingUser.is_active ? 'bg-green-500' : 'bg-gray-400'
                        }`}
                        title={editingUser.is_active ? 'Click to disable user' : 'Click to enable user'}
                      >
                        <span
                          className={`inline-block h-6 w-6 transform rounded-full bg-white shadow-lg transition-all ${
                            editingUser.is_active ? 'translate-x-7' : 'translate-x-0.5'
                          }`}
                        />
                      </button>
                      <span className="text-xs font-medium text-gray-600 min-w-10">Enabled</span>
                    </div>

                    <div className="pt-2 border-t border-gray-300">
                      <div className="flex items-center gap-2 text-sm">
                        <span className={`inline-block w-3 h-3 rounded-full ${
                          editingUser.is_active ? 'bg-green-500' : 'bg-red-500'
                        }`}></span>
                        <span className="font-semibold">
                          {editingUser.is_active ? 'Status: ACTIVE' : 'Status: INACTIVE'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {message && <p className="text-sm text-green-600 font-semibold">{message}</p>}
                  {error && <p className="text-sm text-red-600 font-semibold">{error}</p>}

                  <div className="flex gap-3 pt-4">
                    <button 
                      onClick={() => {
                        setShowEditForm(false);
                        setEditingUser(null);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-900 rounded-lg hover:bg-gray-50 transition font-semibold"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={submitEdit}
                      disabled={loading}
                      className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition font-semibold"
                    >
                      {loading ? 'Saving...' : 'Save Changes'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="mb-4 flex gap-2">
            <input 
              autoComplete="off"
              placeholder="Search by username, email, or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-3 py-2 border rounded"
            />
            <select 
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-2 border rounded"
            >
              <option value="All">All Roles</option>
              <option value="Root">Root</option>
              <option value="Admin">Admin</option>
              <option value="Doctor">Doctor</option>
              <option value="Assistant">Assistant</option>
            </select>
          </div>

          {usersLoading ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <p className="text-gray-600">Loading users...</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-lg shadow">
              <table className="w-full">
                <thead>
                  <tr className="bg-blue-600 text-white">
                    <th className="px-6 py-4 text-left font-semibold">Username</th>
                    <th className="px-6 py-4 text-left font-semibold">Email</th>
                    <th className="px-6 py-4 text-left font-semibold">Full Name</th>
                    <th className="px-6 py-4 text-left font-semibold">Role</th>
                    <th className="px-6 py-4 text-left font-semibold">Organization</th>
                    <th className="px-6 py-4 text-left font-semibold">Status</th>
                    <th className="px-6 py-4 text-center font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan="7" className="px-6 py-8 text-center text-gray-500">
                        No users found
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user, index) => (
                      <tr key={user.id} className={`hover:bg-gray-50 transition ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                        <td className="px-6 py-4 text-gray-900 font-semibold">{user.username}</td>
                        <td className="px-6 py-4 text-gray-700 text-sm">{user.email}</td>
                        <td className="px-6 py-4 text-gray-700 text-sm">{user.full_name || '-'}</td>
                        <td className="px-6 py-4">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                            user.role === 'root' ? 'bg-red-100 text-red-800' :
                            user.role === 'admin' ? 'bg-orange-100 text-orange-800' :
                            user.role === 'doctor' ? 'bg-blue-100 text-blue-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-gray-700 text-sm">{user.organization || '-'}</td>
                        <td className="px-6 py-4">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                            user.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {user.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center space-x-2">
                          <button 
                            onClick={() => startEdit(user)}
                            className="inline-block px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition font-medium"
                          >
                            Edit
                          </button>
                          <button 
                            onClick={() => deleteUser(user.id)}
                            className="inline-block px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition font-medium"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      </div>

      <style>{`
        /* Fix autofill background color */
        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus,
        input:-webkit-autofill:active {
          -webkit-box-shadow: 0 0 0 1000px white inset !important;
          box-shadow: 0 0 0 1000px white inset !important;
          -webkit-transition: background-color 5000s ease-in-out 0s !important;
          transition: background-color 5000s ease-in-out 0s !important;
        }
        
        input:-webkit-autofill {
          -webkit-text-fill-color: #1f2937 !important;
          color: #1f2937 !important;
        }
        
        input:-webkit-autofill::first-line {
          color: #1f2937 !important;
        }
      `}</style>
    </div>
  );
}
