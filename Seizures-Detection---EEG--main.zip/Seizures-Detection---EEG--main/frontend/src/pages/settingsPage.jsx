import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { usersAPI, authAPI } from '../services/api';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function SettingsPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userName, setUserName] = useState('User');
  const [activeSettingsTab, setActiveSettingsTab] = useState('Profile');
  const { theme, toggleTheme } = useTheme();

  // Fetch user data from /me API on mount
  useEffect(() => {
    const fetchUserData = async () => {
      setLoadingProfile(true);
      try {
        const userData = await authAPI.getCurrentUser();
        if (userData) {
          setUserName(userData.full_name || userData.username || 'User');
          setUserId(userData.id || '');
          setUsername(userData.username || '');
          setFullName(userData.full_name || userData.username || 'User');
          setEmail(userData.email || '');
          setProfessionalTitle(userData.title || '');
          setOrganization(userData.organization || '');
          setRole(userData.role || '');
          setIsActive(userData.is_active !== undefined ? userData.is_active : true);
          setCreatedAt(userData.created_at || '');
          setUpdatedAt(userData.updated_at || '');
        }
      } catch (error) {
        console.error('Failed to fetch user data from /me endpoint:', error);
        // Fallback to localStorage if API fails
        const user = JSON.parse(localStorage.getItem('user'));
        if (user && user.name) {
          setUserName(user.name);
        }
      } finally {
        setLoadingProfile(false);
      }
    };

    fetchUserData();
  }, []);

  // Profile form states
  const [userId, setUserId] = useState('');
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [professionalTitle, setProfessionalTitle] = useState('');
  const [organization, setOrganization] = useState('');
  const [role, setRole] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [createdAt, setCreatedAt] = useState('');
  const [updatedAt, setUpdatedAt] = useState('');
  const [loadingProfile, setLoadingProfile] = useState(false);

  const [saving, setSaving] = useState(false);

  const settingsTabs = [
    { name: 'Profile' },
    { name: 'Appearance' }
  ];

  const handleSaveChanges = async () => {
    setSaving(true);
    try {
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      const userId = currentUser.id || 1; // Fallback to 1 if no id stored
      
      await usersAPI.update(userId, {
        full_name: fullName,
        email: email,
        title: professionalTitle,
        organization: organization
      });
      
      alert('Changes saved successfully!');
    } catch (err) {
      console.error('Save failed', err);
      alert('Failed to save changes. See console for details.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="Settings" userName={userName} />

        {/* Content Area */}
        <main className="flex-1 overflow-hidden min-h-0 bg-gray-50 dark:bg-gray-900">
          <div className="flex h-full w-full bg-gray-50 dark:bg-gray-900">
            {/* Settings Sidebar */}
            <div className="w-72 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 p-6 flex flex-col h-full">
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Settings</h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">Manage your account and application preferences.</p>
              </div>

              <nav className="flex-1 overflow-auto">
                <ul className="space-y-1">
                  {settingsTabs.map((tab) => (
                    <li key={tab.name}>
                      <button
                        onClick={() => setActiveSettingsTab(tab.name)}
                        className={`w-full text-left px-4 py-3 rounded-lg transition ${
                          activeSettingsTab === tab.name
                            ? 'bg-blue-50 dark:bg-blue-900/30 text-gray-900 dark:text-blue-400 font-semibold border-l-4 border-blue-600'
                            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                      >
                        {tab.name}
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>

            {/* Settings Content */}
            <div className="flex-1 min-h-0 min-w-0 p-8 overflow-y-auto bg-gray-50 dark:bg-gray-900">
              {activeSettingsTab === 'Profile' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Profile Settings</h2>

                  {/* User Info Card */}
                  <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-lg p-6 mb-6 border border-blue-200 dark:border-blue-800">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">{fullName}</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm mb-2">{organization || 'No organization specified'}</p>
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          isActive 
                            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' 
                            : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
                        }`}>
                          {isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-400 capitalize">
                        {role}
                      </span>
                    </div>
                  </div>

                  {/* Profile Information - Read Only */}
                  <div className="space-y-6 bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Account Information</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Read-only profile information</p>
                      </div>
                      <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full">Read-only</span>
                    </div>

                    {/* Grid Layout for Fields */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* User ID */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          User ID
                        </label>
                        <input
                          type="text"
                          value={userId}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed font-mono text-xs"
                        />
                      </div>

                      {/* Username */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Username
                        </label>
                        <input
                          type="text"
                          value={username}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed"
                        />
                      </div>

                      {/* Full Name */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Full Name
                        </label>
                        <input
                          type="text"
                          value={fullName}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed"
                        />
                      </div>

                      {/* Email */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Email Address
                        </label>
                        <input
                          type="email"
                          value={email}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed"
                        />
                      </div>

                      {/* Organization */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Organization
                        </label>
                        <input
                          type="text"
                          value={organization}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed"
                        />
                      </div>

                      {/* Role */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Role
                        </label>
                        <input
                          type="text"
                          value={role}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed capitalize"
                        />
                      </div>

                      {/* Account Status */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Account Status
                        </label>
                        <input
                          type="text"
                          value={isActive ? 'Active' : 'Inactive'}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed"
                        />
                      </div>

                      {/* Created At */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Account Created
                        </label>
                        <input
                          type="text"
                          value={createdAt ? new Date(createdAt).toLocaleString() : 'N/A'}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed text-sm"
                        />
                      </div>

                      {/* Updated At */}
                      <div>
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Last Updated
                        </label>
                        <input
                          type="text"
                          value={updatedAt ? new Date(updatedAt).toLocaleString() : 'Never'}
                          disabled
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-600 dark:text-gray-400 cursor-not-allowed text-sm"
                        />
                      </div>
                    </div>

                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mt-6">
                      <p className="text-sm text-blue-800 dark:text-blue-300 flex items-start gap-2">
                        <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zm-11-1a1 1 0 11-2 0 1 1 0 012 0zM8 8a1 1 0 000 2h6a1 1 0 100-2H8zm0 4a1 1 0 100 2h3a1 1 0 100-2H8z" clipRule="evenodd" />
                        </svg>
                        <span>Your profile information is managed by your administrator. To change any of these details, please contact your system administrator.</span>
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeSettingsTab === 'Appearance' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">Appearance Settings</h2>

                  <div className="space-y-8">
                    {/* Theme Selection */}
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Theme</h3>
                      <div className="flex gap-6">
                        <button
                          onClick={() => toggleTheme()}
                          className={`group relative w-24 h-24 rounded-2xl transition-all duration-300 flex flex-col items-center justify-center gap-2 transform hover:scale-105 active:scale-95 ${
                            theme === 'light' 
                              ? 'bg-gradient-to-br from-yellow-50 to-white border-2 border-yellow-400 shadow-lg shadow-yellow-200 dark:shadow-yellow-900/30 ring-2 ring-yellow-300 scale-105' 
                              : 'bg-white dark:bg-gray-700 border-2 border-gray-300 dark:border-gray-600 hover:border-yellow-300 dark:hover:border-yellow-400 shadow-md hover:shadow-lg hover:shadow-yellow-200/50'
                          }`}
                          title="Light Mode"
                        >
                          <div className={`transition-all duration-300 ${theme === 'light' ? 'scale-100 text-yellow-500' : 'scale-90 text-gray-400 group-hover:text-yellow-400'}`}>
                            <Sun className="w-10 h-10" />
                          </div>
                          <span className={`text-xs font-bold transition-colors duration-300 ${theme === 'light' ? 'text-yellow-600' : 'text-gray-500 group-hover:text-yellow-600'}`}>
                            Light
                          </span>
                        </button>
                        <button
                          onClick={() => toggleTheme()}
                          className={`group relative w-24 h-24 rounded-2xl transition-all duration-300 flex flex-col items-center justify-center gap-2 transform hover:scale-105 active:scale-95 ${
                            theme === 'dark' 
                              ? 'bg-gradient-to-br from-slate-900 to-slate-950 border-2 border-indigo-500 shadow-lg shadow-indigo-500/40 ring-2 ring-indigo-400 scale-105' 
                              : 'bg-gray-100 dark:bg-gray-800 border-2 border-gray-300 dark:border-gray-600 hover:border-slate-500 dark:hover:border-slate-400 shadow-md hover:shadow-lg hover:shadow-indigo-500/20'
                          }`}
                          title="Dark Mode"
                        >
                          <div className={`transition-all duration-300 ${theme === 'dark' ? 'scale-100 text-indigo-300' : 'scale-90 text-gray-500 group-hover:text-indigo-500'}`}>
                            <Moon className="w-10 h-10" />
                          </div>
                          <span className={`text-xs font-bold transition-colors duration-300 ${theme === 'dark' ? 'text-indigo-300' : 'text-gray-600 dark:text-gray-400 group-hover:text-slate-700'}`}>
                            Dark
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}