import React, { useState, useEffect } from 'react';
import { authAPI, eegAPI, reportsAPI, usersAPI } from '../services/api';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function DashboardPage() {
  const [userName, setUserName] = useState('User');
  const [stats, setStats] = useState([
    { label: 'Total Patients', value: '-', color: 'text-blue-600' },
    { label: 'EEG Files', value: '-', color: 'text-blue-600' },
    { label: 'Reports', value: '-', color: 'text-blue-600' },
    { label: 'Model Accuracy', value: 'N/A', color: 'text-blue-600' }
  ]);

  useEffect(() => {
    loadUserName();
    fetchCounts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadUserName = async () => {
    try {
      const userData = await authAPI.getCurrentUser();
      if (userData) {
        setUserName(userData.full_name || userData.username || 'User');
      }
    } catch (err) {
      console.error('Failed to fetch user name:', err);
    }
  };

  const fetchCounts = async () => {
    try {
      const [eegList, reportsList, usersList] = await Promise.all([
        eegAPI.list(),
        reportsAPI.list(),
        usersAPI.list()
      ]);

      setStats([
        { label: 'Total Patients', value: Array.isArray(usersList) ? usersList.length : '-', color: 'text-blue-600' },
        { label: 'EEG Files', value: Array.isArray(eegList) ? eegList.length : '-', color: 'text-blue-600' },
        { label: 'Reports', value: Array.isArray(reportsList) ? reportsList.length : '-', color: 'text-blue-600' },
        { label: 'Model Accuracy', value: 'N/A', color: 'text-blue-600' }
      ]);
    } catch (err) {
      console.error('Failed to fetch dashboard counts', err);
      // Set default values when API fails
      setStats([
        { label: 'Total Patients', value: '-', color: 'text-blue-600' },
        { label: 'EEG Files', value: '-', color: 'text-blue-600' },
        { label: 'Reports', value: '-', color: 'text-blue-600' },
        { label: 'Model Accuracy', value: 'N/A', color: 'text-blue-600' }
      ]);
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar userName={userName} />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <Header pageName="Dashboard" userName={userName} />
        <main className="flex-1 overflow-y-auto min-h-0 p-8 bg-gray-50 dark:bg-gray-900">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Welcome {userName}!</h1>
            <p className="text-gray-600 dark:text-gray-400">
              This is your EEG visualization dashboard here you can analyze and view EEG data.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition">
                <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">{stat.label}</div>
                <div className={`text-4xl font-bold ${stat.color}`}>{stat.value}</div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}