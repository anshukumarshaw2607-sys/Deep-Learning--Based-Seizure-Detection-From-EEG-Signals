/**
 * API service using axios with environment-based configuration
 */
import axios from 'axios';
import config from '../config/env';

// Track last activity time for auto-refresh
let lastActivityTime = Date.now();

// Logout callback to cleanup timers/listeners
let onLogoutCallback = null;

// Register a callback to be called when logout happens
const setOnLogoutCallback = (callback) => {
  onLogoutCallback = callback;
};

// Create axios instance with base configuration
const apiClient = axios.create({
  baseURL: config.apiUrl,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 300000, // 300 seconds (5 minutes) - seizure detection can take 2-3+ minutes on Windows
});

// Request interceptor - Add auth token to requests and track activity
apiClient.interceptors.request.use(
  (config) => {
    // Update activity timestamp on every request
    lastActivityTime = Date.now();
    
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - Handle errors globally with auto-refresh
let isRefreshing = false;
let refreshSubscribers = [];

const onRefreshed = (token) => {
  refreshSubscribers.forEach((callback) => callback(token));
  refreshSubscribers = [];
};

const addRefreshSubscriber = (callback) => {
  refreshSubscribers.push(callback);
};

apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    // Handle 401 Unauthorized with auto-refresh
    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        // Queue request while refreshing
        return new Promise((resolve) => {
          addRefreshSubscriber((token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            resolve(apiClient(originalRequest));
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshToken = localStorage.getItem('refresh_token');
        
        if (!refreshToken) {
          // No refresh token available - redirect to login
          throw new Error('No refresh token');
        }

        // Try to refresh the token
        const refreshResponse = await axios.post(
          `${config.apiUrl}/auth/refresh`,
          { refresh_token: refreshToken },
          { headers: { 'Content-Type': 'application/json' } }
        );

        const { access_token, refresh_token } = refreshResponse.data;

        // Update stored tokens
        localStorage.setItem('access_token', access_token);
        localStorage.setItem('refresh_token', refresh_token);

        // Update default header
        apiClient.defaults.headers.common.Authorization = `Bearer ${access_token}`;

        isRefreshing = false;
        onRefreshed(access_token);

        // Retry original request with new token
        originalRequest.headers.Authorization = `Bearer ${access_token}`;
        return apiClient(originalRequest);
      } catch (refreshError) {
        isRefreshing = false;
        
        // Refresh failed - clear tokens and redirect to login
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        localStorage.removeItem('user');

        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }

        return Promise.reject(refreshError);
      }
    }

    // Log errors in development
    if (config.isDevelopment) {
      console.error('API Error:', error.response?.data || error.message);
    }

    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: async (username, password) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    
    const response = await apiClient.post('/auth/login', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    if (response.data.access_token) {
      localStorage.setItem('access_token', response.data.access_token);
      if (response.data.refresh_token) {
        localStorage.setItem('refresh_token', response.data.refresh_token);
      }
    }
    
    return response.data;
  },

  register: async (userData) => {
    const response = await apiClient.post('/auth/register', userData);
    return response.data;
  },

  getCurrentUser: async () => {
    const response = await apiClient.get('/auth/me');
    return response.data;
  },

  logout: async () => {
    try {
      // Call backend logout endpoint to revoke tokens
      await apiClient.post('/auth/logout');
    } catch (err) {
      console.error('Logout API call failed:', err);
      // Continue with local cleanup even if API fails
    } finally {
      // Always clear local storage
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      localStorage.removeItem('user');
      
      // Call cleanup callback to stop all timers and listeners
      if (onLogoutCallback) {
        onLogoutCallback();
      }
    }
  },

  // Verify token validity (lightweight check)
  verifyToken: async () => {
    try {
      const response = await apiClient.post('/auth/verify');
      return response.data;
    } catch (err) {
      console.error('Token verification failed:', err);
      return { valid: false };
    }
  },

  // Get comprehensive token information
  getTokenInfo: async () => {
    try {
      const response = await apiClient.get('/auth/token-info');
      return response.data;
    } catch (err) {
      console.error('Failed to get token info:', err);
      return null;
    }
  },

  // Refresh tokens manually
  refreshToken: async () => {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }

    try {
      const response = await axios.post(
        `${config.apiUrl}/auth/refresh`,
        { refresh_token: refreshToken },
        { headers: { 'Content-Type': 'application/json' } }
      );

      const { access_token, refresh_token: newRefreshToken } = response.data;

      // Update stored tokens
      localStorage.setItem('access_token', access_token);
      if (newRefreshToken) {
        localStorage.setItem('refresh_token', newRefreshToken);
      }

      // Update axios default header
      apiClient.defaults.headers.common.Authorization = `Bearer ${access_token}`;

      return response.data;
    } catch (err) {
      // Silently fail on 401 - it means refresh token is invalid
      if (err.response?.status !== 401) {
        console.warn('Token refresh failed:', err.message);
      }
      // Clear tokens on refresh failure
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      localStorage.removeItem('user');
      throw err;
    }
  },

  // Set callback to be called on logout (for cleanup)
  setOnLogoutCallback: (callback) => {
    setOnLogoutCallback(callback);
  },
};

// Users API
export const usersAPI = {
  create: async (userData) => {
    const response = await apiClient.post('/users/register', userData);
    return response.data;
  },

  list: async (skip = 0, limit = 100) => {
    const response = await apiClient.get('/users', {
      params: { skip, limit },
    });
    return response.data;
  },

  get: async (userId) => {
    const response = await apiClient.get(`/users/${userId}`);
    return response.data;
  },

  update: async (userId, userData) => {
    const response = await apiClient.put(`/users/${userId}`, userData);
    return response.data;
  },

  delete: async (userId) => {
    const response = await apiClient.delete(`/users/${userId}`);
    return response.data;
  },

  // Doctor-Assistant relationship endpoints
  assignAssistantToDoctor: async (doctorId, assistantId) => {
    const response = await apiClient.post('/users/doctor-assistants', {
      doctor_id: doctorId,
      assistant_id: assistantId,
    });
    return response.data;
  },

  removeAssistantFromDoctor: async (assistantId) => {
    const response = await apiClient.delete(`/users/doctor-assistants/${assistantId}`);
    return response.data;
  },

  // Get all doctors
  getDoctors: async (skip = 0, limit = 100) => {
    const response = await apiClient.get('/users/doctors', {
      params: { skip, limit },
    });
    return response.data;
  },

  // Get all assistants
  getAssistants: async (skip = 0, limit = 100) => {
    const response = await apiClient.get('/users/assistants', {
      params: { skip, limit },
    });
    return response.data;
  },

  // Get assistants assigned to a specific doctor
  getDoctorAssistants: async (doctorId) => {
    const response = await apiClient.get(`/users/doctor-assistants/by-doctor/${doctorId}`);
    return response.data;
  },

  getMyAssignedDoctor: async () => {
    const response = await apiClient.get('/users/doctor-assistants/my-doctor');
    return response.data;
  },
};

// Organizations API
export const organizationsAPI = {
  create: async (orgData) => {
    const response = await apiClient.post('/organizations/', orgData);
    return response.data;
  },

  list: async (skip = 0, limit = 100) => {
    const response = await apiClient.get('/organizations/', {
      params: { skip, limit },
    });
    return response.data;
  },

  get: async (orgId) => {
    const response = await apiClient.get(`/organizations/${orgId}`);
    return response.data;
  },

  update: async (orgId, orgData) => {
    const response = await apiClient.put(`/organizations/${orgId}`, orgData);
    return response.data;
  },

  delete: async (orgId) => {
    const response = await apiClient.delete(`/organizations/${orgId}`);
    return response.data;
  },
};

// EEG API
export const eegAPI = {
  upload: async (file, onUploadProgress) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await apiClient.post('/eeg/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (onUploadProgress) {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          onUploadProgress(percentCompleted);
        }
      },
    });
    
    return response.data;
  },

  list: async (skip = 0, limit = 100) => {
    const response = await apiClient.get('/eeg', {
      params: { skip, limit },
    });
    return response.data;
  },

  get: async (eegId) => {
    const response = await apiClient.get(`/eeg/${eegId}`);
    return response.data;
  },

  analyze: async (eegId, modelVersion = null) => {
    const response = await apiClient.post(`/eeg/${eegId}/analyze`, {
      eeg_data_id: eegId,
      model_version: modelVersion,
    });
    return response.data;
  },

  getAnalyses: async (eegId) => {
    const response = await apiClient.get(`/eeg/${eegId}/analyses`);
    return response.data;
  },

  delete: async (eegId) => {
    const response = await apiClient.delete(`/eeg/${eegId}`);
    return response.data;
  },
};

// Patients API
export const patientsAPI = {
  create: async (patientData) => {
    const response = await apiClient.post('/patients', patientData);
    return response.data;
  },

  list: async (skip = 0, limit = 100, doctorId = null, includeDeleted = false) => {
    const params = { skip, limit, include_deleted: includeDeleted };
    if (doctorId) {
      params.doctor_id = doctorId;
    }
    const response = await apiClient.get('/patients', { params });
    return response.data;
  },

  get: async (patientId) => {
    const response = await apiClient.get(`/patients/${patientId}`);
    return response.data;
  },

  update: async (patientId, patientData) => {
    const response = await apiClient.put(`/patients/${patientId}`, patientData);
    return response.data;
  },

  delete: async (patientId, hardDelete = false) => {
    const response = await apiClient.delete(`/patients/${patientId}`, {
      params: { hard_delete: hardDelete },
    });
    return response.data;
  },
};

// EEG Files API
export const eegFilesAPI = {
  upload: async (file, patientId, description = null, notes = null, onUploadProgress = null) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('patient_id', patientId);
    if (description) formData.append('description', description);
    if (notes) formData.append('notes', notes);

    const response = await apiClient.post('/eeg-files/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (onUploadProgress) {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          onUploadProgress(percentCompleted);
        }
      },
    });

    return response.data;
  },

  list: async (skip = 0, limit = 100, patientId = null, uploadedBy = null, includeDeleted = false) => {
    const params = { skip, limit, include_deleted: includeDeleted };
    if (patientId) params.patient_id = patientId;
    if (uploadedBy) params.uploaded_by = uploadedBy;
    const response = await apiClient.get('/eeg-files', { params });
    return response.data;
  },

  get: async (fileId) => {
    const response = await apiClient.get(`/eeg-files/${fileId}`);
    return response.data;
  },

  download: async (fileId) => {
    const response = await apiClient.get(`/eeg-files/${fileId}/download`, {
      responseType: 'blob',
    });
    return response.data;
  },

  update: async (fileId, fileData) => {
    const response = await apiClient.put(`/eeg-files/${fileId}`, fileData);
    return response.data;
  },

  delete: async (fileId, hardDelete = false) => {
    const response = await apiClient.delete(`/eeg-files/${fileId}`, {
      params: { hard_delete: hardDelete },
    });
    return response.data;
  },
};

// Reports API
export const reportsAPI = {
  create: async (reportData) => {
    const response = await apiClient.post('/reports', reportData);
    return response.data;
  },

  list: async (skip = 0, limit = 100, reportType = null, status = null) => {
    const params = { skip, limit };
    if (reportType) params.report_type = reportType;
    if (status) params.status = status;
    
    const response = await apiClient.get('/reports', { params });
    return response.data;
  },

  get: async (reportId) => {
    const response = await apiClient.get(`/reports/${reportId}`);
    return response.data;
  },

  update: async (reportId, updateData) => {
    const response = await apiClient.patch(`/reports/${reportId}`, updateData);
    return response.data;
  },

  delete: async (reportId) => {
    await apiClient.delete(`/reports/${reportId}`);
  },

  getByEegFile: async (eegFileId) => {
    const response = await apiClient.get(`/reports/eeg-file/${eegFileId}`);
    return response.data;
  },

  // Export functions
  exportPDF: async (reportId) => {
    const response = await apiClient.get(`/reports/${reportId}/export/pdf`, {
      responseType: 'blob',
    });
    return response.data;
  },

  exportCSV: async (reportId) => {
    const response = await apiClient.get(`/reports/${reportId}/export/csv`, {
      responseType: 'blob',
    });
    return response.data;
  },

  exportJSON: async (reportId) => {
    const response = await apiClient.get(`/reports/${reportId}/export/json`);
    return response.data;
  },

  downloadPDF: async (reportId) => {
    const blob = await reportsAPI.exportPDF(reportId);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `report-${reportId}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.parentNode.removeChild(link);
    window.URL.revokeObjectURL(url);
  },

  downloadCSV: async (reportId) => {
    const blob = await reportsAPI.exportCSV(reportId);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `report-${reportId}.csv`);
    document.body.appendChild(link);
    link.click();
    link.parentNode.removeChild(link);
    window.URL.revokeObjectURL(url);
  },
};

// EEG Analysis/Preprocessing API
export const eegAnalysisAPI = {
  preprocess: async (fileId) => {
    // Use extended timeout for preprocessing (can take 6-10 seconds for ICA alone)
    const response = await apiClient.get(`/analysis/preprocess/${fileId}`, {
      timeout: 120000, // 120 seconds (2 minutes)
    });
    return response.data;
  },

  getRawSignal: async (fileId, duration = 10) => {
    const response = await apiClient.get(`/analysis/analyze/raw/${fileId}`, {
      params: { duration },
    });
    return response.data;
  },

  getFilteredSignal: async (fileId, lFreq = 0.1, hFreq = 30) => {
    const response = await apiClient.get(`/analysis/analyze/filtered/${fileId}`, {
      params: { l_freq: lFreq, h_freq: hFreq },
    });
    return response.data;
  },

  getPowerSpectrum: async (fileId, fmin = 0.5, fmax = 30) => {
    const response = await apiClient.get(`/analysis/analyze/psd/${fileId}`, {
      params: { fmin, fmax },
    });
    return response.data;
  },

  getFrequencyBands: async (fileId) => {
    const response = await apiClient.get(`/analysis/analyze/bands/${fileId}`);
    return response.data;
  },
};

// Seizure Detection API
export const seizureDetectionAPI = {
  detect: async (fileId, saveOutput = true) => {
    // Extended timeout for ML model processing (can take 2-3+ minutes on Windows)
    const response = await apiClient.post(`/detection/${fileId}`, null, {
      params: { save_output: saveOutput },
      timeout: 300000, // 300 seconds (5 minutes) for seizure detection
    });
    return response.data;
  },

  downloadCSVBI: async (fileId) => {
    // Download the CSV_BI annotation file from detection results
    try {
      const response = await apiClient.get(`/detection/${fileId}/download`, {
        responseType: 'blob',
      });
      return response.data;
    } catch (err) {
      console.error('Failed to download CSV_BI file:', err);
      throw err;
    }
  },

  listAllReports: async () => {
    // List all seizure detection reports from CSV_BI files
    try {
      const response = await apiClient.get('/detection/reports/list');
      return response.data;
    } catch (err) {
      console.error('Failed to list reports:', err);
      throw err;
    }
  },

  deleteReport: async (fileId) => {
    // Delete a seizure detection report (CSV_BI file)
    try {
      await apiClient.delete(`/detection/${fileId}/report`);
    } catch (err) {
      console.error(`Failed to delete report for file ${fileId}:`, err);
      throw err;
    }
  },

  exportPDF: async (fileId, clinicalNotes = '') => {
    // Export seizure detection report as PDF with optional clinical notes
    try {
      const response = await apiClient.get(`/detection/${fileId}/report/pdf`, {
        responseType: 'blob',
        params: clinicalNotes ? { clinical_notes: clinicalNotes } : {}
      });
      return response.data;
    } catch (err) {
      console.error(`Failed to export PDF for file ${fileId}:`, err);
      throw err;
    }
  },
};

export default apiClient;

