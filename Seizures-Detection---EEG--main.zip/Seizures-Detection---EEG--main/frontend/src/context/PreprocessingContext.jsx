import React, { createContext, useContext, useState, useEffect } from 'react';

const PreprocessingContext = createContext();

export const PreprocessingProvider = ({ children }) => {
  const [preprocessingData, setPreprocessingData] = useState(null);
  const [currentFileId, setCurrentFileId] = useState(null);

  const updatePreprocessingData = (data, fileId) => {
    setPreprocessingData(data);
    setCurrentFileId(fileId);
  };

  const clearPreprocessingData = () => {
    setPreprocessingData(null);
    setCurrentFileId(null);
  };

  // Monitor logout by checking if token is removed
  useEffect(() => {
    const checkLogout = () => {
      const token = localStorage.getItem('access_token');
      if (!token) {
        clearPreprocessingData();
      }
    };

    // Check on mount and whenever storage changes
    window.addEventListener('storage', checkLogout);
    
    return () => {
      window.removeEventListener('storage', checkLogout);
    };
  }, []);

  return (
    <PreprocessingContext.Provider
      value={{
        preprocessingData,
        currentFileId,
        updatePreprocessingData,
        clearPreprocessingData,
      }}
    >
      {children}
    </PreprocessingContext.Provider>
  );
};

export const usePreprocessing = () => {
  const context = useContext(PreprocessingContext);
  if (!context) {
    throw new Error('usePreprocessing must be used within PreprocessingProvider');
  }
  return context;
};
