import React, { createContext, useContext, useState, useCallback } from 'react';
import { seizureDetectionAPI } from '../services/api';
import { useNotification } from './NotificationContext';

const AnalysisContext = createContext();

export const AnalysisProvider = ({ children }) => {
  const [analysisState, setAnalysisState] = useState({});
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [selectedFileId, setSelectedFileId] = useState('');
  const { addNotification } = useNotification();

  // Start analysis in background (non-blocking)
  // Backend automatically saves CSV_BI file and creates report
  const startAnalysis = useCallback(async (fileId, fileName) => {
    // Initialize analysis state for this file
    setAnalysisState(prev => ({
      ...prev,
      [fileId]: {
        status: 'analyzing',
        fileId,
        fileName,
        results: null,
        error: null,
        startTime: new Date(),
      }
    }));

    // Start the analysis request in background WITHOUT waiting
    // This returns immediately, allowing navigation to continue
    seizureDetectionAPI.detect(fileId, true).then(
      (response) => {
        console.log('Analysis response received:', response);
        
        // Analysis completed successfully (runs in background)
        setAnalysisState(prev => ({
          ...prev,
          [fileId]: {
            ...prev[fileId],
            status: 'completed',
            results: response,
            completedTime: new Date(),
          }
        }));

        // Add notification - backend has already saved CSV_BI file
        addNotification({
          type: 'success',
          title: 'Seizure Detection Complete',
          message: `Analysis of "${fileName}" is complete. ${response.seizure_count} seizures detected.`,
          fileId,
        });
      }
    ).catch((err) => {
      // Analysis failed (runs in background)
      console.error('Analysis failed:', err);
      
      const errorMessage = err.response?.data?.detail || err.message || 'Analysis failed';
      
      // Update state with error
      setAnalysisState(prev => ({
        ...prev,
        [fileId]: {
          ...prev[fileId],
          status: 'failed',
          error: errorMessage,
          completedTime: new Date(),
        }
      }));

      // Add error notification
      addNotification({
        type: 'error',
        title: 'Seizure Detection Failed',
        message: errorMessage,
        fileId,
      });
    });
    
    // Return immediately - don't wait for the analysis to complete
  }, [addNotification]);

  // Get analysis for specific file
  const getAnalysis = useCallback((fileId) => {
    return analysisState[fileId] || null;
  }, [analysisState]);

  // Get all active analyses
  const getActiveAnalyses = useCallback(() => {
    return Object.values(analysisState).filter(a => a.status === 'analyzing');
  }, [analysisState]);

  // Check if any analysis is currently running
  const isAnyAnalysisActive = useCallback(() => {
    return getActiveAnalyses().length > 0;
  }, [getActiveAnalyses]);

  // Clear analysis for specific file
  const clearAnalysis = useCallback((fileId) => {
    setAnalysisState(prev => {
      const newState = { ...prev };
      delete newState[fileId];
      return newState;
    });
  }, []);

  return (
    <AnalysisContext.Provider
      value={{
        analysisState,
        selectedPatientId,
        setSelectedPatientId,
        selectedFileId,
        setSelectedFileId,
        startAnalysis,
        getAnalysis,
        getActiveAnalyses,
        isAnyAnalysisActive,
        clearAnalysis,
      }}
    >
      {children}
    </AnalysisContext.Provider>
  );
};

export const useAnalysis = () => {
  const context = useContext(AnalysisContext);
  if (!context) {
    throw new Error('useAnalysis must be used within AnalysisProvider');
  }
  return context;
};
