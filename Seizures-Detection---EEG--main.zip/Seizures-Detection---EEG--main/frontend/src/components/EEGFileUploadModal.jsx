import React, { useState } from 'react';
import { X, FileUp, AlertCircle, Loader } from 'lucide-react';

const EEGFileUploadModal = ({
  isOpen,
  onClose,
  onUpload,
  patients,
  userRole,
  currentUserId,
}) => {
  const [file, setFile] = useState(null);
  const [patientId, setPatientId] = useState('');
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const userPatients =
    userRole === 'doctor' || userRole === 'assistant'
      ? patients.filter(p => p.doctor_id === currentUserId)
      : patients;

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setError('');

    // Validate file type
    if (!selectedFile.name.toLowerCase().endsWith('.edf')) {
      setError('Only .edf files are allowed');
      return;
    }

    // Validate file size (100MB)
    const maxSize = 100 * 1024 * 1024;
    if (selectedFile.size > maxSize) {
      setError(`File size exceeds 100MB limit. File size: ${(selectedFile.size / (1024 * 1024)).toFixed(2)}MB`);
      return;
    }

    setFile(selectedFile);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!file) {
      setError('Please select a file');
      return;
    }

    if (!patientId) {
      setError('Please select a patient');
      return;
    }

    try {
      setUploading(true);
      await onUpload({
        file,
        patientId,
        description: description || null,
        notes: notes || null,
        onUploadProgress: (progress) => setUploadProgress(progress),
      });
      
      // Reset form
      setFile(null);
      setPatientId('');
      setDescription('');
      setNotes('');
      setUploadProgress(0);
      onClose();
    } catch (err) {
      setError(err.message || 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-slate-900 rounded-lg shadow-lg w-full max-w-md mx-4 border border-slate-700">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h2 className="text-xl font-bold text-white">Upload EEG File</h2>
          <button
            onClick={onClose}
            disabled={uploading}
            className="text-slate-400 hover:text-white disabled:opacity-50"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-900/30 border border-red-700 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-200">{error}</p>
            </div>
          )}

          {/* File Input */}
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              EEG File (.edf)
            </label>
            <div className="relative">
              <input
                type="file"
                accept=".edf"
                onChange={handleFileChange}
                disabled={uploading}
                className="hidden"
                id="file-input"
              />
              <label
                htmlFor="file-input"
                className={`flex items-center justify-center px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
                  file
                    ? 'border-green-500 bg-green-900/20'
                    : 'border-slate-600 bg-slate-800 hover:border-blue-500'
                } ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className="text-center">
                  <FileUp className={`w-6 h-6 mx-auto mb-2 ${file ? 'text-green-400' : 'text-slate-400'}`} />
                  <p className="text-sm font-medium text-slate-300">
                    {file ? file.name : 'Click to select EEG file'}
                  </p>
                  <p className="text-xs text-slate-500">Max 100MB</p>
                </div>
              </label>
            </div>
          </div>

          {/* Patient Selection */}
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Patient <span className="text-red-400">*</span>
            </label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              disabled={uploading}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
            >
              <option value="">Select a patient...</option>
              {userPatients.map(patient => (
                <option key={patient.id} value={patient.id}>
                  {patient.full_name}
                </option>
              ))}
            </select>
            {userPatients.length === 0 && (
              <p className="text-xs text-slate-400 mt-1">No patients available</p>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Description (optional)
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., Baseline recording"
              disabled={uploading}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 placeholder-slate-500"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Notes (optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any relevant notes..."
              rows={3}
              disabled={uploading}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 placeholder-slate-500 resize-none"
            />
          </div>

          {/* Upload Progress */}
          {uploading && uploadProgress > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-300">Uploading...</span>
                <span className="text-sm font-medium text-blue-400">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              disabled={uploading}
              className="flex-1 px-4 py-2 bg-slate-800 border border-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors disabled:opacity-50 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading || !file || !patientId}
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50 font-medium flex items-center justify-center gap-2"
            >
              {uploading ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <FileUp className="w-4 h-4" />
                  Upload
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EEGFileUploadModal;
