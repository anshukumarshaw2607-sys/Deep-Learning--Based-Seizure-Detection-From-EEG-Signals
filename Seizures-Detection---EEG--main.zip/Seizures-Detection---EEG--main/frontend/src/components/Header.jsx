import React from 'react';
import { ChevronRight } from 'lucide-react';

export default function Header({ pageName, userName }) {
  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-8 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
          <span>Home</span>
          <ChevronRight className="w-4 h-4" />
          <span className="text-gray-900 dark:text-white font-medium">{pageName}</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-gray-700 dark:text-gray-300 font-medium">{userName}</span>
        </div>
      </div>
    </header>
  );
}
