import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { authAPI } from '../services/api';

export default function Sidebar({ userName }) {
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'EEG Data', path: '/eeg-data' },
    { name: 'EEG Visualization', path: '/eeg-visualization' },
    { name: 'Analysis', path: '/analysis' },
    { name: 'Reports', path: '/reports' },
    { name: 'Settings', path: '/settings' }
  ];

  const handleLogout = async () => {
    await authAPI.logout();
    navigate('/login', { replace: true });
  };

  return (
    <>
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle cx="50" cy="50" r="45" fill="#3B82F6" opacity="0.1"/>
                <path d="M 50 5 A 45 45 0 0 1 95 50" fill="none" stroke="#EF4444" strokeWidth="8" strokeLinecap="round"/>
                <path d="M 95 50 A 45 45 0 0 1 50 95" fill="none" stroke="#3B82F6" strokeWidth="8" strokeLinecap="round"/>
                <path d="M 50 95 A 45 45 0 0 1 5 50" fill="none" stroke="#10B981" strokeWidth="8" strokeLinecap="round"/>
                <text x="50" y="58" textAnchor="middle" fontSize="20" fontWeight="bold" fill="#1F2937">EEG</text>
              </svg>
            </div>
            <span className="text-xl font-bold text-gray-900 dark:text-white">Quick EEG Labs</span>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.name}>
                <button
                  onClick={() => navigate(item.path)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition ${
                    location.pathname === item.path
                      ? 'bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-300 font-semibold'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  {item.name}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={handleLogout}
            className="w-full px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition font-medium flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
