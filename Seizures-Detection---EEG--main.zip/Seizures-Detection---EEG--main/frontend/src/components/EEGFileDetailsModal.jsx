import React, { useState } from 'react';
import { X, Edit2, Save, RotateCcw, Download, Trash2, Loader } from 'lucide-react';

const EEGFileDetailsModal = ({
  isOpen,
  onClose,
  file,
  patientName,
  isEditing,
  onEdit,
  onCancel,
  onSave,
  onDownload,
  onDelete,
  userRole,
  showHardDeleteOption,
}) => {
  const [description, setDescription] = useState(file.description || '');
  const [notes, setNotes] = useState(file.notes || '');
  const [saving, setS] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    try {
      setError('');
      setS(true);
      await onSave(file.id, {
        description: description || null,
        notes: notes || null,
      });
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save changes');
    } finally {
      setS(false);
    }
  };

  const handleDownload = async () => {
    try {
      setError('');
      setDownloading(true);
      await onDownload();
    } catch (err) {
      setError('Failed to download file');
    } finally {
      setDownloading(false);
    }
  };

  const handleDelete = async (hardDelete = false) => {
    try {
      setError('');
      setDeleting(true);
      await onDelete(file.id, hardDelete);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to delete file');
    } finally {
      setDeleting(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const canEdit = ['doctor', 'admin', 'root'].includes(userRole);

  if (!isOpen || !file) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-lg w-full max-w-2xl mx-4 border border-gray-200 dark:border-slate-700 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-slate-700 sticky top-0 bg-white dark:bg-slate-900">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">File Details</h2>
          <button
            onClick={onClose}
            className="text-gray-400 dark:text-slate-400 hover:text-gray-600 dark:hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-100 dark:bg-red-900/30 border border-red-300 dark:border-red-700 rounded-lg">
              <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
            </div>
          )}

          {/* File Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">File Information</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Filename</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{file.original_filename}</p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Patient</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{patientName}</p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">File Size</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{formatFileSize(file.file_size)}</p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Uploaded By</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{file.uploader_name || '-'}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Upload Date</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{formatDate(file.created_at)}</p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Last Modified</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{file.updated_at ? formatDate(file.updated_at) : 'Never'}</p>
              </div>
            </div>
          </div>

          {/* Recording Metadata */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recording Metadata</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Duration</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">
                  {file.recording_duration ? `${Math.round(file.recording_duration)}s` : '-'}
                </p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Sampling Rate</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">
                  {file.sampling_rate ? `${file.sampling_rate} Hz` : '-'}
                </p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Channels</p>
                <p className="text-sm text-gray-900 dark:text-white font-medium">{file.number_of_channels || '-'}</p>
              </div>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Status</p>
                <p className={`text-sm font-medium ${file.is_deleted ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                  {file.is_deleted ? 'Deleted' : 'Active'}
                </p>
              </div>
            </div>

            {file.channel_names && (
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-2">Channel Names</p>
                <p className="text-sm text-gray-700 dark:text-slate-300 font-mono break-all">{file.channel_names}</p>
              </div>
            )}
          </div>

          {/* Description & Notes - Editable */}
          {isEditing ? (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Edit Information</h3>
              
              <div>
                <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                  Description
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe this recording"
                  className="w-full px-4 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-gray-400 dark:placeholder-slate-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                  Notes
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any notes..."
                  rows={4}
                  className="w-full px-4 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-gray-400 dark:placeholder-slate-500 resize-none"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Information</h3>
              
              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Description</p>
                <p className="text-sm text-gray-700 dark:text-slate-300">{file.description || 'No description'}</p>
              </div>

              <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
                <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">Notes</p>
                <p className="text-sm text-gray-700 dark:text-slate-300">{file.notes || 'No notes'}</p>
              </div>
            </div>
          )}

          {/* Hash Info */}
          <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
            <p className="text-xs text-gray-600 dark:text-slate-400 mb-1">File Hash (SHA256)</p>
            <p className="text-xs text-gray-600 dark:text-slate-400 font-mono break-all">{file.file_hash || '-'}</p>
          </div>
        </div>

        {/* Footer - Actions */}
        <div className="border-t border-gray-200 dark:border-slate-700 p-6 bg-gray-50 dark:bg-slate-800 space-y-3">
          {isEditing && (
            <div className="flex items-center gap-3">
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50 font-medium flex items-center justify-center gap-2"
              >
                {saving ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Changes
                  </>
                )}
              </button>
              <button
                onClick={onCancel}
                disabled={saving}
                className="flex-1 px-4 py-2 bg-gray-300 dark:bg-slate-700 hover:bg-gray-400 dark:hover:bg-slate-600 text-gray-900 dark:text-white rounded-lg transition-colors disabled:opacity-50 font-medium flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Cancel
              </button>
            </div>
          )}

          <div className="flex items-center gap-3">
            {!isEditing && canEdit && (
              <button
                onClick={onEdit}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium flex items-center justify-center gap-2"
              >
                <Edit2 className="w-4 h-4" />
                Edit
              </button>
            )}

            <button
              onClick={handleDownload}
              disabled={downloading}
              className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50 font-medium flex items-center justify-center gap-2"
            >
              {downloading ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Downloading...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download
                </>
              )}
            </button>

            {canEdit && (
              <button
                onClick={() => handleDelete(false)}
                disabled={deleting}
                className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50 font-medium flex items-center justify-center gap-2"
              >
                {deleting ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </>
                )}
              </button>
            )}

            {showHardDeleteOption && (
              <button
                onClick={() => handleDelete(true)}
                disabled={deleting}
                title="Permanently delete file from database"
                className="px-4 py-2 bg-red-900 hover:bg-red-800 disabled:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50 font-medium text-xs"
              >
                {deleting ? 'Deleting...' : 'Hard Delete'}
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-gray-300 dark:bg-slate-700 hover:bg-gray-400 dark:hover:bg-slate-600 text-gray-900 dark:text-white rounded-lg transition-colors font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default EEGFileDetailsModal;
