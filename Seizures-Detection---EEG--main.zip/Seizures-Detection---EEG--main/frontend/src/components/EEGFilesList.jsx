import React, { useState } from 'react';
import { Download, Eye, Trash2, Loader } from 'lucide-react';

const EEGFilesList = ({
  files,
  patients,
  doctors,
  loading,
  total,
  skip,
  limit,
  filters,
  userRole,
  onViewDetails,
  onDownload,
  onFilterChange,
  onPageChange,
  showFilterOptions,
}) => {
  const [downloadingId, setDownloadingId] = useState(null);

  const handleDownload = async (file) => {
    setDownloadingId(file.id);
    try {
      await onDownload(file);
    } finally {
      setDownloadingId(null);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getPatientName = (patientId) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.full_name || 'Unknown';
  };

  const getDoctorName = (doctorId) => {
    const doctor = doctors.find(d => d.id === doctorId);
    return doctor?.full_name || 'Unknown';
  };

  const totalPages = Math.ceil(total / limit);
  const currentPage = Math.floor(skip / limit) + 1;

  return (
    <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg overflow-hidden">
      {/* Filters */}
      {showFilterOptions && (
        <div className="p-6 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800">
          <h3 className="text-gray-900 dark:text-white font-semibold mb-4">Filters</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Patient Filter */}
            <select
              value={filters.patientId || ''}
              onChange={(e) => onFilterChange({ ...filters, patientId: e.target.value || null })}
              className="px-4 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Patients</option>
              {patients.map(patient => (
                <option key={patient.id} value={patient.id}>
                  {patient.full_name}
                </option>
              ))}
            </select>

            {/* Doctor Filter (admin/root only) */}
            {(userRole === 'admin' || userRole === 'root') && (
              <select
                value={filters.uploadedBy || ''}
                onChange={(e) => onFilterChange({ ...filters, uploadedBy: e.target.value || null })}
                className="px-4 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Uploaders</option>
                {doctors.map(doctor => (
                  <option key={doctor.id} value={doctor.id}>
                    Dr. {doctor.full_name}
                  </option>
                ))}
              </select>
            )}

            {/* Include Deleted Filter */}
            <label className="flex items-center gap-2 text-gray-900 dark:text-white cursor-pointer">
              <input
                type="checkbox"
                checked={filters.includeDeleted}
                onChange={(e) => onFilterChange({ ...filters, includeDeleted: e.target.checked })}
                className="w-4 h-4 rounded"
              />
              <span className="text-sm">Include Deleted</span>
            </label>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader className="w-8 h-8 text-blue-500 animate-spin" />
          </div>
        ) : files.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-slate-400">No EEG files found</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Patient</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">File Name</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Duration</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Channels</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Size</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Uploaded</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 dark:text-slate-300">Uploader</th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-slate-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-slate-700">
              {files.map((file) => (
                <tr key={file.id} className="hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {getPatientName(file.patient_id)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-900 dark:text-white">{file.original_filename}</span>
                      {file.description && (
                        <span className="text-xs text-gray-500 dark:text-slate-500">{file.description}</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    {file.recording_duration ? `${Math.round(file.recording_duration)}s` : '-'}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    {file.number_of_channels || '-'}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    {formatFileSize(file.file_size)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    {formatDate(file.created_at)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-slate-300">
                    {file.uploader_name || '-'}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => onViewDetails(file)}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDownload(file)}
                        disabled={downloadingId === file.id}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300 disabled:opacity-50"
                        title="Download file"
                      >
                        {downloadingId === file.id ? (
                          <Loader className="w-4 h-4 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {!loading && files.length > 0 && (
        <div className="px-6 py-4 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 flex items-center justify-between">
          <div className="text-sm text-gray-600 dark:text-slate-400">
            Showing {skip + 1} to {Math.min(skip + limit, total)} of {total} files
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPageChange(Math.max(0, skip - limit))}
              disabled={skip === 0}
              className="px-3 py-1 rounded-lg bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600 text-gray-900 dark:text-white text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <div className="text-sm text-gray-600 dark:text-slate-400">
              Page {currentPage} of {totalPages}
            </div>
            <button
              onClick={() => onPageChange(skip + limit)}
              disabled={skip + limit >= total}
              className="px-3 py-1 rounded-lg bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600 text-gray-900 dark:text-white text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EEGFilesList;
