import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../services/api';

/**
 * UserProtectedRoute - Enforces authentication for regular user pages
 * Redirects to login if not authenticated
 */
export default function UserProtectedRoute({ children }) {
  const navigate = useNavigate();
  const [isAuthorized, setIsAuthorized] = useState(null);
  const [loading, setLoading] = useState(true);
  const [checkCount, setCheckCount] = useState(0);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');
        
        if (!token) {
          setIsAuthorized(false);
          setLoading(false);
          // Delay navigation slightly to prevent race conditions
          setTimeout(() => navigate('/login', { replace: true }), 100);
          return;
        }

        try {
          // First try to get current user with existing token
          const user = await authAPI.getCurrentUser();
          if (user) {
            setIsAuthorized(true);
          } else {
            setIsAuthorized(false);
            setLoading(false);
            setTimeout(() => navigate('/login', { replace: true }), 100);
          }
          setLoading(false);
        } catch (err) {
          // If getCurrentUser fails and we have refresh token, try to refresh
          if (refreshToken && err.response?.status === 401 && checkCount < 1) {
            console.info('Token expired, attempting refresh...');
            try {
              await authAPI.refreshToken();
              // Retry auth check after refresh
              setCheckCount(prev => prev + 1);
              return;
            } catch (refreshErr) {
              console.error('Token refresh failed:', refreshErr);
              // Fall through to unauthorized
            }
          }
          
          console.error('Auth check failed:', err);
          setIsAuthorized(false);
          setLoading(false);
          setTimeout(() => navigate('/login', { replace: true }), 100);
        }
      } catch (err) {
        console.error('Unexpected auth check error:', err);
        setIsAuthorized(false);
        setLoading(false);
        setTimeout(() => navigate('/login', { replace: true }), 100);
      }
    };

    checkAuth();
  }, [navigate, checkCount]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-gray-600 mb-4">Verifying access...</div>
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-red-600 mb-4">Access Denied</h2>
          <p className="text-gray-600">You are not authenticated.</p>
          <p className="text-sm text-gray-500 mt-2">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return children;
}
