import React from 'react';
import { X, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { useNotification } from '../context/NotificationContext';

export default function NotificationCenter() {
  const { notifications, removeNotification } = useNotification();

  return (
    <div className="fixed top-4 right-4 z-50 max-w-md space-y-3">
      {notifications.map((notif) => (
        <div
          key={notif.id}
          className={`rounded-lg shadow-lg p-4 flex items-start gap-3 animate-in slide-in-from-top-2 ${
            notif.type === 'success'
              ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
              : notif.type === 'error'
              ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
              : 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800'
          }`}
        >
          {/* Icon */}
          <div>
            {notif.type === 'success' && (
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
            )}
            {notif.type === 'error' && (
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
            )}
            {notif.type === 'info' && (
              <Loader className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5 animate-spin" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3 className={`font-semibold ${
              notif.type === 'success'
                ? 'text-green-900 dark:text-green-200'
                : notif.type === 'error'
                ? 'text-red-900 dark:text-red-200'
                : 'text-blue-900 dark:text-blue-200'
            }`}>
              {notif.title}
            </h3>
            {notif.message && (
              <p className={`text-sm mt-1 ${
                notif.type === 'success'
                  ? 'text-green-800 dark:text-green-300'
                  : notif.type === 'error'
                  ? 'text-red-800 dark:text-red-300'
                  : 'text-blue-800 dark:text-blue-300'
              }`}>
                {notif.message}
              </p>
            )}
          </div>

          {/* Close Button */}
          <button
            onClick={() => removeNotification(notif.id)}
            className={`flex-shrink-0 mt-0.5 ${
              notif.type === 'success'
                ? 'text-green-600 dark:text-green-400 hover:text-green-700'
                : notif.type === 'error'
                ? 'text-red-600 dark:text-red-400 hover:text-red-700'
                : 'text-blue-600 dark:text-blue-400 hover:text-blue-700'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
