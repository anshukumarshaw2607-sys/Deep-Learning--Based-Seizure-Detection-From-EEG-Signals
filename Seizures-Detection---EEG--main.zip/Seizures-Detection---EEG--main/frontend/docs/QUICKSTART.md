# Frontend Quick Start Guide

Get the EEG Seizure Detection frontend up and running in minutes!

## ⚡ Prerequisites

- **Node.js 18+** installed
- **npm** or **yarn** package manager
- **Backend API** running (see `../backend/docs/QUICKSTART.md`)

## 🚀 Quick Setup (3 minutes)

### Step 1: Navigate to Frontend Directory
```bash
cd frontend
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Environment
```bash
# Copy the example environment file
cp env.example .env

# Edit .env and set at minimum:
# VITE_ENVIRONMENT=development
```

**Minimal `.env` for development:**
```bash
VITE_ENVIRONMENT=development
```

> 💡 **Tip:** The API automatically points to `http://localhost:8000/api` in development mode. No need to configure it manually!

### Step 4: Start Development Server
```bash
npm run dev
```

The app will be available at **http://localhost:5173**

### Step 5: Verify It's Running
- Open http://localhost:5173 in your browser
- You should see the login page
- Make sure the backend is running on http://localhost:8000

## ✅ Success Checklist

- [ ] Node.js 18+ installed (`node --version`)
- [ ] Dependencies installed (`npm install`)
- [ ] `.env` file created with `VITE_ENVIRONMENT=development`
- [ ] Backend API running on http://localhost:8000
- [ ] Frontend running on http://localhost:5173
- [ ] Login page loads successfully

## 🛠️ Common Commands

### Development
```bash
# Start development server
npm run dev

# Run with production mode (for testing)
npm run dev -- --mode production
```

### Building
```bash
# Build for production
npm run build

# Build with production mode explicitly
npm run build:prod

# Preview production build locally
npm run preview
```

### Code Quality
```bash
# Run ESLint
npm run lint
```

## 🔧 Troubleshooting

### Issue: "Cannot find module" errors
**Solution:** Reinstall dependencies:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: API requests failing / CORS errors
**Solution:** 
1. Verify backend is running on http://localhost:8000
2. Check backend CORS configuration
3. Ensure `VITE_ENVIRONMENT=development` in `.env`
4. Restart the dev server after changing `.env`

### Issue: Environment variables not working
**Solution:**
- Environment variables must be prefixed with `VITE_` to be accessible
- Restart the dev server after changing `.env` file
- Check `src/config/env.js` for auto-configuration logic

### Issue: Port 5173 already in use
**Solution:** Vite will automatically try the next available port, or you can specify:
```bash
npm run dev -- --port 3000
```

### Issue: Build fails
**Solution:**
- Ensure all dependencies are installed: `npm install`
- Check for TypeScript/ESLint errors: `npm run lint`
- Verify Node.js version is 18+: `node --version`

## 📝 Environment Variables

### Development (Minimal)
```bash
VITE_ENVIRONMENT=development
# API automatically points to http://localhost:8000/api
```

### Production
```bash
VITE_ENVIRONMENT=production
VITE_BACKEND_URL=https://your-backend.onrender.com
# Or use VITE_API_BASE_URL=https://your-backend.onrender.com/api
```

> **Note:** All environment variables must be prefixed with `VITE_` to be accessible in the frontend code.

## 🎯 Project Structure

```
frontend/
├── src/
│   ├── config/          # Environment configuration
│   ├── services/        # API services
│   ├── pages/           # Page components
│   ├── utils/           # Utilities and constants
│   ├── App.jsx          # Main app component
│   └── main.jsx         # Entry point
├── public/              # Static assets
├── .env                 # Environment variables (create from env.example)
└── package.json         # Dependencies and scripts
```

## 🔌 API Integration

The frontend uses a centralized API service (`src/services/api.js`):

```javascript
import { authAPI, eegAPI, reportsAPI } from './services/api';

// Login
const response = await authAPI.login(username, password);

// Upload EEG file
const result = await eegAPI.upload(file, (progress) => {
  console.log(`Upload: ${progress}%`);
});

// Get analyses
const analyses = await eegAPI.getAnalyses(eegId);
```

## 🚢 Production Deployment

### Build for Production
```bash
npm run build
```

The build output will be in the `dist/` directory.

### Render Deployment

1. **Build Command:**
   ```bash
   cd frontend && npm install && npm run build
   ```

2. **Publish Directory:**
   ```
   frontend/dist
   ```

3. **Environment Variables:**
   - `VITE_ENVIRONMENT=production`
   - `VITE_BACKEND_URL=https://your-backend.onrender.com`

See `README.md` for complete deployment instructions.

## 📚 Next Steps

- **Read Full Documentation:** See `README.md` for complete frontend documentation
- **API Service:** Check `src/services/api.js` for available API methods
- **Configuration:** See `src/config/env.js` for environment configuration
- **Backend Setup:** See `../backend/docs/QUICKSTART.md` to set up the backend

## 💡 Tips

- The dev server includes hot module replacement (HMR) - changes appear instantly
- API requests are automatically proxied to `http://localhost:8000` in development
- Use React DevTools browser extension for component debugging
- Check browser console for environment configuration in development mode
- Environment variables are baked into the build at build time (not runtime)

## 🔐 Authentication

The frontend handles authentication automatically:
- Tokens stored in `localStorage`
- Automatically included in API requests
- Redirects to login on 401 errors
- Supports "Remember Me" functionality

---

**Need Help?** Check the other documentation files:
- `README.md` - Complete frontend documentation
- `CONFIGURATION_SUMMARY.md` - Configuration overview
- `../backend/docs/QUICKSTART.md` - Backend setup guide

