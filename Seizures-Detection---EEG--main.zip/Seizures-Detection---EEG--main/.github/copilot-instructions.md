## Brief orientation

This repository is an EEG seizure-detection web application with a FastAPI Python backend and a React + Vite frontend. The backend contains the ML inference service and REST API; the frontend is a single-page React app that calls the backend API.

Keep instructions concise and actionable and reference the specific files below when making changes.

## Big-picture architecture (what to know first)

- Backend: `backend/` — FastAPI app. Entry: `backend/main.py`. API router: `backend/app/api/v1/api.py`.
- Frontend: `frontend/` — React + Vite. Entry: `frontend/src/main.jsx` and `frontend/src/App.jsx`. Central API client: `frontend/src/services/api.js`.
- ML: `backend/app/services/ml_service.py` — placeholder implementation; real model loading should use `MODEL_PATH` from env (see `backend/app/core/config.py`).
- Config: `backend/app/core/config.py` — Pydantic settings and many `resolved_*` helpers (CORS, directories, DB URL). Many behaviors are environment-driven (`ENVIRONMENT`, `RENDER`, `FRONTEND_URL`).

## Where code flows meet (critical integration points)

- API endpoints are mounted under `/api/v1` (see `API_V1_STR` in `config.py`). Main router: `backend/app/api/v1/api.py`.
- Frontend uses `config.apiUrl` (from `frontend/src/config/env.js`) and `frontend/src/services/api.js` to talk to backend endpoints like:
  - `POST /api/v1/auth/login` (auth)
  - `POST /api/v1/eeg/upload` (file upload, multipart/form-data)
  - `POST /api/v1/eeg/{id}/analyze` (trigger analysis)
- JWT tokens: backend issues tokens; frontend stores them as `access_token` in `localStorage` and axios adds them via an interceptor in `api.js`.

## Development & debug commands (explicit)

- Backend (recommended):
  - Create venv, install deps: `python -m venv venv` then `venv\Scripts\activate` then `pip install -r requirements.txt` (run from `backend/`).
  - Dev server (Invoke task): `invoke dev` (uses uvicorn with reload).
  - Direct uvicorn: `uvicorn main:app --reload --host 0.0.0.0 --port 8000` (run from `backend/`).
  - Alembic migrations: `alembic upgrade head` (migrations live under `backend/alembic/`).
- Frontend:
  - Install and run dev server: `cd frontend && npm install && npm run dev` (Vite hosts at `http://localhost:5173`).
  - Build for production: `npm run build` (publish `frontend/dist`).

## Project-specific conventions and patterns

- Environment-driven config: `backend/app/core/config.py` uses BaseSettings and provides `resolved_*` properties (e.g., `resolved_upload_dir`, `resolved_cors_origins`) — prefer modifying env vars or `env.example` rather than hard-coding paths.
- Render-aware behavior: Settings check `RENDER` and `RENDER_EXTERNAL_HOSTNAME` — use these when adding deployment logic.
- ML placeholders: `ml_service.py` currently returns dummy results if `MODEL_PATH` isn't set. Implement `_load_model`, `_preprocess_eeg`, and `_postprocess_prediction` here to add real inference.
- API surface: endpoints are organized in `backend/app/api/v1/endpoints/*.py` — follow their patterns for adding new routes (router per resource + service layer in `backend/app/services`).

## Files to consult for common tasks (examples)

- Add/change API routes: `backend/app/api/v1/api.py`, `backend/app/api/v1/endpoints/*.py`.
- Change auth/token logic: `backend/app/core/security.py` and `frontend/src/services/api.js` (axios interceptors expect `access_token`).
- Implement ML inference: `backend/app/services/ml_service.py` and model path via `.env` key `MODEL_PATH`.
- Adjust CORS or host rules: `backend/app/core/config.py` (see `resolved_cors_origins`, `resolved_allowed_hosts`).

## Helpful examples (copyable snippets)

- Upload example (frontend): `eegAPI.upload(file)` uses multipart/form-data and reports progress via `onUploadProgress` (see `frontend/src/services/api.js`).
- Health check: `GET /` and `GET /health` are present in `backend/main.py`.

## Safety and scope for AI edits

- Prefer non-breaking, minimal edits. When adding features that change database models, include an Alembic migration (`invoke migrations-auto --message "desc"`) and run tests/migrations.
- For ML changes, keep a development fallback (existing placeholder) while wiring real models behind `MODEL_PATH`.

## Quick verification checklist after edits

1. Backend runs: `invoke dev` or `uvicorn main:app --reload` (no import errors).
2. Frontend runs: `cd frontend && npm run dev` and successfully calls backend (auth/login or `/health`).
3. If DB models changed, `alembic upgrade head` applies migrations.

---

If any part of this file is unclear or you want more examples (e.g., typical unit-test patterns, suggested places to add ML unit tests, or CI hooks), tell me which area to expand and I will update this file.
