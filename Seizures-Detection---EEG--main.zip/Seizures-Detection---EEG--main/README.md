# 🧠 EEG-Based Epilepsy and Seizure Detection (On-Going)

A **smart diagnostic web platform** built with **FastAPI** and **React**, designed to detect epileptic seizures from EEG data using a **ResNet-Based Model**.  
Developed as part of the Final Year Project (FYP) at **COMSATS University Islamabad, Lahore Campus**, this research-driven system aims to assist in early and reliable seizure detection—especially in under-resourced clinical environments.

---

## 🌟 Core Highlights

- ⚙️ **FastAPI Backend Architecture** — Lightweight, high-performance Python backend managing EEG file uploads, model inference, and user sessions.  
- 🧠 **ResNet Deep Learning Model** — Trained on TUH EEG dataset for seizure classification, integrated directly into the backend for local inference.  
- 📈 **EEG Processing Pipeline** — Preprocessing (filtering, normalization), feature extraction, and model evaluation handled in Python.  
- 🖥️ **Interactive Web Interface** — React frontend for EEG upload, visualization, and displaying model predictions in real-time.  
- 🗂️ **Secure Storage & Reporting** — Persistent file storage on Render Disk and PostgreSQL metadata tracking with downloadable files and reports.  
- ☁️ **End-to-End Deployment on Render** — Frontend, backend, and database hosted on a single Render setup for low-latency communication.

---

## 🛠️ Tech Stack

| Layer             | Technologies Used                         |
|------------------|-------------------------------------------|
| 💻 Frontend       | React.js (TypeScript, Vite)               |
| 🔧 Backend        | FastAPI (Python)                          |
| 🤖 ML Model       | TensorFlow / PyTorch (ResNet Architecture)|
| 🗃️ Database       | PostgreSQL (via Render)                   |
| 💾 File Storage    | Render Persistent Disk                    |
| 🔒 Security       | JWT Authentication, bcrypt Password Hashing|

---

## 🎯 Goals

- Automate seizure detection using a trained ResNet model on EEG signals  
- Offer an accessible diagnostic tool for low-resource clinical setups  
- Provide interpretable model outputs and automated report generation  
- Demonstrate full-stack ML deployment in a real-world healthcare use case  

---

## 🚀 System Workflow

1. **User Login** → Secure, role-based access for clinicians or researchers  
2. **EEG Upload** → Users upload `.edf` or `.csv` EEG data files  
3. **Model Inference** → FastAPI backend runs the ResNet model for seizure detection  
4. **Visualization** → Frontend plots EEG signals and highlights detected seizure zones  
5. **Reporting** → Backend generates detailed diagnostic reports stored on Render Disk

## 🔒 Security Features

- **JWT Authentication:** Secure token-based authentication
- **CORS Protection:** Environment-based CORS configuration
- **Trusted Host Validation:** Production mode host header validation
- **Password Hashing:** bcrypt for secure password storage

---

## ⚙️ Deployment Overview (Render)

| Component      | Deployment Type       | Description |
|----------------|-----------------------|-------------|
| **Frontend**   | Render Web Service     | React-based interface |
| **Backend**    | Render Web Service     | FastAPI app exposing REST endpoints |
| **Database**   | Render PostgreSQL      | Stores user data, reports, and metadata |
| **File Storage** | Render Persistent Disk | Stores EEG files and generated reports |

**Continuous Deployment:**  
Every push to the GitHub main branch automatically triggers a new build and deploy on Render.

### 📚 Deployment Documentation

For detailed deployment instructions, see:
- **[RENDER_DEPLOYMENT.md](/backend/docs/RENDER_DEPLOYMENT.md)** - Complete step-by-step deployment guide
- **[DEPLOYMENT_CHECKLIST.md](/backend/docs/DEPLOYMENT_CHECKLIST.md)** - Quick deployment checklist
- **[MODEL_STORAGE_GUIDE.md](/backend/docs/MODEL_STORAGE_GUIDE.md)** - Guide for storing ML models on Render disk

**Quick Start:**
1. Create PostgreSQL database on Render
2. Deploy backend service (see [RENDER_DEPLOYMENT.md](./RENDER_DEPLOYMENT.md))
3. Deploy frontend service
4. Configure CORS and environment variables
5. Run database migrations
6. Create initial admin user

---

## 🎓 Developed By

👨‍💻 **Rizwan Khalid** (`SP22-BSE-064`)  
👨‍💻 **Hamza Akhtar** (`SP22-BSE-086`)  
📚 **Supervisor:** Mr. Muhammad Sharjeel  
🏫 **COMSATS University Islamabad, Lahore Campus**  
🗓️ **Session 2022–2026**

---

> ✨ _Advancing intelligent seizure detection through deep learning, modern web technologies, and purpose-driven research._
