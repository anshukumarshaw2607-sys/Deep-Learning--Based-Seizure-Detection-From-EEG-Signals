# 🚀 EEG Data Page - Quick Start Guide

## Access the Page

**URL:** `http://localhost:5174/eeg-data` (after login)

---

## Features at a Glance

### 📤 Upload EEG File

- Click **"Upload EEG File"** button
- Select `.edf` file (max 100MB)
- Choose patient
- (Optional) Add description and notes
- Click **"Upload"**
- Progress bar shows upload status

### 📋 View Files

- Table displays all accessible files
- Shows: Patient, Filename, Duration, Channels, Size, Date, Uploader
- Click 👁 icon to view details
- Click ⬇️ icon to download

### 🔍 Filter & Search

- **Select Patient:** Filter by specific patient
- **Select Uploader:** Filter by who uploaded (admin/root)
- **Include Deleted:** Show archived files
- Filters reset pagination to page 1

### 📖 View Details

- Click 👁 icon on any file
- See all metadata and auto-extracted info
- Download file
- Edit description/notes (if authorized)
- Delete file (soft or hard)

### ✏️ Edit Metadata

1. Click 👁 to view details
2. Click "Edit" button
3. Modify description/notes
4. Click "Save Changes"
5. File updated in system

### ⬇️ Download File

- Click ⬇️ icon in table row OR
- Open file details → Click "Download"
- Browser auto-saves file as `.edf`

### 🗑️ Delete File

- **Soft Delete** (anyone): Archives file
  - File still exists but hidden from normal view
  - Can be recovered
- **Hard Delete** (root only): Permanent deletion
  - Cannot be recovered
  - Removes from database and filesystem

---

## Role Capabilities

### 👨‍⚕️ Doctor

```
✅ See own patients' files
✅ Upload new files
✅ Edit own files
✅ Download files
✅ Soft delete own files
❌ Cannot see other doctors' files
❌ Cannot hard delete
```

### 👔 Admin

```
✅ See organization patients' files
✅ Upload files
✅ Edit files
✅ Download files
✅ Filter by patient/doctor
✅ Soft delete files
❌ Cannot hard delete
```

### 🔐 Root

```
✅ See all system files
✅ Upload any file
✅ Edit any file
✅ Download any file
✅ Filter by any patient/doctor
✅ Soft delete any file
✅ Hard delete any file
```

---

## Keyboard Shortcuts & Tips

- **Tab:** Navigate between fields
- **Enter:** Submit forms
- **Escape:** Close modals
- **Click outside:** Close modals (most)
- **Pagination:** Use Previous/Next buttons
- **Hover:** See button descriptions in tooltips

---

## Common Tasks

### Task: Upload a patient's EEG recording

1. Click "Upload EEG File"
2. Drag-drop or click to select `.edf` file
3. Select patient from dropdown
4. Add description (e.g., "Baseline recording")
5. Click "Upload"

### Task: Find all files for a specific patient

1. Use "Select Patient" filter
2. Choose patient name
3. Table updates to show only their files
4. Results reset to page 1

### Task: Download a file for offline analysis

1. Find file in table
2. Click ⬇️ download icon
3. Loading indicator appears
4. Browser saves file automatically

### Task: Archive a suspicious file

1. Find file in table
2. Click 👁 to view details
3. Click "Delete" button (red)
4. Confirm deletion
5. File archived (not visible unless "Include Deleted" checked)

### Task: View file recording details

1. Click 👁 on file
2. Scroll to "Recording Metadata" section
3. See:
   - Duration (seconds)
   - Sampling rate (Hz)
   - Number of channels
   - Channel names (e.g., Fp1, Fp2, etc.)
   - File hash (verification)

---

## Troubleshooting

### Issue: "File format error"

**Solution:** Ensure uploading a `.edf` file (European Data Format), not `.csv` or other format

### Issue: "File too large"

**Solution:** File exceeds 100MB limit. Try compressing or splitting the file

### Issue: "Patient not found"

**Solution:** Selected patient doesn't exist or you don't have access. Choose another patient

### Issue: "Failed to load files"

**Solution:** Check internet connection, verify backend API is running

### Issue: "Cannot see other doctor's files"

**Solution:** This is expected - doctors only see their own patients' files. Use admin account for org-wide view

### Issue: Download not starting

**Solution:** Check browser download settings, clear browser cache, try in incognito mode

---

## Page Layout

```
┌─────────────────────────────────────────┐
│ Page Title: "EEG Data Management"       │
│ Description by role                     │
├─────────────────────────────────────────┤
│ [Upload EEG File] Button                │
├─────────────────────────────────────────┤
│ Filters (if authorized):                │
│ [Select Patient] [Select Uploader]      │
│ [✓] Include Deleted                     │
├─────────────────────────────────────────┤
│ File List Table:                        │
│ Patient | Filename | Duration | Channels│
│ Size | Upload Date | Uploader | Actions│
├─────────────────────────────────────────┤
│ Pagination:                             │
│ [Previous] Page 1 of 5 [Next]           │
│ Showing 1-10 of 47 files                │
└─────────────────────────────────────────┘
```

---

## Data Displayed in Table

| Column    | Description                        |
| --------- | ---------------------------------- |
| Patient   | Patient name from database         |
| File Name | Original filename + description    |
| Duration  | Recording length in seconds        |
| Channels  | Number of EEG electrodes           |
| Size      | File size (B, KB, MB, GB)          |
| Uploaded  | Date and time uploaded             |
| Uploader  | Name of person who uploaded        |
| Actions   | View (👁) and Download (⬇️) buttons |

---

## Modal Details

### Upload Modal

```
Title: "Upload EEG File"
Fields:
  • EEG File (.edf) - required
  • Patient - required, dropdown
  • Description - optional text
  • Notes - optional textarea
Buttons:
  • Cancel
  • Upload (with progress)
```

### Details Modal

```
Title: "File Details"
Sections:
  • File Information (4 cards)
  • Recording Metadata (4 cards)
  • Channel Names (if available)
  • File Hash
  • Description (editable in edit mode)
  • Notes (editable in edit mode)
Buttons:
  • Edit (if authorized)
  • Download
  • Delete
  • Hard Delete (root only)
  • Close
```

---

## Best Practices

1. **Use Descriptions:** Add descriptive text to help identify recordings
2. **Archive Old Files:** Use soft delete for old recordings (not permanent)
3. **Verify Uploads:** Check file details after uploading
4. **Filter Results:** Use filters to reduce table size for better performance
5. **Regular Backups:** Download important files regularly

---

## Color Legend

- 🟦 **Blue** - Primary actions (Upload, View, Edit)
- 🟩 **Green** - Download/Success actions
- 🟥 **Red** - Delete/Warning actions
- 🟫 **Gray/Slate** - Neutral/Secondary buttons

---

## Performance Tips

1. Each page shows 10 files - use pagination for large datasets
2. Apply filters to reduce data loaded
3. Use specific patient filter instead of viewing all
4. Close unused modals
5. Clear browser cache if slow

---

## Security Notes

- ✅ All operations require authentication
- ✅ Role-based access control enforced
- ✅ File hashes verify integrity
- ✅ Soft delete prevents accidental loss
- ✅ Hard delete only for root user
- ✅ API tokens stored securely in localStorage

---

## Support

For issues or questions:

1. Check error messages carefully
2. Review browser console for details
3. Verify backend API is running
4. Check your user role and permissions
5. Try in incognito mode to clear cache

---

**Version:** 1.0  
**Last Updated:** November 19, 2025  
**Status:** ✅ Production Ready
