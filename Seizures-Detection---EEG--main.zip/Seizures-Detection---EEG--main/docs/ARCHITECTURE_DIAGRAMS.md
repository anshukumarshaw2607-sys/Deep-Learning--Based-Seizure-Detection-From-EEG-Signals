# EEG Preprocessing System Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    EEG SEIZURE DETECTION APP                    │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────────────┐           ┌──────────────────────────┐
│   FRONTEND (React)       │           │   BACKEND (FastAPI)      │
├──────────────────────────┤           ├──────────────────────────┤
│ EEG Visualization Page   │◄────────► │ Preprocessing Endpoints  │
│ - File Selection         │  HTTP     │ - /analysis/preprocess   │
│ - Process Button         │  REST     │ - /analysis/analyze/*    │
│ - 5 Viz Tabs             │           │                          │
│ - Charts & Analysis      │           │ EEGPreprocessingService  │
│                          │           │ - Load EDF               │
│ eegAnalysisAPI           │           │ - Filter & ICA           │
│ - preprocess()           │           │ - PSD & Bands            │
│ - getRawSignal()         │           │                          │
│ - getFilteredSignal()    │           │ Permission Check         │
│ - getPowerSpectrum()     │           │ - Role-based access      │
│ - getFrequencyBands()    │           │ - DoctorAssistant check  │
│                          │           │                          │
└──────────────────────────┘           └──────────────────────────┘
         │                                        │
         └────────────────────┬───────────────────┘
                              │
                    ┌─────────▼──────────┐
                    │   PostgreSQL DB    │
                    │ - EEG Files        │
                    │ - Patients         │
                    │ - Users            │
                    │ - DoctorAssistants │
                    └────────────────────┘
                              │
                    ┌─────────▼──────────┐
                    │ File System        │
                    │ uploads/           │
                    │ patient_*/         │
                    │ *.edf              │
                    └────────────────────┘
```

## Frontend Component Tree

```
EEGVisualizationPage (main)
├── Sidebar
│   └── Navigation links
├── Header
│   └── "EEG Visualization"
└── Main Content
    ├── Welcome Section
    ├── File Selection Card
    │   ├── File Dropdown (eegFilesAPI.list)
    │   ├── Process Button
    │   └── File Info Display
    ├── Error Alert (if any)
    └── Results Section (if data)
        ├── Tab Navigation
        │   ├── Raw
        │   ├── Filtered
        │   ├── ICA Cleaned
        │   ├── PSD
        │   └── Bands
        ├── Visualization Area
        │   └── SVG Charts
        └── Channel Info Box
```

## Backend Route Structure

```
FastAPI Server (http://localhost:8000)
│
└── /api/v1
    ├── /auth
    │   ├── /login (POST)
    │   ├── /logout (POST)
    │   └── /refresh (POST)
    ├── /users
    ├── /patients
    ├── /eeg-files
    │   ├── /upload (POST)
    │   ├── / (GET) - list files
    │   ├── /{id} (GET)
    │   ├── /{id}/download (GET)
    │   ├── /{id} (PUT)
    │   └── /{id} (DELETE)
    │
    └── /analysis ◄── PREPROCESSING (NEW)
        ├── /preprocess/{file_id} (GET)
        │   └── Full preprocessing report
        │
        ├── /analyze/raw/{file_id} (GET)
        │   └── Raw signal extraction
        │
        ├── /analyze/filtered/{file_id} (GET)
        │   └── Bandpass filtered signal
        │
        ├── /analyze/psd/{file_id} (GET)
        │   └── Power Spectral Density
        │
        └── /analyze/bands/{file_id} (GET)
            └── Frequency band analysis
```

## Preprocessing Pipeline Flow

```
Input: EEG File (EDF format)
   │
   ▼
┌─────────────────────────────────┐
│ 1. LOAD EDF FILE                │
│ - Use MNE-Python                │
│ - Extract channels, sampling rate │
│ - Load raw signal data          │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 2. BANDPASS FILTER              │
│ - Low: 0.1 Hz (remove DC)       │
│ - High: 30 Hz (remove noise)    │
│ - FIR filter design             │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 3. ICA (INDEPENDENT COMPONENTS) │
│ - 15 components extracted       │
│ - Exclude components 1, 2       │
│ - Remove artifacts (eyes, EMG)  │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 4. POWER SPECTRAL DENSITY (PSD) │
│ - Multitaper method             │
│ - Frequency range: 0.5-30 Hz    │
│ - Welch's method for smoothing  │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 5. FREQUENCY BAND ANALYSIS      │
│ - Delta (0.5-4 Hz)              │
│ - Theta (4-8 Hz)                │
│ - Alpha (8-12 Hz)               │
│ - Beta (12-30 Hz)               │
│ - Compute power for each band   │
└──────────┬──────────────────────┘
           │
           ▼
Output: Preprocessing Report (JSON)
```

## Data Structure: Preprocessing Report

```json
{
  "status": "success",
  "file_id": "uuid",
  "file_name": "patient_eeg.edf",
  "preprocessing_report": {

    ┌─────────────────────────────────────┐
    │ raw_signal                          │
    ├─────────────────────────────────────┤
    │ channels: [Fp1, Fp2, F3, ...]      │
    │ times: [0, 0.004, 0.008, ...]      │
    │ data: [[values], [values], ...]    │
    │ sampling_rate: 256                  │
    └─────────────────────────────────────┘

    ┌─────────────────────────────────────┐
    │ filtered_signal (0.1-30 Hz)         │
    ├─────────────────────────────────────┤
    │ (same structure as raw_signal)     │
    └─────────────────────────────────────┘

    ┌─────────────────────────────────────┐
    │ ica_signal (artifacts removed)      │
    ├─────────────────────────────────────┤
    │ (same structure as raw_signal)     │
    └─────────────────────────────────────┘

    ┌─────────────────────────────────────┐
    │ psd (Power Spectral Density)        │
    ├─────────────────────────────────────┤
    │ frequencies: [0.5, 1.0, 1.5, ...]  │
    │ power: [[values], [values], ...]   │
    │ channels: [Fp1, Fp2, F3, ...]      │
    └─────────────────────────────────────┘

    ┌─────────────────────────────────────┐
    │ frequency_bands                     │
    ├─────────────────────────────────────┤
    │ bands: {                            │
    │   delta: {Fp1: 1.2, Fp2: 1.3, ...} │
    │   theta: {Fp1: 1.5, Fp2: 1.4, ...} │
    │   alpha: {Fp1: 2.1, Fp2: 2.0, ...} │
    │   beta: {Fp1: 1.8, Fp2: 1.9, ...}  │
    │ }                                   │
    └─────────────────────────────────────┘

    ┌─────────────────────────────────────┐
    │ channel_info                        │
    ├─────────────────────────────────────┤
    │ channels: [Fp1, Fp2, F3, ...]      │
    │ sampling_rate: 256                  │
    │ duration: 120.5 seconds             │
    │ sample_count: 30976                 │
    └─────────────────────────────────────┘
  }
}
```

## Permission Model

```
User Role Hierarchy:
┌─────────────────────────────────┐
│ ROOT                            │
│ - Access all files              │
│ - Full preprocessing access     │
└──────────┬──────────────────────┘
           │
┌──────────▼──────────────────────┐
│ ADMIN                           │
│ - Org-filtered files only       │
│ - Can process org's files       │
└──────────┬──────────────────────┘
           │
┌──────────▼──────────────────────────────┐
│ DOCTOR                                  │
│ - Own patients' files                   │
│ - Can process own patients' files       │
└──────────┬───────────────────────────────┘
           │
┌──────────▼──────────────────────────────┐
│ ASSISTANT                               │
│ - Assigned doctor's patients' files     │
│ - Lookup via DoctorAssistant table      │
│ - Can process assigned doctor's files   │
└──────────┬───────────────────────────────┘
           │
┌──────────▼──────────────────────────────┐
│ PATIENT                                 │
│ - NO access to preprocessing            │
└─────────────────────────────────────────┘
```

## DoctorAssistant Relationship Check

```
When Assistant tries to access file:

1. Get current user (assistant_id)
   │
2. Query DoctorAssistant table
   where assistant_id = current_user.id
   │
3. Get assigned doctor_id
   │
4. Check file ownership
   EEGFile.patient.doctor_id == assigned_doctor_id?
   │
4a. YES ─────► ALLOW preprocessing
4b. NO  ─────► DENY with 403 Forbidden
```

## File Storage Structure

```
Backend Storage:
  /uploads
  ├── patient_550e8400-e29b-41d4-a716-446655440000/
  │   ├── eeg_20240120_120000.edf
  │   ├── eeg_20240121_110000.edf
  │   └── eeg_20240122_100000.edf
  ├── patient_660e8400-e29b-41d4-a716-446655440001/
  │   ├── seizure_episode_1.edf
  │   └── seizure_episode_2.edf
  └── ...

Database (EEGFile):
  {
    id: uuid,
    patient_id: uuid,
    uploaded_by: uuid (doctor),
    original_filename: "eeg_20240120_120000.edf",
    file_path: "patient_550e8400.../eeg_20240120_120000.edf",
    created_at: timestamp,
    ...
  }
```

## Visualization Tabs

```
┌──────────────────────────────────────────────────────┐
│  Raw  │ Filtered │ ICA Cleaned │ PSD │ Bands │       │
├──────────────────────────────────────────────────────┤
│ CONTENT AREA                                         │
│                                                      │
│ Raw Tab:                                             │
│ ├─ Fp1: ╱╲╱╲╱╱╲╱╲                                  │
│ ├─ Fp2: ╱╲╱╲╱╱╲╱╲                                  │
│ ├─ F3:  ╱╲╱╲╱╱╲╱╲                                  │
│ └─ ...                                               │
│                                                      │
│ Filtered Tab:                                        │
│ ├─ (Same but with less noise)                       │
│                                                      │
│ ICA Tab:                                             │
│ ├─ (Smoother, artifacts removed)                    │
│                                                      │
│ PSD Tab:                                             │
│ ├─ Frequency spectrum plot                          │
│ └─ Power vs Frequency graph                         │
│                                                      │
│ Bands Tab:                                           │
│ ├─ Delta:  [████░░░░] 0.8                          │
│ ├─ Theta:  [██████░░] 1.2                          │
│ ├─ Alpha:  [████████] 2.1                          │
│ └─ Beta:   [███████░] 1.8                          │
│                                                      │
│ Channel Info:                                        │
│ ├─ Sampling Rate: 256 Hz                            │
│ ├─ Duration: 120.5 seconds                          │
│ ├─ Channels: 22                                      │
│ └─ Total Samples: 30976                             │
└──────────────────────────────────────────────────────┘
```

## Request/Response Flow

```
USER INTERACTION:
1. Navigate to EEG Visualization
2. Select file from dropdown
   └─► eegFilesAPI.list() [GET /eeg-files]
       └─► Returns: [file1, file2, ...]

3. Click "Process File"
   └─► eegAnalysisAPI.preprocess(fileId)
       [GET /analysis/preprocess/{fileId}]

BACKEND PROCESSING:
4. Backend receives request
   ├─► Check authentication (JWT)
   ├─► Load EEGFile from DB
   ├─► Check permissions
   │   └─► Query DoctorAssistant if needed
   ├─► Get file path
   └─► Load file exists?

5. EEGPreprocessingService.get_full_preprocessing_report()
   ├─► load_eeg_file()
   ├─► apply_bandpass_filter()
   ├─► apply_ica()
   ├─► compute_power_spectral_density()
   ├─► compute_frequency_bands_power()
   └─► get_channel_info()

6. Return JSON response
   └─► {status, file_id, file_name, preprocessing_report}

FRONTEND DISPLAY:
7. Receive response & store in state
8. Render visualization tabs
   ├─► Raw: renderWaveform(raw_signal)
   ├─► Filtered: renderWaveform(filtered_signal)
   ├─► ICA: renderWaveform(ica_signal)
   ├─► PSD: renderPSD(psd_data)
   └─► Bands: renderFrequencyBands(bands)

9. Display channel information
   └─► Sampling rate, duration, channels, samples
```

## Error Handling Flow

```
USER REQUEST
     │
     ▼
┌─ Is user authenticated?
│  NO ──────────► 401 Unauthorized
│  YES
     │
     ▼
┌─ Does file exist?
│  NO ──────────► 404 Not Found
│  YES
     │
     ▼
┌─ Can user access file?
│  (Check role & relationships)
│  NO ──────────► 403 Forbidden
│  YES
     │
     ▼
┌─ Does file exist on disk?
│  NO ──────────► 404 File not found
│  YES
     │
     ▼
┌─ Can MNE load file?
│  NO ──────────► 400 Bad Request
│  YES
     │
     ▼
Processing...
     │
     ▼
┌─ Processing successful?
│  NO ──────────► 500 Internal Server Error
│  YES
     │
     ▼
200 OK + JSON Report
```

## Performance Timeline

```
Preprocessing of 60-second EEG file (22 channels):

Load EDF     ════════ 1-2 seconds
Filter       ═══ 0.5 seconds
ICA          ══════════════ 3-5 seconds
PSD          ════════ 1-2 seconds
Bands        ══ 0.5 seconds
               ────────────────────
Total:         ~6-10 seconds

Memory: ~20-50 MB per operation
```

## State Machine: Visualization Page

```
                    ┌─────────────────┐
                    │   INITIAL       │
                    │ - No file sel.  │
                    │ - No data       │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  FILE SELECTED  │
                    │ - User picks    │
                    │   file          │
                    └────────┬────────┘
                             │ (Process button)
                    ┌────────▼────────┐
                    │ PREPROCESSING   │
                    │ - Loading state │
                    │ - Progress...   │
                    └────────┬────────┘
                             │ (Success)
                    ┌────────▼────────┐
                    │  DATA READY     │
                    │ - Tabs visible  │
                    │ - Charts render │
                    └────────┬────────┘
                             │ (Select tab)
                    ┌────────▼────────┐
                    │  TAB VIEWING    │
                    │ - Active tab    │
                    │ - Chart display │
                    └─────────────────┘

Error: ───────────► ┌─────────────────┐
                    │  ERROR STATE    │
                    │ - Alert message │
                    │ - Retry option  │
                    └─────────────────┘
```

## Database Schema Relationships

```
Users
├─ id (PK)
├─ username
├─ role (root, admin, doctor, assistant, patient)
├─ org_id (FK)
└─ ...

Patients
├─ id (PK)
├─ name
├─ doctor_id (FK → Users.id)
└─ ...

EEGFiles
├─ id (PK)
├─ patient_id (FK → Patients.id)
├─ uploaded_by (FK → Users.id) [Doctor]
├─ original_filename
├─ file_path
├─ created_at
└─ ...

DoctorAssistant
├─ id (PK)
├─ doctor_id (FK → Users.id)
├─ assistant_id (FK → Users.id)
└─ ...
```

---

This architecture ensures:
✅ Complete EEG preprocessing pipeline
✅ Secure role-based access control
✅ Efficient file handling
✅ Clean data flow
✅ Professional visualization
✅ Scalable design
