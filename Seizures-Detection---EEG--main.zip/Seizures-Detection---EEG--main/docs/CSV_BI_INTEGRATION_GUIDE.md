# CSV_BI Reports Integration - Quick Reference

## What Changed

✅ **Reports now use CSV_BI files from backend instead of localStorage**

### Key Points:

- Analysis runs → Backend saves CSV_BI file
- Reports page fetches reports from backend
- Deletion removes CSV_BI files from disk
- No browser storage limitations

## Files Modified

### Backend

- `backend/app/api/v1/endpoints/seizure_detection.py`
  - Added `GET /api/v1/detection/reports/list` endpoint
  - Added `DELETE /api/v1/detection/{file_id}/report` endpoint

### Frontend

- `frontend/src/services/api.js`

  - Added `seizureDetectionAPI.listAllReports()`
  - Added `seizureDetectionAPI.deleteReport(fileId)`

- `frontend/src/pages/ReportsPage.jsx`

  - Updated `loadReports()` to use backend endpoint
  - Updated `handleDeleteReport()` to delete CSV_BI files
  - Removed localStorage operations

- `frontend/src/context/AnalysisContext.jsx`
  - Removed `createReportFromAnalysis()` function
  - Removed localStorage persistence code
  - Simplified to just manage UI state

## How to Test

### 1. Run Backend

```powershell
cd backend
.\venv\Scripts\Activate.ps1
python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 2. Run Frontend

```powershell
cd frontend
npm run dev
```

### 3. Test Analysis Flow

1. Go to Analysis page
2. Select a patient
3. Select an EEG file
4. Click "Run Analysis"
5. Wait for completion (2-3 minutes)
6. Check that CSV_BI file is created in `backend/reports/`

### 4. Test Reports Display

1. Go to Reports page
2. Should display the newly created report
3. Verify:
   - Patient name shows correctly
   - EEG filename (e.g., "Seizure.edf") displays
   - Seizure count matches analysis
   - Date is current

### 5. Test Report Deletion

1. On Reports page, find a report
2. Click the delete (trash) icon
3. Confirm deletion
4. Report should disappear from table
5. Check `backend/reports/` - CSV_BI file should be gone

## Data Locations

### CSV_BI Files

- **Location:** `backend/reports/`
- **Format:** `{eeg_filename}.csv_bi`
- **Example:** `Seizure.csv_bi`

### Database

- Still stores EEG files and patient data
- Does NOT store report data anymore
- Reports are read-only from CSV_BI files

## API Endpoints Reference

### List All Reports

```
GET /api/v1/detection/reports/list
Authorization: Bearer {access_token}

Response:
{
  "reports": [
    {
      "id": "report_...",
      "filename": "Seizure.edf",
      "patient_name": "John Doe",
      "seizure_count": 4,
      "total_seizure_duration_seconds": 349.0,
      "seizure_percentage": 9.74,
      "status": "completed",
      "generated_at": "2026-01-11T14:20:00"
    }
  ],
  "total_count": 1
}
```

### Delete Report

```
DELETE /api/v1/detection/{file_id}/report
Authorization: Bearer {access_token}

Response: 204 No Content
```

## Troubleshooting

### Reports page shows empty list

1. Check if any CSV_BI files exist in `backend/reports/`
2. If no files, run an analysis first
3. Check browser console for API errors
4. Verify backend is running and accessible

### "Failed to delete report" error

1. Check that the eeg_file_id is correct
2. Verify user has permission to delete
3. Check that CSV_BI file actually exists
4. Check backend logs for deletion errors

### Report shows "Unknown" patient

1. Patient data not found in database
2. This is normal if patient was deleted
3. Patient ID and report data still preserved

## Performance Notes

- First load may be slow if many CSV_BI files exist (backend scans directory)
- Subsequent loads are fast
- CSV_BI file parsing is efficient
- Consider archiving old reports if thousands accumulate

## Backward Compatibility

⚠️ **Old localStorage reports are NOT migrated**

- If you had reports in browser localStorage, they won't appear
- All new reports use CSV_BI system
- This is intentional - cleaner backend storage

## Next Steps

1. Test the implementation with actual EEG data
2. Monitor backend logs for any CSV_BI parsing errors
3. Verify report deletion works correctly
4. Test with multiple users/roles
