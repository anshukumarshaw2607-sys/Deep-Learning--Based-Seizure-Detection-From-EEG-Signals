# EEG Preprocessing - Quick Start Testing Guide

## Prerequisites

Ensure both backend and frontend are running:

```powershell
# Terminal 1: Backend
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
invoke dev

# Terminal 2: Frontend
cd frontend
npm install
npm run dev
```

Backend runs at: `http://localhost:8000`
Frontend runs at: `http://localhost:5173`

## Testing Workflow

### Step 1: Create Test User & Login

1. Go to frontend: `http://localhost:5173`
2. Create account or login with existing credentials
3. Note: You need a doctor account to upload EEG files

### Step 2: Create a Patient (Doctor Only)

1. Navigate to **Dashboard**
2. Go to **Patients** section
3. Click **Add Patient**
4. Fill in patient details:
   - Name: "Test Patient"
   - ID: "PT001"
   - DOB: Any date
5. Save patient

### Step 3: Upload EEG File

1. Navigate to **EEG Data** page
2. Click **Upload File**
3. Select the patient created in Step 2
4. Choose an EDF file (test file should be in `backend/uploads/` or use sample)
5. Add description: "Test preprocessing"
6. Upload and wait for completion

### Step 4: Visualize & Preprocess

1. Navigate to **EEG Visualization** page
2. In **Select File & Preprocess** section:
   - Dropdown should show: "your_file.edf - Test Patient"
   - Select the uploaded file
3. Click **Process File** button
4. Wait for "Processing..." to complete (~10-20 seconds)
5. Results appear with tabs:
   - **Raw**: Original signal
   - **Filtered**: Bandpass filtered
   - **ICA Cleaned**: Artifact-removed
   - **PSD**: Power spectrum
   - **Bands**: Frequency band analysis

### Step 5: Explore Analysis Tabs

#### Raw Signal Tab

- Shows unprocessed EEG waveform
- Displays all channels in separate rows
- Shows sampling rate, channel count, duration

#### Filtered Tab

- Bandpass filtered (0.1-30 Hz)
- Removes DC offset and high-frequency noise
- Should appear cleaner than raw

#### ICA Tab

- ICA-cleaned signal (components 1,2 excluded)
- Removes eye blinks, muscle artifacts
- Significantly smoother appearance

#### PSD Tab

- Power Spectral Density plot
- Frequency range on X-axis
- Power on Y-axis
- Shows where signal power is concentrated

#### Bands Tab

- Delta (0.5-4 Hz): Slow sleep waves
- Theta (4-8 Hz): Drowsiness/sleep
- Alpha (8-12 Hz): Relaxation
- Beta (12-30 Hz): Active thinking
- Each band shows power for all channels

## Test Cases

### Test Case 1: Basic Preprocessing Flow

**Objective**: Verify preprocessing works end-to-end

Steps:

1. Upload valid EDF file
2. Go to visualization page
3. Select file and process
4. Verify all 5 tabs show data
5. Check channel info displays correctly

Expected Result: ✓ All tabs populate with data

### Test Case 2: Permission Check (Assistant)

**Objective**: Verify assistant can see doctor's patient files

Steps:

1. Login as doctor, upload file
2. Logout and login as assistant for that doctor
3. Navigate to EEG Visualization
4. Verify file appears in dropdown
5. Process and verify success

Expected Result: ✓ Assistant sees doctor's files

### Test Case 3: Permission Check (Admin)

**Objective**: Verify admin can process files from their org

Steps:

1. Login as admin
2. Go to EEG Visualization
3. Verify only org's files visible
4. Process a file

Expected Result: ✓ Admin sees org files only

### Test Case 4: Error Handling

**Objective**: Verify proper error messages

Steps:

1. Try to access non-existent file (modify URL)
2. Try to process file from different org (as admin)
3. Check browser console for errors
4. Check error message displayed

Expected Result: ✓ Clear error messages shown

## API Testing (cURL/Postman)

### Get Authentication Token

```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"doctor@example.com","password":"password"}'
```

Response:

```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer"
}
```

### Full Preprocessing

```bash
curl -X GET "http://localhost:8000/api/v1/analysis/preprocess/{file_id}" \
  -H "Authorization: Bearer {access_token}"
```

Response:

```json
{
  "status": "success",
  "file_id": "...",
  "file_name": "test.edf",
  "preprocessing_report": {
    "raw_signal": {...},
    "filtered_signal": {...},
    "ica_signal": {...},
    "psd": {...},
    "frequency_bands": {...},
    "channel_info": {...}
  }
}
```

### Get Raw Signal Only

```bash
curl -X GET "http://localhost:8000/api/v1/analysis/analyze/raw/{file_id}?duration=10" \
  -H "Authorization: Bearer {access_token}"
```

### Get PSD Analysis

```bash
curl -X GET "http://localhost:8000/api/v1/analysis/analyze/psd/{file_id}?fmin=0.5&fmax=30" \
  -H "Authorization: Bearer {access_token}"
```

### Get Frequency Bands

```bash
curl -X GET "http://localhost:8000/api/v1/analysis/analyze/bands/{file_id}" \
  -H "Authorization: Bearer {access_token}"
```

## Common Test Scenarios

### Scenario 1: Invalid File ID

```bash
curl -X GET "http://localhost:8000/api/v1/analysis/preprocess/invalid-uuid" \
  -H "Authorization: Bearer {token}"
```

Expected: 404 Not Found

### Scenario 2: Unauthorized Access

```bash
# Login as patient, try to process file
curl -X GET "http://localhost:8000/api/v1/analysis/preprocess/{file_id}" \
  -H "Authorization: Bearer {patient_token}"
```

Expected: 403 Forbidden

### Scenario 3: File Not on Disk

```bash
# Upload file, delete from disk, try to process
curl -X GET "http://localhost:8000/api/v1/analysis/preprocess/{file_id}" \
  -H "Authorization: Bearer {token}"
```

Expected: 404 File not found on disk

## Performance Testing

### Single File Processing

- Upload 60-second EDF
- Time preprocessing: ~10-15 seconds
- Verify all steps complete
- Check memory usage: Should be <100MB

### Multiple Concurrent Requests

```bash
# Terminal: Run 3 concurrent preprocessing jobs
for i in {1..3}; do
  curl -X GET "http://localhost:8000/api/v1/analysis/preprocess/{file_id}" \
    -H "Authorization: Bearer {token}" &
done
wait
```

Expected: All complete without errors

## Debugging Tips

### Backend Logs

Check server output for preprocessing details:

```
INFO:     application startup complete
DEBUG:    Loading EEG file from: uploads/patient_xxx/file.edf
DEBUG:    Applying bandpass filter 0.1-30Hz
DEBUG:    Running ICA with 15 components
DEBUG:    Computing PSD
DEBUG:    Preprocessing complete
```

### Frontend Console

Open browser DevTools (F12) → Console tab:

- Watch API requests in Network tab
- Check response payloads
- Monitor for JavaScript errors

### Database Queries

Verify file exists and has correct path:

```sql
SELECT id, original_filename, file_path, patient_id, uploaded_by
FROM eeg_files
WHERE id = '{file_id}';
```

## Sample Test Data

If you don't have EDF files, create test data:

```python
# Create dummy EDF file
import mne
import numpy as np

# Create raw signal
sfreq = 256  # Sampling frequency
duration = 60  # seconds
n_channels = 22

times = np.arange(0, duration, 1/sfreq)
data = np.random.randn(n_channels, len(times))

# Create MNE Raw object
ch_names = [f'Ch{i}' for i in range(n_channels)]
ch_types = ['eeg'] * n_channels
info = mne.create_info(ch_names, sfreq, ch_types)
raw = mne.io.RawArray(data, info)

# Save as EDF
raw.export('test_eeg.edf')
```

Then upload this test file.

## Verification Checklist

After testing, verify:

- [ ] Backend preprocessing service loads successfully
- [ ] Frontend visualization page renders
- [ ] File dropdown populates with uploaded files
- [ ] Process button triggers preprocessing
- [ ] All 5 visualization tabs show data
- [ ] Channel information displays
- [ ] Raw waveform visible
- [ ] PSD plot visible
- [ ] Frequency bands heatmap visible
- [ ] Error messages display properly
- [ ] Permission checks work (doctor/assistant/admin)
- [ ] No console errors in browser
- [ ] No server errors in backend logs

## Next Steps

Once basic testing passes:

1. **Advanced Visualization**

   - Integrate chart library (Chart.js, Plotly.js)
   - Improve waveform rendering
   - Add interactive zoom/pan

2. **Performance**

   - Implement result caching
   - Add background job processing
   - Optimize for large files

3. **ML Integration**

   - Load seizure detection model
   - Show predictions alongside analysis
   - Generate automated reports

4. **Export Features**
   - PDF report export
   - CSV data export
   - Image export

## Support

If issues occur:

1. **Check logs**: Backend terminal and browser console
2. **Verify setup**: Both servers running and connected
3. **Test dependencies**: `pip install -r requirements.txt`
4. **Check file format**: Ensure EDF files are valid
5. **Restart servers**: Fresh start can resolve state issues
