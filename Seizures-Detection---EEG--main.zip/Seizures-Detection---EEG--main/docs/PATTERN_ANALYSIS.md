# Background Processing Pattern Analysis

## What You Observed

You correctly noticed that the **Visualization page already implements background processing with state persistence** when switching pages.

When you click "Process File" (handlePreprocess):

- ✅ Processing continues in background
- ✅ State persists across page navigation
- ✅ Results available anywhere via context
- ✅ No blocking, no interruption

## How It Works (Visualization Page)

### The Pattern (PreprocessingContext)

```javascript
// 1. Global context stores preprocessing data
const [preprocessingData, setPreprocessingData] = useState(null);
const [currentFileId, setCurrentFileId] = useState(null);

// 2. Update method to store results
const updatePreprocessingData = (data, fileId) => {
  setPreprocessingData(data);
  setCurrentFileId(fileId);
};

// 3. Use in component
const { updatePreprocessingData } = usePreprocessing();

// 4. After processing completes
const result = await eegAnalysisAPI.preprocess(selectedFile.id);
updatePreprocessingData(result.preprocessing_report, selectedFile.id);
```

### Key Components

**File:** `frontend/src/context/PreprocessingContext.jsx`

- Global state management
- State persists across page navigation
- Auto-clears on logout
- Clean, reusable pattern

**File:** `frontend/src/pages/eegVisualizationPage.jsx`

- Calls `eegAnalysisAPI.preprocess()`
- Updates context when complete
- Can navigate away immediately

## Why This Works

The magic is:

1. **Context is above Router** in App.jsx hierarchy
2. **State not tied to component** - lives in context
3. **Results available anywhere** - any component can read context
4. **No localStorage needed** - kept in memory during session

## What I Just Implemented (AnalysisContext)

I applied the **exact same pattern** for seizure detection!

### Comparison

| Feature                 | PreprocessingContext | AnalysisContext               |
| ----------------------- | -------------------- | ----------------------------- |
| **Global State**        | ✅ Yes               | ✅ Yes                        |
| **Persists Across Nav** | ✅ Yes               | ✅ Yes                        |
| **Non-blocking**        | ✅ Yes               | ✅ Yes                        |
| **Auto-cleanup**        | ✅ On logout         | ✅ Every 8s (notifications)   |
| **Notifications**       | ❌ No                | ✅ Yes                        |
| **Multiple Concurrent** | ⚠️ One at a time     | ✅ Multiple (keyed by fileId) |

## The Difference

**PreprocessingContext** (Visualization):

- Stores single preprocessing result
- No notifications
- Simple, focused

**AnalysisContext** (I created):

- Stores multiple analyses (by fileId)
- Built-in notification system
- Auto-cleanup of old notifications
- Shows results as toasts on any page

## You Already Had the Right Idea!

The Visualization page demonstrates that:

1. ✅ Background processing without blocking works
2. ✅ Global context for state is the right approach
3. ✅ Users can navigate freely without losing state
4. ✅ Results persist across page changes

**I applied this proven pattern to seizure detection** with enhancements:

- Multiple concurrent analyses (not just one)
- Automatic notifications (instead of manual polling)
- Better error handling

## Recommendation

Since you already have this pattern working on Visualization:

### Option 1: Use Existing Pattern

Keep using `PreprocessingContext` for any preprocessing-related state that needs to persist.

### Option 2: Use New Pattern

Use `AnalysisContext` for seizure detection because:

- Multiple analyses support
- Built-in notifications
- Auto-cleanup
- Better suited for long-running ML tasks

### Option 3: Unify Both

Could create a generic `ProcessingContext` that handles both:

```javascript
const { startProcessing, getResults, addNotification } = useProcessing();
```

## Current Architecture

```
App.jsx
├─ ThemeProvider
├─ PreprocessingProvider (handles EEG preprocessing)
└─ AnalysisProvider (handles seizure detection) ← I added this
   └─ Router
      ├─ Visualization (uses PreprocessingContext)
      ├─ Analysis (uses AnalysisContext)
      └─ ... other pages ...
```

## What This Means

✅ **Your instinct was right** - using global context for async operations is the correct pattern

✅ **The implementation is proven** - you've already seen it work on Visualization

✅ **My implementation follows the same pattern** - just with notifications

✅ **No conflicts** - both contexts coexist peacefully

## Next Steps

Test the AnalysisContext the same way you're testing PreprocessingContext:

1. Start analysis
2. Navigate pages
3. Come back to see if state persisted
4. Navigate to other pages during processing
5. Notification appears when complete

The behavior should feel familiar because it's the same pattern! 🎯

---

## Summary

You observed a working example of **background processing with state persistence** on the Visualization page using `PreprocessingContext`.

I applied the **exact same proven pattern** to create `AnalysisContext` for seizure detection, with enhancements for:

- Multiple concurrent operations
- Automatic notifications
- Better error handling

Both now coexist in your app, following the same architectural principle: **Global context above Router = state persists across navigation**.
