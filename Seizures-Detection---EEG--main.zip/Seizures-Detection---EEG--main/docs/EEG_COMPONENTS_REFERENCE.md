# EEG Data Page Components - Code Reference

## Component Overview

| Component           | Location                             | Lines | Purpose                            |
| ------------------- | ------------------------------------ | ----- | ---------------------------------- |
| EEGDataPage         | `pages/eegdataPage.jsx`              | 280   | Main container, state management   |
| EEGFilesList        | `components/EEGFilesList.jsx`        | 200+  | Table display, pagination, filters |
| EEGFileUploadModal  | `components/EEGFileUploadModal.jsx`  | 200+  | File upload dialog                 |
| EEGFileDetailsModal | `components/EEGFileDetailsModal.jsx` | 250+  | File view/edit dialog              |

---

## EEGDataPage.jsx - Main Component

### Purpose

Central hub for EEG data management. Handles state, API calls, and modal management.

### Key State Variables

```javascript
user; // Current authenticated user
loading; // Loading indicator for file list
files; // Array of EEG files
patients; // Array of patients
doctors; // Array of doctors
total; // Total files count
skip; // Pagination offset
limit; // Records per page (10)
filters; // { patientId, uploadedBy, includeDeleted }
uploadModalOpen; // Upload modal visibility
detailsModalOpen; // Details modal visibility
selectedFile; // Currently viewed file
isEditing; // Edit mode toggle
```

### Key Functions

```javascript
loadUser(); // Fetch current user from API
loadPatients(); // Load role-filtered patients
loadDoctors(); // Load doctors list
loadFiles(); // Load paginated EEG files
handleUpload(); // Process file upload
handleViewDetails(); // Fetch and display file details
handleUpdateMetadata(); // Save metadata changes
handleDownload(); // Download file blob
handleDelete(); // Delete file (soft or hard)
handleFilterChange(); // Apply filters
handlePageChange(); // Change page
getPatientName(); // Lookup patient name by ID
```

### UI Structure

```
Header Section
  ↓
Upload Button (conditional)
  ↓
EEGFilesList Component
  ↓
Modals (conditional)
  - EEGFileUploadModal
  - EEGFileDetailsModal
```

---

## EEGFilesList.jsx - Table Component

### Purpose

Display paginated list of EEG files with filters and actions.

### Props

```javascript
files; // Array of file objects
patients; // Array of patient objects (for lookup)
doctors; // Array of doctor objects
loading; // Loading state boolean
total; // Total files count
skip; // Current pagination offset
limit; // Records per page
filters; // Current filter state
userRole; // Current user's role
onViewDetails; // Callback for view details
onDownload; // Callback for download
onFilterChange; // Callback for filter changes
onPageChange; // Callback for pagination
showFilterOptions; // Boolean to show filters
```

### Table Columns

```
Patient Name
  ↓
File Name (with description)
  ↓
Duration (seconds)
  ↓
Number of Channels
  ↓
File Size (formatted)
  ↓
Upload Date (formatted)
  ↓
Uploader Name
  ↓
Actions (View, Download)
```

### Filter Controls

```
Patient Filter
  - Dropdown with all accessible patients
  - Default: "All Patients"

Uploader Filter (admin/root only)
  - Dropdown with all doctors
  - Default: "All Uploaders"

Include Deleted Checkbox
  - Toggle to show archived files
  - Default: unchecked
```

### Pagination

```
Records Display: "Showing 1 to 10 of 47 files"
  ↓
Navigation: [Previous] Page 1 of 5 [Next]
  ↓
Buttons disabled when at boundary
```

---

## EEGFileUploadModal.jsx - Upload Dialog

### Purpose

Modal dialog for uploading new EEG files with validation and progress tracking.

### Props

```javascript
isOpen; // Modal visibility boolean
onClose; // Callback to close modal
onUpload; // Callback with upload data
patients; // Array of accessible patients
userRole; // Current user's role
currentUserId; // Current user's ID
```

### Form Fields

```
File Input
  - Accept: .edf files only
  - Validation: size < 100MB
  - Visual: Drag-drop box

Patient Dropdown
  - Required field
  - Role-filtered options
  - Doctor: own patients only
  - Admin/Root: all patients

Description Field
  - Optional text input
  - Placeholder: "e.g., Baseline recording"

Notes Field
  - Optional textarea
  - Placeholder: "Add any relevant notes..."
```

### Validation Logic

```javascript
if (file.name.endsWith('.edf')) // ✓ Correct format
  if (file.size < 100MB)        // ✓ Correct size
    if (patientId)              // ✓ Patient selected
      // Allow upload
```

### Upload Flow

```
1. Select file
   ↓
2. File validated
   ↓
3. Patient selected
   ↓
4. Click Upload
   ↓
5. Progress bar shown (0-100%)
   ↓
6. On success: Modal closes, list refreshes
   ↓
7. On error: Error message displayed
```

---

## EEGFileDetailsModal.jsx - Details Dialog

### Purpose

View and edit EEG file metadata. Display detailed information and provide download/delete options.

### Props

```javascript
isOpen; // Modal visibility
onClose; // Close callback
file; // File object to display
patientName; // Patient name for display
isEditing; // Edit mode toggle
onEdit; // Enter edit mode callback
onCancel; // Cancel edit callback
onSave; // Save changes callback
onDownload; // Download callback
onDelete; // Delete callback
userRole; // Current user's role
showHardDeleteOption; // Show hard delete button
```

### Display Sections

#### File Information

```
Filename
Patient Name
File Size
Uploaded By
Upload Date
Last Modified Date
```

#### Recording Metadata (Auto-extracted)

```
Duration (seconds)
Sampling Rate (Hz)
Number of Channels
Channel Names (comma-separated)
Status (Active/Deleted)
```

#### User Metadata

```
Description (editable in edit mode)
Notes (editable in edit mode)
```

#### Technical Details

```
File Hash (SHA256) - read-only
```

### Modes

**View Mode:**

- All fields read-only
- Show metadata as is
- Display Edit button
- Display Download button
- Display Delete button

**Edit Mode:**

- Description field becomes input
- Notes field becomes textarea
- Show Save button
- Show Cancel button
- Other fields remain read-only

### Action Buttons

```
Edit (conditionally shown)
  - Only if user has permission
  - Shows only in view mode

Download
  - Available in both modes
  - Shows loading state
  - Triggers file download

Delete
  - Soft delete for doctor/admin/root
  - Shows confirmation
  - Removes file from list

Hard Delete (root only)
  - Permanently removes file
  - Shows warning
  - Only visible for root role

Close
  - Closes modal without changes
  - Available always
```

---

## Data Models

### File Object Structure

```javascript
{
  id: "uuid",
  patient_id: "uuid",
  uploaded_by: "uuid",
  filename: "abc123def456.edf",        // System name
  original_filename: "patient.edf",    // User's name
  file_path: "patient_id/filename",
  file_size: 1048576,                  // Bytes
  file_hash: "sha256hash...",
  recording_duration: 3600.0,          // Seconds
  sampling_rate: 256.0,                // Hz
  number_of_channels: 19,
  channel_names: "Fp1,Fp2,F3,...",
  description: "string",
  notes: "string",
  is_deleted: false,
  created_at: "2024-01-15T10:30:00Z",
  updated_at: null,
  uploader_name: "Dr. John Smith"
}
```

### Patient Object Structure

```javascript
{
  id: "uuid",
  doctor_id: "uuid",
  full_name: "John Doe",
  date_of_birth: "1990-05-15",
  age: 34,
  gender: "Male",
  contact_number: "+1234567890",
  email: "john@example.com",
  medical_history: "string",
  notes: "string",
  is_deleted: false,
  created_at: "2024-01-15T10:30:00Z",
  updated_at: null,
  doctor_name: "Dr. Jane Smith"
}
```

### Doctor Object Structure

```javascript
{
  id: "uuid",
  username: "dr_john",
  full_name: "Dr. John Smith",
  email: "john@example.com",
  role: "doctor",
  org_id: "uuid",
  is_active: true,
  created_at: "2024-01-15T10:30:00Z"
}
```

### User Object Structure

```javascript
{
  id: "uuid",
  username: "username",
  full_name: "Full Name",
  email: "email@example.com",
  role: "doctor|admin|root",
  org_id: "uuid|null",
  is_active: true,
  created_at: "2024-01-15T10:30:00Z"
}
```

---

## API Integration Methods

### Used from eegFilesAPI

```javascript
eegFilesAPI.upload(file, patientId, description, notes, onUploadProgress)
  → POST /eeg-files/upload
  → Returns: { message, data: fileObject }

eegFilesAPI.list(skip, limit, patientId, uploadedBy, includeDeleted)
  → GET /eeg-files
  → Returns: { files: [], total, skip, limit }

eegFilesAPI.get(fileId)
  → GET /eeg-files/{id}
  → Returns: fileObject

eegFilesAPI.download(fileId)
  → GET /eeg-files/{id}/download
  → Returns: Blob

eegFilesAPI.update(fileId, updateData)
  → PUT /eeg-files/{id}
  → Params: { description, notes, is_deleted }
  → Returns: { message, data: fileObject }

eegFilesAPI.delete(fileId, hardDelete)
  → DELETE /eeg-files/{id}
  → Params: { hard_delete: boolean }
  → Returns: { message, file_id, deletion_type }
```

### Used from patientsAPI

```javascript
patientsAPI.list(skip, limit, doctorId)
  → GET /patients
  → Returns: patientArray (or wrapped in data)
```

### Used from usersAPI

```javascript
usersAPI.getDoctors(skip, limit)
  → GET /users/doctors
  → Returns: doctorArray (or wrapped in data)
```

### Used from authAPI

```javascript
authAPI.getCurrentUser()
  → GET /me
  → Returns: userObject
```

---

## Hooks & Dependencies

### useCallback Usage

```javascript
loadPatients = useCallback(
  () => {
    /* load logic */
  },
  [user?.id, user?.role] // Only recreate if user changes
);

loadDoctors = useCallback(
  () => {
    /* load logic */
  },
  [user?.role] // Only recreate if role changes
);

loadFiles = useCallback(
  () => {
    /* load logic */
  },
  [skip, limit, filters] // Recreate when pagination/filters change
);
```

### useEffect Usage

```javascript
// Load user on mount
useEffect(() => {
  loadUser();
}, []);

// Load patients/doctors when user changes
useEffect(() => {
  loadPatients();
  loadDoctors();
}, [loadPatients, loadDoctors]);

// Load files when pagination/filters change
useEffect(() => {
  loadFiles();
}, [loadFiles]);
```

---

## Styling Classes

### Color Scheme

```
Background: bg-slate-950, bg-slate-900, bg-slate-800
Text: text-white, text-slate-300, text-slate-400
Borders: border-slate-700, border-slate-600
Hover: hover:bg-slate-700, hover:bg-slate-600

Primary: bg-blue-600, hover:bg-blue-700
Success: bg-green-600, hover:bg-green-700
Danger: bg-red-600, hover:bg-red-700
```

### Common Patterns

```
Button: px-4 py-2 rounded-lg transition-colors
Input: px-4 py-2 bg-slate-800 border border-slate-600 rounded-lg
Table Row: hover:bg-slate-800 transition-colors
Modal: fixed inset-0 bg-black/50 flex items-center justify-center z-50
```

---

## Error Handling Pattern

```javascript
try {
  // API call
  const response = await apiMethod();
  // Update state
  setState(response);
} catch (error) {
  // Log error
  console.error("Operation failed:", error);
  // Set error state
  setError(error.message);
  // User sees error in UI
}
```

---

## Performance Considerations

1. **Pagination:** Only 10 files loaded per page
2. **useCallback:** Prevents unnecessary re-renders
3. **Filters:** Reduce data before display
4. **Lazy Loading:** Files loaded on demand via pagination
5. **Memoization:** Component props prevent unnecessary renders

---

## Browser Compatibility

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Requires ES6+ support
- Requires Fetch API or Axios

---

## Accessibility Features

- ✅ Semantic HTML elements
- ✅ Form labels with inputs
- ✅ Button titles/tooltips
- ✅ Disabled state indicators
- ✅ Color + text for status
- ✅ Keyboard navigation
- ✅ ARIA labels where needed

---

## Security Considerations

- ✅ JWT token in Authorization header
- ✅ Role-based access control enforced
- ✅ Input validation before upload
- ✅ File hash verification
- ✅ Proper error messages (no data leakage)
- ✅ HTTPS recommended for production

---

**Component Documentation Complete**
