# EEG Preprocessing Integration Guide

## Overview

The EEG preprocessing integration connects uploaded EEG files to a complete signal analysis pipeline that can be visualized in the frontend. The system includes backend preprocessing services, REST API endpoints, and an interactive frontend visualization page.

## Architecture

### Backend Stack

**Service Layer** (`backend/app/services/eeg_preprocessing.py`)

- `EEGPreprocessingService`: Main preprocessing class
- Handles EEG file loading, filtering, ICA, PSD analysis
- Returns JSON-serializable data for REST API responses

**Endpoints** (`backend/app/api/v1/endpoints/eeg_preprocessing.py`)

- `GET /analysis/preprocess/{file_id}` - Full preprocessing report
- `GET /analysis/analyze/raw/{file_id}` - Raw signal extraction
- `GET /analysis/analyze/filtered/{file_id}` - Bandpass filtered signal (0.1-30 Hz)
- `GET /analysis/analyze/psd/{file_id}` - Power Spectral Density analysis
- `GET /analysis/analyze/bands/{file_id}` - Frequency band power (Delta/Theta/Alpha/Beta)

**Router Integration** (`backend/app/api/v1/api.py`)

- Preprocessing router registered at `/analysis` prefix
- All endpoints require authentication via `get_current_user`

### Frontend Stack

**API Service** (`frontend/src/services/api.js`)

- `eegAnalysisAPI` object with methods:
  - `preprocess(fileId)` - Trigger full preprocessing
  - `getRawSignal(fileId, duration)` - Get raw signal window
  - `getFilteredSignal(fileId, lFreq, hFreq)` - Get filtered signal
  - `getPowerSpectrum(fileId, fmin, fmax)` - Get PSD data
  - `getFrequencyBands(fileId)` - Get frequency band analysis

**Visualization Page** (`frontend/src/pages/eegVisualizationPage.jsx`)

- File selection dropdown (loads available EEG files)
- Preprocessing trigger button
- Tabbed visualization interface
- Chart rendering functions for:
  - Waveform displays (raw, filtered, ICA-cleaned)
  - Power spectral density plots
  - Frequency band analysis heatmaps
- Channel information display

## Preprocessing Pipeline

The preprocessing follows these steps (from the user's notebook):

1. **Load EDF File**: Read EEG data using MNE-Python

   ```
   mne.io.read_raw_edf(filename)
   ```

2. **Bandpass Filter**: Filter signal to 0.1-30 Hz range

   - Removes DC offset and high-frequency noise
   - Focuses on relevant brain activity

3. **ICA (Independent Component Analysis)**

   - 15 components
   - Excludes components 1 and 2 (typical artifacts)
   - Removes eye blinks, muscle artifacts

4. **Power Spectral Density (PSD)**

   - Multitaper method
   - Frequency range: 0.5-30 Hz
   - Computed for all channels

5. **Frequency Band Analysis**
   - Delta: 0.5-4 Hz
   - Theta: 4-8 Hz
   - Alpha: 8-12 Hz
   - Beta: 12-30 Hz

## Usage Flow

### Step 1: Upload EEG File

1. Navigate to EEG Data page
2. Select patient
3. Upload EDF file
4. File saved with metadata (patient, doctor, timestamp)

### Step 2: Visualize & Analyze

1. Navigate to EEG Visualization page
2. Select file from dropdown
3. Click "Process File" button
4. Wait for preprocessing to complete
5. View results in tabs:
   - **Raw**: Original signal
   - **Filtered**: Bandpass filtered (0.1-30 Hz)
   - **ICA Cleaned**: After artifact removal
   - **PSD**: Power spectrum density
   - **Bands**: Frequency band power distribution

## Data Flow Diagram

```
EEG Data Page
    ↓
Upload EDF File → Save to disk
    ↓
EEG Visualization Page
    ↓
Select File → [Process File Button]
    ↓
Frontend: eegAnalysisAPI.preprocess(fileId)
    ↓
Backend: POST /analysis/preprocess/{file_id}
    ↓
EEGPreprocessingService
    ├→ Load file
    ├→ Filter signal
    ├→ Apply ICA
    ├→ Compute PSD
    └→ Compute frequency bands
    ↓
Return JSON Report
    ↓
Frontend Display
    ├→ Waveform charts
    ├→ Frequency plots
    ├→ Band heatmaps
    └→ Channel info
```

## API Response Format

### Full Preprocessing Report (`/analysis/preprocess/{file_id}`)

```json
{
  "status": "success",
  "file_id": "uuid",
  "file_name": "patient_eeg.edf",
  "preprocessing_report": {
    "raw_signal": {
      "channels": ["Fp1", "Fp2", "F3", ...],
      "times": [0, 0.1, 0.2, ...],
      "data": [[...signal values...], ...],
      "sampling_rate": 256
    },
    "filtered_signal": {...},
    "ica_signal": {...},
    "psd": {
      "frequencies": [0.5, 1.0, 1.5, ...],
      "power": [[...power values...], ...],
      "channels": ["Fp1", "Fp2", ...]
    },
    "frequency_bands": {
      "bands": {
        "delta": {
          "Fp1": 1.23,
          "Fp2": 1.45,
          ...
        },
        "theta": {...},
        "alpha": {...},
        "beta": {...}
      }
    },
    "channel_info": {
      "channels": ["Fp1", "Fp2", ...],
      "sampling_rate": 256,
      "duration": 120.5,
      "sample_count": 30976
    }
  }
}
```

## Permission Model

### Access Control

All preprocessing endpoints check user permissions:

- **Root**: Full access to all files
- **Admin**: Can only access files from their organization
- **Doctor**: Can only access their own patients' files
- **Assistant**: Can only access assigned doctor's patients' files
- **Patient**: No preprocessing access

### Database Queries

Assistant access requires DoctorAssistant relationship lookup:

```python
# Get assistant's assigned doctor
doc_assistant = await db.execute(
    select(DoctorAssistant).filter(
        DoctorAssistant.assistant_id == current_user.id
    )
)
# Then verify file belongs to doctor's patients
```

## File Storage

Uploaded EEG files are stored in:

```
{UPLOAD_DIR}/patient_{patient_id}/{unique_filename}
```

Example:

```
uploads/patient_12e4f82c-c2db-4a5a-8f3d-1b8d4e5c6a7b/eeg_20240120_123456.edf
```

File path is stored in `EEGFile.file_path` (relative to `UPLOAD_DIR`).

## Configuration

### Environment Variables (`.env`)

```env
# Upload directory for EEG files
UPLOAD_DIR=uploads

# Model path (for future ML inference)
MODEL_PATH=/path/to/model

# Database URL
DATABASE_URL=postgresql://...
```

### MNE Configuration

Default preprocessing parameters (can be customized):

- Bandpass filter: 0.1-30 Hz
- ICA components: 15
- ICA exclude: [1, 2]
- PSD frequency range: 0.5-30 Hz
- FFT window: 256 samples

## Error Handling

### Common Errors

1. **File Not Found** (404)

   - EEG file doesn't exist in database
   - File missing from disk

2. **Insufficient Permissions** (403)

   - User doesn't own the file's patient
   - User not in same organization (admin)

3. **Processing Failed** (400/500)
   - Invalid EDF file format
   - Missing MNE dependencies
   - Signal processing error

### Backend Logging

Check server logs for detailed errors:

```
Preprocessing error: {error_message}
```

## Performance Considerations

### Processing Time

Typical preprocessing times (for full 60-second EDF):

- Load file: ~1-2s
- Filter: ~0.5s
- ICA: ~3-5s
- PSD: ~1-2s
- Total: ~6-10s

### Optimization Tips

1. Process shorter signal windows (use `duration` parameter)
2. Cache preprocessing results for same file
3. Run preprocessing asynchronously with task queue
4. Limit concurrent preprocessing jobs

### Memory Usage

- Raw signal (256 Hz, 60s, 22 channels): ~3.3 MB
- After ICA (15 components): ~1.4 MB
- PSD data: ~500 KB
- Total working memory: ~10-20 MB per job

## Troubleshooting

### Backend Not Starting

```bash
# Check imports
python -c "from app.services.eeg_preprocessing import EEGPreprocessingService"

# Check MNE installation
pip install mne scipy

# Run dev server
invoke dev
```

### Frontend Showing "Preprocessing failed"

1. Check browser console for error details
2. Verify file is properly uploaded
3. Check backend logs: `invoke logs` or direct server logs
4. Ensure file is valid EDF format

### Missing Dependencies

```bash
# Backend requirements
pip install -r requirements.txt

# Frontend dependencies
cd frontend
npm install
```

## Future Enhancements

1. **Asynchronous Processing**

   - Use Celery/RQ for background preprocessing
   - Queue multiple file processing
   - Progress notifications via WebSocket

2. **Advanced Visualization**

   - Interactive waveform zoom/pan
   - 3D head model with topomap
   - Real-time sliding window analysis
   - Spectrogram visualization

3. **ML Integration**

   - Load pre-trained seizure detection model
   - Real-time seizure detection scoring
   - Artifact classification
   - Automatic report generation

4. **Caching & Optimization**

   - Cache preprocessing results
   - Incremental updates
   - Parallel multi-file processing

5. **Export Features**
   - Export preprocessing report as PDF
   - Export charts as images
   - Export data as CSV/HDF5

## References

- MNE-Python Documentation: https://mne.tools/
- SciPy Signal Processing: https://docs.scipy.org/doc/scipy/reference/signal.html
- FastAPI Documentation: https://fastapi.tiangolo.com/
- React Documentation: https://react.dev/

## Contact & Support

For issues or questions about the preprocessing integration:

1. Check the logs in `backend/logs/`
2. Review MNE error messages
3. Verify EDF file format compatibility
4. Check database connections and file permissions
