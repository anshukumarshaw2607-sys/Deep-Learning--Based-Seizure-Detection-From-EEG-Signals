# EEG Seizure Detection - API Endpoints Documentation

## Overview

This document describes all API endpoints required by the frontend. The base URL is `/api/v1`.

---

## Authentication Endpoints

### 1. Login

**Endpoint:** `POST /api/v1/auth/login`

**Description:** Authenticate user and receive JWT access token.

**Request Format:** `application/x-www-form-urlencoded`

```
username=doctor1&password=yourpassword
```

**Response (200 OK):**

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Error (401):**

```json
{
  "detail": "Incorrect username or password"
}
```

---

### 2. Register

**Endpoint:** `POST /api/v1/auth/register`

**Description:** Create a new user account.

**Request (Content-Type: application/json):**

```json
{
  "username": "doctor1",
  "email": "doctor1@example.com",
  "password": "SecurePass123!"
}
```

**Response (201 Created):**

```json
{
  "id": 1,
  "username": "doctor1",
  "email": "doctor1@example.com",
  "is_active": true
}
```

**Error (400):**

```json
{
  "detail": "Email already registered"
}
```

---

### 3. Get Current User

**Endpoint:** `GET /api/v1/auth/me`

**Description:** Get authenticated user's information.

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "id": 1,
  "username": "doctor1",
  "email": "doctor1@example.com",
  "is_active": true,
  "created_at": "2025-11-12T10:30:00"
}
```

**Error (401):**

```json
{
  "detail": "Not authenticated"
}
```

---

## Users Endpoints

### 4. List Users

**Endpoint:** `GET /api/v1/users/`

**Description:** Get list of all users (paginated).

**Query Parameters:**

- `skip` (optional, default: 0) - Number of records to skip
- `limit` (optional, default: 100) - Maximum number of records to return

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
[
  {
    "id": 1,
    "username": "doctor1",
    "email": "doctor1@example.com",
    "is_active": true
  },
  {
    "id": 2,
    "username": "doctor2",
    "email": "doctor2@example.com",
    "is_active": true
  }
]
```

---

### 5. Get User by ID

**Endpoint:** `GET /api/v1/users/{user_id}`

**Description:** Get specific user information.

**URL Parameters:**

- `user_id` (required) - User ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "id": 1,
  "username": "doctor1",
  "email": "doctor1@example.com",
  "is_active": true,
  "professional_title": "EEG Specialist",
  "organization": "Hospital Name",
  "bio": "Specializing in EEG analysis"
}
```

**Error (404):**

```json
{
  "detail": "User not found"
}
```

---

### 6. Update User

**Endpoint:** `PUT /api/v1/users/{user_id}`

**Description:** Update user profile information.

**URL Parameters:**

- `user_id` (required) - User ID

**Request (Content-Type: application/json):**

```json
{
  "name": "Dr. John Doe",
  "email": "newemail@example.com",
  "professional_title": "EEG Specialist",
  "organization": "Hospital Name",
  "bio": "Specializing in EEG analysis and epilepsy research"
}
```

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "id": 1,
  "username": "doctor1",
  "email": "newemail@example.com",
  "professional_title": "EEG Specialist",
  "organization": "Hospital Name",
  "bio": "Specializing in EEG analysis and epilepsy research",
  "is_active": true
}
```

---

## EEG Data Endpoints

### 7. List EEG Recordings

**Endpoint:** `GET /api/v1/eeg/`

**Description:** Get list of all user's EEG recordings (paginated).

**Query Parameters:**

- `skip` (optional, default: 0) - Number of records to skip
- `limit` (optional, default: 100) - Maximum number of records to return

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
[
  {
    "id": 1,
    "eeg_data_id": 1,
    "name": "Baseline Recording",
    "filename": "baseline_001.edf",
    "upload_date": "2025-11-10T14:30:00",
    "size": "12.1 MB",
    "status": "Analyzed",
    "created_at": "2025-11-10T14:30:00"
  },
  {
    "id": 2,
    "eeg_data_id": 2,
    "name": "Follow-up EEG",
    "filename": "followup_001.csv",
    "upload_date": "2025-11-11T09:15:00",
    "size": "8.5 MB",
    "status": "Not Analyzed",
    "created_at": "2025-11-11T09:15:00"
  }
]
```

---

### 8. Upload EEG File

**Endpoint:** `POST /api/v1/eeg/upload`

**Description:** Upload an EEG file (.edf or .csv format).

**Request Format:** `multipart/form-data`

```
file: <binary file data>
```

**Headers Required:**

```
Authorization: Bearer <access_token>
Content-Type: multipart/form-data
```

**Response (201 Created):**

```json
{
  "id": 3,
  "eeg_data_id": 3,
  "name": "New Recording",
  "filename": "new_recording.edf",
  "upload_date": "2025-11-12T10:00:00",
  "size": "15.3 MB",
  "status": "Not Analyzed",
  "created_at": "2025-11-12T10:00:00"
}
```

**Error (400):**

```json
{
  "detail": "File size exceeds 50MB limit"
}
```

---

### 9. Get EEG Details

**Endpoint:** `GET /api/v1/eeg/{eeg_id}`

**Description:** Get detailed information about a specific EEG recording.

**URL Parameters:**

- `eeg_id` (required) - EEG ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "id": 1,
  "eeg_data_id": 1,
  "name": "Baseline Recording",
  "filename": "baseline_001.edf",
  "upload_date": "2025-11-10T14:30:00",
  "size": "12.1 MB",
  "status": "Analyzed",
  "duration": "45 minutes",
  "channels": 19,
  "sampling_rate": 250,
  "created_at": "2025-11-10T14:30:00"
}
```

---

### 10. Analyze EEG

**Endpoint:** `POST /api/v1/eeg/{eeg_id}/analyze`

**Description:** Run seizure detection analysis on an EEG recording.

**URL Parameters:**

- `eeg_id` (required) - EEG ID

**Request (Content-Type: application/json):**

```json
{
  "eeg_data_id": 1,
  "model_version": "v1"
}
```

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "analysis_id": 10,
  "eeg_id": 1,
  "status": "processing",
  "seizure_detected": true,
  "confidence_score": 0.92,
  "seizure_start_time": 120,
  "seizure_end_time": 167,
  "processing_notes": "Analysis in progress",
  "created_at": "2025-11-12T10:05:00"
}
```

---

### 11. Get EEG Analyses

**Endpoint:** `GET /api/v1/eeg/{eeg_id}/analyses`

**Description:** Get all analysis results for a specific EEG recording.

**URL Parameters:**

- `eeg_id` (required) - EEG ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
[
  {
    "analysis_id": 10,
    "eeg_id": 1,
    "status": "completed",
    "seizure_detected": true,
    "confidence_score": 0.92,
    "seizure_start_time": 120,
    "seizure_end_time": 167,
    "processing_notes": "2 seizure events detected",
    "created_at": "2025-11-12T10:05:00"
  }
]
```

---

### 12. Delete EEG Recording

**Endpoint:** `DELETE /api/v1/eeg/{eeg_id}`

**Description:** Delete an EEG recording and associated data.

**URL Parameters:**

- `eeg_id` (required) - EEG ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "message": "EEG recording deleted successfully",
  "eeg_id": 1
}
```

**Error (404):**

```json
{
  "detail": "EEG recording not found"
}
```

---

## Reports Endpoints

### 13. Create Report

**Endpoint:** `POST /api/v1/reports/`

**Description:** Generate a diagnostic report from EEG analysis.

**Request (Content-Type: application/json):**

```json
{
  "title": "Seizure Analysis Report",
  "eeg_id": 1,
  "findings": "2 seizure events detected",
  "conclusions": "Consistent with temporal lobe epilepsy. Further clinical correlation recommended."
}
```

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (201 Created):**

```json
{
  "id": 5,
  "title": "Seizure Analysis Report",
  "eeg_id": 1,
  "findings": "2 seizure events detected",
  "conclusions": "Consistent with temporal lobe epilepsy. Further clinical correlation recommended.",
  "created_at": "2025-11-12T10:10:00",
  "updated_at": "2025-11-12T10:10:00"
}
```

---

### 14. List Reports

**Endpoint:** `GET /api/v1/reports/`

**Description:** Get list of all user's reports (paginated).

**Query Parameters:**

- `skip` (optional, default: 0) - Number of records to skip
- `limit` (optional, default: 100) - Maximum number of records to return

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
[
  {
    "id": 1,
    "title": "Seizure Analysis Report",
    "eeg_id": 1,
    "date": "2025-11-12T10:10:00",
    "findings": "2 seizure events detected",
    "type": "Analysis Report",
    "created_at": "2025-11-12T10:10:00"
  },
  {
    "id": 2,
    "title": "Clinical Assessment",
    "eeg_id": 2,
    "date": "2025-11-11T15:30:00",
    "findings": "Normal EEG",
    "type": "Clinical Assessment Report",
    "created_at": "2025-11-11T15:30:00"
  }
]
```

---

### 15. Get Report Details

**Endpoint:** `GET /api/v1/reports/{report_id}`

**Description:** Get detailed information about a specific report.

**URL Parameters:**

- `report_id` (required) - Report ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "id": 1,
  "title": "Seizure Analysis Report",
  "eeg_id": 1,
  "recording": "Baseline Recording",
  "recording_date": "2025-11-10T14:30:00",
  "duration": "45 minutes",
  "channels": 19,
  "findings": "2 seizure events detected",
  "seizure_details": [
    {
      "event": "Seizure 1",
      "time": "00:12:34",
      "duration": "47 seconds",
      "channels": "T3, T5, F7",
      "confidence": "92%"
    },
    {
      "event": "Seizure 2",
      "time": "00:23:45",
      "duration": "32 seconds",
      "channels": "T3, T5, F7, C3",
      "confidence": "87%"
    }
  ],
  "conclusions": "The analysis indicates focal seizure activity from the left temporal region.",
  "created_at": "2025-11-12T10:10:00"
}
```

---

### 16. Download Report (PDF)

**Endpoint:** `GET /api/v1/reports/{report_id}/download`

**Description:** Download report as PDF file.

**URL Parameters:**

- `report_id` (required) - Report ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

- Returns binary PDF file
- Content-Type: `application/pdf`

**Error (404):**

```json
{
  "detail": "Report not found"
}
```

---

### 17. Delete Report

**Endpoint:** `DELETE /api/v1/reports/{report_id}`

**Description:** Delete a report.

**URL Parameters:**

- `report_id` (required) - Report ID

**Headers Required:**

```
Authorization: Bearer <access_token>
```

**Response (200 OK):**

```json
{
  "message": "Report deleted successfully",
  "report_id": 1
}
```

**Error (404):**

```json
{
  "detail": "Report not found"
}
```

---

## Common Response Codes

| Code | Meaning                                  |
| ---- | ---------------------------------------- |
| 200  | Success                                  |
| 201  | Created                                  |
| 400  | Bad Request (validation error)           |
| 401  | Unauthorized (missing/invalid token)     |
| 403  | Forbidden (user doesn't have permission) |
| 404  | Not Found (resource doesn't exist)       |
| 500  | Internal Server Error                    |

---

## Error Response Format

All errors follow this format:

```json
{
  "detail": "Error message describing what went wrong"
}
```

---

## Authentication Notes

- All protected endpoints require a valid JWT token in the `Authorization` header
- Format: `Authorization: Bearer <access_token>`
- Tokens expire after 30 minutes (configurable)
- Frontend automatically redirects to login if a 401 is received

---

## File Upload Requirements

- **Supported formats:** `.edf`, `.csv`
- **Maximum file size:** 50 MB
- **Content-Type:** `multipart/form-data`

---

## Database Models Expected

### User

- `id` - Primary key
- `username` - Unique username
- `email` - Unique email
- `hashed_password` - Bcrypt hashed password
- `is_active` - Account status
- `professional_title` - User's job title
- `organization` - Organization name
- `bio` - Short bio
- `created_at` - Timestamp
- `updated_at` - Timestamp

### EEG Data

- `id` - Primary key
- `user_id` - Foreign key to User
- `name` - Recording name
- `filename` - Original filename
- `file_path` - Storage path
- `size` - File size
- `upload_date` - Upload timestamp
- `duration` - Recording duration
- `channels` - Number of channels
- `sampling_rate` - Sampling rate
- `status` - Analysis status
- `created_at` - Timestamp

### Report

- `id` - Primary key
- `user_id` - Foreign key to User
- `eeg_id` - Foreign key to EEG Data
- `title` - Report title
- `findings` - Analysis findings
- `conclusions` - Conclusions
- `file_path` - PDF storage path
- `created_at` - Timestamp
- `updated_at` - Timestamp

---

## Frontend Client Library

The frontend uses the following API client methods (see `frontend/src/services/api.js`):

```javascript
// Auth
authAPI.login(username, password);
authAPI.register(userData);
authAPI.getCurrentUser();
authAPI.logout();

// Users
usersAPI.list(skip, limit);
usersAPI.get(userId);
usersAPI.update(userId, userData);

// EEG
eegAPI.upload(file, onUploadProgress);
eegAPI.list(skip, limit);
eegAPI.get(eegId);
eegAPI.analyze(eegId, modelVersion);
eegAPI.getAnalyses(eegId);
eegAPI.delete(eegId);

// Reports
reportsAPI.create(reportData);
reportsAPI.list(skip, limit);
reportsAPI.get(reportId);
reportsAPI.download(reportId);
reportsAPI.delete(reportId);
```

---

**Last Updated:** November 12, 2025
