# EEG Files API - Comprehensive Analysis

## Overview

The EEG Files API manages European Data Format (.edf) files for patients. It provides full CRUD operations with role-based access control and automatic metadata extraction.

---

## 1. API Endpoints Summary

### Base Endpoint

- **URL:** `/api/v1/eeg-files`
- **Authentication:** Required (Bearer token)

### Endpoints Available

| Method | Endpoint                        | Purpose                           |
| ------ | ------------------------------- | --------------------------------- |
| POST   | `/eeg-files/upload`             | Upload new EEG file               |
| GET    | `/eeg-files`                    | List all EEG files with filtering |
| GET    | `/eeg-files/{file_id}`          | Get specific file details         |
| GET    | `/eeg-files/{file_id}/download` | Download EEG file                 |
| PUT    | `/eeg-files/{file_id}`          | Update file metadata              |
| DELETE | `/eeg-files/{file_id}`          | Delete file (soft/hard)           |

---

## 2. Detailed Endpoint Analysis

### 2.1 Upload EEG File

**POST** `/eeg-files/upload`

**Purpose:** Upload an EDF file for a patient with optional metadata.

**Permissions:**

- ✅ **Root:** Can upload for any patient
- ✅ **Admin:** Can upload for patients of doctors in their organization
- ✅ **Doctor:** Can upload for their own patients only
- ❌ **Assistant:** No upload permission

**Request Format:** `multipart/form-data`

**Form Parameters:**

```
file: UploadFile (required)           # .edf file only
patient_id: UUID (required)           # Patient to associate with
description: string (optional)        # Description of recording
notes: string (optional)              # Additional notes
```

**Validation Rules:**

- File extension must be `.edf` (case-insensitive)
- File size max: 100MB (configurable via `MAX_UPLOAD_SIZE`)
- Patient must exist and user must have access to it

**Success Response (200 OK):**

```json
{
  "message": "EEG file uploaded successfully",
  "data": {
    "id": "uuid",
    "patient_id": "uuid",
    "uploaded_by": "uuid",
    "filename": "abc123def456.edf",           # System-generated name
    "original_filename": "patient_eeg.edf",  # User's original name
    "file_path": "patient_id/filename.edf",
    "file_size": 1048576,                     # In bytes
    "file_hash": "sha256hash...",
    "recording_duration": 3600.0,             # Auto-extracted (seconds)
    "sampling_rate": 256.0,                   # Auto-extracted (Hz)
    "number_of_channels": 19,                 # Auto-extracted
    "channel_names": "Fp1,Fp2,F3,...",       # Auto-extracted
    "description": "Description...",
    "notes": "Notes...",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": null,
    "uploader_name": "Dr. John Smith"
  }
}
```

**Error Responses:**

- **400:** Invalid file format, file too large, patient not found
- **403:** Insufficient permissions
- **500:** Server error during processing

**Frontend Method:**

```javascript
eegFilesAPI.upload(file, patientId, description, notes, onUploadProgress);
// Returns: response object with 'data' containing file details
// onUploadProgress: callback for upload percentage (0-100)
```

---

### 2.2 List EEG Files

**GET** `/eeg-files`

**Purpose:** Get paginated list of EEG files with optional filters.

**Permissions:**

- ✅ **Root:** See all files
- ✅ **Admin:** See files for patients in their organization (org-scoped)
- ✅ **Doctor:** See files for their own patients only
- ❌ **Assistant:** No list permission (need to update backend to allow)

**Query Parameters:**

```
skip: int (default: 0)                    # Pagination offset
limit: int (default: 100, max: 1000)      # Records per page
patient_id: UUID (optional)               # Filter by patient
uploaded_by: UUID (optional)              # Filter by uploader
include_deleted: bool (default: false)    # Include soft-deleted
```

**Success Response (200 OK):**

```json
{
  "files": [
    {
      "id": "uuid",
      "patient_id": "uuid",
      "uploaded_by": "uuid",
      "filename": "abc123def456.edf",
      "original_filename": "patient_eeg.edf",
      "file_path": "patient_id/filename.edf",
      "file_size": 1048576,
      "file_hash": "sha256hash...",
      "recording_duration": 3600.0,
      "sampling_rate": 256.0,
      "number_of_channels": 19,
      "channel_names": "Fp1,Fp2,F3,...",
      "description": "Baseline recording",
      "notes": null,
      "is_deleted": false,
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": null,
      "uploader_name": "Dr. John Smith"
    }
  ],
  "total": 42,
  "skip": 0,
  "limit": 100
}
```

**Frontend Method:**

```javascript
eegFilesAPI.list(skip, limit, patientId, uploadedBy, includeDeleted);
// Returns: { files: [], total, skip, limit }
```

---

### 2.3 Get Single EEG File

**GET** `/eeg-files/{file_id}`

**Purpose:** Retrieve detailed information about a specific EEG file.

**Permissions:**

- ✅ **Root:** Can get any file
- ✅ **Admin:** Can get files for org patients
- ✅ **Doctor:** Can get files for own patients only
- ❌ **Assistant:** No permission (need to update)

**Path Parameters:**

```
file_id: UUID (required)  # File identifier
```

**Success Response (200 OK):**

```json
{
  "id": "uuid",
  "patient_id": "uuid",
  "uploaded_by": "uuid",
  "filename": "abc123def456.edf",
  "original_filename": "patient_eeg.edf",
  "file_path": "patient_id/filename.edf",
  "file_size": 1048576,
  "file_hash": "sha256hash...",
  "recording_duration": 3600.0,
  "sampling_rate": 256.0,
  "number_of_channels": 19,
  "channel_names": "Fp1,Fp2,F3,...",
  "description": "Baseline recording",
  "notes": null,
  "is_deleted": false,
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-16T14:20:00Z",
  "uploader_name": "Dr. John Smith"
}
```

**Frontend Method:**

```javascript
eegFilesAPI.get(fileId);
// Returns: file object
```

---

### 2.4 Download EEG File

**GET** `/eeg-files/{file_id}/download`

**Purpose:** Download the actual EEG file binary.

**Permissions:** Same as get_eeg_file

- ✅ **Root:** Can download any file
- ✅ **Admin:** Can download org patient files
- ✅ **Doctor:** Can download own patient files
- ❌ **Assistant:** No permission

**Path Parameters:**

```
file_id: UUID (required)  # File identifier
```

**Success Response:**

- **Content-Type:** `application/octet-stream`
- **Content-Disposition:** attachment; filename="original_filename.edf"
- **Body:** Binary EDF file

**Frontend Method:**

```javascript
eegFilesAPI.download(fileId);
// Returns: Blob
// Browser automatically triggers download with original filename
```

**Frontend Usage Pattern:**

```javascript
// Download and save
const blob = await eegFilesAPI.download(fileId);
const url = window.URL.createObjectURL(blob);
const a = document.createElement("a");
a.href = url;
a.download = `eeg_${fileId}.edf`;
document.body.appendChild(a);
a.click();
window.URL.revokeObjectURL(url);
document.body.removeChild(a);
```

---

### 2.5 Update EEG File Metadata

**PUT** `/eeg-files/{file_id}`

**Purpose:** Update file metadata (description, notes, soft delete status).

**Permissions:** Same as get_eeg_file

- ✅ **Root:** Can update any file
- ✅ **Admin:** Can update org patient files
- ✅ **Doctor:** Can update own patient files
- ❌ **Assistant:** No permission

**Path Parameters:**

```
file_id: UUID (required)  # File identifier
```

**Request Body** (all optional):

```json
{
  "description": "Updated description",
  "notes": "Updated notes",
  "is_deleted": false
}
```

**Limitations:**

- ❌ Cannot modify the actual file
- ❌ Cannot change recording_duration, sampling_rate, channels (auto-extracted)
- ✅ Can only update: description, notes, is_deleted

**Success Response (200 OK):**

```json
{
  "message": "EEG file updated successfully",
  "data": {
    // Full file object with updates applied
    "id": "uuid",
    "description": "Updated description",
    "notes": "Updated notes",
    // ... other fields
    "updated_at": "2024-01-16T15:45:00Z"
  }
}
```

**Frontend Method:**

```javascript
eegFilesAPI.update(fileId, { description, notes, is_deleted });
// Returns: response object with updated file data
```

---

### 2.6 Delete EEG File

**DELETE** `/eeg-files/{file_id}`

**Purpose:** Delete an EEG file (soft or hard delete).

**Permissions:**

- ✅ **Root:** Can soft delete OR hard delete
- ✅ **Admin:** Can only soft delete org patient files
- ✅ **Doctor:** Can only soft delete own patient files
- ❌ **Assistant:** No permission

**Path Parameters:**

```
file_id: UUID (required)  # File identifier
```

**Query Parameters:**

```
hard_delete: bool (default: false)  # Permanent delete (root only)
```

**Soft Delete:** Sets `is_deleted = true`, file still exists but hidden from normal queries
**Hard Delete:** Permanently removes file from database and file system (root only)

**Success Response (200 OK):**

```json
{
  "message": "EEG file deleted successfully",
  "file_id": "uuid",
  "deletion_type": "soft" // or "hard"
}
```

**Frontend Method:**

```javascript
eegFilesAPI.delete(fileId, (hardDelete = false));
// Returns: response object
// hardDelete: only works for root users
```

---

## 3. Role-Based Permission Matrix

| Action          | Root   | Admin  | Doctor | Assistant |
| --------------- | ------ | ------ | ------ | --------- |
| **Upload**      | ✅ Any | ✅ Org | ✅ Own | ❌        |
| **List**        | ✅ All | ✅ Org | ✅ Own | ❌        |
| **View**        | ✅ Any | ✅ Org | ✅ Own | ❌        |
| **Download**    | ✅ Any | ✅ Org | ✅ Own | ❌        |
| **Update**      | ✅ Any | ✅ Org | ✅ Own | ❌        |
| **Soft Delete** | ✅     | ✅     | ✅     | ❌        |
| **Hard Delete** | ✅     | ❌     | ❌     | ❌        |

**Key Notes:**

- **Own:** Only files for user's own patients
- **Org:** Files for patients of doctors in user's organization
- **Any:** Any file in system

---

## 4. Data Model & Fields

### EEGFile Model Fields

**Identifiers:**

- `id`: UUID (auto-generated)
- `patient_id`: UUID (foreign key to Patient)
- `uploaded_by`: UUID (foreign key to User who uploaded)

**File Information:**

- `filename`: string (system-generated, unique)
- `original_filename`: string (user's original filename)
- `file_path`: string (relative path: `patient_id/filename.edf`)
- `file_size`: integer (bytes)
- `file_hash`: string (SHA256 hash for integrity)

**Auto-Extracted Metadata** (from EDF file):

- `recording_duration`: float (seconds)
- `sampling_rate`: float (Hz)
- `number_of_channels`: integer
- `channel_names`: string (comma-separated: "Fp1,Fp2,F3,...")

**User-Provided Metadata:**

- `description`: string (optional)
- `notes`: string (optional)

**Status:**

- `is_deleted`: boolean (soft delete flag)
- `created_at`: datetime
- `updated_at`: datetime

**Computed Fields (in response):**

- `uploader_name`: string (from User.full_name)

---

## 5. Key Implementation Considerations

### 5.1 Frontend Implementation Strategy

For EEG Data Page, we should implement:

1. **List View:**

   - Display paginated table of EEG files
   - Show: filename, patient name, upload date, uploader, duration, channels
   - Filter by patient (pre-select if on patient detail)
   - Pagination controls

2. **Upload Feature:**

   - File input with .edf validation
   - Progress bar during upload
   - Error handling for file size/format
   - Optional description and notes fields

3. **Actions:**

   - View details (modal/side panel)
   - Download file
   - Edit metadata (description, notes)
   - Delete (soft delete for doctor/admin)
   - Hard delete (root only)

4. **Filters:**
   - By patient (if admin showing all org, doctor showing own)
   - By uploader
   - Include/exclude deleted

### 5.2 Role-Based UI Rendering

**Doctor Role:**

- Can only see their own patients' files
- Can upload for own patients
- Can edit/delete own files (soft delete)
- File list pre-filtered to own patients

**Admin Role:**

- Can see all organization patients' files
- Can upload for org patients
- Can edit/delete org files (soft delete)
- File list shows all org files with patient names

**Root Role:**

- Can see all system files
- Can perform all operations
- Access to hard delete
- File list shows all files with doctor/organization info

**Assistant Role:**

- Currently no EEG files permission
- **Recommendation:** Update backend to allow assistants to view/download files of their assigned doctor's patients

### 5.3 Error Handling

Common errors to handle:

- **400:** Invalid file (not .edf, too large)
- **403:** Permission denied (trying to access other doctor's files)
- **404:** File not found
- **413:** File too large
- **500:** Server error

### 5.4 File Metadata Extraction

Auto-extracted from EDF file:

- Recording duration (in seconds)
- Sampling rate (frequency in Hz)
- Number of channels
- Channel names (e.g., Fp1, Fp2, F3, F4, etc.)

These are read-only and cannot be updated without re-uploading.

---

## 6. Frontend Methods Already Implemented

All methods are ready in `frontend/src/services/api.js`:

```javascript
// Upload with progress tracking
eegFilesAPI.upload(file, patientId, description, notes, onUploadProgress);

// List with pagination and filters
eegFilesAPI.list(skip, limit, patientId, uploadedBy, includeDeleted);

// Get single file details
eegFilesAPI.get(fileId);

// Download file as blob
eegFilesAPI.download(fileId);

// Update metadata
eegFilesAPI.update(fileId, { description, notes, is_deleted });

// Delete file
eegFilesAPI.delete(fileId, hardDelete);
```

---

## 7. Recommended EEG Data Page Structure

### Components Needed:

1. **EEGDataPage.jsx** - Main container component

   - Role-based view selection
   - State management for files, filters, pagination

2. **EEGFilesList.jsx** - Table/list display component

   - Pagination
   - Sorting
   - Actions (view, download, edit, delete)

3. **EEGFileUploadModal.jsx** - Upload dialog

   - File input with validation
   - Progress bar
   - Description/notes fields
   - Patient selector (or pre-selected)

4. **EEGFileDetailsModal.jsx** - View/edit details

   - Display all metadata
   - Edit description/notes
   - Download button
   - Delete button

5. **Filters Component** - Optional
   - Patient filter
   - Date range filter
   - Uploader filter

---

## 8. Backend Update Recommendations

**For Assistant Role:**
Currently, assistants cannot access EEG files. Recommended update:

```python
# Allow assistants to list files for their assigned doctor's patients
elif current_user.role == "assistant":
    # Get assigned doctor
    doctor = await user_service.get_doctor_by_assistant_id(current_user.id)
    if not doctor:
        raise HTTPException(status_code=403, detail="Not assigned to any doctor")

    # Get doctor's patients
    doctor_patients = await patient_service.get_patients_by_doctor(doctor.id)
    patient_ids = {p.id for p in doctor_patients}

    # Filter files by those patient IDs
```

This would allow assistants to:

- ✅ View EEG files for their doctor's patients
- ✅ Download files
- ❌ Upload/edit/delete (restrict to doctor/admin)

---

## 9. API Validation & Constraints

### File Upload Constraints:

- **File Format:** .edf only (case-insensitive)
- **Max Size:** 100MB (configurable)
- **Patient Association:** Required and must be accessible to user

### Field Constraints:

- **description:** Optional, string
- **notes:** Optional, string
- **is_deleted:** Boolean (soft delete only)

### Pagination Constraints:

- **skip:** >= 0 (non-negative)
- **limit:** 1-1000 (min 1, max 1000)

---

## Summary

The EEG Files API is a comprehensive system for managing EDF format files with:

- ✅ Full CRUD operations
- ✅ Role-based access control
- ✅ Automatic metadata extraction
- ✅ Soft/hard delete support
- ✅ File upload with progress tracking
- ✅ Pagination and filtering

**Ready to implement in EEG Data Page** with proper role-based UI and permission handling.
