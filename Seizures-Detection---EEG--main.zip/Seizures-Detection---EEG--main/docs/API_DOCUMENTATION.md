# API Documentation - Patients & EEG Files

## Base Information

**Base URL:** `http://localhost:8000/api/v1` (or your server URL)

**Authentication:** All endpoints require a Bearer token in the Authorization header.

```
Authorization: Bearer <your_access_token>
```

Get the access token from the `/api/v1/auth/login` endpoint.

---

## Table of Contents

1. [Patients Endpoints](#patients-endpoints)
2. [EEG Files Endpoints](#eeg-files-endpoints)
3. [Error Responses](#error-responses)
4. [Permission Matrix](#permission-matrix)

---

## Patients Endpoints

### 1. Create Patient

**POST** `/patients`

Create a new patient record.

**Permissions:**
- **Doctors:** Can create patients and assign them to themselves (doctor_id optional, defaults to current user)
- **Admins:** Can create patients and assign them to doctors in their organization
- **Root:** Can create patients and assign them to any doctor

**Request Body:**
```json
{
  "full_name": "John Doe",
  "date_of_birth": "1990-05-15",
  "age": 34,
  "gender": "Male",
  "contact_number": "+1234567890",
  "email": "john.doe@example.com",
  "medical_history": "No significant medical history",
  "notes": "Regular checkups",
  "doctor_id": "550e8400-e29b-41d4-a716-446655440000"  // Optional for doctors
}
```

**Response (200 OK):**
```json
{
  "message": "Patient created successfully",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "doctor_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John Doe",
    "date_of_birth": "1990-05-15",
    "age": 34,
    "gender": "Male",
    "contact_number": "+1234567890",
    "email": "john.doe@example.com",
    "medical_history": "No significant medical history",
    "notes": "Regular checkups",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": null,
    "doctor_name": "Dr. Jane Smith"
  }
}
```

---

### 2. Get All Patients

**GET** `/patients`

Get a paginated list of patients.

**Permissions:**
- **Doctors:** Can see their own patients only
- **Admins:** Can see patients of doctors in their organization
- **Root:** Can see all patients

**Query Parameters:**
- `skip` (optional, default: 0): Number of records to skip for pagination
- `limit` (optional, default: 100, max: 1000): Number of records to return
- `doctor_id` (optional): Filter by doctor ID
- `include_deleted` (optional, default: false): Include soft-deleted patients

**Example Requests:**
```
GET /patients
GET /patients?skip=0&limit=50
GET /patients?doctor_id=550e8400-e29b-41d4-a716-446655440000
GET /patients?skip=10&limit=20&include_deleted=false
```

**Response (200 OK):**
```json
[
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "doctor_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John Doe",
    "date_of_birth": "1990-05-15",
    "age": 34,
    "gender": "Male",
    "contact_number": "+1234567890",
    "email": "john.doe@example.com",
    "medical_history": "No significant medical history",
    "notes": "Regular checkups",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": null,
    "doctor_name": "Dr. Jane Smith"
  }
]
```

---

### 3. Get Patient by ID

**GET** `/patients/{patient_id}`

Get a specific patient by their ID.

**Permissions:**
- **Doctors:** Can see their own patients only
- **Admins:** Can see patients of doctors in their organization
- **Root:** Can see any patient

**Path Parameters:**
- `patient_id` (UUID): The patient's unique identifier

**Example Request:**
```
GET /patients/123e4567-e89b-12d3-a456-426614174000
```

**Response (200 OK):**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "doctor_id": "550e8400-e29b-41d4-a716-446655440000",
  "full_name": "John Doe",
  "date_of_birth": "1990-05-15",
  "age": 34,
  "gender": "Male",
  "contact_number": "+1234567890",
  "email": "john.doe@example.com",
  "medical_history": "No significant medical history",
  "notes": "Regular checkups",
  "is_deleted": false,
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": null,
  "doctor_name": "Dr. Jane Smith"
}
```

---

### 4. Update Patient

**PUT** `/patients/{patient_id}`

Update patient information.

**Permissions:**
- **Doctors:** Can update their own patients (cannot reassign to other doctors)
- **Admins:** Can update patients of doctors in their organization
- **Root:** Can update any patient

**Path Parameters:**
- `patient_id` (UUID): The patient's unique identifier

**Request Body:** (All fields are optional - only include fields you want to update)
```json
{
  "full_name": "John Doe Updated",
  "age": 35,
  "contact_number": "+1234567891",
  "medical_history": "Updated medical history",
  "notes": "Updated notes"
}
```

**Response (200 OK):**
```json
{
  "message": "Patient updated successfully",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "doctor_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John Doe Updated",
    "date_of_birth": "1990-05-15",
    "age": 35,
    "gender": "Male",
    "contact_number": "+1234567891",
    "email": "john.doe@example.com",
    "medical_history": "Updated medical history",
    "notes": "Updated notes",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-16T14:20:00Z",
    "doctor_name": "Dr. Jane Smith"
  }
}
```

---

### 5. Delete Patient

**DELETE** `/patients/{patient_id}`

Delete a patient (soft delete by default).

**Permissions:**
- **Doctors:** Can soft delete their own patients
- **Admins:** Can soft delete patients of doctors in their organization
- **Root:** Can delete any patient (soft or hard delete)

**Path Parameters:**
- `patient_id` (UUID): The patient's unique identifier

**Query Parameters:**
- `hard_delete` (optional, default: false): Permanently delete the patient (root only)

**Example Requests:**
```
DELETE /patients/123e4567-e89b-12d3-a456-426614174000
DELETE /patients/123e4567-e89b-12d3-a456-426614174000?hard_delete=false
```

**Response (200 OK):**
```json
{
  "message": "Patient deleted successfully",
  "patient_id": "123e4567-e89b-12d3-a456-426614174000",
  "deletion_type": "soft"
}
```

---

## EEG Files Endpoints

### 1. Upload EEG File

**POST** `/eeg-files/upload`

Upload an EDF (European Data Format) file for a patient.

**Permissions:**
- **Doctors:** Can upload files for their own patients
- **Admins:** Can upload files for patients of doctors in their organization
- **Root:** Can upload files for any patient

**Content-Type:** `multipart/form-data`

**Form Data:**
- `file` (File, required): The EDF file to upload (only `.edf` files are allowed)
- `patient_id` (UUID, required): Patient ID to associate the file with
- `description` (String, optional): Optional description of the file
- `notes` (String, optional): Optional notes about the file

**File Requirements:**
- File format: `.edf` (European Data Format) only
- Maximum file size: 100MB (configurable)

**Example Request (using FormData):**
```javascript
const formData = new FormData();
formData.append('file', fileInput.files[0]);
formData.append('patient_id', '550e8400-e29b-41d4-a716-446655440000');
formData.append('description', 'Baseline EEG recording');
formData.append('notes', 'Patient was calm during recording');
```

**Response (200 OK):**
```json
{
  "message": "EEG file uploaded successfully",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "patient_id": "550e8400-e29b-41d4-a716-446655440000",
    "uploaded_by": "789e0123-e45b-67c8-d901-234567890abc",
    "filename": "abc123def456.edf",
    "original_filename": "patient_recording.edf",
    "file_path": "550e8400-e29b-41d4-a716-446655440000/abc123def456.edf",
    "file_size": 1048576,
    "file_hash": "sha256hash...",
    "recording_duration": 3600.0,
    "sampling_rate": 256.0,
    "number_of_channels": 19,
    "channel_names": "Fp1,Fp2,F3,F4,C3,C4,P3,P4,O1,O2,F7,F8,T3,T4,T5,T6,Fz,Cz,Pz",
    "description": "Baseline EEG recording",
    "notes": "Patient was calm during recording",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": null,
    "uploader_name": "Dr. John Smith"
  }
}
```

**Note:** The metadata (recording_duration, sampling_rate, number_of_channels, channel_names) is automatically extracted from the EDF file.

---

### 2. Get All EEG Files

**GET** `/eeg-files`

Get a paginated list of EEG files.

**Permissions:**
- **Doctors:** Can see files for their own patients
- **Admins:** Can see files for patients of doctors in their organization
- **Root:** Can see all files

**Query Parameters:**
- `skip` (optional, default: 0): Number of records to skip for pagination
- `limit` (optional, default: 100, max: 1000): Number of records to return
- `patient_id` (optional): Filter by patient ID
- `uploaded_by` (optional): Filter by uploader ID
- `include_deleted` (optional, default: false): Include soft-deleted files

**Example Requests:**
```
GET /eeg-files
GET /eeg-files?skip=0&limit=50
GET /eeg-files?patient_id=550e8400-e29b-41d4-a716-446655440000
GET /eeg-files?skip=10&limit=20&include_deleted=false
```

**Response (200 OK):**
```json
{
  "files": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "patient_id": "550e8400-e29b-41d4-a716-446655440000",
      "uploaded_by": "789e0123-e45b-67c8-d901-234567890abc",
      "filename": "abc123def456.edf",
      "original_filename": "patient_recording.edf",
      "file_path": "550e8400-e29b-41d4-a716-446655440000/abc123def456.edf",
      "file_size": 1048576,
      "file_hash": "sha256hash...",
      "recording_duration": 3600.0,
      "sampling_rate": 256.0,
      "number_of_channels": 19,
      "channel_names": "Fp1,Fp2,F3,F4,C3,C4,P3,P4,O1,O2,F7,F8,T3,T4,T5,T6,Fz,Cz,Pz",
      "description": "Baseline EEG recording",
      "notes": null,
      "is_deleted": false,
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": null,
      "uploader_name": "Dr. John Smith"
    }
  ],
  "total": 1,
  "skip": 0,
  "limit": 50
}
```

---

### 3. Get EEG File by ID

**GET** `/eeg-files/{file_id}`

Get a specific EEG file by its ID.

**Permissions:**
- **Doctors:** Can see files for their own patients
- **Admins:** Can see files for patients of doctors in their organization
- **Root:** Can see any file

**Path Parameters:**
- `file_id` (UUID): The EEG file's unique identifier

**Example Request:**
```
GET /eeg-files/123e4567-e89b-12d3-a456-426614174000
```

**Response (200 OK):**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "patient_id": "550e8400-e29b-41d4-a716-446655440000",
  "uploaded_by": "789e0123-e45b-67c8-d901-234567890abc",
  "filename": "abc123def456.edf",
  "original_filename": "patient_recording.edf",
  "file_path": "550e8400-e29b-41d4-a716-446655440000/abc123def456.edf",
  "file_size": 1048576,
  "file_hash": "sha256hash...",
  "recording_duration": 3600.0,
  "sampling_rate": 256.0,
  "number_of_channels": 19,
  "channel_names": "Fp1,Fp2,F3,F4,C3,C4,P3,P4,O1,O2,F7,F8,T3,T4,T5,T6,Fz,Cz,Pz",
  "description": "Baseline EEG recording",
  "notes": null,
  "is_deleted": false,
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": null,
  "uploader_name": "Dr. John Smith"
}
```

---

### 4. Download EEG File

**GET** `/eeg-files/{file_id}/download`

Download an EEG file.

**Permissions:**
- **Doctors:** Can download files for their own patients
- **Admins:** Can download files for patients of doctors in their organization
- **Root:** Can download any file

**Path Parameters:**
- `file_id` (UUID): The EEG file's unique identifier

**Example Request:**
```
GET /eeg-files/123e4567-e89b-12d3-a456-426614174000/download
```

**Response:** Binary file download (`.edf` file)

**Note:** The response will be a file download with the original filename.

---

### 5. Update EEG File Metadata

**PUT** `/eeg-files/{file_id}`

Update EEG file metadata (description, notes, or soft delete status).

**Permissions:**
- **Doctors:** Can update files for their own patients
- **Admins:** Can update files for patients of doctors in their organization
- **Root:** Can update any file

**Path Parameters:**
- `file_id` (UUID): The EEG file's unique identifier

**Request Body:** (All fields are optional - only include fields you want to update)
```json
{
  "description": "Updated description - Follow-up recording",
  "notes": "Patient showed improvement",
  "is_deleted": false
}
```

**Response (200 OK):**
```json
{
  "message": "EEG file updated successfully",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "patient_id": "550e8400-e29b-41d4-a716-446655440000",
    "uploaded_by": "789e0123-e45b-67c8-d901-234567890abc",
    "filename": "abc123def456.edf",
    "original_filename": "patient_recording.edf",
    "file_path": "550e8400-e29b-41d4-a716-446655440000/abc123def456.edf",
    "file_size": 1048576,
    "file_hash": "sha256hash...",
    "recording_duration": 3600.0,
    "sampling_rate": 256.0,
    "number_of_channels": 19,
    "channel_names": "Fp1,Fp2,F3,F4,C3,C4,P3,P4,O1,O2,F7,F8,T3,T4,T5,T6,Fz,Cz,Pz",
    "description": "Updated description - Follow-up recording",
    "notes": "Patient showed improvement",
    "is_deleted": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-16T14:20:00Z",
    "uploader_name": "Dr. John Smith"
  }
}
```

**Note:** You cannot update the file itself or the automatically extracted metadata (recording_duration, sampling_rate, number_of_channels, channel_names). To change these, upload a new file.

---

### 6. Delete EEG File

**DELETE** `/eeg-files/{file_id}`

Delete an EEG file (soft delete by default).

**Permissions:**
- **Doctors:** Can soft delete files for their own patients
- **Admins:** Can soft delete files for patients of doctors in their organization
- **Root:** Can delete any file (soft or hard delete)

**Path Parameters:**
- `file_id` (UUID): The EEG file's unique identifier

**Query Parameters:**
- `hard_delete` (optional, default: false): Permanently delete the file (root only)

**Example Requests:**
```
DELETE /eeg-files/123e4567-e89b-12d3-a456-426614174000
DELETE /eeg-files/123e4567-e89b-12d3-a456-426614174000?hard_delete=false
```

**Response (200 OK):**
```json
{
  "message": "EEG file deleted successfully",
  "file_id": "123e4567-e89b-12d3-a456-426614174000",
  "deletion_type": "soft"
}
```

---

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "detail": "Error message describing what went wrong"
}
```

**Common causes:**
- Invalid request body format
- Missing required fields
- Invalid UUID format
- Invalid file format (for EEG file uploads)

### 401 Unauthorized
```json
{
  "detail": "Not authenticated"
}
```

**Cause:** Missing or invalid authentication token.

### 403 Forbidden
```json
{
  "detail": "You do not have permission to perform this action"
}
```

**Common causes:**
- Insufficient permissions for the requested operation
- Trying to access resources outside your scope
- Attempting hard delete without root privileges

### 404 Not Found
```json
{
  "detail": "Resource not found"
}
```

**Common causes:**
- Invalid UUID (resource doesn't exist)
- Resource has been deleted

### 413 Request Entity Too Large
```json
{
  "detail": "File size exceeds maximum allowed size of 100.0 MB"
}
```

**Cause:** Uploaded file exceeds the maximum file size limit.

### 500 Internal Server Error
```json
{
  "detail": "Internal server error"
}
```

**Cause:** Unexpected server error. Contact support if this persists.

---

## Permission Matrix

| Action | Doctor | Admin | Root |
|--------|--------|-------|------|
| **Patients** |
| Create patient | Own only | Org doctors | Any |
| View patients | Own only | Org doctors | All |
| Update patient | Own only | Org doctors | Any |
| Delete patient (soft) | Own only | Org doctors | Any |
| Delete patient (hard) | ❌ | ❌ | ✅ |
| **EEG Files** |
| Upload file | Own patients | Org patients | Any |
| View files | Own patients | Org patients | All |
| Download file | Own patients | Org patients | Any |
| Update file | Own patients | Org patients | Any |
| Delete file (soft) | Own patients | Org patients | Any |
| Delete file (hard) | ❌ | ❌ | ✅ |

**Legend:**
- **Own only/patients:** Can only access resources they created or resources for their own patients
- **Org doctors/patients:** Can access resources for doctors/patients in their organization
- **Any/All:** Can access any resource in the system
- ❌: Not allowed
- ✅: Allowed

---

## Data Types

### UUID Format
All IDs use UUID v4 format:
```
550e8400-e29b-41d4-a716-446655440000
```

### Date Format
Dates use ISO 8601 format:
```
YYYY-MM-DD (e.g., "1990-05-15")
```

### DateTime Format
Timestamps use ISO 8601 format with UTC timezone:
```
YYYY-MM-DDTHH:mm:ssZ (e.g., "2024-01-15T10:30:00Z")
```

### File Size
File sizes are returned in bytes (integer).

### Duration
Recording duration is returned in seconds (float).

### Sampling Rate
Sampling rate is returned in Hz (float).

### Channel Names
Channel names are returned as a comma-separated string:
```
"Fp1,Fp2,F3,F4,C3,C4,P3,P4,O1,O2"
```

---

## Frontend Integration Examples

### JavaScript/TypeScript Examples

#### Upload EEG File
```javascript
async function uploadEEGFile(file, patientId, description = null, notes = null) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('patient_id', patientId);
  if (description) formData.append('description', description);
  if (notes) formData.append('notes', notes);

  const response = await fetch(`${API_BASE_URL}/eeg-files/upload`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`
    },
    body: formData
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }

  return await response.json();
}
```

#### Get All Patients with Pagination
```javascript
async function getPatients(skip = 0, limit = 100, doctorId = null) {
  const params = new URLSearchParams({
    skip: skip.toString(),
    limit: limit.toString()
  });
  
  if (doctorId) {
    params.append('doctor_id', doctorId);
  }

  const response = await fetch(`${API_BASE_URL}/patients?${params}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }

  return await response.json();
}
```

#### Download EEG File
```javascript
async function downloadEEGFile(fileId) {
  const response = await fetch(`${API_BASE_URL}/eeg-files/${fileId}/download`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`
    }
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `eeg_file_${fileId}.edf`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
```

#### Create Patient
```javascript
async function createPatient(patientData) {
  const response = await fetch(`${API_BASE_URL}/patients`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(patientData)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }

  return await response.json();
}
```

---

## Notes for Frontend Developers

1. **Authentication:** Always include the Bearer token in the Authorization header for all requests.

2. **File Uploads:** Use `multipart/form-data` for EEG file uploads. Do not set `Content-Type` header manually - let the browser set it with the boundary.

3. **Pagination:** Use `skip` and `limit` parameters for pagination. The response includes `total`, `skip`, and `limit` for EEG files list endpoint.

4. **Error Handling:** Always check `response.ok` and handle errors appropriately. Error responses follow the format: `{ "detail": "error message" }`.

5. **UUID Format:** All IDs are UUIDs. Validate UUID format on the frontend before making requests.

6. **File Size:** Check file size before uploading. The maximum is 100MB by default.

7. **File Format:** Only `.edf` files are accepted for EEG file uploads.

8. **Metadata Extraction:** EEG file metadata (duration, sampling rate, channels) is automatically extracted from the EDF file. You don't need to provide this information.

9. **Soft Delete:** Deleted resources (patients/files) are soft-deleted by default. They won't appear in normal queries unless `include_deleted=true` is specified.

10. **Permissions:** Respect the permission matrix. Show/hide UI elements based on user roles to prevent unnecessary API calls that will fail.

---

## Support

For questions or issues, please contact the backend development team.

**Last Updated:** 2024-01-15

